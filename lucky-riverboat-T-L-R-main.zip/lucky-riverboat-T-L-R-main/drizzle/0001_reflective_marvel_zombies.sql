CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`action` varchar(128) NOT NULL,
	`entity` varchar(64),
	`entityId` int,
	`details` text,
	`ipAddress` varchar(45),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `bonus_codes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(64) NOT NULL,
	`description` text,
	`type` enum('deposit_match','free_credits','free_spins','cashback') NOT NULL,
	`value` decimal(20,8) NOT NULL,
	`currency` enum('BTC','ETH','USDT') NOT NULL DEFAULT 'USDT',
	`maxUses` int DEFAULT 0,
	`currentUses` int NOT NULL DEFAULT 0,
	`minDeposit` decimal(20,8) DEFAULT '0',
	`maxPayout` decimal(20,8),
	`expiresAt` timestamp,
	`isActive` boolean NOT NULL DEFAULT true,
	`vipTierRequired` enum('bronze','silver','gold','platinum','diamond'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `bonus_codes_id` PRIMARY KEY(`id`),
	CONSTRAINT `bonus_codes_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `bonus_redemptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`bonusCodeId` int NOT NULL,
	`code` varchar(64) NOT NULL,
	`amountCredited` decimal(20,8) NOT NULL,
	`currency` enum('BTC','ETH','USDT') NOT NULL DEFAULT 'USDT',
	`redeemedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `bonus_redemptions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `crypto_deposit_addresses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`currency` enum('BTC','ETH','USDT') NOT NULL,
	`address` varchar(128) NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`lastChecked` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `crypto_deposit_addresses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `game_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`gameType` varchar(32) NOT NULL,
	`betAmount` decimal(20,8) NOT NULL,
	`currency` enum('BTC','ETH','USDT') NOT NULL DEFAULT 'USDT',
	`result` enum('pending','win','loss') NOT NULL DEFAULT 'pending',
	`payout` decimal(20,8) DEFAULT '0',
	`multiplier` decimal(10,4),
	`gameData` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `game_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `house_wallet` (
	`id` int AUTO_INCREMENT NOT NULL,
	`currency` enum('BTC','ETH','USDT') NOT NULL,
	`balance` decimal(20,8) NOT NULL DEFAULT '0',
	`totalEarnings` decimal(20,8) NOT NULL DEFAULT '0',
	`totalPayouts` decimal(20,8) NOT NULL DEFAULT '0',
	`hotWalletAddress` varchar(128),
	`hotWalletPrivateKey` varchar(256),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `house_wallet_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(256) NOT NULL,
	`message` text NOT NULL,
	`type` enum('info','success','warning','error','vip','bonus') NOT NULL DEFAULT 'info',
	`isRead` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `player_stats` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`gameType` varchar(32) NOT NULL,
	`totalBets` int DEFAULT 0,
	`totalWins` int DEFAULT 0,
	`totalLosses` int DEFAULT 0,
	`totalWagered` decimal(20,8) NOT NULL DEFAULT '0',
	`totalPayout` decimal(20,8) NOT NULL DEFAULT '0',
	`biggestWin` decimal(20,8) DEFAULT '0',
	`currentStreak` int DEFAULT 0,
	`longestStreak` int DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `player_stats_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `rtp_configs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`gameType` varchar(32) NOT NULL,
	`targetRtp` decimal(6,4) NOT NULL DEFAULT '0.9600',
	`minRtp` decimal(6,4) NOT NULL DEFAULT '0.9000',
	`maxRtp` decimal(6,4) NOT NULL DEFAULT '1.0000',
	`houseEdge` decimal(6,4) NOT NULL DEFAULT '0.0400',
	`isActive` boolean NOT NULL DEFAULT true,
	`adjustmentNotes` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `rtp_configs_id` PRIMARY KEY(`id`),
	CONSTRAINT `rtp_configs_gameType_unique` UNIQUE(`gameType`)
);
--> statement-breakpoint
CREATE TABLE `slots_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`provider` enum('hacksaw','pragmatic','massive_studios','lady_shady') NOT NULL,
	`gameId` varchar(128) NOT NULL,
	`gameName` varchar(256),
	`sessionToken` varchar(256) NOT NULL,
	`initialBalance` decimal(20,8) NOT NULL,
	`currentBalance` decimal(20,8) NOT NULL,
	`currency` enum('BTC','ETH','USDT') NOT NULL DEFAULT 'USDT',
	`status` enum('active','completed','expired') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`closedAt` timestamp,
	CONSTRAINT `slots_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sports_bets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`eventId` int NOT NULL,
	`prediction` enum('home','draw','away') NOT NULL,
	`betAmount` decimal(20,8) NOT NULL,
	`currency` enum('BTC','ETH','USDT') NOT NULL,
	`odds` decimal(6,2) NOT NULL,
	`potentialPayout` decimal(20,8) NOT NULL,
	`actualPayout` decimal(20,8),
	`status` enum('pending','won','lost','cancelled') NOT NULL DEFAULT 'pending',
	`settledAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sports_bets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sports_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sport` varchar(32) NOT NULL,
	`league` varchar(64),
	`homeTeam` varchar(128) NOT NULL,
	`awayTeam` varchar(128) NOT NULL,
	`homeOdds` decimal(6,2) NOT NULL DEFAULT '2.00',
	`drawOdds` decimal(6,2) DEFAULT '3.00',
	`awayOdds` decimal(6,2) NOT NULL DEFAULT '2.00',
	`status` enum('upcoming','live','completed','cancelled') NOT NULL DEFAULT 'upcoming',
	`result` enum('home','draw','away'),
	`eventDate` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sports_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stripe_payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`stripePaymentIntentId` varchar(256) NOT NULL,
	`amount` decimal(12,2) NOT NULL,
	`currency` varchar(8) NOT NULL,
	`cryptoType` varchar(8) NOT NULL,
	`cryptoAmount` decimal(20,8) NOT NULL,
	`status` enum('pending','succeeded','failed','canceled') NOT NULL DEFAULT 'pending',
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stripe_payments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`walletId` int NOT NULL,
	`type` enum('deposit','withdrawal','bet','win','refund','bonus','vip_reward') NOT NULL,
	`amount` decimal(20,8) NOT NULL,
	`currency` enum('BTC','ETH','USDT') NOT NULL,
	`status` enum('pending','completed','failed','cancelled') NOT NULL DEFAULT 'completed',
	`txHash` varchar(128),
	`gameId` int,
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `vip_tiers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` enum('bronze','silver','gold','platinum','diamond') NOT NULL,
	`minWagered` decimal(20,8) NOT NULL DEFAULT '0',
	`cashbackPercent` decimal(5,2) NOT NULL DEFAULT '0',
	`depositBonus` decimal(5,2) NOT NULL DEFAULT '0',
	`weeklyBonus` decimal(20,8) NOT NULL DEFAULT '0',
	`levelUpBonus` decimal(20,8) NOT NULL DEFAULT '0',
	`maxBetMultiplier` decimal(5,2) NOT NULL DEFAULT '1',
	`exclusiveGames` boolean NOT NULL DEFAULT false,
	`prioritySupport` boolean NOT NULL DEFAULT false,
	`description` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `vip_tiers_id` PRIMARY KEY(`id`),
	CONSTRAINT `vip_tiers_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `wallets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`currency` enum('BTC','ETH','USDT') NOT NULL,
	`balance` decimal(20,8) NOT NULL DEFAULT '0',
	`address` varchar(128),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `wallets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `withdrawal_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`currency` enum('BTC','ETH','USDT') NOT NULL,
	`amount` decimal(20,8) NOT NULL,
	`toAddress` varchar(128) NOT NULL,
	`txHash` varchar(128),
	`status` enum('pending','processing','completed','failed','cancelled') NOT NULL DEFAULT 'pending',
	`processedAt` timestamp,
	`failureReason` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `withdrawal_requests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `vipTier` enum('bronze','silver','gold','platinum','diamond') DEFAULT 'bronze' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `vipPoints` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `totalWagered` decimal(20,8) DEFAULT '0' NOT NULL;