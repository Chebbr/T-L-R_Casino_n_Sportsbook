import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, json } from "drizzle-orm/mysql-core";

// Core user table
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  vipTier: mysqlEnum("vipTier", ["bronze", "silver", "gold", "platinum", "diamond"]).default("bronze").notNull(),
  vipPoints: int("vipPoints").default(0).notNull(),
  totalWagered: decimal("totalWagered", { precision: 20, scale: 8 }).default("0").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Wallets
export const wallets = mysqlTable("wallets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  currency: mysqlEnum("currency", ["BTC", "ETH", "USDT"]).notNull(),
  balance: decimal("balance", { precision: 20, scale: 8 }).default("0").notNull(),
  address: varchar("address", { length: 128 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Transactions
export const transactions = mysqlTable("transactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  walletId: int("walletId").notNull(),
  type: mysqlEnum("type", ["deposit", "withdrawal", "bet", "win", "refund", "bonus", "vip_reward"]).notNull(),
  amount: decimal("amount", { precision: 20, scale: 8 }).notNull(),
  currency: mysqlEnum("currency", ["BTC", "ETH", "USDT"]).notNull(),
  status: mysqlEnum("status", ["pending", "completed", "failed", "cancelled"]).default("completed").notNull(),
  txHash: varchar("txHash", { length: 128 }),
  gameId: int("gameId"),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Game sessions
export const gameSessions = mysqlTable("game_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  gameType: varchar("gameType", { length: 32 }).notNull(),
  betAmount: decimal("betAmount", { precision: 20, scale: 8 }).notNull(),
  currency: mysqlEnum("currency", ["BTC", "ETH", "USDT"]).default("USDT").notNull(),
  result: mysqlEnum("result", ["pending", "win", "loss"]).default("pending").notNull(),
  payout: decimal("payout", { precision: 20, scale: 8 }).default("0"),
  multiplier: decimal("multiplier", { precision: 10, scale: 4 }),
  gameData: text("gameData"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
});

// Player stats per game
export const playerStats = mysqlTable("player_stats", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  gameType: varchar("gameType", { length: 32 }).notNull(),
  totalBets: int("totalBets").default(0),
  totalWins: int("totalWins").default(0),
  totalLosses: int("totalLosses").default(0),
  totalWagered: decimal("totalWagered", { precision: 20, scale: 8 }).default("0").notNull(),
  totalPayout: decimal("totalPayout", { precision: 20, scale: 8 }).default("0").notNull(),
  biggestWin: decimal("biggestWin", { precision: 20, scale: 8 }).default("0"),
  currentStreak: int("currentStreak").default(0),
  longestStreak: int("longestStreak").default(0),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// House wallet
export const houseWallet = mysqlTable("house_wallet", {
  id: int("id").autoincrement().primaryKey(),
  currency: mysqlEnum("currency", ["BTC", "ETH", "USDT"]).notNull(),
  balance: decimal("balance", { precision: 20, scale: 8 }).default("0").notNull(),
  totalEarnings: decimal("totalEarnings", { precision: 20, scale: 8 }).default("0").notNull(),
  totalPayouts: decimal("totalPayouts", { precision: 20, scale: 8 }).default("0").notNull(),
  hotWalletAddress: varchar("hotWalletAddress", { length: 128 }),
  hotWalletPrivateKey: varchar("hotWalletPrivateKey", { length: 256 }),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// Sports events
export const sportsEvents = mysqlTable("sports_events", {
  id: int("id").autoincrement().primaryKey(),
  sport: varchar("sport", { length: 32 }).notNull(),
  league: varchar("league", { length: 64 }),
  homeTeam: varchar("homeTeam", { length: 128 }).notNull(),
  awayTeam: varchar("awayTeam", { length: 128 }).notNull(),
  homeOdds: decimal("homeOdds", { precision: 6, scale: 2 }).default("2.00").notNull(),
  drawOdds: decimal("drawOdds", { precision: 6, scale: 2 }).default("3.00"),
  awayOdds: decimal("awayOdds", { precision: 6, scale: 2 }).default("2.00").notNull(),
  status: mysqlEnum("status", ["upcoming", "live", "completed", "cancelled"]).default("upcoming").notNull(),
  result: mysqlEnum("result", ["home", "draw", "away"]),
  eventDate: timestamp("eventDate").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Sports bets
export const sportsBets = mysqlTable("sports_bets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  eventId: int("eventId").notNull(),
  prediction: mysqlEnum("prediction", ["home", "draw", "away"]).notNull(),
  betAmount: decimal("betAmount", { precision: 20, scale: 8 }).notNull(),
  currency: mysqlEnum("currency", ["BTC", "ETH", "USDT"]).notNull(),
  odds: decimal("odds", { precision: 6, scale: 2 }).notNull(),
  potentialPayout: decimal("potentialPayout", { precision: 20, scale: 8 }).notNull(),
  actualPayout: decimal("actualPayout", { precision: 20, scale: 8 }),
  status: mysqlEnum("status", ["pending", "won", "lost", "cancelled"]).default("pending").notNull(),
  settledAt: timestamp("settledAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Stripe payments
export const stripePayments = mysqlTable("stripe_payments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 256 }).notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 8 }).notNull(),
  cryptoType: varchar("cryptoType", { length: 8 }).notNull(),
  cryptoAmount: decimal("cryptoAmount", { precision: 20, scale: 8 }).notNull(),
  status: mysqlEnum("status", ["pending", "succeeded", "failed", "canceled"]).default("pending").notNull(),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type InsertStripePayment = typeof stripePayments.$inferInsert;

// Notifications
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 256 }).notNull(),
  message: text("message").notNull(),
  type: mysqlEnum("type", ["info", "success", "warning", "error", "vip", "bonus"]).default("info").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type InsertNotification = typeof notifications.$inferInsert;

// VIP Tiers configuration
export const vipTiers = mysqlTable("vip_tiers", {
  id: int("id").autoincrement().primaryKey(),
  name: mysqlEnum("name", ["bronze", "silver", "gold", "platinum", "diamond"]).notNull().unique(),
  minWagered: decimal("minWagered", { precision: 20, scale: 8 }).default("0").notNull(),
  cashbackPercent: decimal("cashbackPercent", { precision: 5, scale: 2 }).default("0").notNull(),
  depositBonus: decimal("depositBonus", { precision: 5, scale: 2 }).default("0").notNull(),
  weeklyBonus: decimal("weeklyBonus", { precision: 20, scale: 8 }).default("0").notNull(),
  levelUpBonus: decimal("levelUpBonus", { precision: 20, scale: 8 }).default("0").notNull(),
  maxBetMultiplier: decimal("maxBetMultiplier", { precision: 5, scale: 2 }).default("1").notNull(),
  exclusiveGames: boolean("exclusiveGames").default(false).notNull(),
  prioritySupport: boolean("prioritySupport").default(false).notNull(),
  description: text("description"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// Bonus codes
export const bonusCodes = mysqlTable("bonus_codes", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 64 }).notNull().unique(),
  description: text("description"),
  type: mysqlEnum("type", ["deposit_match", "free_credits", "free_spins", "cashback"]).notNull(),
  value: decimal("value", { precision: 20, scale: 8 }).notNull(),
  currency: mysqlEnum("currency", ["BTC", "ETH", "USDT"]).default("USDT").notNull(),
  maxUses: int("maxUses").default(0),
  currentUses: int("currentUses").default(0).notNull(),
  minDeposit: decimal("minDeposit", { precision: 20, scale: 8 }).default("0"),
  maxPayout: decimal("maxPayout", { precision: 20, scale: 8 }),
  expiresAt: timestamp("expiresAt"),
  isActive: boolean("isActive").default(true).notNull(),
  vipTierRequired: mysqlEnum("vipTierRequired", ["bronze", "silver", "gold", "platinum", "diamond"]),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Bonus code redemptions
export const bonusRedemptions = mysqlTable("bonus_redemptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  bonusCodeId: int("bonusCodeId").notNull(),
  code: varchar("code", { length: 64 }).notNull(),
  amountCredited: decimal("amountCredited", { precision: 20, scale: 8 }).notNull(),
  currency: mysqlEnum("currency", ["BTC", "ETH", "USDT"]).default("USDT").notNull(),
  redeemedAt: timestamp("redeemedAt").defaultNow().notNull(),
});

// RTP configurations
export const rtpConfigs = mysqlTable("rtp_configs", {
  id: int("id").autoincrement().primaryKey(),
  gameType: varchar("gameType", { length: 32 }).notNull().unique(),
  targetRtp: decimal("targetRtp", { precision: 6, scale: 4 }).default("0.9600").notNull(),
  minRtp: decimal("minRtp", { precision: 6, scale: 4 }).default("0.9000").notNull(),
  maxRtp: decimal("maxRtp", { precision: 6, scale: 4 }).default("1.0000").notNull(),
  houseEdge: decimal("houseEdge", { precision: 6, scale: 4 }).default("0.0400").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  adjustmentNotes: text("adjustmentNotes"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// Crypto deposit addresses (for monitoring)
export const cryptoDepositAddresses = mysqlTable("crypto_deposit_addresses", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  currency: mysqlEnum("currency", ["BTC", "ETH", "USDT"]).notNull(),
  address: varchar("address", { length: 128 }).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  lastChecked: timestamp("lastChecked"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Withdrawal requests
export const withdrawalRequests = mysqlTable("withdrawal_requests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  currency: mysqlEnum("currency", ["BTC", "ETH", "USDT"]).notNull(),
  amount: decimal("amount", { precision: 20, scale: 8 }).notNull(),
  toAddress: varchar("toAddress", { length: 128 }).notNull(),
  txHash: varchar("txHash", { length: 128 }),
  status: mysqlEnum("status", ["pending", "processing", "completed", "failed", "cancelled"]).default("pending").notNull(),
  processedAt: timestamp("processedAt"),
  failureReason: text("failureReason"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Audit logs
export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  action: varchar("action", { length: 128 }).notNull(),
  entity: varchar("entity", { length: 64 }),
  entityId: int("entityId"),
  details: text("details"),
  ipAddress: varchar("ipAddress", { length: 45 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Site settings (house wallet addresses, config)
export const siteSettings = mysqlTable("site_settings", {
  id: int("id").autoincrement().primaryKey(),
  settingKey: varchar("settingKey", { length: 128 }).notNull().unique(),
  settingValue: text("settingValue").notNull(),
  description: text("description"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// Chat messages (global player chat)
export const chatMessages = mysqlTable("chat_messages", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  userName: varchar("userName", { length: 128 }),
  message: text("message").notNull(),
  type: mysqlEnum("type", ["chat", "system", "support"]).default("chat").notNull(),
  isDeleted: boolean("isDeleted").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Support tickets
export const supportTickets = mysqlTable("support_tickets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  userName: varchar("userName", { length: 128 }),
  subject: varchar("subject", { length: 256 }).notNull(),
  status: mysqlEnum("status", ["open", "in_progress", "resolved", "closed"]).default("open").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const supportMessages = mysqlTable("support_messages", {
  id: int("id").autoincrement().primaryKey(),
  ticketId: int("ticketId").notNull(),
  userId: int("userId").notNull(),
  isAdmin: boolean("isAdmin").default(false).notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Referrals
export const referrals = mysqlTable("referrals", {
  id: int("id").autoincrement().primaryKey(),
  referrerId: int("referrerId").notNull(),
  referredUserId: int("referredUserId"),
  referralCode: varchar("referralCode", { length: 32 }).notNull().unique(),
  commissionRate: decimal("commissionRate", { precision: 5, scale: 4 }).default("0.0500").notNull(),
  totalEarnings: decimal("totalEarnings", { precision: 20, scale: 8 }).default("0").notNull(),
  totalReferred: int("totalReferred").default(0).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const referralEarnings = mysqlTable("referral_earnings", {
  id: int("id").autoincrement().primaryKey(),
  referralId: int("referralId").notNull(),
  referrerId: int("referrerId").notNull(),
  referredUserId: int("referredUserId").notNull(),
  wagerAmount: decimal("wagerAmount", { precision: 20, scale: 8 }).notNull(),
  commissionAmount: decimal("commissionAmount", { precision: 20, scale: 8 }).notNull(),
  currency: mysqlEnum("currency", ["BTC", "ETH", "USDT"]).default("USDT").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Slots provider sessions
export const slotsSessions = mysqlTable("slots_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  provider: mysqlEnum("provider", ["hacksaw", "pragmatic", "massive_studios", "lady_shady"]).notNull(),
  gameId: varchar("gameId", { length: 128 }).notNull(),
  gameName: varchar("gameName", { length: 256 }),
  sessionToken: varchar("sessionToken", { length: 256 }).notNull(),
  initialBalance: decimal("initialBalance", { precision: 20, scale: 8 }).notNull(),
  currentBalance: decimal("currentBalance", { precision: 20, scale: 8 }).notNull(),
  currency: mysqlEnum("currency", ["BTC", "ETH", "USDT"]).default("USDT").notNull(),
  status: mysqlEnum("status", ["active", "completed", "expired"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  closedAt: timestamp("closedAt"),
});
