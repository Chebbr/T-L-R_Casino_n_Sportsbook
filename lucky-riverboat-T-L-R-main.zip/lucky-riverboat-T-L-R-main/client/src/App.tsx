import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Wallet from "./pages/Wallet";
import Profile from "./pages/Profile";
import KenoGame from "./pages/games/KenoGame";
import CrashGame from "./pages/games/CrashGame";
import RouletteGame from "./pages/games/RouletteGame";
import HelmGame from "./pages/games/HelmGame";
import TowerGame from "./pages/games/TowerGame";
import MinesGame from "./pages/games/MinesGame";
import HiLowGame from "./pages/games/HiLowGame";
import Sportsbook from "./pages/Sportsbook";
import VipPage from "./pages/VipPage";
import BonusPage from "./pages/BonusPage";
import SlotsLobby from "./pages/SlotsLobby";
import AdminPanel from "./pages/AdminPanel";
import ChatPage from "./pages/ChatPage";
import SupportPage from "./pages/SupportPage";
import ReferralsPage from "./pages/ReferralsPage";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/wallet" component={Wallet} />
      <Route path="/profile" component={Profile} />
      <Route path="/games/keno" component={KenoGame} />
      <Route path="/games/crash" component={CrashGame} />
      <Route path="/games/roulette" component={RouletteGame} />
      <Route path="/games/helm" component={HelmGame} />
      <Route path="/games/tower" component={TowerGame} />
      <Route path="/games/mines" component={MinesGame} />
      <Route path="/games/hilow" component={HiLowGame} />
      <Route path="/sportsbook" component={Sportsbook} />
      <Route path="/vip" component={VipPage} />
      <Route path="/bonus" component={BonusPage} />
      <Route path="/slots" component={SlotsLobby} />
      <Route path="/admin" component={AdminPanel} />
      <Route path="/chat" component={ChatPage} />
      <Route path="/support" component={SupportPage} />
      <Route path="/referrals" component={ReferralsPage} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
