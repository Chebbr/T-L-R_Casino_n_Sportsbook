import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { useAudio } from "@/hooks/useAudio";
import { toast } from "sonner";
import { Trophy, Clock, Zap, TrendingUp, X, ChevronRight } from "lucide-react";

const SPORTS = ["football", "basketball", "baseball", "soccer", "hockey", "mma", "boxing", "esports"];
const sportEmojis: Record<string, string> = {
  football: "\uD83C\uDFC8", basketball: "\uD83C\uDFC0", baseball: "\u26BE", soccer: "\u26BD",
  hockey: "\uD83C\uDFD2", mma: "\uD83E\uDD4A", boxing: "\uD83E\uDD4A", esports: "\uD83C\uDFAE",
};

export default function Sportsbook() {
  const { user, loading } = useAuth();
  const { play } = useAudio();
  const [selectedSport, setSelectedSport] = useState("football");
  const [betAmount, setBetAmount] = useState("1");
  const [currency, setCurrency] = useState<"BTC" | "ETH" | "USDT">("USDT");
  const [selectedBets, setSelectedBets] = useState<Array<{ eventId: number; selection: string; odds: number; label: string }>>([]);
  const [activeTab, setActiveTab] = useState<"upcoming" | "live" | "mybets">("upcoming");

  const utils = trpc.useUtils();
  const { data: wallets } = trpc.wallet.getAll.useQuery(undefined, { enabled: !!user });
  const { data: upcomingEvents } = trpc.sportsbook.getEvents.useQuery({ status: "upcoming" });
  const { data: liveEvents } = trpc.sportsbook.getEvents.useQuery({ status: "live" });
  const events = useMemo(() => (upcomingEvents || []).filter((e: any) => e.sport?.toLowerCase() === selectedSport), [upcomingEvents, selectedSport]);
  const liveFiltered = useMemo(() => (liveEvents || []).filter((e: any) => e.sport?.toLowerCase() === selectedSport), [liveEvents, selectedSport]);
  const { data: myBets } = trpc.sportsbook.getMyBets.useQuery({ limit: 20 }, { enabled: !!user });

  const placeBetMutation = trpc.sportsbook.placeBet.useMutation({
    onSuccess: () => {
      play("bet");
      toast.success("Bet placed successfully!");
      setSelectedBets([]);
      setBetAmount("1");
      utils.wallet.getAll.invalidate();
      utils.sportsbook.getMyBets.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const toggleBet = (eventId: number, selection: string, odds: number, label: string) => {
    play("click");
    setSelectedBets((prev) => {
      const exists = prev.find((b) => b.eventId === eventId && b.selection === selection);
      if (exists) return prev.filter((b) => !(b.eventId === eventId && b.selection === selection));
      const filtered = prev.filter((b) => b.eventId !== eventId);
      return [...filtered, { eventId, selection, odds, label }];
    });
  };

  const totalOdds = useMemo(() => selectedBets.reduce((acc, b) => acc * b.odds, 1), [selectedBets]);
  const potentialWin = parseFloat(betAmount || "0") * totalOdds;
  const currentBalance = wallets?.find((w: any) => w.currency === currency);

  const handlePlaceBet = () => {
    if (selectedBets.length === 0) { toast.error("Select at least one bet"); return; }
    if (parseFloat(betAmount) <= 0) { toast.error("Enter a valid bet amount"); return; }
    selectedBets.forEach((bet) => {
      placeBetMutation.mutate({
        eventId: bet.eventId,
        prediction: bet.selection as "home" | "draw" | "away",
        betAmount: parseFloat(betAmount) / selectedBets.length,
        currency,
        odds: bet.odds,
      });
    });
  };

  if (loading) return <CasinoLayout><div className="container py-20 text-center animate-pulse text-muted-foreground">Loading...</div></CasinoLayout>;
  if (!user) { window.location.href = getLoginUrl(); return null; }

  return (
    <CasinoLayout>
      <div className="container py-6 max-w-6xl">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-primary/10"><Trophy className="h-6 w-6 text-primary" /></div>
            <div>
              <h1 className="text-2xl font-bold">Sportsbook</h1>
              <p className="text-xs text-muted-foreground">Bet on your favorite sports with competitive odds</p>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Sports Sidebar */}
          <div className="lg:col-span-1">
            <Card className="casino-card">
              <CardContent className="p-3">
                <h3 className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider px-2 mb-2">Sports</h3>
                <div className="space-y-0.5">
                  {SPORTS.map((sport) => (
                    <button
                      key={sport}
                      onClick={() => { setSelectedSport(sport); play("click"); }}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                        selectedSport === sport
                          ? "bg-primary/10 text-primary border border-primary/20"
                          : "text-muted-foreground hover:bg-muted/30 hover:text-foreground"
                      }`}
                    >
                      <span className="text-lg">{sportEmojis[sport]}</span>
                      <span className="capitalize flex-1 text-left">{sport}</span>
                      {selectedSport === sport && <ChevronRight className="h-3 w-3" />}
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Events */}
          <div className="lg:col-span-2">
            {/* Tab buttons */}
            <div className="flex gap-1 mb-3 p-1 rounded-xl bg-muted/20 border border-border/20">
              {[
                { id: "upcoming" as const, label: "Upcoming", icon: Clock },
                { id: "live" as const, label: "Live", icon: Zap },
                { id: "mybets" as const, label: "My Bets", icon: TrendingUp },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                    activeTab === tab.id
                      ? "bg-primary/10 text-primary border border-primary/20"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <tab.icon className="h-3 w-3" /> {tab.label}
                </button>
              ))}
            </div>

            {/* Upcoming Events */}
            {activeTab === "upcoming" && (
              <div className="space-y-2">
                {events && events.length > 0 ? events.map((event: any, idx: number) => (
                  <motion.div key={event.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.03 }}>
                    <Card className="casino-card">
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20 capitalize font-medium">{event.sport}</span>
                            <span className="text-[10px] text-muted-foreground">{event.league}</span>
                          </div>
                          <span className="text-[10px] text-muted-foreground">
                            {new Date(event.eventDate).toLocaleDateString()} {new Date(event.eventDate).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                          </span>
                        </div>
                        <div className="flex items-center justify-between mb-3">
                          <span className="font-semibold text-sm">{event.homeTeam}</span>
                          <span className="text-[10px] text-muted-foreground px-2 py-0.5 rounded-full bg-muted/30">VS</span>
                          <span className="font-semibold text-sm">{event.awayTeam}</span>
                        </div>
                        <div className="grid grid-cols-3 gap-1.5">
                          {[
                            { label: event.homeTeam, sel: "home", odds: parseFloat(event.homeOdds || "2.0") },
                            { label: "Draw", sel: "draw", odds: parseFloat(event.drawOdds || "3.5") },
                            { label: event.awayTeam, sel: "away", odds: parseFloat(event.awayOdds || "2.5") },
                          ].map((opt) => {
                            const isSelected = selectedBets.some((b) => b.eventId === event.id && b.selection === opt.sel);
                            return (
                              <button
                                key={opt.sel}
                                onClick={() => toggleBet(event.id, opt.sel, opt.odds, opt.label)}
                                className={`flex flex-col items-center py-2 px-2 rounded-lg border text-xs transition-all ${
                                  isSelected
                                    ? "bg-primary/15 border-primary/40 text-primary"
                                    : "bg-muted/20 border-border/20 text-muted-foreground hover:bg-muted/40 hover:text-foreground"
                                }`}
                              >
                                <span className="truncate w-full text-center text-[10px]">{opt.label}</span>
                                <span className="font-bold text-sm font-mono mt-0.5">{opt.odds.toFixed(2)}</span>
                              </button>
                            );
                          })}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )) : (
                  <Card className="casino-card">
                    <CardContent className="p-10 text-center text-muted-foreground">
                      <Trophy className="h-10 w-10 mx-auto mb-3 opacity-20" />
                      <p className="text-sm">No events for {selectedSport}</p>
                      <p className="text-xs text-muted-foreground/60 mt-1">Check back soon for upcoming matches!</p>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}

            {/* Live Events */}
            {activeTab === "live" && (
              <div className="space-y-2">
                {liveFiltered && liveFiltered.length > 0 ? liveFiltered.map((event: any, idx: number) => (
                  <motion.div key={event.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.03 }}>
                    <Card className="casino-card border-red-500/20">
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-red-500/15 text-red-400 border border-red-500/20 font-medium flex items-center gap-1"><Zap className="h-2.5 w-2.5" /> LIVE</span>
                            <span className="text-[10px] text-muted-foreground capitalize">{event.sport}</span>
                          </div>
                        </div>
                        <div className="flex items-center justify-between mb-3">
                          <span className="font-semibold text-sm">{event.homeTeam}</span>
                          <span className="text-[10px] text-muted-foreground px-2 py-0.5 rounded-full bg-muted/30">VS</span>
                          <span className="font-semibold text-sm">{event.awayTeam}</span>
                        </div>
                        <div className="grid grid-cols-3 gap-1.5">
                          {[
                            { label: event.homeTeam, sel: "home", odds: parseFloat(event.homeOdds || "2.0") },
                            { label: "Draw", sel: "draw", odds: parseFloat(event.drawOdds || "3.5") },
                            { label: event.awayTeam, sel: "away", odds: parseFloat(event.awayOdds || "2.5") },
                          ].map((opt) => {
                            const isSelected = selectedBets.some((b) => b.eventId === event.id && b.selection === opt.sel);
                            return (
                              <button key={opt.sel} onClick={() => toggleBet(event.id, opt.sel, opt.odds, opt.label)}
                                className={`flex flex-col items-center py-2 px-2 rounded-lg border text-xs transition-all ${
                                  isSelected ? "bg-primary/15 border-primary/40 text-primary" : "bg-muted/20 border-border/20 text-muted-foreground hover:bg-muted/40 hover:text-foreground"
                                }`}>
                                <span className="truncate w-full text-center text-[10px]">{opt.label}</span>
                                <span className="font-bold text-sm font-mono mt-0.5">{opt.odds.toFixed(2)}</span>
                              </button>
                            );
                          })}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )) : (
                  <Card className="casino-card">
                    <CardContent className="p-10 text-center text-muted-foreground">
                      <Zap className="h-10 w-10 mx-auto mb-3 opacity-20" />
                      <p className="text-sm">No live events right now</p>
                      <p className="text-xs text-muted-foreground/60 mt-1">Live betting appears when events are in progress</p>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}

            {/* My Bets */}
            {activeTab === "mybets" && (
              <div className="space-y-1.5">
                {myBets && myBets.length > 0 ? myBets.map((bet: any, i: number) => (
                  <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.03 }}>
                    <Card className="casino-card">
                      <CardContent className="p-3 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${
                            bet.status === "won" ? "bg-emerald-500/15 text-emerald-400" :
                            bet.status === "lost" ? "bg-red-500/15 text-red-400" :
                            "bg-amber-500/15 text-amber-400"
                          }`}>{bet.status}</span>
                          <span className="text-xs font-medium capitalize">{bet.selection}</span>
                        </div>
                        <div className="text-right">
                          <p className="font-mono text-xs font-semibold">{parseFloat(bet.amount).toFixed(4)} {bet.currency}</p>
                          <p className="text-[10px] text-muted-foreground">@ {parseFloat(bet.odds).toFixed(2)}</p>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )) : (
                  <Card className="casino-card">
                    <CardContent className="p-10 text-center text-muted-foreground text-sm">No bets placed yet</CardContent>
                  </Card>
                )}
              </div>
            )}
          </div>

          {/* Bet Slip */}
          <div className="lg:col-span-1">
            <Card className="casino-card sticky top-4">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-semibold">Bet Slip</h3>
                  {selectedBets.length > 0 && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-primary/15 text-primary font-medium">{selectedBets.length}</span>
                  )}
                </div>

                {selectedBets.length > 0 ? (
                  <div className="space-y-3">
                    {selectedBets.map((bet, i) => (
                      <div key={i} className="p-2 rounded-lg bg-muted/20 border border-border/20 flex items-center justify-between">
                        <div>
                          <p className="text-xs font-medium truncate">{bet.label}</p>
                          <p className="text-[10px] text-muted-foreground capitalize">{bet.selection}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-primary">{bet.odds.toFixed(2)}</span>
                          <button onClick={() => toggleBet(bet.eventId, bet.selection, bet.odds, bet.label)} className="p-0.5 rounded text-muted-foreground/40 hover:text-foreground">
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      </div>
                    ))}

                    <div className="space-y-2 pt-2 border-t border-border/20">
                      <div>
                        <label className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-1 block">Currency</label>
                        <Select value={currency} onValueChange={(v: any) => setCurrency(v)}>
                          <SelectTrigger className="bg-muted/20 h-8 text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="BTC">BTC</SelectItem>
                            <SelectItem value="ETH">ETH</SelectItem>
                            <SelectItem value="USDT">USDT</SelectItem>
                          </SelectContent>
                        </Select>
                        {currentBalance && (
                          <p className="text-[10px] text-muted-foreground mt-1">Balance: {parseFloat(currentBalance.balance).toFixed(4)}</p>
                        )}
                      </div>
                      <div>
                        <label className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-1 block">Stake</label>
                        <Input
                          type="number"
                          value={betAmount}
                          onChange={(e) => setBetAmount(e.target.value)}
                          className="bet-input h-8 text-xs"
                          step="0.01"
                          min="0"
                        />
                      </div>
                      <div className="p-2.5 rounded-lg bg-muted/20 border border-border/20 space-y-1">
                        <div className="flex justify-between text-[10px]">
                          <span className="text-muted-foreground">Total Odds</span>
                          <span className="font-mono font-semibold">{totalOdds.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Potential Win</span>
                          <span className="font-mono font-bold text-emerald-400">{potentialWin.toFixed(4)} {currency}</span>
                        </div>
                      </div>
                      <button
                        onClick={handlePlaceBet}
                        disabled={placeBetMutation.isPending}
                        className="bet-btn w-full h-10 text-sm flex items-center justify-center gap-2"
                      >
                        {placeBetMutation.isPending ? (
                          <><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> Placing...</>
                        ) : (
                          <><Zap className="h-4 w-4" /> Place Bet</>
                        )}
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <Trophy className="h-8 w-8 mx-auto mb-2 opacity-20" />
                    <p className="text-xs">Select odds to add to your bet slip</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </CasinoLayout>
  );
}
