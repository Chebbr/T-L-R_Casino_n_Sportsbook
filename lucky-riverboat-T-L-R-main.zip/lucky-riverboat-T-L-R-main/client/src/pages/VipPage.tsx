import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import { Crown, Star, Gift, TrendingUp, Shield, Gem, Sparkles, Lock } from "lucide-react";

const VIP_TIERS = [
  { name: "Bronze", icon: Shield, color: "text-amber-600", bg: "from-amber-900/30 to-amber-800/10", border: "border-amber-700/30", gradient: "from-amber-700 to-amber-900", minWager: 0, cashback: 1, depositBonus: 5, weeklyBonus: 0, levelUpBonus: 0 },
  { name: "Silver", icon: Star, color: "text-gray-300", bg: "from-gray-600/30 to-gray-500/10", border: "border-gray-400/30", gradient: "from-gray-400 to-gray-600", minWager: 1000, cashback: 2, depositBonus: 10, weeklyBonus: 25, levelUpBonus: 50 },
  { name: "Gold", icon: Crown, color: "text-yellow-400", bg: "from-yellow-600/30 to-yellow-500/10", border: "border-yellow-500/30", gradient: "from-yellow-400 to-yellow-600", minWager: 5000, cashback: 3, depositBonus: 15, weeklyBonus: 100, levelUpBonus: 200 },
  { name: "Platinum", icon: Gem, color: "text-cyan-300", bg: "from-cyan-600/30 to-cyan-500/10", border: "border-cyan-400/30", gradient: "from-cyan-300 to-cyan-500", minWager: 25000, cashback: 5, depositBonus: 20, weeklyBonus: 500, levelUpBonus: 1000 },
  { name: "Diamond", icon: Gem, color: "text-violet-300", bg: "from-violet-600/30 to-violet-500/10", border: "border-violet-400/30", gradient: "from-violet-300 to-violet-500", minWager: 100000, cashback: 8, depositBonus: 30, weeklyBonus: 2000, levelUpBonus: 5000 },
];

export default function VipPage() {
  const { user, loading } = useAuth();
  const { data: vipInfo } = trpc.vip.getMyTier.useQuery(undefined, { enabled: !!user });

  if (loading) return <CasinoLayout><div className="container py-20 text-center animate-pulse text-muted-foreground">Loading...</div></CasinoLayout>;
  if (!user) { window.location.href = getLoginUrl(); return null; }

  const currentTierIdx = VIP_TIERS.findIndex((t) => t.name.toLowerCase() === (vipInfo?.tier || "bronze"));
  const currentTier = VIP_TIERS[currentTierIdx] || VIP_TIERS[0];
  const nextTier = VIP_TIERS[currentTierIdx + 1];
  const wagered = vipInfo?.currentWagered || 0;
  const progress = nextTier ? Math.min((wagered / nextTier.minWager) * 100, 100) : 100;

  return (
    <CasinoLayout>
      <div className="container py-6 max-w-5xl">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-primary/10"><Crown className="h-6 w-6 text-primary" /></div>
            <div>
              <h1 className="text-2xl font-bold">VIP Program</h1>
              <p className="text-xs text-muted-foreground">Climb the ranks and unlock exclusive rewards</p>
            </div>
          </div>
        </motion.div>

        {/* Current Status Card */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card className={`casino-card mb-5 border ${currentTier.border} overflow-hidden`}>
            <CardContent className="p-5 relative">
              {/* Background glow */}
              <div className={`absolute top-0 right-0 w-48 h-48 bg-gradient-to-bl ${currentTier.bg} rounded-full blur-3xl opacity-30 pointer-events-none`} />
              
              <div className="relative flex flex-col sm:flex-row items-start sm:items-center gap-4 mb-4">
                <div className={`p-3 rounded-2xl bg-gradient-to-br ${currentTier.bg} border ${currentTier.border}`}>
                  <currentTier.icon className={`h-8 w-8 ${currentTier.color}`} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-bold">{currentTier.name} VIP</h2>
                    <Sparkles className="h-4 w-4 text-primary animate-pulse" />
                  </div>
                  <p className="text-sm text-muted-foreground">VIP Points: <span className="font-mono font-semibold text-foreground">{vipInfo?.vipPoints || 0}</span></p>
                </div>
                <div className="text-right hidden sm:block">
                  <p className="text-xs text-muted-foreground">Total Wagered</p>
                  <p className="text-lg font-mono font-bold">${wagered.toLocaleString()}</p>
                </div>
              </div>

              {nextTier ? (
                <div className="relative space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Progress to <span className="font-semibold text-foreground">{nextTier.name}</span></span>
                    <span className="font-mono text-muted-foreground">${wagered.toFixed(0)} / ${nextTier.minWager.toLocaleString()}</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                  <p className="text-[11px] text-muted-foreground">Wager <span className="text-primary font-semibold">${(nextTier.minWager - wagered).toLocaleString()}</span> more to reach {nextTier.name}</p>
                </div>
              ) : (
                <div className="flex items-center gap-2 p-3 rounded-lg bg-primary/5 border border-primary/20">
                  <Crown className="h-4 w-4 text-primary" />
                  <p className="text-sm font-semibold text-primary">Maximum VIP tier reached!</p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Current Benefits */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Your Benefits</h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
            {[
              { label: "Cashback", value: `${currentTier.cashback}%`, icon: TrendingUp, desc: "On all losses", color: "text-emerald-400" },
              { label: "Deposit Bonus", value: `${currentTier.depositBonus}%`, icon: Gift, desc: "Every deposit", color: "text-amber-400" },
              { label: "Weekly Bonus", value: `$${currentTier.weeklyBonus}`, icon: Star, desc: "Free credits", color: "text-blue-400" },
              { label: "Level Up Bonus", value: `$${currentTier.levelUpBonus}`, icon: Crown, desc: "One-time", color: "text-purple-400" },
            ].map((b, i) => (
              <Card key={i} className="casino-card">
                <CardContent className="p-4 text-center">
                  <b.icon className={`h-5 w-5 mx-auto mb-2 ${b.color}`} />
                  <p className="text-xl font-bold font-display">{b.value}</p>
                  <p className="text-xs font-semibold mt-0.5">{b.label}</p>
                  <p className="text-[10px] text-muted-foreground">{b.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </motion.div>

        {/* All Tiers */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">All Tiers</h2>
          <div className="space-y-2.5">
            {VIP_TIERS.map((tier, i) => {
              const isCurrent = i === currentTierIdx;
              const isUnlocked = i <= currentTierIdx;
              return (
                <motion.div key={tier.name} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.25 + i * 0.05 }}>
                  <Card className={`casino-card transition-all ${isCurrent ? `border ${tier.border}` : ""} ${!isUnlocked ? "opacity-50" : ""}`}>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-xl bg-gradient-to-br ${tier.bg} border ${tier.border}`}>
                          <tier.icon className={`h-5 w-5 ${tier.color}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold text-sm">{tier.name}</h3>
                            {isCurrent && <span className="text-[10px] bg-primary/15 text-primary px-1.5 py-0.5 rounded-full font-medium">Current</span>}
                            {isUnlocked && !isCurrent && <span className="text-[10px] bg-emerald-500/15 text-emerald-400 px-1.5 py-0.5 rounded-full font-medium">Unlocked</span>}
                            {!isUnlocked && <Lock className="h-3 w-3 text-muted-foreground/40" />}
                          </div>
                          <p className="text-[11px] text-muted-foreground">${tier.minWager.toLocaleString()} total wagered</p>
                        </div>
                        <div className="hidden sm:grid grid-cols-4 gap-3 text-center shrink-0">
                          {[
                            { val: `${tier.cashback}%`, label: "Cashback" },
                            { val: `${tier.depositBonus}%`, label: "Deposit" },
                            { val: `$${tier.weeklyBonus}`, label: "Weekly" },
                            { val: `$${tier.levelUpBonus}`, label: "Level Up" },
                          ].map((stat) => (
                            <div key={stat.label} className="min-w-[60px]">
                              <p className="text-xs font-bold font-mono">{stat.val}</p>
                              <p className="text-[10px] text-muted-foreground">{stat.label}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                      {/* Mobile stats */}
                      <div className="sm:hidden grid grid-cols-4 gap-2 mt-3 pt-3 border-t border-border/20 text-center">
                        {[
                          { val: `${tier.cashback}%`, label: "Cashback" },
                          { val: `${tier.depositBonus}%`, label: "Deposit" },
                          { val: `$${tier.weeklyBonus}`, label: "Weekly" },
                          { val: `$${tier.levelUpBonus}`, label: "Level Up" },
                        ].map((stat) => (
                          <div key={stat.label}>
                            <p className="text-xs font-bold font-mono">{stat.val}</p>
                            <p className="text-[10px] text-muted-foreground">{stat.label}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.div>
      </div>
    </CasinoLayout>
  );
}
