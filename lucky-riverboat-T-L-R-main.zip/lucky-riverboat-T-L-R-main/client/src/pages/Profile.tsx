import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import { User, Crown, Trophy, TrendingUp, Calendar } from "lucide-react";

export default function Profile() {
  const { user, loading } = useAuth();
  const { data: stats } = trpc.stats.get.useQuery(undefined, { enabled: !!user });
  const { data: vipInfo } = trpc.vip.getMyTier.useQuery(undefined, { enabled: !!user });

  if (loading) return <CasinoLayout><div className="container py-20 text-center"><div className="animate-pulse text-muted-foreground">Loading...</div></div></CasinoLayout>;
  if (!user) { window.location.href = getLoginUrl(); return null; }

  return (
    <CasinoLayout>
      <div className="container py-8 max-w-3xl">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="casino-card mb-6">
            <CardContent className="p-8">
              <div className="flex items-center gap-6">
                <Avatar className="h-20 w-20">
                  <AvatarFallback className="bg-primary text-primary-foreground text-2xl">{user.name?.charAt(0)?.toUpperCase() || "U"}</AvatarFallback>
                </Avatar>
                <div>
                  <h1 className="text-2xl font-bold">{user.name || "Player"}</h1>
                  <p className="text-muted-foreground">{user.email || "No email set"}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Crown className="h-4 w-4 text-primary" />
                    <span className="text-primary font-semibold capitalize">{vipInfo?.tier || "Bronze"} VIP</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Card className="casino-card">
              <CardContent className="p-5">
                <div className="flex items-center gap-3 mb-2">
                  <Trophy className="h-5 w-5 text-amber-500" />
                  <span className="text-sm text-muted-foreground">Total Wins</span>
                </div>
                <p className="text-2xl font-bold">{stats?.totalWins || 0}</p>
              </CardContent>
            </Card>
            <Card className="casino-card">
              <CardContent className="p-5">
                <div className="flex items-center gap-3 mb-2">
                  <TrendingUp className="h-5 w-5 text-green-500" />
                  <span className="text-sm text-muted-foreground">Total Wagered</span>
                </div>
                <p className="text-2xl font-bold">${stats ? parseFloat(String(stats.totalWagered || "0")).toFixed(2) : "0.00"}</p>
              </CardContent>
            </Card>
            <Card className="casino-card">
              <CardContent className="p-5">
                <div className="flex items-center gap-3 mb-2">
                  <TrendingUp className="h-5 w-5 text-blue-500" />
                  <span className="text-sm text-muted-foreground">Total Payout</span>
                </div>
                <p className="text-2xl font-bold">${stats ? parseFloat(String(stats.totalPayout || "0")).toFixed(2) : "0.00"}</p>
              </CardContent>
            </Card>
            <Card className="casino-card">
              <CardContent className="p-5">
                <div className="flex items-center gap-3 mb-2">
                  <Trophy className="h-5 w-5 text-purple-500" />
                  <span className="text-sm text-muted-foreground">Biggest Win</span>
                </div>
                <p className="text-2xl font-bold">${stats ? parseFloat(String(stats.biggestWin || "0")).toFixed(2) : "0.00"}</p>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      </div>
    </CasinoLayout>
  );
}
