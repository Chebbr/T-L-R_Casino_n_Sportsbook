import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAudio } from "@/hooks/useAudio";
import { toast } from "sonner";
import { CircleDot, Sparkles, Trash2 } from "lucide-react";

export default function KenoGame() {
  const { user, loading } = useAuth();
  const { play } = useAudio();
  const [selected, setSelected] = useState<number[]>([]);
  const [betAmount, setBetAmount] = useState("1");
  const [currency, setCurrency] = useState<"BTC" | "ETH" | "USDT">("USDT");
  const [result, setResult] = useState<any>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const utils = trpc.useUtils();
  const { data: wallets } = trpc.wallet.getAll.useQuery(undefined, { enabled: !!user });
  const playMutation = trpc.casino.playKeno.useMutation({
    onSuccess: (data) => {
      setResult(data);
      setIsPlaying(false);
      if (data.isWin) { play("bigWin"); toast.success(`You won ${data.payout.toFixed(4)} ${currency}!`); }
      else { play("lose"); toast.error("No win this time. Try again!"); }
      utils.wallet.getAll.invalidate();
    },
    onError: (err) => { toast.error(err.message); setIsPlaying(false); },
  });

  const toggleNumber = (n: number) => {
    if (isPlaying) return;
    play("click");
    setSelected((prev) => prev.includes(n) ? prev.filter((x) => x !== n) : prev.length < 10 ? [...prev, n] : prev);
    setResult(null);
  };

  const handlePlay = () => {
    if (selected.length === 0) { toast.error("Select at least 1 number"); return; }
    if (parseFloat(betAmount) <= 0) { toast.error("Enter a valid bet amount"); return; }
    play("bet");
    setIsPlaying(true);
    playMutation.mutate({ selectedNumbers: selected, betAmount: parseFloat(betAmount), currency });
  };

  const autoSelect = (count: number) => {
    const nums: number[] = [];
    while (nums.length < count) {
      const n = Math.floor(Math.random() * 40) + 1;
      if (!nums.includes(n)) nums.push(n);
    }
    setSelected(nums);
    setResult(null);
    play("click");
  };

  const currentBalance = wallets?.find((w: any) => w.currency === currency);

  if (loading) return <CasinoLayout><div className="container py-20 text-center animate-pulse text-muted-foreground">Loading...</div></CasinoLayout>;
  if (!user) { window.location.href = getLoginUrl(); return null; }

  return (
    <CasinoLayout>
      <div className="container py-6 max-w-6xl">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-blue-500/10"><CircleDot className="h-6 w-6 text-blue-400" /></div>
            <div>
              <h1 className="text-2xl font-bold">Riverboat Keno</h1>
              <p className="text-xs text-muted-foreground">Pick up to 10 numbers. 20 will be drawn. More matches = bigger wins!</p>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Keno Board */}
          <div className="lg:col-span-3">
            <Card className="casino-card">
              <CardContent className="p-4 sm:p-6">
                {/* Selection info bar */}
                <div className="flex items-center justify-between mb-4 p-3 rounded-xl bg-muted/20 border border-border/30">
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground">Selected: <span className="text-foreground font-semibold">{selected.length}</span>/10</span>
                  </div>
                  <div className="flex gap-2">
                    {[3, 5, 7, 10].map(c => (
                      <button key={c} onClick={() => autoSelect(c)} className="quick-bet text-[10px] px-2 py-1" disabled={isPlaying}>
                        Auto {c}
                      </button>
                    ))}
                    <button onClick={() => { setSelected([]); setResult(null); }} className="quick-bet text-[10px] px-2 py-1" disabled={isPlaying}>
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                </div>

                {/* Number Grid */}
                <div className="grid grid-cols-8 sm:grid-cols-10 gap-1.5 sm:gap-2">
                  {Array.from({ length: 40 }, (_, i) => i + 1).map((n) => {
                    const isSelected = selected.includes(n);
                    const isDrawn = result?.drawnNumbers?.includes(n);
                    const isMatch = isSelected && isDrawn;
                    const isMiss = isSelected && result && !isDrawn;

                    let tileClass = "bg-muted/20 border-border/20 text-muted-foreground hover:bg-muted/40 hover:border-border/40";
                    if (isMatch) tileClass = "bg-emerald-500/20 border-emerald-500/50 text-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.2)]";
                    else if (isMiss) tileClass = "bg-red-500/15 border-red-500/40 text-red-400";
                    else if (isDrawn) tileClass = "bg-blue-500/10 border-blue-500/30 text-blue-400/70";
                    else if (isSelected) tileClass = "bg-primary/15 border-primary/50 text-primary shadow-[0_0_8px_rgba(212,160,23,0.15)]";

                    return (
                      <motion.button
                        key={n}
                        whileHover={!isPlaying ? { scale: 1.08 } : {}}
                        whileTap={!isPlaying ? { scale: 0.92 } : {}}
                        className={`aspect-square rounded-lg border-2 font-bold text-xs sm:text-sm flex items-center justify-center transition-all duration-200 ${tileClass} ${isPlaying ? "pointer-events-none" : "cursor-pointer"}`}
                        onClick={() => toggleNumber(n)}
                      >
                        <AnimatePresence mode="wait">
                          {isMatch ? (
                            <motion.span key="match" initial={{ scale: 0 }} animate={{ scale: 1 }} className="flex items-center justify-center">
                              <Sparkles className="h-3.5 w-3.5" />
                            </motion.span>
                          ) : (
                            <motion.span key="num" initial={false}>{n}</motion.span>
                          )}
                        </AnimatePresence>
                      </motion.button>
                    );
                  })}
                </div>

                {/* Result */}
                <AnimatePresence>
                  {result && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-4">
                      <Card className={`border ${result.isWin ? "border-green-500/30 bg-green-500/5" : "border-red-500/30 bg-red-500/5"}`}>
                        <CardContent className="p-4 text-center">
                          <p className={`text-base font-bold ${result.isWin ? "text-green-400" : "text-red-400"}`}>
                            {result.isWin
                              ? `${result.matches} matches! Won ${result.payout.toFixed(4)} ${currency} (${result.multiplier.toFixed(2)}x)`
                              : `${result.matches} matches - No payout`}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            Drawn: {result.drawnNumbers?.slice(0, 20).join(", ")}
                          </p>
                        </CardContent>
                      </Card>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>
          </div>

          {/* Controls */}
          <div className="space-y-3">
            <Card className="casino-card">
              <CardContent className="p-4 space-y-3">
                <div>
                  <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">Currency</label>
                  <Select value={currency} onValueChange={(v: any) => setCurrency(v)}>
                    <SelectTrigger className="bg-muted/20 h-9 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="BTC">BTC</SelectItem>
                      <SelectItem value="ETH">ETH</SelectItem>
                      <SelectItem value="USDT">USDT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Bet Amount</label>
                    <span className="text-[10px] text-muted-foreground">Bal: {currentBalance ? parseFloat(currentBalance.balance).toFixed(4) : "0.0000"}</span>
                  </div>
                  <Input type="number" value={betAmount} onChange={(e) => setBetAmount(e.target.value)} className="bet-input h-10 text-base" step="0.01" min="0" />
                  <div className="flex gap-1.5 mt-2">
                    {["0.5", "1", "5", "10"].map((v) => (
                      <button key={v} onClick={() => setBetAmount(v)} className="quick-bet flex-1">{v}</button>
                    ))}
                  </div>
                </div>

                {/* Payout Table */}
                <div className="p-3 rounded-lg bg-muted/20 border border-border/30">
                  <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-2">Payout Table</p>
                  <div className="space-y-0.5">
                    {[
                      { m: "1 match", p: "0.5x" }, { m: "2 matches", p: "1x" }, { m: "3 matches", p: "2x" },
                      { m: "4 matches", p: "5x" }, { m: "5 matches", p: "15x" }, { m: "6+", p: "50x+" },
                    ].map(({ m, p }) => (
                      <div key={m} className="flex justify-between text-xs text-muted-foreground">
                        <span>{m}</span><span className="font-mono text-primary">{p}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <button onClick={handlePlay} disabled={playMutation.isPending || selected.length === 0} className="bet-btn w-full h-12 text-base flex items-center justify-center gap-2">
                  {playMutation.isPending ? (
                    <><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> Drawing...</>
                  ) : (
                    <><CircleDot className="h-4 w-4" /> Play Keno</>
                  )}
                </button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </CasinoLayout>
  );
}
