import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAudio } from "@/hooks/useAudio";
import { toast } from "sonner";
import { Gem, Bomb, Sparkles } from "lucide-react";

export default function MinesGame() {
  const { user, loading } = useAuth();
  const { play } = useAudio();
  const [betAmount, setBetAmount] = useState("1");
  const [currency, setCurrency] = useState<"BTC" | "ETH" | "USDT">("USDT");
  const [mineCount, setMineCount] = useState(5);
  const [gameActive, setGameActive] = useState(false);
  const [revealedTiles, setRevealedTiles] = useState<Set<number>>(new Set());
  const [minePositions, setMinePositions] = useState<number[]>([]);
  const [gameOver, setGameOver] = useState(false);
  const [currentMultiplier, setCurrentMultiplier] = useState(1);

  const utils = trpc.useUtils();
  const { data: wallets } = trpc.wallet.getAll.useQuery(undefined, { enabled: !!user });

  const startMutation = trpc.casino.startMines.useMutation({
    onSuccess: () => {
      setGameActive(true);
      setRevealedTiles(new Set());
      setMinePositions([]);
      setGameOver(false);
      setCurrentMultiplier(1);
      play("bet");
    },
    onError: (err) => toast.error(err.message),
  });

  const revealMutation = trpc.casino.revealMine.useMutation({
    onSuccess: (data) => {
      if (data.isMine) {
        play("crash");
        toast.error("You hit a mine! Game over.");
        setMinePositions(data.minePositions || []);
        setGameOver(true);
        setGameActive(false);
        utils.wallet.getAll.invalidate();
      } else {
        play("reveal");
        const safeCount = revealedTiles.size;
        const simpleMult = Math.pow(25 / (25 - mineCount), safeCount) * 0.97;
        setCurrentMultiplier(Math.max(1, simpleMult));
      }
    },
    onError: (err) => toast.error(err.message),
  });

  const cashoutMutation = trpc.casino.cashoutMines.useMutation({
    onSuccess: (data) => {
      play("cashout");
      toast.success(`Cashed out! Won ${data.payout.toFixed(4)}`);
      setGameActive(false);
      setGameOver(true);
      utils.wallet.getAll.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const handleStart = () => {
    if (parseFloat(betAmount) <= 0) { toast.error("Enter a valid bet"); return; }
    startMutation.mutate({ betAmount: parseFloat(betAmount), currency, mineCount });
  };

  const handleReveal = (pos: number) => {
    if (!gameActive || gameOver || revealedTiles.has(pos)) return;
    const newRevealed = new Set(revealedTiles);
    newRevealed.add(pos);
    setRevealedTiles(newRevealed);
    revealMutation.mutate({ position: pos });
  };

  const handleCashout = () => {
    cashoutMutation.mutate({ revealedCount: revealedTiles.size, multiplier: currentMultiplier });
  };

  const currentBalance = wallets?.find((w: any) => w.currency === currency);

  if (loading) return <CasinoLayout><div className="container py-20 text-center animate-pulse text-muted-foreground">Loading...</div></CasinoLayout>;
  if (!user) { window.location.href = getLoginUrl(); return null; }

  return (
    <CasinoLayout>
      <div className="container py-6 max-w-6xl">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-purple-500/10"><Gem className="h-6 w-6 text-purple-400" /></div>
            <div>
              <h1 className="text-2xl font-bold">Hidden Treasure</h1>
              <p className="text-xs text-muted-foreground">Uncover gems while avoiding mines. Cash out anytime!</p>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Game Grid */}
          <div className="lg:col-span-3">
            <Card className="casino-card">
              <CardContent className="p-4 sm:p-6">
                {/* Multiplier Bar */}
                {gameActive && !gameOver && (
                  <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-4 flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-purple-500/10 to-primary/10 border border-purple-500/20">
                    <div className="flex items-center gap-3">
                      <Sparkles className="h-4 w-4 text-primary" />
                      <span className="text-sm text-muted-foreground">Gems: <span className="text-foreground font-semibold">{revealedTiles.size}</span></span>
                      <span className="text-sm font-mono font-bold text-primary">{currentMultiplier.toFixed(2)}x</span>
                    </div>
                    {revealedTiles.size > 0 && (
                      <button onClick={handleCashout} disabled={cashoutMutation.isPending} className="bet-btn px-5 py-2 text-sm">
                        Cash Out {(parseFloat(betAmount) * currentMultiplier).toFixed(4)}
                      </button>
                    )}
                  </motion.div>
                )}

                {/* 5x5 Grid */}
                <div className="grid grid-cols-5 gap-2 sm:gap-3 max-w-md mx-auto">
                  {Array.from({ length: 25 }, (_, i) => {
                    const isRevealed = revealedTiles.has(i);
                    const isMine = minePositions.includes(i);
                    const isClickable = gameActive && !gameOver && !isRevealed;

                    let tileClass = "bg-muted/30 border-border/30";
                    let content = null;

                    if (gameOver && isMine) {
                      tileClass = "bg-red-500/20 border-red-500/40";
                      content = <Bomb className="h-6 w-6 text-red-400 drop-shadow-[0_0_6px_rgba(239,68,68,0.5)]" />;
                    } else if (isRevealed && !isMine) {
                      tileClass = "bg-emerald-500/15 border-emerald-500/30";
                      content = <Gem className="h-6 w-6 text-emerald-400 drop-shadow-[0_0_6px_rgba(52,211,153,0.5)]" />;
                    } else if (gameOver && !isMine) {
                      tileClass = "bg-emerald-500/5 border-border/20";
                      content = <Gem className="h-5 w-5 text-emerald-400/30" />;
                    } else if (isClickable) {
                      tileClass = "bg-muted/20 border-border/30 hover:bg-primary/10 hover:border-primary/30 cursor-pointer active:scale-95";
                      content = <span className="text-muted-foreground/30 text-lg font-bold">?</span>;
                    } else if (!gameActive) {
                      tileClass = "bg-muted/15 border-border/20";
                      content = <span className="text-muted-foreground/15 text-lg">?</span>;
                    }

                    return (
                      <motion.button
                        key={i}
                        whileHover={isClickable ? { scale: 1.05 } : {}}
                        whileTap={isClickable ? { scale: 0.92 } : {}}
                        className={`aspect-square rounded-xl border-2 flex items-center justify-center transition-all duration-200 ${tileClass}`}
                        onClick={() => handleReveal(i)}
                        disabled={!isClickable || revealMutation.isPending}
                      >
                        <AnimatePresence mode="wait">
                          {content && (
                            <motion.div
                              key={`${i}-${isRevealed}-${gameOver}`}
                              initial={{ scale: 0, rotate: -180 }}
                              animate={{ scale: 1, rotate: 0 }}
                              transition={{ type: "spring", stiffness: 300, damping: 15 }}
                            >
                              {content}
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.button>
                    );
                  })}
                </div>

                {/* Game Over Result */}
                {gameOver && (
                  <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mt-4 text-center">
                    <p className={`text-sm font-semibold ${minePositions.length > 0 && revealedTiles.has(minePositions[0] ?? -1) ? "text-red-400" : "text-green-400"}`}>
                      {minePositions.length > 0 && Array.from(revealedTiles).some(t => minePositions.includes(t))
                        ? "Game Over - You hit a mine!"
                        : `Cashed out at ${currentMultiplier.toFixed(2)}x`}
                    </p>
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Controls */}
          <div className="space-y-3">
            <Card className="casino-card">
              <CardContent className="p-4 space-y-3">
                <div>
                  <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">Currency</label>
                  <Select value={currency} onValueChange={(v: any) => setCurrency(v)} disabled={gameActive}>
                    <SelectTrigger className="bg-muted/20 h-9 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="BTC">BTC</SelectItem>
                      <SelectItem value="ETH">ETH</SelectItem>
                      <SelectItem value="USDT">USDT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Bet Amount</label>
                    <span className="text-[10px] text-muted-foreground">Bal: {currentBalance ? parseFloat(currentBalance.balance).toFixed(4) : "0.0000"}</span>
                  </div>
                  <Input type="number" value={betAmount} onChange={(e) => setBetAmount(e.target.value)} className="bet-input h-10 text-base" disabled={gameActive} step="0.01" min="0" />
                  <div className="flex gap-1.5 mt-2">
                    {["0.5", "1", "5", "10"].map((v) => (
                      <button key={v} onClick={() => setBetAmount(v)} className="quick-bet flex-1" disabled={gameActive}>{v}</button>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Mines</label>
                    <span className="text-sm font-mono font-bold text-primary">{mineCount}</span>
                  </div>
                  <Slider value={[mineCount]} onValueChange={(v) => setMineCount(v[0])} min={1} max={24} step={1} disabled={gameActive} />
                  <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                    <span>1 (Easy)</span><span>24 (Extreme)</span>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-muted/20 border border-border/30 space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Safe tiles</span>
                    <span className="font-medium">{25 - mineCount}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Max multiplier</span>
                    <span className="font-medium text-primary">{(Math.pow(25 / (25 - mineCount), 25 - mineCount) * 0.97).toFixed(2)}x</span>
                  </div>
                </div>

                <button onClick={handleStart} disabled={startMutation.isPending || (gameActive && !gameOver)} className="bet-btn w-full h-12 text-base flex items-center justify-center gap-2">
                  {startMutation.isPending ? (
                    <><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> Starting...</>
                  ) : gameActive && !gameOver ? (
                    "Game Active"
                  ) : (
                    <><Gem className="h-4 w-4" /> Start Game</>
                  )}
                </button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </CasinoLayout>
  );
}
