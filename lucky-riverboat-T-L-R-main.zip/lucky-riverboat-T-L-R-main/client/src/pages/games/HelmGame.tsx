import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAudio } from "@/hooks/useAudio";
import { toast } from "sonner";
import { Anchor, RotateCw } from "lucide-react";

const SEGMENTS = [
  { label: "0x", color: "#374151", multiplier: 0 },
  { label: "0.5x", color: "#1e40af", multiplier: 0.5 },
  { label: "1x", color: "#047857", multiplier: 1 },
  { label: "1.5x", color: "#7c3aed", multiplier: 1.5 },
  { label: "2x", color: "#b45309", multiplier: 2 },
  { label: "3x", color: "#dc2626", multiplier: 3 },
  { label: "5x", color: "#be185d", multiplier: 5 },
  { label: "10x", color: "#d97706", multiplier: 10 },
];

export default function HelmGame() {
  const { user, loading } = useAuth();
  const { play } = useAudio();
  const [betAmount, setBetAmount] = useState("1");
  const [currency, setCurrency] = useState<"BTC" | "ETH" | "USDT">("USDT");
  const [result, setResult] = useState<any>(null);
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);

  const utils = trpc.useUtils();
  const { data: wallets } = trpc.wallet.getAll.useQuery(undefined, { enabled: !!user });

  const playMutation = trpc.casino.playHelm.useMutation({
    onSuccess: (data) => {
      const segAngle = 360 / SEGMENTS.length;
      const targetAngle = 360 - (data.segmentIndex * segAngle + segAngle / 2);
      const newRotation = rotation + 1440 + targetAngle;
      setRotation(newRotation);
      setSpinning(true);
      play("spin");

      setTimeout(() => {
        setSpinning(false);
        setResult(data);
        if (data.isWin) {
          play("bigWin");
          toast.success(`${data.segment}! Won ${data.payout.toFixed(4)} ${currency}`);
        } else {
          play("lose");
          toast.error("0x - No payout this spin");
        }
        utils.wallet.getAll.invalidate();
      }, 4000);
    },
    onError: (err) => { toast.error(err.message); setSpinning(false); },
  });

  const handlePlay = () => {
    if (parseFloat(betAmount) <= 0) { toast.error("Enter a valid bet"); return; }
    play("bet");
    setResult(null);
    playMutation.mutate({ betAmount: parseFloat(betAmount), currency });
  };

  const currentBalance = wallets?.find((w: any) => w.currency === currency);

  if (loading) return <CasinoLayout><div className="container py-20 text-center animate-pulse text-muted-foreground">Loading...</div></CasinoLayout>;
  if (!user) { window.location.href = getLoginUrl(); return null; }

  return (
    <CasinoLayout>
      <div className="container py-6 max-w-6xl">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/10"><Anchor className="h-6 w-6 text-amber-400" /></div>
            <div>
              <h1 className="text-2xl font-bold">Helm Spin</h1>
              <p className="text-xs text-muted-foreground">Spin the captain's wheel and claim your treasure!</p>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Wheel Area */}
          <div className="lg:col-span-3">
            <Card className="casino-card">
              <CardContent className="p-6 flex flex-col items-center">
                <div className="relative w-64 h-64 sm:w-80 sm:h-80 md:w-96 md:h-96 mb-6">
                  {/* Pointer */}
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-3 z-10">
                    <div className="w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-t-[20px] border-t-primary drop-shadow-[0_0_8px_rgba(212,160,23,0.5)]" />
                  </div>

                  {/* Outer ring glow */}
                  <div className="absolute -inset-2 rounded-full bg-primary/5 blur-xl pointer-events-none" />

                  <motion.div
                    className="w-full h-full rounded-full border-[6px] border-primary/30 relative overflow-hidden shadow-[0_0_40px_rgba(212,160,23,0.1)]"
                    style={{
                      background: `conic-gradient(${SEGMENTS.map((s, i) => {
                        const start = (i / SEGMENTS.length) * 100;
                        const end = ((i + 1) / SEGMENTS.length) * 100;
                        return `${s.color} ${start}% ${end}%`;
                      }).join(", ")})`,
                    }}
                    animate={{ rotate: rotation }}
                    transition={{ duration: 4, ease: [0.17, 0.67, 0.12, 0.99] }}
                  >
                    {/* Segment dividers */}
                    {SEGMENTS.map((_, i) => {
                      const angle = (i / SEGMENTS.length) * 360;
                      return (
                        <div key={`div-${i}`} className="absolute inset-0" style={{ transform: `rotate(${angle}deg)` }}>
                          <div className="absolute top-0 left-1/2 w-px h-1/2 bg-white/20 origin-bottom" />
                        </div>
                      );
                    })}

                    {/* Segment Labels */}
                    {SEGMENTS.map((s, i) => {
                      const angle = (i / SEGMENTS.length) * 360 + 360 / SEGMENTS.length / 2;
                      return (
                        <div key={i} className="absolute inset-0 flex items-start justify-center" style={{ transform: `rotate(${angle}deg)` }}>
                          <span className="mt-5 sm:mt-7 text-white font-bold text-[10px] sm:text-xs md:text-sm drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
                            {s.label}
                          </span>
                        </div>
                      );
                    })}

                    {/* Center hub */}
                    <div className="absolute inset-[30%] rounded-full bg-background border-4 border-primary/30 flex items-center justify-center shadow-inner">
                      <Anchor className="h-8 w-8 sm:h-10 sm:w-10 text-primary/80" />
                    </div>
                  </motion.div>

                  {/* Decorative pegs */}
                  {SEGMENTS.map((_, i) => {
                    const angle = (i / SEGMENTS.length) * 360;
                    const rad = (angle * Math.PI) / 180;
                    const r = 50;
                    const x = 50 + r * Math.sin(rad);
                    const y = 50 - r * Math.cos(rad);
                    return (
                      <div key={`peg-${i}`} className="absolute w-2 h-2 rounded-full bg-primary/60 shadow-[0_0_4px_rgba(212,160,23,0.4)]" style={{ left: `${x}%`, top: `${y}%`, transform: "translate(-50%, -50%)" }} />
                    );
                  })}
                </div>

                {/* Result */}
                <AnimatePresence>
                  {result && !spinning && (
                    <motion.div initial={{ opacity: 0, scale: 0.9, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0 }}>
                      <Card className={`border ${result.isWin ? "border-green-500/30 bg-green-500/5" : "border-red-500/30 bg-red-500/5"}`}>
                        <CardContent className="p-4 text-center">
                          <p className={`text-lg font-bold font-display ${result.isWin ? "text-green-400" : "text-red-400"}`}>
                            {result.isWin ? `${result.segment} - Won ${result.payout.toFixed(4)} ${currency}` : "0x - No payout"}
                          </p>
                        </CardContent>
                      </Card>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>
          </div>

          {/* Controls */}
          <div className="space-y-3">
            <Card className="casino-card">
              <CardContent className="p-4 space-y-3">
                <div>
                  <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">Currency</label>
                  <Select value={currency} onValueChange={(v: any) => setCurrency(v)}>
                    <SelectTrigger className="bg-muted/20 h-9 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="BTC">BTC</SelectItem>
                      <SelectItem value="ETH">ETH</SelectItem>
                      <SelectItem value="USDT">USDT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Bet Amount</label>
                    <span className="text-[10px] text-muted-foreground">Bal: {currentBalance ? parseFloat(currentBalance.balance).toFixed(4) : "0.0000"}</span>
                  </div>
                  <Input type="number" value={betAmount} onChange={(e) => setBetAmount(e.target.value)} className="bet-input h-10 text-base" step="0.01" min="0" />
                  <div className="flex gap-1.5 mt-2">
                    {["0.5", "1", "5", "10"].map((v) => (
                      <button key={v} onClick={() => setBetAmount(v)} className="quick-bet flex-1">{v}</button>
                    ))}
                  </div>
                </div>

                {/* Segments info */}
                <div className="p-3 rounded-lg bg-muted/20 border border-border/30 space-y-1.5">
                  <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1">Segments</p>
                  {SEGMENTS.map((s) => (
                    <div key={s.label} className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: s.color }} />
                      <span className="text-xs text-muted-foreground">{s.label}</span>
                      <span className="text-[10px] text-muted-foreground/60 ml-auto">
                        {s.multiplier > 0 ? `+${(parseFloat(betAmount) * s.multiplier).toFixed(2)}` : "Loss"}
                      </span>
                    </div>
                  ))}
                </div>

                <button onClick={handlePlay} disabled={playMutation.isPending || spinning} className="bet-btn w-full h-12 text-base flex items-center justify-center gap-2">
                  {playMutation.isPending || spinning ? (
                    <><RotateCw className="h-4 w-4 animate-spin" /> Spinning...</>
                  ) : (
                    <><Anchor className="h-4 w-4" /> Spin the Helm</>
                  )}
                </button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </CasinoLayout>
  );
}
