import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { motion } from "framer-motion";
import { useAudio } from "@/hooks/useAudio";
import { toast } from "sonner";
import { Ship, Skull, Check, ArrowUp } from "lucide-react";

export default function TowerGame() {
  const { user, loading } = useAuth();
  const { play } = useAudio();
  const [betAmount, setBetAmount] = useState("1");
  const [currency, setCurrency] = useState<"BTC" | "ETH" | "USDT">("USDT");
  const [difficulty, setDifficulty] = useState<"easy" | "medium" | "hard">("easy");
  const [gameActive, setGameActive] = useState(false);
  const [columns, setColumns] = useState(4);
  const [currentRow, setCurrentRow] = useState(0);
  const [multiplier, setMultiplier] = useState(1);
  const [revealed, setRevealed] = useState<Record<string, "safe" | "danger">>({});
  const [safeColumns, setSafeColumns] = useState<number[][] | null>(null);
  const [gameOver, setGameOver] = useState(false);

  const utils = trpc.useUtils();
  const { data: wallets } = trpc.wallet.getAll.useQuery(undefined, { enabled: !!user });

  const startMutation = trpc.casino.startTower.useMutation({
    onSuccess: (data) => {
      setGameActive(true);
      setColumns(data.columns);
      setCurrentRow(0);
      setMultiplier(1);
      setRevealed({});
      setSafeColumns(null);
      setGameOver(false);
      play("bet");
    },
    onError: (err) => toast.error(err.message),
  });

  const climbMutation = trpc.casino.climbTower.useMutation({
    onSuccess: (data) => {
      if (data.safe) {
        play("reveal");
        setCurrentRow(data.currentRow);
        setMultiplier(data.multiplier);
        setRevealed((prev) => ({ ...prev, [`${currentRow}`]: "safe" }));
        if (data.gameOver) {
          play("bigWin");
          toast.success(`Reached the top! ${data.multiplier.toFixed(2)}x`);
          setGameOver(true);
        }
      } else {
        play("crash");
        toast.error("You hit a trap! Game over.");
        setSafeColumns(data.safeColumns || null);
        setGameOver(true);
        setGameActive(false);
        utils.wallet.getAll.invalidate();
      }
    },
    onError: (err) => toast.error(err.message),
  });

  const cashoutMutation = trpc.casino.cashoutTower.useMutation({
    onSuccess: (data) => {
      play("cashout");
      toast.success(`Cashed out! Won ${data.payout.toFixed(4)} (${data.multiplier.toFixed(2)}x)`);
      setGameActive(false);
      setGameOver(true);
      utils.wallet.getAll.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const handleStart = () => {
    if (parseFloat(betAmount) <= 0) { toast.error("Enter a valid bet"); return; }
    startMutation.mutate({ betAmount: parseFloat(betAmount), currency, difficulty });
  };

  const handleClimb = (col: number) => {
    if (!gameActive || gameOver) return;
    setRevealed((prev) => ({ ...prev, [`${currentRow}-${col}`]: "safe" }));
    climbMutation.mutate({ column: col });
  };

  const currentBalance = wallets?.find((w: any) => w.currency === currency);
  const rows = 8;

  const multiplierTable: Record<string, number[]> = {
    easy: [1.2, 1.4, 1.7, 2.1, 2.6, 3.2, 4.0, 5.0],
    medium: [1.4, 1.9, 2.6, 3.5, 4.8, 6.5, 8.8, 12.0],
    hard: [1.8, 3.2, 5.8, 10.4, 18.7, 33.6, 60.5, 108.9],
  };

  if (loading) return <CasinoLayout><div className="container py-20 text-center animate-pulse text-muted-foreground">Loading...</div></CasinoLayout>;
  if (!user) { window.location.href = getLoginUrl(); return null; }

  return (
    <CasinoLayout>
      <div className="container py-6 max-w-6xl">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-500/10"><Ship className="h-6 w-6 text-emerald-400" /></div>
            <div>
              <h1 className="text-2xl font-bold">Walk the Plank</h1>
              <p className="text-xs text-muted-foreground">Climb the tower! Each safe step increases your multiplier.</p>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Tower Grid */}
          <div className="lg:col-span-3">
            <Card className="casino-card">
              <CardContent className="p-4 sm:p-6">
                {/* Cashout Bar */}
                {gameActive && !gameOver && currentRow > 0 && (
                  <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-4 flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-emerald-500/10 to-primary/10 border border-emerald-500/20">
                    <div className="flex items-center gap-3">
                      <ArrowUp className="h-4 w-4 text-emerald-400" />
                      <span className="text-sm text-muted-foreground">Level <span className="text-foreground font-semibold">{currentRow}</span></span>
                      <span className="text-sm font-mono font-bold text-primary">{multiplier.toFixed(2)}x</span>
                    </div>
                    <button onClick={() => cashoutMutation.mutate()} disabled={cashoutMutation.isPending} className="bet-btn px-5 py-2 text-sm">
                      Cash Out {(parseFloat(betAmount) * multiplier).toFixed(4)}
                    </button>
                  </motion.div>
                )}

                {/* Tower */}
                <div className="flex flex-col-reverse gap-1.5 max-w-lg mx-auto">
                  {Array.from({ length: rows }, (_, rowIdx) => {
                    const isCurrentRow = rowIdx === currentRow && gameActive && !gameOver;
                    const isPastRow = rowIdx < currentRow;
                    const rowMult = multiplierTable[difficulty]?.[rowIdx] || 1;
                    const isFutureRow = rowIdx > currentRow;

                    return (
                      <motion.div
                        key={rowIdx}
                        initial={false}
                        animate={{
                          opacity: isCurrentRow ? 1 : isPastRow ? 0.7 : isFutureRow && gameActive ? 0.4 : 0.8,
                        }}
                        className="flex items-center gap-2"
                      >
                        <span className={`text-[11px] w-12 text-right font-mono ${isCurrentRow ? "text-primary font-bold" : "text-muted-foreground/60"}`}>
                          {rowMult.toFixed(1)}x
                        </span>
                        <div className="flex gap-1.5 flex-1">
                          {Array.from({ length: columns }, (_, colIdx) => {
                            let tileClass = "bg-muted/20 border-border/20";
                            let content: React.ReactNode = null;

                            if (isPastRow && revealed[`${rowIdx}`] === "safe") {
                              tileClass = "bg-emerald-500/15 border-emerald-500/30";
                              content = <Check className="h-4 w-4 text-emerald-400" />;
                            } else if (gameOver && safeColumns && safeColumns[rowIdx]) {
                              if (safeColumns[rowIdx].includes(colIdx)) {
                                tileClass = "bg-emerald-500/10 border-emerald-500/20";
                                content = <Check className="h-4 w-4 text-emerald-400/60" />;
                              } else {
                                tileClass = "bg-red-500/15 border-red-500/30";
                                content = <Skull className="h-4 w-4 text-red-400/80" />;
                              }
                            } else if (isCurrentRow) {
                              tileClass = "bg-primary/10 border-primary/30 hover:bg-primary/20 hover:border-primary/50 cursor-pointer active:scale-95";
                              content = <span className="text-primary/50 text-sm font-bold">?</span>;
                            } else if (!gameActive && !gameOver) {
                              tileClass = "bg-muted/10 border-border/15";
                            }

                            return (
                              <motion.button
                                key={colIdx}
                                whileHover={isCurrentRow ? { scale: 1.03, y: -2 } : {}}
                                whileTap={isCurrentRow ? { scale: 0.95 } : {}}
                                className={`flex-1 h-11 rounded-lg border-2 flex items-center justify-center transition-all duration-200 ${tileClass}`}
                                onClick={() => handleClimb(colIdx)}
                                disabled={!isCurrentRow || climbMutation.isPending}
                              >
                                {content}
                              </motion.button>
                            );
                          })}
                        </div>
                        {/* Row indicator */}
                        <div className={`w-1.5 h-1.5 rounded-full ${isCurrentRow ? "bg-primary animate-pulse" : isPastRow ? "bg-emerald-400/50" : "bg-muted/20"}`} />
                      </motion.div>
                    );
                  })}
                </div>

                {/* Game Over */}
                {gameOver && (
                  <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mt-4 text-center">
                    <p className={`text-sm font-semibold ${safeColumns ? "text-red-400" : "text-green-400"}`}>
                      {safeColumns ? "Game Over - You hit a trap!" : `Cashed out at ${multiplier.toFixed(2)}x`}
                    </p>
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Controls */}
          <div className="space-y-3">
            <Card className="casino-card">
              <CardContent className="p-4 space-y-3">
                <div>
                  <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">Difficulty</label>
                  <Select value={difficulty} onValueChange={(v: any) => setDifficulty(v)} disabled={gameActive}>
                    <SelectTrigger className="bg-muted/20 h-9 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="easy">Easy (4 cols)</SelectItem>
                      <SelectItem value="medium">Medium (3 cols)</SelectItem>
                      <SelectItem value="hard">Hard (2 cols)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">Currency</label>
                  <Select value={currency} onValueChange={(v: any) => setCurrency(v)} disabled={gameActive}>
                    <SelectTrigger className="bg-muted/20 h-9 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="BTC">BTC</SelectItem>
                      <SelectItem value="ETH">ETH</SelectItem>
                      <SelectItem value="USDT">USDT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Bet Amount</label>
                    <span className="text-[10px] text-muted-foreground">Bal: {currentBalance ? parseFloat(currentBalance.balance).toFixed(4) : "0.0000"}</span>
                  </div>
                  <Input type="number" value={betAmount} onChange={(e) => setBetAmount(e.target.value)} className="bet-input h-10 text-base" disabled={gameActive} step="0.01" min="0" />
                  <div className="flex gap-1.5 mt-2">
                    {["0.5", "1", "5", "10"].map((v) => (
                      <button key={v} onClick={() => setBetAmount(v)} className="quick-bet flex-1" disabled={gameActive}>{v}</button>
                    ))}
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-muted/20 border border-border/30 space-y-1">
                  <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1">Multiplier Table</p>
                  {(multiplierTable[difficulty] || []).map((m, i) => (
                    <div key={i} className={`flex justify-between text-xs ${i === currentRow && gameActive ? "text-primary font-semibold" : "text-muted-foreground"}`}>
                      <span>Level {i + 1}</span>
                      <span className="font-mono">{m.toFixed(1)}x</span>
                    </div>
                  ))}
                </div>

                <button onClick={handleStart} disabled={startMutation.isPending || (gameActive && !gameOver)} className="bet-btn w-full h-12 text-base flex items-center justify-center gap-2">
                  {startMutation.isPending ? (
                    <><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> Starting...</>
                  ) : gameActive && !gameOver ? (
                    "Game Active"
                  ) : (
                    <><Ship className="h-4 w-4" /> Start Climbing</>
                  )}
                </button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </CasinoLayout>
  );
}
