import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAudio } from "@/hooks/useAudio";
import { toast } from "sonner";
import { CircleDot, RotateCw } from "lucide-react";

const ROULETTE_NUMBERS = [0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,28,12,35,3,26];
const RED_NUMBERS = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];

function getNumberColor(n: number): string {
  if (n === 0) return "green";
  return RED_NUMBERS.includes(n) ? "red" : "black";
}

type BetType = "number" | "red" | "black" | "odd" | "even" | "1-18" | "19-36" | "1st12" | "2nd12" | "3rd12" | "green";

export default function RouletteGame() {
  const { user, loading } = useAuth();
  const { play } = useAudio();
  const [betAmount, setBetAmount] = useState("1");
  const [currency, setCurrency] = useState<"BTC" | "ETH" | "USDT">("USDT");
  const [betType, setBetType] = useState<BetType>("red");
  const [betNumber, setBetNumber] = useState(0);
  const [result, setResult] = useState<any>(null);
  const [spinning, setSpinning] = useState(false);
  const [spinDeg, setSpinDeg] = useState(0);

  const utils = trpc.useUtils();
  const { data: wallets } = trpc.wallet.getAll.useQuery(undefined, { enabled: !!user });

  const playMutation = trpc.casino.playRoulette.useMutation({
    onSuccess: (data) => {
      play("spin");
      setSpinning(true);
      const num = data.result;
      const idx = ROULETTE_NUMBERS.indexOf(num);
      const sliceDeg = 360 / 37;
      const targetDeg = spinDeg + 360 * 5 + (360 - idx * sliceDeg);
      setSpinDeg(targetDeg);

      setTimeout(() => {
        setSpinning(false);
        setResult({ ...data, displayNumber: num });
        const won = data.isWin;
        if (won) {
          play("bigWin");
          toast.success(`Won ${data.payout.toFixed(4)} ${currency}! Number: ${num}`);
        } else {
          play("lose");
          toast.error(`Number: ${num}. Better luck next time!`);
        }
        utils.wallet.getAll.invalidate();
      }, 4000);
    },
    onError: (err) => { toast.error(err.message); setSpinning(false); },
  });

  const handlePlay = () => {
    if (parseFloat(betAmount) <= 0) { toast.error("Enter a valid bet"); return; }
    play("bet");
    setResult(null);
    playMutation.mutate({ betAmount: parseFloat(betAmount), currency, betType: betType as any, ...(betType === "number" ? { betNumber } : {}) });
  };

  const currentBalance = wallets?.find((w: any) => w.currency === currency);

  if (loading) return <CasinoLayout><div className="container py-20 text-center animate-pulse text-muted-foreground">Loading...</div></CasinoLayout>;
  if (!user) { window.location.href = getLoginUrl(); return null; }

  return (
    <CasinoLayout>
      <div className="container py-6 max-w-6xl">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-red-500/10"><CircleDot className="h-6 w-6 text-red-400" /></div>
            <div>
              <h1 className="text-2xl font-bold">Roulette</h1>
              <p className="text-xs text-muted-foreground">Spin the wheel and test your luck</p>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          <div className="lg:col-span-3 space-y-4">
            <Card className="casino-card">
              <CardContent className="p-6">
                {/* Wheel */}
                <div className="flex justify-center mb-6">
                  <div className="relative w-56 h-56 sm:w-64 sm:h-64">
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-2 z-10 w-0 h-0 border-l-[8px] border-r-[8px] border-t-[14px] border-l-transparent border-r-transparent border-t-primary" />
                    <motion.div
                      className="w-full h-full rounded-full border-4 border-primary/30 relative overflow-hidden"
                      style={{
                        background: `conic-gradient(${ROULETTE_NUMBERS.map((n, i) => {
                          const c = n === 0 ? "#16a34a" : RED_NUMBERS.includes(n) ? "#dc2626" : "#1e293b";
                          return `${c} ${(i/37)*100}% ${((i+1)/37)*100}%`;
                        }).join(", ")})`,
                      }}
                      animate={{ rotate: spinDeg }}
                      transition={{ duration: 4, ease: [0.2, 0.8, 0.3, 1] }}
                    >
                      {ROULETTE_NUMBERS.map((num, i) => {
                        const angle = (i * 360) / 37 + (360 / 37 / 2);
                        return (
                          <div key={i} className="absolute text-[7px] font-bold text-white" style={{ left: "50%", top: "50%", transform: `rotate(${angle}deg) translateY(-95px)`, transformOrigin: "0 0" }}>
                            <span style={{ display: "inline-block", transform: `rotate(-${angle}deg)` }}>{num}</span>
                          </div>
                        );
                      })}
                      <div className="absolute inset-[28%] rounded-full bg-background border-2 border-border/50 flex items-center justify-center">
                        <span className="font-display text-2xl font-bold text-primary">
                          {result ? result.displayNumber : spinning ? "..." : "?"}
                        </span>
                      </div>
                    </motion.div>
                  </div>
                </div>

                {/* Number Board */}
                <div className="max-w-lg mx-auto space-y-2">
                  <div className="grid grid-cols-13 gap-px">
                    <button onClick={() => { setBetType("number"); setBetNumber(0); }} className={`col-span-1 row-span-3 rounded-l text-[10px] font-bold py-6 transition-all ${betType === "number" && betNumber === 0 ? "ring-2 ring-primary bg-green-600 text-white" : "bg-green-700/60 text-white/80 hover:bg-green-600/80"}`}>0</button>
                    {[...Array(36)].map((_, i) => {
                      const num = i + 1;
                      const color = getNumberColor(num);
                      const col = Math.floor((num - 1) / 3) + 1;
                      const row = ((num - 1) % 3);
                      const isSelected = betType === "number" && betNumber === num;
                      return (
                        <button key={num} onClick={() => { setBetType("number"); setBetNumber(num); }} className={`text-[10px] font-bold py-1.5 transition-all ${isSelected ? "ring-2 ring-primary scale-110 z-10" : "hover:scale-105"} ${color === "red" ? "bg-red-600/80 text-white" : "bg-gray-700/80 text-white"}`} style={{ gridColumn: col + 1, gridRow: 3 - row }}>{num}</button>
                      );
                    })}
                  </div>

                  <div className="grid grid-cols-6 gap-1.5">
                    {([
                      { label: "1-18", value: "1-18" as BetType },
                      { label: "Even", value: "even" as BetType },
                      { label: "Red", value: "red" as BetType },
                      { label: "Black", value: "black" as BetType },
                      { label: "Odd", value: "odd" as BetType },
                      { label: "19-36", value: "19-36" as BetType },
                    ]).map((bet) => (
                      <button key={bet.value} onClick={() => setBetType(bet.value)} className={`py-2 rounded text-xs font-semibold transition-all ${betType === bet.value ? "bg-primary text-primary-foreground ring-1 ring-primary" : bet.value === "red" ? "bg-red-600/40 text-red-300 hover:bg-red-600/60" : bet.value === "black" ? "bg-gray-600/40 text-gray-300 hover:bg-gray-600/60" : "bg-muted/40 text-muted-foreground hover:bg-muted/60"}`}>{bet.label}</button>
                    ))}
                  </div>
                  <div className="grid grid-cols-3 gap-1.5">
                    {([
                      { label: "1st 12", value: "1st12" as BetType },
                      { label: "2nd 12", value: "2nd12" as BetType },
                      { label: "3rd 12", value: "3rd12" as BetType },
                    ]).map((bet) => (
                      <button key={bet.value} onClick={() => setBetType(bet.value)} className={`py-2 rounded text-xs font-semibold transition-all ${betType === bet.value ? "bg-primary text-primary-foreground" : "bg-muted/30 text-muted-foreground hover:bg-muted/50"}`}>{bet.label}</button>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <AnimatePresence>
              {result && !spinning && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                  <Card className={`border ${result.isWin ? "border-green-500/30 bg-green-500/5" : "border-red-500/30 bg-red-500/5"}`}>
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white ${getNumberColor(result.displayNumber) === "red" ? "bg-red-600" : getNumberColor(result.displayNumber) === "green" ? "bg-green-600" : "bg-gray-700"}`}>{result.displayNumber}</div>
                      <div>
                        <p className={`font-semibold ${(result.won ?? result.isWin) ? "text-green-400" : "text-red-400"}`}>
                          {result.isWin ? `Won ${result.payout.toFixed(4)} ${currency}` : "No win"}
                        </p>
                        <p className="text-xs text-muted-foreground">{getNumberColor(result.displayNumber)} {result.displayNumber}</p>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Controls */}
          <div className="space-y-3">
            <Card className="casino-card">
              <CardContent className="p-4 space-y-3">
                <div>
                  <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">Currency</label>
                  <Select value={currency} onValueChange={(v: any) => setCurrency(v)}>
                    <SelectTrigger className="bg-muted/20 h-9 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="BTC">BTC</SelectItem>
                      <SelectItem value="ETH">ETH</SelectItem>
                      <SelectItem value="USDT">USDT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Bet Amount</label>
                    <span className="text-[10px] text-muted-foreground">Bal: {currentBalance ? parseFloat(currentBalance.balance).toFixed(4) : "0.0000"}</span>
                  </div>
                  <Input type="number" value={betAmount} onChange={(e) => setBetAmount(e.target.value)} className="bet-input h-10 text-base" step="0.01" min="0" />
                  <div className="flex gap-1.5 mt-2">
                    {["0.5", "1", "5", "10"].map((v) => (
                      <button key={v} onClick={() => setBetAmount(v)} className="quick-bet flex-1">{v}</button>
                    ))}
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-muted/20 border border-border/30">
                  <p className="text-[11px] text-muted-foreground mb-1">Current Bet</p>
                  <p className="text-sm font-semibold text-primary">{betType === "number" ? `Number ${betNumber}` : betType.charAt(0).toUpperCase() + betType.slice(1)}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">Payout: {betType === "number" || betType === "green" ? "35x" : ["red","black","odd","even","1-18","19-36"].includes(betType) ? "2x" : "3x"}</p>
                </div>
                <button onClick={handlePlay} disabled={playMutation.isPending || spinning} className="bet-btn w-full h-12 text-base flex items-center justify-center gap-2">
                  {playMutation.isPending || spinning ? (<><RotateCw className="h-4 w-4 animate-spin" /> Spinning...</>) : (<><CircleDot className="h-4 w-4" /> Spin</>)}
                </button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </CasinoLayout>
  );
}
