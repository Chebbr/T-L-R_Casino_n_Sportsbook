import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAudio } from "@/hooks/useAudio";
import { toast } from "sonner";
import { ArrowUp, ArrowDown, Equal, Layers } from "lucide-react";

function getCardDisplay(card: string) {
  if (!card) return { value: "?", suit: "", color: "text-foreground", fullValue: "?" };
  const [value, suit] = card.split("_");
  const suitSymbol = suit === "hearts" ? "\u2665" : suit === "diamonds" ? "\u2666" : suit === "clubs" ? "\u2663" : "\u2660";
  const color = suit === "hearts" || suit === "diamonds" ? "text-red-500" : "text-foreground";
  const displayVal = value === "10" ? "10" : (value?.charAt(0) || "?");
  return { value: displayVal, suit: suitSymbol, color, fullValue: value || "?" };
}

export default function HiLowGame() {
  const { user, loading } = useAuth();
  const { play } = useAudio();
  const [betAmount, setBetAmount] = useState("1");
  const [currency, setCurrency] = useState<"BTC" | "ETH" | "USDT">("USDT");
  const [currentCard, setCurrentCard] = useState<string | null>(null);
  const [previousCards, setPreviousCards] = useState<string[]>([]);
  const [gameActive, setGameActive] = useState(false);
  const [streak, setStreak] = useState(0);
  const [multiplier, setMultiplier] = useState(1);
  const [result, setResult] = useState<any>(null);
  const [flipping, setFlipping] = useState(false);

  const utils = trpc.useUtils();
  const { data: wallets } = trpc.wallet.getAll.useQuery(undefined, { enabled: !!user });

  const startMutation = trpc.casino.playHiLow.useMutation({
    onSuccess: (data) => {
      setCurrentCard(data.currentCard);
      setPreviousCards([]);
      setGameActive(true);
      setStreak(0);
      setMultiplier(1);
      setResult(null);
      play("cardFlip");
    },
    onError: (err) => toast.error(err.message),
  });

  const guessMutation = trpc.casino.guessHiLow.useMutation({
    onSuccess: (data) => {
      setFlipping(true);
      setTimeout(() => {
        setFlipping(false);
        if (data.correct) {
          play("win");
          setPreviousCards((prev) => [...prev, currentCard!]);
          setCurrentCard(data.nextCard);
          setStreak(data.streak);
          setMultiplier(data.multiplier);
          toast.success(`Correct! Streak: ${data.streak} (${data.multiplier.toFixed(2)}x)`);
        } else {
          play("lose");
          setPreviousCards((prev) => [...prev, currentCard!]);
          setCurrentCard(data.nextCard);
          setGameActive(false);
          setResult({ lost: true, streak: data.streak });
          toast.error(`Wrong! The card was ${data.nextCard.split("_")[0]}. Streak ended at ${data.streak}.`);
          utils.wallet.getAll.invalidate();
        }
      }, 600);
    },
    onError: (err) => toast.error(err.message),
  });

  const cashoutMutation = trpc.casino.cashoutHiLow.useMutation({
    onSuccess: (data) => {
      play("cashout");
      toast.success(`Cashed out! Won ${data.payout.toFixed(4)}`);
      setGameActive(false);
      setResult({ won: true, payout: data.payout });
      utils.wallet.getAll.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const handleStart = () => {
    if (parseFloat(betAmount) <= 0) { toast.error("Enter a valid bet"); return; }
    play("bet");
    startMutation.mutate({ betAmount: parseFloat(betAmount), currency });
  };

  const handleGuess = (guess: "high" | "low" | "same") => {
    if (!gameActive || flipping) return;
    play("click");
    guessMutation.mutate({ guess });
  };

  const currentBalance = wallets?.find((w: any) => w.currency === currency);
  const cardDisplay = currentCard ? getCardDisplay(currentCard) : null;

  if (loading) return <CasinoLayout><div className="container py-20 text-center animate-pulse text-muted-foreground">Loading...</div></CasinoLayout>;
  if (!user) { window.location.href = getLoginUrl(); return null; }

  return (
    <CasinoLayout>
      <div className="container py-6 max-w-6xl">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-indigo-500/10"><Layers className="h-6 w-6 text-indigo-400" /></div>
            <div>
              <h1 className="text-2xl font-bold">Hitide Lowtide</h1>
              <p className="text-xs text-muted-foreground">Will the next card be higher, lower, or the same? Build your streak!</p>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          <div className="lg:col-span-3">
            <Card className="casino-card">
              <CardContent className="p-4 sm:p-6">
                {/* Streak Bar */}
                {gameActive && streak > 0 && (
                  <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-4 flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-indigo-500/10 to-primary/10 border border-indigo-500/20">
                    <div className="flex items-center gap-3">
                      <div className="flex gap-1">
                        {Array.from({ length: Math.min(streak, 10) }, (_, i) => (
                          <div key={i} className="w-2 h-4 rounded-sm bg-primary" style={{ opacity: 0.4 + (i / 10) * 0.6 }} />
                        ))}
                      </div>
                      <span className="text-sm text-muted-foreground">Streak: <span className="text-foreground font-semibold">{streak}</span></span>
                      <span className="text-sm font-mono font-bold text-primary">{multiplier.toFixed(2)}x</span>
                    </div>
                    <button onClick={() => cashoutMutation.mutate({ streak, multiplier })} disabled={cashoutMutation.isPending} className="bet-btn px-5 py-2 text-sm">
                      Cash Out {(parseFloat(betAmount) * multiplier).toFixed(4)}
                    </button>
                  </motion.div>
                )}

                {/* Previous Cards Trail */}
                {previousCards.length > 0 && (
                  <div className="flex gap-1.5 mb-5 overflow-x-auto pb-2 scrollbar-hide">
                    {previousCards.map((card, i) => {
                      const d = getCardDisplay(card);
                      return (
                        <motion.div
                          key={i}
                          initial={{ scale: 0, opacity: 0 }}
                          animate={{ scale: 1, opacity: 0.5 }}
                          className="shrink-0 w-10 h-14 rounded-lg bg-muted/20 border border-border/30 flex flex-col items-center justify-center"
                        >
                          <span className={`text-[10px] font-bold ${d.color}`}>{d.value}</span>
                          <span className={`text-[10px] ${d.color}`}>{d.suit}</span>
                        </motion.div>
                      );
                    })}
                  </div>
                )}

                {/* Current Card */}
                <div className="flex justify-center mb-8">
                  {currentCard ? (
                    <motion.div
                      className="relative"
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ type: "spring", stiffness: 300 }}
                    >
                      {/* Card glow */}
                      <div className="absolute -inset-4 rounded-3xl bg-primary/5 blur-xl pointer-events-none" />
                      <div className={`relative w-36 h-52 sm:w-44 sm:h-60 rounded-2xl bg-gradient-to-br from-card via-card to-muted/50 border-2 border-primary/20 flex flex-col items-center justify-center shadow-[0_10px_40px_rgba(0,0,0,0.3)] ${flipping ? "animate-pulse" : ""}`}>
                        {/* Corner values */}
                        <div className={`absolute top-3 left-3 flex flex-col items-center ${cardDisplay?.color}`}>
                          <span className="text-sm font-bold leading-none">{cardDisplay?.value}</span>
                          <span className="text-xs leading-none">{cardDisplay?.suit}</span>
                        </div>
                        <div className={`absolute bottom-3 right-3 flex flex-col items-center rotate-180 ${cardDisplay?.color}`}>
                          <span className="text-sm font-bold leading-none">{cardDisplay?.value}</span>
                          <span className="text-xs leading-none">{cardDisplay?.suit}</span>
                        </div>
                        {/* Center */}
                        <span className={`text-5xl sm:text-6xl font-bold ${cardDisplay?.color}`}>{cardDisplay?.value}</span>
                        <span className={`text-3xl sm:text-4xl mt-1 ${cardDisplay?.color}`}>{cardDisplay?.suit}</span>
                      </div>
                    </motion.div>
                  ) : (
                    <div className="w-36 h-52 sm:w-44 sm:h-60 rounded-2xl bg-gradient-to-br from-primary/10 to-primary/5 border-2 border-primary/15 flex items-center justify-center">
                      <div className="text-center">
                        <Layers className="h-10 w-10 text-primary/30 mx-auto mb-2" />
                        <p className="text-xs text-muted-foreground">Deal to start</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Guess Buttons */}
                {gameActive && (
                  <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex justify-center gap-3 mb-4">
                    {[
                      { guess: "high" as const, icon: ArrowUp, label: "Higher", color: "from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600" },
                      { guess: "same" as const, icon: Equal, label: "Same", color: "from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600" },
                      { guess: "low" as const, icon: ArrowDown, label: "Lower", color: "from-red-600 to-red-700 hover:from-red-500 hover:to-red-600" },
                    ].map(({ guess, icon: Icon, label, color }) => (
                      <motion.button
                        key={guess}
                        whileHover={{ scale: 1.05, y: -2 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => handleGuess(guess)}
                        disabled={guessMutation.isPending || flipping}
                        className={`h-16 w-24 sm:w-28 rounded-xl bg-gradient-to-b ${color} text-white font-semibold flex flex-col items-center justify-center gap-1 shadow-lg transition-all disabled:opacity-50`}
                      >
                        <Icon className="h-5 w-5" />
                        <span className="text-xs">{label}</span>
                      </motion.button>
                    ))}
                  </motion.div>
                )}

                {/* Result */}
                <AnimatePresence>
                  {result && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                      <Card className={`border ${result.won ? "border-green-500/30 bg-green-500/5" : "border-red-500/30 bg-red-500/5"}`}>
                        <CardContent className="p-4 text-center">
                          <p className={`text-base font-bold ${result.won ? "text-green-400" : "text-red-400"}`}>
                            {result.won ? `Cashed out! Won ${result.payout.toFixed(4)} ${currency}` : `Game over! Streak ended at ${result.streak}.`}
                          </p>
                        </CardContent>
                      </Card>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>
          </div>

          {/* Controls */}
          <div className="space-y-3">
            <Card className="casino-card">
              <CardContent className="p-4 space-y-3">
                <div>
                  <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">Currency</label>
                  <Select value={currency} onValueChange={(v: any) => setCurrency(v)} disabled={gameActive}>
                    <SelectTrigger className="bg-muted/20 h-9 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="BTC">BTC</SelectItem>
                      <SelectItem value="ETH">ETH</SelectItem>
                      <SelectItem value="USDT">USDT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Bet Amount</label>
                    <span className="text-[10px] text-muted-foreground">Bal: {currentBalance ? parseFloat(currentBalance.balance).toFixed(4) : "0.0000"}</span>
                  </div>
                  <Input type="number" value={betAmount} onChange={(e) => setBetAmount(e.target.value)} className="bet-input h-10 text-base" disabled={gameActive} step="0.01" min="0" />
                  <div className="flex gap-1.5 mt-2">
                    {["0.5", "1", "5", "10"].map((v) => (
                      <button key={v} onClick={() => setBetAmount(v)} className="quick-bet flex-1" disabled={gameActive}>{v}</button>
                    ))}
                  </div>
                </div>

                {/* How to play */}
                <div className="p-3 rounded-lg bg-muted/20 border border-border/30 space-y-1.5">
                  <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1">How to Play</p>
                  <p className="text-xs text-muted-foreground">Guess if the next card is higher, lower, or the same value.</p>
                  <p className="text-xs text-muted-foreground">Each correct guess increases your multiplier by 1.5x.</p>
                  <p className="text-xs text-muted-foreground">Cash out anytime to lock in winnings!</p>
                </div>

                {/* Multiplier ladder */}
                <div className="p-3 rounded-lg bg-muted/20 border border-border/30">
                  <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-2">Multiplier Ladder</p>
                  <div className="space-y-0.5">
                    {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => {
                      const m = Math.pow(1.5, s);
                      const isActive = streak === s;
                      return (
                        <div key={s} className={`flex justify-between text-xs ${isActive ? "text-primary font-semibold" : "text-muted-foreground"}`}>
                          <span>Streak {s}</span>
                          <span className="font-mono">{m.toFixed(2)}x</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <button onClick={handleStart} disabled={startMutation.isPending || gameActive} className="bet-btn w-full h-12 text-base flex items-center justify-center gap-2">
                  {startMutation.isPending ? (
                    <><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> Dealing...</>
                  ) : gameActive ? (
                    "Game Active"
                  ) : (
                    <><Layers className="h-4 w-4" /> Deal Card</>
                  )}
                </button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </CasinoLayout>
  );
}
