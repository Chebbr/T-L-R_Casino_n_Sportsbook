import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { useAudio } from "@/hooks/useAudio";
import { toast } from "sonner";
import { Waves, Zap } from "lucide-react";

export default function CrashGame() {
  const { user, loading } = useAuth();
  const { play } = useAudio();
  const [betAmount, setBetAmount] = useState("1");
  const [autoCashout, setAutoCashout] = useState("2");
  const [currency, setCurrency] = useState<"BTC" | "ETH" | "USDT">("USDT");
  const [result, setResult] = useState<any>(null);
  const [animMultiplier, setAnimMultiplier] = useState(1.0);
  const [isAnimating, setIsAnimating] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);

  const utils = trpc.useUtils();
  const { data: wallets } = trpc.wallet.getAll.useQuery(undefined, { enabled: !!user });

  const playMutation = trpc.casino.playCrash.useMutation({
    onSuccess: (data) => {
      setIsAnimating(true);
      const startTime = Date.now();
      const crashAt = data.crashPoint;
      const duration = Math.min(crashAt * 800, 5000);

      const animate = () => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const currentMult = 1 + (crashAt - 1) * Math.pow(progress, 0.7);
        setAnimMultiplier(Math.min(currentMult, crashAt));

        if (progress < 1) {
          animRef.current = requestAnimationFrame(animate);
        } else {
          setIsAnimating(false);
          setResult(data);
          if (data.didCashout) {
            play("bigWin");
            toast.success(`Cashed out at ${data.multiplier.toFixed(2)}x! Won ${data.payout.toFixed(4)} ${currency}`);
          } else {
            play("crash");
            toast.error(`Crashed at ${data.crashPoint.toFixed(2)}x!`);
          }
          utils.wallet.getAll.invalidate();
        }
      };
      animRef.current = requestAnimationFrame(animate);
    },
    onError: (err) => toast.error(err.message),
  });

  useEffect(() => {
    return () => { if (animRef.current) cancelAnimationFrame(animRef.current); };
  }, []);

  // Premium canvas rendering
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);
    const dw = rect.width;
    const dh = rect.height;

    ctx.clearRect(0, 0, dw, dh);

    // Background gradient
    const bgGrad = ctx.createLinearGradient(0, 0, 0, dh);
    bgGrad.addColorStop(0, "rgba(10, 12, 20, 0.9)");
    bgGrad.addColorStop(1, "rgba(10, 12, 20, 0.95)");
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, dw, dh);

    // Grid lines
    ctx.strokeStyle = "rgba(255,255,255,0.03)";
    ctx.lineWidth = 1;
    for (let i = 1; i < 5; i++) {
      const y = dh - (dh * i) / 5;
      ctx.beginPath(); ctx.moveTo(40, y); ctx.lineTo(dw - 10, y); ctx.stroke();
      // Y-axis labels
      ctx.fillStyle = "rgba(255,255,255,0.15)";
      ctx.font = "10px Inter, sans-serif";
      ctx.textAlign = "right";
      const labelVal = 1 + ((Math.max(animMultiplier, 2) - 1) * i) / 4;
      ctx.fillText(`${labelVal.toFixed(1)}x`, 35, y + 3);
    }

    // Determine colors
    const crashed = result && !result.didCashout;
    const won = result?.didCashout;
    const primaryColor = crashed ? "#ef4444" : won ? "#22c55e" : "#d4a017";
    const glowColor = crashed ? "rgba(239,68,68,0.3)" : won ? "rgba(34,197,94,0.3)" : "rgba(212,160,23,0.3)";

    // Draw curve with gradient fill
    const maxMult = Math.max(animMultiplier, 2);
    const padding = { left: 45, right: 15, top: 30, bottom: 40 };
    const chartW = dw - padding.left - padding.right;
    const chartH = dh - padding.top - padding.bottom;

    ctx.beginPath();
    ctx.moveTo(padding.left, dh - padding.bottom);

    const points = 150;
    const curvePoints: [number, number][] = [];
    for (let i = 0; i <= points; i++) {
      const progress = i / points;
      const mult = 1 + (animMultiplier - 1) * Math.pow(progress, 0.7);
      const x = padding.left + progress * chartW;
      const y = dh - padding.bottom - ((mult - 1) / (maxMult - 1)) * chartH;
      curvePoints.push([x, y]);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }

    // Fill under curve
    const lastPoint = curvePoints[curvePoints.length - 1];
    ctx.lineTo(lastPoint[0], dh - padding.bottom);
    ctx.lineTo(padding.left, dh - padding.bottom);
    ctx.closePath();
    const fillGrad = ctx.createLinearGradient(0, padding.top, 0, dh - padding.bottom);
    fillGrad.addColorStop(0, glowColor);
    fillGrad.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = fillGrad;
    ctx.fill();

    // Draw curve line
    ctx.beginPath();
    for (let i = 0; i < curvePoints.length; i++) {
      if (i === 0) ctx.moveTo(curvePoints[i][0], curvePoints[i][1]);
      else ctx.lineTo(curvePoints[i][0], curvePoints[i][1]);
    }
    ctx.strokeStyle = primaryColor;
    ctx.lineWidth = 2.5;
    ctx.shadowColor = primaryColor;
    ctx.shadowBlur = 15;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Dot at end of curve
    if (curvePoints.length > 0) {
      const [dx, dy] = lastPoint;
      ctx.beginPath();
      ctx.arc(dx, dy, 4, 0, Math.PI * 2);
      ctx.fillStyle = primaryColor;
      ctx.fill();
      ctx.beginPath();
      ctx.arc(dx, dy, 8, 0, Math.PI * 2);
      ctx.fillStyle = glowColor;
      ctx.fill();
    }

    // Center multiplier text
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    // Large multiplier
    ctx.fillStyle = primaryColor;
    ctx.font = "bold 56px Orbitron, monospace";
    ctx.shadowColor = primaryColor;
    ctx.shadowBlur = 20;
    ctx.fillText(`${animMultiplier.toFixed(2)}x`, dw / 2, dh / 2 - 10);
    ctx.shadowBlur = 0;

    // Status text
    if (crashed) {
      ctx.fillStyle = "#ef4444";
      ctx.font = "bold 16px Inter, sans-serif";
      ctx.fillText("CRASHED", dw / 2, dh / 2 + 25);
    } else if (won) {
      ctx.fillStyle = "#22c55e";
      ctx.font = "bold 16px Inter, sans-serif";
      ctx.fillText(`CASHED OUT +${result.payout.toFixed(4)}`, dw / 2, dh / 2 + 25);
    } else if (isAnimating) {
      ctx.fillStyle = "rgba(212,160,23,0.6)";
      ctx.font = "12px Inter, sans-serif";
      ctx.fillText("RIDING THE WAVE...", dw / 2, dh / 2 + 25);
    }
  }, [animMultiplier, result, isAnimating]);

  const handlePlay = () => {
    if (parseFloat(betAmount) <= 0) { toast.error("Enter a valid bet"); return; }
    play("bet");
    setResult(null);
    setAnimMultiplier(1.0);
    playMutation.mutate({
      betAmount: parseFloat(betAmount),
      currency,
      autoCashout: parseFloat(autoCashout) > 1 ? parseFloat(autoCashout) : undefined,
    });
  };

  const currentBalance = wallets?.find((w: any) => w.currency === currency);

  if (loading) return <CasinoLayout><div className="container py-20 text-center animate-pulse text-muted-foreground">Loading...</div></CasinoLayout>;
  if (!user) { window.location.href = getLoginUrl(); return null; }

  return (
    <CasinoLayout>
      <div className="container py-6 max-w-6xl">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-500/10">
              <Waves className="h-6 w-6 text-cyan-400" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Beached <span className="text-cyan-400">(Crash)</span></h1>
              <p className="text-xs text-muted-foreground">Ride the wave and cash out before it crashes</p>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Chart Area */}
          <div className="lg:col-span-3">
            <Card className="casino-card overflow-hidden">
              <CardContent className="p-0">
                <div className="relative w-full" style={{ aspectRatio: "16/9" }}>
                  <canvas ref={canvasRef} className="w-full h-full" style={{ display: "block" }} />
                  {!isAnimating && !result && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center">
                        <Waves className="h-12 w-12 text-muted-foreground/20 mx-auto mb-3" />
                        <p className="text-sm text-muted-foreground/40">Place a bet to start</p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Controls */}
          <div className="space-y-3">
            <Card className="casino-card">
              <CardContent className="p-4 space-y-3">
                <div>
                  <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">Currency</label>
                  <Select value={currency} onValueChange={(v: any) => setCurrency(v)}>
                    <SelectTrigger className="bg-muted/20 h-9 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="BTC">BTC</SelectItem>
                      <SelectItem value="ETH">ETH</SelectItem>
                      <SelectItem value="USDT">USDT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Bet Amount</label>
                    <span className="text-[10px] text-muted-foreground">
                      Bal: {currentBalance ? parseFloat(currentBalance.balance).toFixed(4) : "0.0000"}
                    </span>
                  </div>
                  <Input
                    type="number"
                    value={betAmount}
                    onChange={(e) => setBetAmount(e.target.value)}
                    className="bet-input h-10 text-base"
                    step="0.01"
                    min="0"
                  />
                  <div className="flex gap-1.5 mt-2">
                    {["0.5", "1", "5", "10", "25"].map((v) => (
                      <button key={v} onClick={() => setBetAmount(v)} className="quick-bet flex-1">{v}</button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">Auto Cashout</label>
                  <Input
                    type="number"
                    value={autoCashout}
                    onChange={(e) => setAutoCashout(e.target.value)}
                    className="bg-muted/20 h-9 text-sm font-mono"
                    step="0.1"
                    min="1.01"
                    placeholder="2.00x"
                  />
                  <div className="flex gap-1.5 mt-2">
                    {["1.5", "2", "3", "5", "10"].map((v) => (
                      <button key={v} onClick={() => setAutoCashout(v)} className="quick-bet flex-1">{v}x</button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={handlePlay}
                  disabled={playMutation.isPending || isAnimating}
                  className="bet-btn w-full h-12 text-base flex items-center justify-center gap-2"
                >
                  {playMutation.isPending || isAnimating ? (
                    <>
                      <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                      Riding...
                    </>
                  ) : (
                    <>
                      <Zap className="h-4 w-4" /> Place Bet
                    </>
                  )}
                </button>
              </CardContent>
            </Card>

            {/* Result Card */}
            {result && (
              <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
                <Card className={`border ${result.didCashout ? "border-green-500/30 bg-green-500/5" : "border-red-500/30 bg-red-500/5"}`}>
                  <CardContent className="p-4 text-center">
                    <p className={`text-lg font-bold font-display ${result.didCashout ? "text-green-400" : "text-red-400"}`}>
                      {result.didCashout ? `+${result.payout.toFixed(4)}` : "CRASHED"}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {result.didCashout
                        ? `Cashed out at ${result.multiplier.toFixed(2)}x`
                        : `Crashed at ${result.crashPoint.toFixed(2)}x`}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </CasinoLayout>
  );
}
