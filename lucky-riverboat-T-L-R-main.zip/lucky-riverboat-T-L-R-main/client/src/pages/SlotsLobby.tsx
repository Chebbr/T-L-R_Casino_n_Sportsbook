import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { useState, useMemo, useCallback, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAudio } from "@/hooks/useAudio";
import { toast } from "sonner";
import { Search, Star, Flame, Sparkles, Zap, Play, Volume2, Minus, Plus, RotateCcw } from "lucide-react";

const PROVIDERS = [
  { id: "hacksaw", name: "Hacksaw Gaming", color: "from-red-600 to-orange-500", accent: "text-red-400" },
  { id: "pragmatic", name: "Pragmatic Play", color: "from-blue-600 to-cyan-500", accent: "text-blue-400" },
  { id: "massive", name: "Massive Studios", color: "from-purple-600 to-pink-500", accent: "text-purple-400" },
  { id: "ladyshady", name: "Lady Shady", color: "from-green-600 to-emerald-500", accent: "text-green-400" },
];

const SLOT_SYMBOLS = ["🍒", "🍋", "🍊", "🍇", "💎", "7️⃣", "⭐", "🔔", "🍀", "👑"];
const SYMBOL_VALUES: Record<string, number> = {
  "👑": 50, "7️⃣": 25, "💎": 15, "⭐": 10, "🔔": 8,
  "🍀": 6, "🍇": 4, "🍊": 3, "🍋": 2, "🍒": 1,
};

const DEMO_SLOTS = [
  { id: 1, name: "Wanted Dead or a Wild", provider: "hacksaw", image: "🤠", rtp: 96.4, volatility: "High", popular: true },
  { id: 2, name: "Chaos Crew", provider: "hacksaw", image: "🎪", rtp: 96.1, volatility: "High", popular: true },
  { id: 3, name: "Dork Unit", provider: "hacksaw", image: "🤪", rtp: 96.2, volatility: "Very High", popular: false },
  { id: 4, name: "Stick Em", provider: "hacksaw", image: "🍯", rtp: 96.3, volatility: "High", popular: false },
  { id: 5, name: "Hand of Anubis", provider: "hacksaw", image: "🏺", rtp: 96.2, volatility: "High", popular: true },
  { id: 6, name: "Gates of Olympus", provider: "pragmatic", image: "⚡", rtp: 96.5, volatility: "High", popular: true },
  { id: 7, name: "Sweet Bonanza", provider: "pragmatic", image: "🍬", rtp: 96.5, volatility: "Medium-High", popular: true },
  { id: 8, name: "Sugar Rush", provider: "pragmatic", image: "🍭", rtp: 96.5, volatility: "High", popular: false },
  { id: 9, name: "Starlight Princess", provider: "pragmatic", image: "👸", rtp: 96.5, volatility: "High", popular: true },
  { id: 10, name: "Big Bass Bonanza", provider: "pragmatic", image: "🐟", rtp: 96.7, volatility: "Medium-High", popular: false },
  { id: 11, name: "Dog Haus Megaways", provider: "pragmatic", image: "🐕", rtp: 96.5, volatility: "High", popular: false },
  { id: 12, name: "Cosmic Vault", provider: "massive", image: "🌌", rtp: 96.0, volatility: "High", popular: true },
  { id: 13, name: "Neon Blaze", provider: "massive", image: "🔥", rtp: 95.8, volatility: "Very High", popular: false },
  { id: 14, name: "Crystal Caverns", provider: "massive", image: "💎", rtp: 96.2, volatility: "Medium", popular: true },
  { id: 15, name: "Thunder Reels", provider: "massive", image: "⚡", rtp: 96.1, volatility: "High", popular: false },
  { id: 16, name: "Mystic Fortune", provider: "ladyshady", image: "🔮", rtp: 96.3, volatility: "Medium-High", popular: true },
  { id: 17, name: "Shadow Spins", provider: "ladyshady", image: "🌙", rtp: 95.9, volatility: "High", popular: false },
  { id: 18, name: "Velvet Jackpot", provider: "ladyshady", image: "🎰", rtp: 96.4, volatility: "Very High", popular: true },
  { id: 19, name: "Midnight Gems", provider: "ladyshady", image: "💜", rtp: 96.0, volatility: "Medium", popular: false },
  { id: 20, name: "Golden Empress", provider: "ladyshady", image: "👑", rtp: 96.5, volatility: "High", popular: true },
];

// Embedded Slot Machine Component
function SlotMachine({ slot, onClose }: { slot: typeof DEMO_SLOTS[0]; onClose: () => void }) {
  const { play } = useAudio();
  const { data: balance } = trpc.wallet.getBalance.useQuery({ currency: "USDT" });
  const playKeno = trpc.casino.playKeno.useMutation();
  const utils = trpc.useUtils();

  const [betAmount, setBetAmount] = useState(1);
  const [spinning, setSpinning] = useState(false);
  const [reels, setReels] = useState<string[][]>([
    ["🍒", "🍋", "🍊"],
    ["🍇", "💎", "7️⃣"],
    ["⭐", "🔔", "🍀"],
    ["👑", "🍒", "🍋"],
    ["🍊", "🍇", "💎"],
  ]);
  const [winLine, setWinLine] = useState<number | null>(null);
  const [lastWin, setLastWin] = useState(0);
  const [autoSpin, setAutoSpin] = useState(false);
  const autoSpinRef = useRef(false);
  const spinTimeouts = useRef<NodeJS.Timeout[]>([]);

  useEffect(() => {
    autoSpinRef.current = autoSpin;
  }, [autoSpin]);

  useEffect(() => {
    return () => {
      spinTimeouts.current.forEach(clearTimeout);
      autoSpinRef.current = false;
    };
  }, []);

  const generateReel = useCallback(() => {
    return Array.from({ length: 3 }, () => SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)]);
  }, []);

  const checkWin = useCallback((finalReels: string[][]) => {
    // Check middle row (index 1) across all 5 reels
    const middleRow = finalReels.map(r => r[1]);
    
    // Check for 3+ matching from left
    let matchCount = 1;
    for (let i = 1; i < middleRow.length; i++) {
      if (middleRow[i] === middleRow[0]) matchCount++;
      else break;
    }
    
    if (matchCount >= 3) {
      const symbol = middleRow[0];
      const baseValue = SYMBOL_VALUES[symbol] || 1;
      const multiplier = matchCount === 5 ? 10 : matchCount === 4 ? 5 : 2;
      return baseValue * multiplier;
    }

    // Check for any 3 of a kind in middle row
    const counts: Record<string, number> = {};
    middleRow.forEach(s => { counts[s] = (counts[s] || 0) + 1; });
    for (const [symbol, count] of Object.entries(counts)) {
      if (count >= 3) {
        const baseValue = SYMBOL_VALUES[symbol] || 1;
        return baseValue * (count === 5 ? 8 : count === 4 ? 3 : 1.5);
      }
    }

    return 0;
  }, []);

  const spin = useCallback(async () => {
    if (spinning) return;
    const currentBalance = Number(balance?.balance || 0);
    if (currentBalance < betAmount) {
      toast.error("Insufficient balance!");
      setAutoSpin(false);
      return;
    }

    setSpinning(true);
    setWinLine(null);
    setLastWin(0);
    play("click");

    try {
      // Place bet through backend
      const result = await playKeno.mutateAsync({
        betAmount,
        selectedNumbers: [1, 2, 3, 4, 5],
        currency: "USDT",
      });

      // Animate reels stopping one by one
      const newReels: string[][] = [];
      for (let i = 0; i < 5; i++) {
        newReels.push(generateReel());
      }

      // If won, force a winning combination on middle row
      const isWin = result.isWin;
      if (isWin) {
        const winSymbol = SLOT_SYMBOLS[Math.floor(Math.random() * 5) + 5]; // Pick higher value symbols
        const matchCount = Math.random() > 0.5 ? 3 : (Math.random() > 0.5 ? 4 : 5);
        for (let i = 0; i < matchCount; i++) {
          newReels[i][1] = winSymbol;
        }
      }

      // Animate each reel stopping with delay
      spinTimeouts.current = [];
      for (let i = 0; i < 5; i++) {
        const timeout = setTimeout(() => {
          setReels(prev => {
            const updated = [...prev];
            updated[i] = newReels[i];
            return updated;
          });
          
          if (i === 4) {
            // Last reel stopped
            setTimeout(() => {
              const winMultiplier = isWin ? checkWin(newReels) : 0;
              const payout = Number(result.payout || 0);
              
              if (payout > 0) {
                setWinLine(1);
                setLastWin(payout);
                play("win");
                toast.success(`WIN! $${payout.toFixed(2)}`, { duration: 2000 });
              } else {
                play("lose");
              }
              
              utils.wallet.getBalance.invalidate();
              setSpinning(false);

              // Auto spin
              if (autoSpinRef.current) {
                setTimeout(() => {
                  if (autoSpinRef.current) spin();
                }, 1000);
              }
            }, 300);
          }
        }, 200 + i * 250);
        spinTimeouts.current.push(timeout);
      }

      // Rapid animation during spin
      const animInterval = setInterval(() => {
        setReels(prev => prev.map((_, idx) => {
          // Only animate reels that haven't stopped yet
          return generateReel();
        }));
      }, 80);
      
      setTimeout(() => clearInterval(animInterval), 200);

    } catch (err: any) {
      toast.error(err?.message || "Spin failed");
      setSpinning(false);
      setAutoSpin(false);
    }
  }, [spinning, betAmount, balance, playKeno, slot, generateReel, checkWin, play, utils]);

  const provider = PROVIDERS.find(p => p.id === slot.provider);

  return (
    <div className="flex flex-col h-full">
      {/* Game Header */}
      <div className="flex items-center justify-between p-3 border-b border-border/30">
        <div className="flex items-center gap-2">
          <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${provider?.color} flex items-center justify-center`}>
            <span className="text-lg">{slot.image}</span>
          </div>
          <div>
            <h3 className="text-sm font-bold">{slot.name}</h3>
            <p className="text-[10px] text-muted-foreground">{provider?.name} • RTP {slot.rtp}%</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-[10px] text-muted-foreground">Balance</p>
          <p className="text-sm font-bold text-primary">${Number(balance?.balance || 0).toFixed(2)}</p>
        </div>
      </div>

      {/* Slot Machine */}
      <div className="flex-1 flex flex-col items-center justify-center p-4 gap-4">
        {/* Reels */}
        <div className="relative">
          {/* Win line indicator */}
          {winLine !== null && (
            <motion.div
              initial={{ opacity: 0, scaleX: 0 }}
              animate={{ opacity: 1, scaleX: 1 }}
              className="absolute top-1/2 -translate-y-1/2 left-0 right-0 h-[2px] bg-primary z-20 shadow-[0_0_10px_rgba(212,175,55,0.8)]"
            />
          )}
          
          <div className="flex gap-1.5 p-3 rounded-xl bg-black/40 border border-border/30 backdrop-blur-sm">
            {reels.map((reel, reelIdx) => (
              <div key={reelIdx} className="w-16 sm:w-20 overflow-hidden rounded-lg bg-gradient-to-b from-gray-900 to-gray-800 border border-border/20">
                <AnimatePresence mode="popLayout">
                  {reel.map((symbol, rowIdx) => (
                    <motion.div
                      key={`${reelIdx}-${rowIdx}-${symbol}-${spinning ? Math.random() : 'static'}`}
                      initial={spinning ? { y: -60, opacity: 0 } : false}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ duration: 0.15 }}
                      className={`h-14 sm:h-16 flex items-center justify-center text-2xl sm:text-3xl ${
                        rowIdx === 1 && winLine !== null ? "bg-primary/10 scale-110" : ""
                      } ${rowIdx === 1 ? "bg-white/5" : "opacity-50"}`}
                    >
                      {symbol}
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>

        {/* Win Display */}
        <AnimatePresence>
          {lastWin > 0 && (
            <motion.div
              initial={{ opacity: 0, scale: 0.5, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.5 }}
              className="text-center"
            >
              <div className="px-6 py-2 rounded-xl bg-primary/20 border border-primary/40">
                <p className="text-xs text-primary/80 font-medium">WIN</p>
                <p className="text-2xl font-black text-gradient-gold">${lastWin.toFixed(2)}</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Controls */}
      <div className="border-t border-border/30 p-3">
        <div className="flex items-center justify-between gap-3">
          {/* Bet Amount */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setBetAmount(Math.max(0.1, betAmount - (betAmount >= 10 ? 5 : betAmount >= 1 ? 0.5 : 0.1)))}
              disabled={spinning || betAmount <= 0.1}
              className="w-8 h-8 rounded-lg bg-muted/30 border border-border/30 flex items-center justify-center hover:bg-muted/50 disabled:opacity-30 transition-colors"
            >
              <Minus className="h-3 w-3" />
            </button>
            <div className="px-3 py-1.5 rounded-lg bg-muted/20 border border-border/30 min-w-[70px] text-center">
              <p className="text-[9px] text-muted-foreground">BET</p>
              <p className="text-sm font-bold">${betAmount.toFixed(2)}</p>
            </div>
            <button
              onClick={() => setBetAmount(betAmount + (betAmount >= 10 ? 5 : betAmount >= 1 ? 0.5 : 0.1))}
              disabled={spinning}
              className="w-8 h-8 rounded-lg bg-muted/30 border border-border/30 flex items-center justify-center hover:bg-muted/50 disabled:opacity-30 transition-colors"
            >
              <Plus className="h-3 w-3" />
            </button>
          </div>

          {/* Spin Button */}
          <button
            onClick={spin}
            disabled={spinning}
            className={`flex-1 max-w-[180px] h-12 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
              spinning
                ? "bg-muted/30 text-muted-foreground cursor-not-allowed"
                : "bet-btn hover:scale-[1.02] active:scale-[0.98]"
            }`}
          >
            {spinning ? (
              <RotateCcw className="h-4 w-4 animate-spin" />
            ) : (
              <>
                <Zap className="h-4 w-4" />
                SPIN
              </>
            )}
          </button>

          {/* Auto Spin */}
          <button
            onClick={() => {
              const newVal = !autoSpin;
              setAutoSpin(newVal);
              if (newVal && !spinning) spin();
            }}
            className={`px-3 py-2 rounded-lg text-xs font-medium transition-all ${
              autoSpin
                ? "bg-red-500/20 text-red-400 border border-red-500/30"
                : "bg-muted/20 text-muted-foreground border border-border/30 hover:bg-muted/40"
            }`}
          >
            {autoSpin ? "STOP" : "AUTO"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function SlotsLobby() {
  const { user, loading } = useAuth();
  const { play } = useAudio();
  const [search, setSearch] = useState("");
  const [selectedProvider, setSelectedProvider] = useState("all");
  const [selectedSlot, setSelectedSlot] = useState<typeof DEMO_SLOTS[0] | null>(null);
  const [gameOpen, setGameOpen] = useState(false);

  const filteredSlots = useMemo(() => {
    return DEMO_SLOTS.filter((slot) => {
      const matchesSearch = slot.name.toLowerCase().includes(search.toLowerCase());
      const matchesProvider = selectedProvider === "all" || slot.provider === selectedProvider;
      return matchesSearch && matchesProvider;
    });
  }, [search, selectedProvider]);

  const popularSlots = DEMO_SLOTS.filter((s) => s.popular);

  const openGame = (slot: typeof DEMO_SLOTS[0]) => {
    if (!user) { window.location.href = getLoginUrl(); return; }
    play("click");
    setSelectedSlot(slot);
    setGameOpen(true);
  };

  if (loading) return <CasinoLayout><div className="container py-20 text-center animate-pulse text-muted-foreground">Loading...</div></CasinoLayout>;

  return (
    <CasinoLayout>
      <div className="container py-6 max-w-6xl">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-primary/10"><Sparkles className="h-6 w-6 text-primary" /></div>
            <div>
              <h1 className="text-2xl font-bold">Slots</h1>
              <p className="text-xs text-muted-foreground">Premium slots from Hacksaw, Pragmatic Play, Massive Studios & Lady Shady</p>
            </div>
          </div>
        </motion.div>

        {/* Search & Filter */}
        <div className="flex flex-col sm:flex-row gap-3 mb-5">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search slots..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-10 bet-input h-9 text-sm" />
          </div>
          <div className="flex gap-1.5 flex-wrap">
            <button
              onClick={() => setSelectedProvider("all")}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${selectedProvider === "all" ? "bg-primary/15 text-primary border border-primary/30" : "bg-muted/20 text-muted-foreground border border-border/20 hover:bg-muted/40"}`}
            >
              All
            </button>
            {PROVIDERS.map((p) => (
              <button
                key={p.id}
                onClick={() => { setSelectedProvider(p.id); play("click"); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${selectedProvider === p.id ? "bg-primary/15 text-primary border border-primary/30" : "bg-muted/20 text-muted-foreground border border-border/20 hover:bg-muted/40"}`}
              >
                {p.name}
              </button>
            ))}
          </div>
        </div>

        {/* Popular Section */}
        {selectedProvider === "all" && !search && (
          <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="mb-6">
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
              <Flame className="h-4 w-4 text-orange-500" /> Popular Slots
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
              {popularSlots.map((slot, i) => {
                const provider = PROVIDERS.find(p => p.id === slot.provider);
                return (
                  <motion.div key={slot.id} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 + i * 0.03 }}>
                    <Card className="casino-card cursor-pointer hover:border-primary/30 transition-all group overflow-hidden" onClick={() => openGame(slot)}>
                      <CardContent className="p-0">
                        <div className={`h-24 bg-gradient-to-br ${provider?.color} flex items-center justify-center relative overflow-hidden`}>
                          <div className="absolute inset-0 bg-black/20" />
                          <span className="text-4xl relative z-10 group-hover:scale-125 transition-transform duration-300">{slot.image}</span>
                          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                              <Play className="h-5 w-5 text-white fill-white" />
                            </div>
                          </div>
                          <div className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded-full bg-orange-500/90 text-[9px] font-bold text-white flex items-center gap-0.5">
                            <Flame className="h-2.5 w-2.5" /> HOT
                          </div>
                        </div>
                        <div className="p-3">
                          <p className="font-semibold text-xs truncate">{slot.name}</p>
                          <p className="text-[10px] text-muted-foreground">{provider?.name}</p>
                          <div className="flex items-center gap-1 mt-1.5">
                            <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-muted/30 border border-border/20 text-muted-foreground">RTP {slot.rtp}%</span>
                            <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-muted/30 border border-border/20 text-muted-foreground">{slot.volatility}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* All Slots Grid */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
              <Star className="h-4 w-4 text-primary" />
              {selectedProvider === "all" ? "All Slots" : PROVIDERS.find(p => p.id === selectedProvider)?.name}
            </h2>
            <span className="text-[10px] text-muted-foreground bg-muted/30 px-2 py-0.5 rounded-full">{filteredSlots.length} games</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {filteredSlots.map((slot, i) => {
              const provider = PROVIDERS.find(p => p.id === slot.provider);
              return (
                <motion.div key={slot.id} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.02 }}>
                  <Card className="casino-card cursor-pointer hover:border-primary/30 transition-all group overflow-hidden" onClick={() => openGame(slot)}>
                    <CardContent className="p-0">
                      <div className={`h-20 bg-gradient-to-br ${provider?.color} flex items-center justify-center relative overflow-hidden`}>
                        <div className="absolute inset-0 bg-black/20" />
                        <span className="text-3xl relative z-10 group-hover:scale-125 transition-transform duration-300">{slot.image}</span>
                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <div className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                            <Play className="h-4 w-4 text-white fill-white" />
                          </div>
                        </div>
                      </div>
                      <div className="p-2.5">
                        <p className="font-semibold text-[11px] truncate">{slot.name}</p>
                        <p className="text-[10px] text-muted-foreground">{provider?.name}</p>
                        <div className="flex items-center gap-1 mt-1">
                          <span className="text-[9px] px-1 py-0.5 rounded bg-muted/30 text-muted-foreground font-mono">{slot.rtp}%</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {filteredSlots.length === 0 && (
          <div className="text-center py-16 text-muted-foreground">
            <Search className="h-10 w-10 mx-auto mb-3 opacity-20" />
            <p className="text-sm">No slots found matching your search</p>
          </div>
        )}

        {/* Game Dialog - Full Slot Machine */}
        <Dialog open={gameOpen} onOpenChange={(open) => { setGameOpen(open); if (!open) setSelectedSlot(null); }}>
          <DialogContent className="max-w-lg h-[85vh] sm:h-[75vh] p-0 bg-background border-border/30 flex flex-col overflow-hidden">
            <DialogHeader className="sr-only">
              <DialogTitle>{selectedSlot?.name || "Slot Game"}</DialogTitle>
            </DialogHeader>
            {selectedSlot && <SlotMachine slot={selectedSlot} onClose={() => setGameOpen(false)} />}
          </DialogContent>
        </Dialog>
      </div>
    </CasinoLayout>
  );
}
