import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { MessageCircle, Send, Users, Crown } from "lucide-react";
import { toast } from "sonner";

export default function ChatPage() {
  const { user, loading } = useAuth();
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const utils = trpc.useUtils();

  const { data: messages, isLoading: msgsLoading } = trpc.chat.getMessages.useQuery(
    { limit: 100 },
    { refetchInterval: 3000 }
  );

  const sendMutation = trpc.chat.send.useMutation({
    onSuccess: () => {
      setMessage("");
      utils.chat.getMessages.invalidate();
    },
    onError: (err: any) => toast.error(err.message),
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  if (loading) return <CasinoLayout><div className="container py-20 text-center animate-pulse text-muted-foreground">Loading...</div></CasinoLayout>;
  if (!user) { window.location.href = getLoginUrl(); return null; }

  const handleSend = () => {
    const trimmed = message.trim();
    if (!trimmed) return;
    sendMutation.mutate({ message: trimmed });
  };

  return (
    <CasinoLayout>
      <div className="container py-6 max-w-3xl">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-primary/10"><MessageCircle className="h-6 w-6 text-primary" /></div>
            <div>
              <h1 className="text-2xl font-bold">Player Chat</h1>
              <p className="text-xs text-muted-foreground">Chat with other players in real-time</p>
            </div>
          </div>
        </motion.div>

        <Card className="casino-card">
          <CardContent className="p-0 flex flex-col" style={{ height: "calc(100vh - 220px)", minHeight: "400px" }}>
            {/* Online indicator */}
            <div className="px-4 py-2.5 border-b border-border/20 flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              <span className="text-xs text-muted-foreground">
                <Users className="h-3 w-3 inline mr-1" />
                Global Chat Room
              </span>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {msgsLoading ? (
                <div className="text-center py-10 text-muted-foreground text-sm animate-pulse">Loading messages...</div>
              ) : messages && messages.length > 0 ? (
                messages.map((msg: any, i: number) => {
                  const isMe = msg.userId === user.id;
                  return (
                    <motion.div
                      key={msg.id || i}
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex ${isMe ? "justify-end" : "justify-start"}`}
                    >
                      <div className={`max-w-[75%] ${isMe ? "order-2" : ""}`}>
                        <div className={`flex items-center gap-1.5 mb-0.5 ${isMe ? "justify-end" : ""}`}>
                          <span className={`text-[10px] font-medium ${isMe ? "text-primary" : "text-muted-foreground"}`}>
                            {msg.userName || "Player"}
                          </span>
                          {msg.userRole === "admin" && (
                            <Crown className="h-2.5 w-2.5 text-primary" />
                          )}
                          <span className="text-[9px] text-muted-foreground/50">
                            {new Date(msg.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                          </span>
                        </div>
                        <div className={`px-3 py-2 rounded-xl text-sm ${
                          isMe
                            ? "bg-primary/15 border border-primary/20 text-foreground"
                            : "bg-muted/30 border border-border/20 text-foreground"
                        }`}>
                          {msg.message}
                        </div>
                      </div>
                    </motion.div>
                  );
                })
              ) : (
                <div className="text-center py-10 text-muted-foreground">
                  <MessageCircle className="h-10 w-10 mx-auto mb-3 opacity-20" />
                  <p className="text-sm">No messages yet. Be the first to say something!</p>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-3 border-t border-border/20">
              <form
                onSubmit={(e) => { e.preventDefault(); handleSend(); }}
                className="flex items-center gap-2"
              >
                <Input
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Type a message..."
                  className="bet-input h-10 flex-1"
                  maxLength={500}
                  disabled={sendMutation.isPending}
                />
                <button
                  type="submit"
                  disabled={sendMutation.isPending || !message.trim()}
                  className="bet-btn h-10 w-10 flex items-center justify-center shrink-0"
                >
                  <Send className="h-4 w-4" />
                </button>
              </form>
            </div>
          </CardContent>
        </Card>
      </div>
    </CasinoLayout>
  );
}
