import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { motion } from "framer-motion";
import { Wallet as WalletIcon, ArrowDownToLine, ArrowUpFromLine, Copy, Check, Clock, Shield, AlertTriangle, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { useAudio } from "@/hooks/useAudio";

export default function Wallet() {
  const { user, loading: authLoading } = useAuth();
  const { play } = useAudio();
  const [currency, setCurrency] = useState<"BTC" | "ETH" | "USDT">("USDT");
  const [depositTxHash, setDepositTxHash] = useState("");
  const [depositAmount, setDepositAmount] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [withdrawAddress, setWithdrawAddress] = useState("");
  const [copied, setCopied] = useState(false);

  const utils = trpc.useUtils();
  const { data: wallets } = trpc.wallet.getAll.useQuery(undefined, { enabled: !!user });
  const { data: depositAddr } = trpc.wallet.getDepositAddress.useQuery({ currency }, { enabled: !!user });
  const { data: transactions } = trpc.wallet.getTransactions.useQuery({ limit: 20 }, { enabled: !!user });
  const { data: withdrawals } = trpc.wallet.getWithdrawals.useQuery({ limit: 20 }, { enabled: !!user });

  const depositMutation = trpc.wallet.submitDeposit.useMutation({
    onSuccess: () => {
      play("deposit");
      toast.success("Deposit claim submitted! Your funds will be credited after blockchain verification by our team.");
      utils.wallet.getAll.invalidate();
      utils.wallet.getTransactions.invalidate();
      setDepositAmount("");
      setDepositTxHash("");
    },
    onError: (err: any) => toast.error(err.message),
  });

  const withdrawMutation = trpc.wallet.withdraw.useMutation({
    onSuccess: () => {
      play("withdraw");
      toast.success("Withdrawal request submitted! It will be processed after admin approval.");
      utils.wallet.getAll.invalidate();
      utils.wallet.getWithdrawals.invalidate();
      setWithdrawAmount("");
      setWithdrawAddress("");
    },
    onError: (err: any) => toast.error(err.message),
  });

  if (authLoading) return <CasinoLayout><div className="container py-20 text-center"><div className="animate-pulse text-muted-foreground">Loading...</div></div></CasinoLayout>;
  if (!user) { window.location.href = getLoginUrl(); return null; }

  const copyAddress = () => {
    if (depositAddr?.address) {
      navigator.clipboard.writeText(depositAddr.address);
      setCopied(true);
      toast.success("Address copied!");
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const currentWallet = wallets?.find((w: any) => w.currency === currency);
  const currentBalance = parseFloat(currentWallet?.balance || "0");

  const currencyConfig: Record<string, { symbol: string; color: string; bg: string; explorer: string }> = {
    BTC: { symbol: "B", color: "text-orange-400", bg: "bg-orange-500/10", explorer: "https://www.blockchain.com/btc/tx/" },
    ETH: { symbol: "E", color: "text-blue-400", bg: "bg-blue-500/10", explorer: "https://etherscan.io/tx/" },
    USDT: { symbol: "$", color: "text-green-400", bg: "bg-green-500/10", explorer: "https://etherscan.io/tx/" },
  };

  return (
    <CasinoLayout>
      <div className="container py-6 max-w-5xl">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-primary/10"><WalletIcon className="h-6 w-6 text-primary" /></div>
            <div>
              <h1 className="text-2xl font-bold">Wallet</h1>
              <p className="text-xs text-muted-foreground">Manage your crypto balances, deposits, and withdrawals</p>
            </div>
          </div>
        </motion.div>

        {/* Balance Cards */}
        <div className="grid grid-cols-3 gap-3 mb-5">
          {(["BTC", "ETH", "USDT"] as const).map((cur, idx) => {
            const w = wallets?.find((wl: any) => wl.currency === cur);
            const cfg = currencyConfig[cur];
            const isActive = currency === cur;
            return (
              <motion.div key={cur} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.05 }}>
                <Card
                  className={`casino-card cursor-pointer transition-all ${isActive ? "border-primary/40 shadow-[0_0_20px_rgba(212,160,23,0.08)]" : "hover:border-border/50"}`}
                  onClick={() => setCurrency(cur)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${cfg.bg} ${cfg.color}`}>
                        {cfg.symbol}
                      </div>
                      <span className="text-sm font-medium">{cur}</span>
                      {isActive && <div className="w-1.5 h-1.5 rounded-full bg-primary ml-auto animate-pulse" />}
                    </div>
                    <p className="text-xl font-mono font-bold">{parseFloat(w?.balance || "0").toFixed(cur === "BTC" ? 8 : 4)}</p>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        <Tabs defaultValue="deposit" className="space-y-4">
          <TabsList className="bg-muted/30 border border-border/30 p-1">
            <TabsTrigger value="deposit" className="gap-2 text-sm data-[state=active]:bg-primary/10 data-[state=active]:text-primary">
              <ArrowDownToLine className="h-3.5 w-3.5" /> Deposit
            </TabsTrigger>
            <TabsTrigger value="withdraw" className="gap-2 text-sm data-[state=active]:bg-primary/10 data-[state=active]:text-primary">
              <ArrowUpFromLine className="h-3.5 w-3.5" /> Withdraw
            </TabsTrigger>
            <TabsTrigger value="history" className="gap-2 text-sm data-[state=active]:bg-primary/10 data-[state=active]:text-primary">
              <Clock className="h-3.5 w-3.5" /> History
            </TabsTrigger>
          </TabsList>

          {/* Deposit Tab */}
          <TabsContent value="deposit">
            <Card className="casino-card">
              <CardContent className="p-5 space-y-5">
                <div className="flex items-center gap-2 mb-1">
                  <ArrowDownToLine className="h-5 w-5 text-emerald-400" />
                  <h2 className="text-lg font-semibold">Deposit {currency}</h2>
                </div>

                <div>
                  <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">Currency</label>
                  <Select value={currency} onValueChange={(v: any) => setCurrency(v)}>
                    <SelectTrigger className="bg-muted/20 h-9 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                      <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                      <SelectItem value="USDT">Tether (USDT - ERC20)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {depositAddr && (
                  <div>
                    <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">
                      Send {currency} to this address
                    </label>
                    <div className="flex items-center gap-2">
                      <Input value={depositAddr.address} readOnly className="font-mono text-xs bg-muted/20 h-10" />
                      <button onClick={copyAddress} className="shrink-0 p-2.5 rounded-lg bg-muted/30 border border-border/30 hover:bg-muted/50 transition-colors">
                        {copied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4 text-muted-foreground" />}
                      </button>
                    </div>
                  </div>
                )}

                <div className="border-t border-border/20 pt-4">
                  <div className="flex items-start gap-2 p-3 rounded-lg bg-blue-500/5 border border-blue-500/15 mb-4">
                    <Shield className="h-4 w-4 text-blue-400 mt-0.5 shrink-0" />
                    <div className="text-[11px] text-muted-foreground space-y-1">
                      <p className="font-medium text-blue-400">How deposits work:</p>
                      <p>1. Send {currency} to the address above</p>
                      <p>2. After sending, paste your transaction hash below</p>
                      <p>3. Our team will verify the transaction on the blockchain</p>
                      <p>4. Once confirmed, your account will be credited</p>
                    </div>
                  </div>

                  <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">
                    Transaction Hash (TxID)
                  </label>
                  <Input
                    placeholder="Paste your blockchain transaction hash here..."
                    value={depositTxHash}
                    onChange={(e) => setDepositTxHash(e.target.value)}
                    className="bet-input h-10 font-mono text-xs mb-3"
                  />

                  <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">
                    Amount Sent
                  </label>
                  <Input
                    type="number"
                    placeholder={`Amount of ${currency} sent`}
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(e.target.value)}
                    className="bet-input h-10 mb-3"
                    step="0.0001"
                    min="0"
                  />

                  <button
                    onClick={() => {
                      if (!depositTxHash || depositTxHash.length < 10) {
                        toast.error("Please enter a valid transaction hash");
                        return;
                      }
                      if (!depositAmount || parseFloat(depositAmount) <= 0) {
                        toast.error("Please enter the amount you sent");
                        return;
                      }
                      depositMutation.mutate({
                        currency,
                        amount: parseFloat(depositAmount),
                        txHash: depositTxHash.trim(),
                      });
                    }}
                    disabled={depositMutation.isPending || !depositTxHash || !depositAmount}
                    className="bet-btn w-full h-12 text-base flex items-center justify-center gap-2"
                  >
                    {depositMutation.isPending ? (
                      <><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> Submitting...</>
                    ) : (
                      <><ArrowDownToLine className="h-4 w-4" /> Submit Deposit Claim</>
                    )}
                  </button>

                  {depositTxHash && depositTxHash.length > 10 && (
                    <a
                      href={`${currencyConfig[currency].explorer}${depositTxHash}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-1.5 mt-2 text-[11px] text-primary hover:text-primary/80 transition-colors"
                    >
                      <ExternalLink className="h-3 w-3" /> View on blockchain explorer
                    </a>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Withdraw Tab */}
          <TabsContent value="withdraw">
            <Card className="casino-card">
              <CardContent className="p-5 space-y-4">
                <div className="flex items-center gap-2 mb-1">
                  <ArrowUpFromLine className="h-5 w-5 text-red-400" />
                  <h2 className="text-lg font-semibold">Withdraw {currency}</h2>
                </div>

                <div className="p-3 rounded-lg bg-muted/20 border border-border/30 flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Available Balance</span>
                  <span className="font-mono font-bold">{currentBalance.toFixed(currency === "BTC" ? 8 : 4)} {currency}</span>
                </div>

                <div>
                  <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">Currency</label>
                  <Select value={currency} onValueChange={(v: any) => setCurrency(v)}>
                    <SelectTrigger className="bg-muted/20 h-9 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                      <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                      <SelectItem value="USDT">Tether (USDT - ERC20)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">
                    Your {currency === "BTC" ? "BTC" : "ETH/ERC-20"} Wallet Address
                  </label>
                  <Input
                    placeholder={currency === "BTC" ? "bc1q..." : "0x..."}
                    value={withdrawAddress}
                    onChange={(e) => setWithdrawAddress(e.target.value)}
                    className="bet-input h-10 font-mono text-xs"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Amount</label>
                    <button onClick={() => setWithdrawAmount(String(currentBalance))} className="text-[10px] text-primary hover:text-primary/80 font-medium">MAX</button>
                  </div>
                  <Input type="number" placeholder="0.00" value={withdrawAmount} onChange={(e) => setWithdrawAmount(e.target.value)} className="bet-input h-10" step="0.01" min="0" />
                </div>

                <div className="flex items-start gap-2 p-2.5 rounded-lg bg-amber-500/5 border border-amber-500/15">
                  <AlertTriangle className="h-3.5 w-3.5 text-amber-400 mt-0.5 shrink-0" />
                  <div className="text-[11px] text-muted-foreground">
                    <p>Withdrawals require manual admin approval before processing. Funds will be deducted from your balance immediately and sent from our house wallet after approval.</p>
                    <p className="mt-1 font-medium text-amber-400">Double-check your wallet address - transactions cannot be reversed.</p>
                  </div>
                </div>

                <button
                  onClick={() => {
                    if (parseFloat(withdrawAmount) > 0 && withdrawAddress.length >= 10) {
                      withdrawMutation.mutate({ currency, amount: parseFloat(withdrawAmount), toAddress: withdrawAddress });
                    } else {
                      toast.error("Please enter a valid amount and wallet address");
                    }
                  }}
                  disabled={withdrawMutation.isPending || !withdrawAmount || !withdrawAddress}
                  className="bet-btn w-full h-12 text-base flex items-center justify-center gap-2"
                >
                  {withdrawMutation.isPending ? (
                    <><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> Processing...</>
                  ) : (
                    <><ArrowUpFromLine className="h-4 w-4" /> Request Withdrawal</>
                  )}
                </button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history">
            <div className="space-y-4">
              <Card className="casino-card">
                <CardContent className="p-5">
                  <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                    <Clock className="h-4 w-4 text-primary" /> Transactions
                  </h3>
                  {transactions && transactions.length > 0 ? (
                    <div className="space-y-1.5">
                      {transactions.map((tx: any, i: number) => (
                        <div key={i} className="flex items-center justify-between p-2.5 rounded-lg bg-muted/20 border border-border/20">
                          <div className="flex items-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${
                              tx.type === "deposit" || tx.type === "game_win" || tx.type === "bonus" ? "bg-emerald-400" : "bg-red-400"
                            }`} />
                            <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${
                              tx.type === "deposit" ? "bg-emerald-500/15 text-emerald-400" :
                              tx.type === "withdrawal" ? "bg-red-500/15 text-red-400" :
                              tx.type === "game_win" ? "bg-green-500/15 text-green-400" :
                              tx.type === "bonus" ? "bg-purple-500/15 text-purple-400" :
                              "bg-blue-500/15 text-blue-400"
                            }`}>
                              {tx.type}
                            </span>
                            <span className="text-xs text-muted-foreground">{tx.currency}</span>
                            {tx.status === "pending_verification" && (
                              <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-500/15 text-amber-400 font-medium">Pending Verification</span>
                            )}
                          </div>
                          <span className={`font-mono text-xs font-medium ${
                            tx.type === "deposit" || tx.type === "game_win" || tx.type === "bonus" ? "text-emerald-400" : "text-red-400"
                          }`}>
                            {tx.type === "deposit" || tx.type === "game_win" || tx.type === "bonus" ? "+" : "-"}{parseFloat(tx.amount || "0").toFixed(4)}
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground text-sm">No transactions yet</div>
                  )}
                </CardContent>
              </Card>

              <Card className="casino-card">
                <CardContent className="p-5">
                  <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                    <ArrowUpFromLine className="h-4 w-4 text-red-400" /> Withdrawal Requests
                  </h3>
                  {withdrawals && withdrawals.length > 0 ? (
                    <div className="space-y-1.5">
                      {withdrawals.map((wd: any, i: number) => (
                        <div key={i} className="flex items-center justify-between p-2.5 rounded-lg bg-muted/20 border border-border/20">
                          <div className="flex items-center gap-2">
                            <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${
                              wd.status === "completed" ? "bg-emerald-500/15 text-emerald-400" :
                              wd.status === "pending" ? "bg-amber-500/15 text-amber-400" :
                              wd.status === "processing" ? "bg-blue-500/15 text-blue-400" :
                              "bg-red-500/15 text-red-400"
                            }`}>
                              {wd.status}
                            </span>
                            <span className="text-xs text-muted-foreground">{wd.currency}</span>
                          </div>
                          <div className="text-right">
                            <span className="font-mono text-xs font-medium text-red-400">-{parseFloat(wd.amount || "0").toFixed(4)}</span>
                            <p className="text-[10px] text-muted-foreground/60 font-mono truncate max-w-[120px]">{wd.toAddress}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground text-sm">No withdrawal requests</div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </CasinoLayout>
  );
}
