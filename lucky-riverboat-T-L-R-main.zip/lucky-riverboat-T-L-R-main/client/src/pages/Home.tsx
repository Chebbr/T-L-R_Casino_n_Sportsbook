import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { useAudio } from "@/hooks/useAudio";
import {
  Zap, Shield, Crown, Gift, Wallet, TrendingUp,
  Target, Waves, CircleDot, Anchor, Ship, Gem, Spade,
  Gamepad2, ArrowRight, Star, Users, Trophy, Percent,
  ExternalLink, Play, Volume2,
} from "lucide-react";
import { useState } from "react";

const XEBB_PHOTO = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663340758289/ToxIpleDWKEuJVwx.jpg";
const INFOGRAPHIC = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663340758289/DbgWYtIkckZLXjQw.png";
const VIDEO_TLR = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663340758289/kNhkYinGBsOGseoC.mp4";
const VIDEO_UNTITLED = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663340758289/RsmTRBFuXsBLXofB.mp4";

const houseGames = [
  { name: "Riverboat Keno", path: "/games/keno", icon: Target, color: "from-blue-500/20 to-blue-600/5", iconColor: "text-blue-400", desc: "Pick your lucky numbers" },
  { name: "Beached (Crash)", path: "/games/crash", icon: Waves, color: "from-cyan-500/20 to-cyan-600/5", iconColor: "text-cyan-400", desc: "Ride the wave up" },
  { name: "Roulette", path: "/games/roulette", icon: CircleDot, color: "from-red-500/20 to-red-600/5", iconColor: "text-red-400", desc: "Spin the wheel" },
  { name: "Helm Spin", path: "/games/helm", icon: Anchor, color: "from-amber-500/20 to-amber-600/5", iconColor: "text-amber-400", desc: "Spin for multipliers" },
  { name: "Walk the Plank", path: "/games/tower", icon: Ship, color: "from-emerald-500/20 to-emerald-600/5", iconColor: "text-emerald-400", desc: "Climb the tower" },
  { name: "Hidden Treasure", path: "/games/mines", icon: Gem, color: "from-purple-500/20 to-purple-600/5", iconColor: "text-purple-400", desc: "Find the gems" },
  { name: "Hitide Lowtide", path: "/games/hilow", icon: Spade, color: "from-pink-500/20 to-pink-600/5", iconColor: "text-pink-400", desc: "Higher or lower?" },
];

const features = [
  { icon: Percent, title: "0% House Edge", desc: "We don't take a cut. Every game runs at true odds. Your wins are your wins, period.", color: "text-green-400" },
  { icon: Shield, title: "Provably Fair", desc: "Every game outcome is cryptographically verifiable. Full transparency, zero manipulation.", color: "text-blue-400" },
  { icon: Zap, title: "Crypto Payouts", desc: "Deposit BTC, ETH, or USDT. Withdrawals processed directly to your wallet after admin approval.", color: "text-yellow-400" },
  { icon: Crown, title: "VIP Rewards", desc: "5-tier VIP program with escalating cashback, deposit bonuses, and exclusive weekly rewards.", color: "text-purple-400" },
];

const providers = [
  { name: "Hacksaw Gaming", count: "50+ Slots" },
  { name: "Pragmatic Play", count: "80+ Slots" },
  { name: "Massive Studios", count: "30+ Slots" },
  { name: "Lady Shady", count: "25+ Slots" },
];

const stagger = {
  container: { hidden: {}, show: { transition: { staggerChildren: 0.08 } } },
  item: { hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0, transition: { duration: 0.5 } } },
};

export default function Home() {
  const { user } = useAuth();
  const { play } = useAudio();
  const [activeVideo, setActiveVideo] = useState<string | null>(null);

  return (
    <CasinoLayout>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-hero-gradient">
        <div className="absolute top-20 left-[10%] w-[400px] h-[400px] rounded-full bg-primary/[0.04] blur-[100px] pointer-events-none" />
        <div className="absolute bottom-0 right-[15%] w-[300px] h-[300px] rounded-full bg-purple-500/[0.03] blur-[80px] pointer-events-none" />

        <div className="container py-16 md:py-24 lg:py-32 relative z-10">
          <div className="max-w-3xl">
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, ease: "easeOut" }}>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-green-500/10 border border-green-500/20 mb-6">
                <Percent className="h-3.5 w-3.5 text-green-400" />
                <span className="text-xs font-medium text-green-400">0% House Edge - True Odds Casino</span>
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.1] mb-5">
                <span className="text-foreground">Play. Win. </span>
                <span className="text-gradient-gold">Keep Everything.</span>
              </h1>
              <p className="text-base sm:text-lg text-muted-foreground max-w-xl leading-relaxed mb-8">
                The only crypto casino with <strong className="text-green-400">0% house edge</strong>. 7 provably fair house games, 185+ slots, live sportsbook, and instant crypto payouts. No hidden fees. No rigged odds.
              </p>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }} className="flex flex-wrap items-center gap-3">
              {user ? (
                <>
                  <Link href="/games/crash">
                    <Button size="lg" className="h-12 px-8 text-sm font-semibold bg-primary hover:bg-primary/90 gap-2" onClick={() => play("click")}>
                      Play Now <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="/wallet">
                    <Button size="lg" variant="outline" className="h-12 px-8 text-sm font-semibold border-border/50 bg-transparent gap-2">
                      <Wallet className="h-4 w-4" /> Deposit
                    </Button>
                  </Link>
                </>
              ) : (
                <>
                  <Button asChild size="lg" className="h-12 px-8 text-sm font-semibold bg-primary hover:bg-primary/90 gap-2" onClick={() => play("click")}>
                    <a href={getLoginUrl()}>Get Started <ArrowRight className="h-4 w-4" /></a>
                  </Button>
                  <Link href="/games/crash">
                    <Button size="lg" variant="outline" className="h-12 px-8 text-sm font-semibold border-border/50 bg-transparent">
                      Explore Games
                    </Button>
                  </Link>
                </>
              )}
            </motion.div>

            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }} className="flex flex-wrap items-center gap-6 mt-10 text-xs text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Percent className="h-3.5 w-3.5 text-green-400" />
                <span className="text-green-400 font-semibold">0% House Edge</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Users className="h-3.5 w-3.5 text-green-400" />
                <span>2,400+ Players</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Trophy className="h-3.5 w-3.5 text-primary" />
                <span>$1.2M+ Paid Out</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Shield className="h-3.5 w-3.5 text-blue-400" />
                <span>Provably Fair</span>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 0% House Edge Banner */}
      <section className="py-12 relative overflow-hidden" style={{ background: "linear-gradient(135deg, oklch(0.14 0.04 145) 0%, oklch(0.11 0.02 160) 50%, oklch(0.13 0.03 130) 100%)" }}>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,oklch(0.3_0.08_145/0.15),transparent_60%)]" />
        <div className="container relative z-10">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center">
            <div className="inline-flex items-center gap-3 px-6 py-3 rounded-2xl bg-green-500/10 border border-green-500/20 mb-6">
              <Percent className="h-8 w-8 text-green-400" />
              <span className="text-3xl font-bold text-green-400">0% HOUSE EDGE</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-bold mb-3">We Don't Take a Cut. Ever.</h2>
            <p className="text-sm text-muted-foreground max-w-lg mx-auto leading-relaxed mb-6">
              Unlike every other casino that skims 1-15% off every bet, Lucky Riverboat runs at true mathematical odds. When you win, you keep 100% of your winnings. No hidden margins. No rigged RTP. Just pure, fair gambling.
            </p>
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              <div className="p-3 rounded-xl bg-green-500/5 border border-green-500/15">
                <p className="text-2xl font-bold text-green-400">0%</p>
                <p className="text-[10px] text-muted-foreground">House Edge</p>
              </div>
              <div className="p-3 rounded-xl bg-green-500/5 border border-green-500/15">
                <p className="text-2xl font-bold text-green-400">100%</p>
                <p className="text-[10px] text-muted-foreground">Fair RTP</p>
              </div>
              <div className="p-3 rounded-xl bg-green-500/5 border border-green-500/15">
                <p className="text-2xl font-bold text-green-400">24/7</p>
                <p className="text-[10px] text-muted-foreground">Provably Fair</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* House Games Grid */}
      <section className="bg-section-alt py-16">
        <div className="container">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl font-bold mb-1">House Games</h2>
              <p className="text-sm text-muted-foreground">7 exclusive provably fair games with 0% house edge</p>
            </div>
            <Link href="/games/crash">
              <Button variant="ghost" size="sm" className="gap-1 text-xs text-muted-foreground hover:text-primary">
                View All <ArrowRight className="h-3 w-3" />
              </Button>
            </Link>
          </div>

          <motion.div variants={stagger.container} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-50px" }} className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-3">
            {houseGames.map((game) => (
              <motion.div key={game.path} variants={stagger.item}>
                <Link href={game.path}>
                  <div className="game-tile group p-4 h-full" onClick={() => play("click")}>
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${game.color} flex items-center justify-center mb-3 transition-transform duration-300 group-hover:scale-110`}>
                      <game.icon className={`h-5 w-5 ${game.iconColor}`} />
                    </div>
                    <h3 className="text-sm font-semibold mb-0.5 leading-tight">{game.name}</h3>
                    <p className="text-[11px] text-muted-foreground">{game.desc}</p>
                  </div>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Meet Xebb Section */}
      <section className="py-16 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] rounded-full bg-primary/[0.03] blur-[100px] pointer-events-none" />
        <div className="container relative z-10">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            {/* Photo */}
            <div className="relative">
              <div className="rounded-2xl overflow-hidden border border-border/40 shadow-2xl">
                <img src={XEBB_PHOTO} alt="Xebb - Founder of Lucky Riverboat Casino" className="w-full h-auto object-cover" loading="lazy" />
              </div>
              <div className="absolute -bottom-3 -right-3 px-4 py-2 rounded-xl bg-primary/10 border border-primary/30 backdrop-blur-sm">
                <span className="text-xs font-bold text-primary">The Lucky Riverboat Casino</span>
              </div>
            </div>

            {/* Bio */}
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-2">
                <span className="text-gradient-gold">Meet Xebb</span>
              </h2>
              <p className="text-lg font-semibold text-muted-foreground mb-5">Founder &amp; Degenerate Gambler</p>

              <div className="space-y-4 text-sm text-muted-foreground leading-relaxed">
                <p>
                  I'm Xebb &mdash; lover of sexy women, my dog and cat, a little Adderall when the grind calls, and most of all... degenerate gambling.
                </p>
                <p>
                  I stream the madness live on{" "}
                  <a href="https://kick.com/x3bb3r" target="_blank" rel="noopener noreferrer" className="text-primary hover:text-primary/80 font-semibold inline-flex items-center gap-1">
                    Kick.com/x3bb3r <ExternalLink className="h-3 w-3" />
                  </a>{" "}
                  &mdash; slots, parlays, and whatever hits. The chat's always lit, the bets are reckless, and the vibe never clocks out.
                </p>
                <p>
                  I built Lucky Riverboat because I was tired of casinos skimming my wins. <strong className="text-green-400">0% house edge</strong> means when you win, you actually win. No BS. No hidden margins. Just pure gambling the way it should be.
                </p>
              </div>

              <div className="flex flex-wrap gap-3 mt-6">
                <a href="https://kick.com/x3bb3r" target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" className="gap-2 border-primary/30 text-primary hover:bg-primary/10">
                    <Play className="h-4 w-4" /> Watch Live on Kick
                  </Button>
                </a>
                {user ? (
                  <Link href="/games/crash">
                    <Button className="bg-primary hover:bg-primary/90 gap-2" onClick={() => play("click")}>
                      Start Playing <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                ) : (
                  <Button asChild className="bg-primary hover:bg-primary/90 gap-2">
                    <a href={getLoginUrl()}>Join Now <ArrowRight className="h-4 w-4" /></a>
                  </Button>
                )}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Commercial Videos Section */}
      <section className="bg-section-alt py-16">
        <div className="container">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold mb-2">See It In Action</h2>
            <p className="text-sm text-muted-foreground">Watch what Lucky Riverboat is all about</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <Card className="casino-card overflow-hidden">
                <div className="relative aspect-video bg-black rounded-t-xl overflow-hidden">
                  <video
                    src={VIDEO_TLR}
                    controls
                    preload="metadata"
                    playsInline
                    className="w-full h-full object-cover"
                    poster={XEBB_PHOTO}
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="text-sm font-semibold flex items-center gap-2">
                    <Volume2 className="h-4 w-4 text-primary" /> The Lucky Riverboat
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1">Official casino promo</p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
              <Card className="casino-card overflow-hidden">
                <div className="relative aspect-video bg-black rounded-t-xl overflow-hidden">
                  <video
                    src={VIDEO_UNTITLED}
                    controls
                    preload="metadata"
                    playsInline
                    className="w-full h-full object-cover"
                    poster={XEBB_PHOTO}
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="text-sm font-semibold flex items-center gap-2">
                    <Volume2 className="h-4 w-4 text-primary" /> Lucky Riverboat Highlights
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1">Big wins and wild moments</p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Slots Providers */}
      <section className="py-16">
        <div className="container">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl font-bold mb-1">Slots</h2>
              <p className="text-sm text-muted-foreground">185+ slots from world-class providers</p>
            </div>
            <Link href="/slots">
              <Button variant="ghost" size="sm" className="gap-1 text-xs text-muted-foreground hover:text-primary">
                Slots Lobby <ArrowRight className="h-3 w-3" />
              </Button>
            </Link>
          </div>

          <motion.div variants={stagger.container} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-50px" }} className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {providers.map((provider) => (
              <motion.div key={provider.name} variants={stagger.item}>
                <Link href="/slots">
                  <Card className="casino-card group cursor-pointer" onClick={() => play("click")}>
                    <CardContent className="p-5 text-center">
                      <Gamepad2 className="h-8 w-8 mx-auto mb-3 text-primary/60 group-hover:text-primary transition-colors" />
                      <h3 className="text-sm font-semibold mb-1">{provider.name}</h3>
                      <p className="text-xs text-muted-foreground">{provider.count}</p>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Sportsbook Promo */}
      <section className="bg-section-alt py-16">
        <div className="container">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            className="relative overflow-hidden rounded-2xl border border-border/40"
            style={{ background: "linear-gradient(135deg, oklch(0.15 0.02 265) 0%, oklch(0.12 0.015 265) 50%, oklch(0.14 0.02 200) 100%)" }}>
            <div className="absolute top-0 right-0 w-[300px] h-[300px] rounded-full bg-primary/[0.04] blur-[80px] pointer-events-none" />
            <div className="p-8 md:p-12 relative z-10">
              <div className="max-w-lg">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-green-500/10 border border-green-500/20 mb-4">
                  <TrendingUp className="h-3.5 w-3.5 text-green-400" />
                  <span className="text-xs font-medium text-green-400">Live Sportsbook</span>
                </div>
                <h2 className="text-2xl md:text-3xl font-bold mb-3">Bet on Your Favorite Sports</h2>
                <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
                  Football, basketball, soccer, MMA, esports, and more. Competitive odds, live betting, and instant crypto payouts.
                </p>
                <Link href="/sportsbook">
                  <Button className="bg-primary hover:bg-primary/90 gap-2" onClick={() => play("click")}>
                    <TrendingUp className="h-4 w-4" /> View Sportsbook
                  </Button>
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16">
        <div className="container">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold mb-2">Why Lucky Riverboat?</h2>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">The only crypto casino built for players, not profits.</p>
          </div>

          <motion.div variants={stagger.container} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-50px" }} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {features.map((feature) => (
              <motion.div key={feature.title} variants={stagger.item}>
                <Card className="casino-card h-full">
                  <CardContent className="p-5">
                    <feature.icon className={`h-8 w-8 ${feature.color} mb-3`} />
                    <h3 className="text-sm font-semibold mb-1.5">{feature.title}</h3>
                    <p className="text-xs text-muted-foreground leading-relaxed">{feature.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Infographic Section */}
      <section className="bg-section-alt py-16">
        <div className="container">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">The Lucky Riverboat Difference</h2>
              <p className="text-sm text-muted-foreground">See why players are switching to 0% house edge</p>
            </div>
            <div className="rounded-2xl overflow-hidden border border-border/40 shadow-xl">
              <img src={INFOGRAPHIC} alt="Lucky Riverboat Casino - 0% House Edge Infographic" className="w-full h-auto" loading="lazy" />
            </div>
          </motion.div>
        </div>
      </section>

      {/* VIP CTA */}
      <section className="py-16">
        <div className="container">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            className="relative overflow-hidden rounded-2xl border border-primary/20"
            style={{ background: "linear-gradient(135deg, oklch(0.16 0.03 85 / 0.3) 0%, oklch(0.12 0.015 265) 50%, oklch(0.14 0.02 300 / 0.2) 100%)" }}>
            <div className="absolute top-0 left-[20%] w-[200px] h-[200px] rounded-full bg-primary/[0.06] blur-[60px] pointer-events-none" />
            <div className="p-8 md:p-12 text-center relative z-10">
              <Crown className="h-10 w-10 text-primary mx-auto mb-4" />
              <h2 className="text-2xl md:text-3xl font-bold mb-3">
                Join the <span className="text-gradient-gold">VIP Club</span>
              </h2>
              <p className="text-sm text-muted-foreground max-w-md mx-auto mb-6 leading-relaxed">
                5 exclusive tiers from Bronze to Diamond. Earn cashback up to 5%, deposit bonuses up to 20%, weekly rewards, and level-up bonuses.
              </p>
              <div className="flex flex-wrap justify-center gap-3 mb-6">
                {["Bronze", "Silver", "Gold", "Platinum", "Diamond"].map((tier, i) => (
                  <div key={tier} className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-muted/30 border border-border/30 text-xs font-medium">
                    <Star className={`h-3 w-3 ${i === 0 ? "text-amber-600" : i === 1 ? "text-gray-400" : i === 2 ? "text-yellow-400" : i === 3 ? "text-cyan-300" : "text-purple-400"}`} />
                    {tier}
                  </div>
                ))}
              </div>
              <Link href="/vip">
                <Button className="bg-primary hover:bg-primary/90 gap-2" onClick={() => play("click")}>
                  <Crown className="h-4 w-4" /> Explore VIP
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Referral CTA */}
      <section className="bg-section-alt py-16">
        <div className="container text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <Gift className="h-10 w-10 text-pink-400 mx-auto mb-4" />
            <h2 className="text-2xl md:text-3xl font-bold mb-3">Refer Friends, Earn Rewards</h2>
            <p className="text-sm text-muted-foreground max-w-md mx-auto mb-6">
              Share your unique referral link and earn commission on every bet your friends place. The more they play, the more you earn.
            </p>
            <Link href="/referrals">
              <Button className="bg-primary hover:bg-primary/90 gap-2" onClick={() => play("click")}>
                <Gift className="h-4 w-4" /> Get Your Referral Link
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20">
        <div className="container text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Ready to <span className="text-gradient-gold">Set Sail</span>?
            </h2>
            <p className="text-sm text-muted-foreground max-w-md mx-auto mb-8">
              Create your account in seconds. Deposit crypto and start playing with 0% house edge.
            </p>
            {user ? (
              <Link href="/games/crash">
                <Button size="lg" className="h-12 px-10 text-sm font-semibold bg-primary hover:bg-primary/90 gap-2 neon-pulse">
                  Start Playing <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            ) : (
              <Button asChild size="lg" className="h-12 px-10 text-sm font-semibold bg-primary hover:bg-primary/90 gap-2 neon-pulse">
                <a href={getLoginUrl()}>Create Account <ArrowRight className="h-4 w-4" /></a>
              </Button>
            )}
          </motion.div>
        </div>
      </section>
    </CasinoLayout>
  );
}
