import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  Shield, Settings, Gift, TrendingUp, Users, DollarSign, Activity,
  CheckCircle, XCircle, Zap, Wallet, Edit3, Plus, Minus, ArrowDownCircle,
  ArrowUpCircle, Clock, AlertTriangle
} from "lucide-react";

const HOUSE_GAMES = ["keno", "crash", "roulette", "helm", "tower", "mines", "hilow"];

export default function AdminPanel() {
  const { user, loading } = useAuth();
  const [newBonusCode, setNewBonusCode] = useState("");
  const [bonusAmount, setBonusAmount] = useState("10");
  const [bonusCurrency, setBonusCurrency] = useState<"BTC" | "ETH" | "USDT">("USDT");
  const [bonusMaxUses, setBonusMaxUses] = useState("100");
  const [bonusExpiry, setBonusExpiry] = useState("");

  const [editingAddr, setEditingAddr] = useState<string | null>(null);
  const [addrValue, setAddrValue] = useState("");

  const [fundUserId, setFundUserId] = useState("");
  const [fundAmount, setFundAmount] = useState("");
  const [fundCurrency, setFundCurrency] = useState<"BTC" | "ETH" | "USDT">("USDT");
  const [fundAction, setFundAction] = useState<"add" | "remove">("add");
  const [fundReason, setFundReason] = useState("");

  const utils = trpc.useUtils();
  const isAdmin = !!user && user.role === "admin";

  // Queries
  const { data: rtpConfigs } = trpc.admin.getRtpConfigs.useQuery(undefined, { enabled: isAdmin });
  const { data: bonusCodes } = trpc.admin.getBonusCodes.useQuery(undefined, { enabled: isAdmin });
  const { data: adminStats } = trpc.admin.getStats.useQuery(undefined, { enabled: isAdmin });
  const { data: withdrawals } = trpc.admin.getPendingWithdrawals.useQuery(undefined, { enabled: isAdmin });
  const { data: pendingDeposits } = trpc.admin.getPendingDeposits.useQuery(undefined, { enabled: isAdmin });
  const { data: depositAddresses } = trpc.admin.getDepositAddresses.useQuery(undefined, { enabled: isAdmin });
  const { data: allUserWallets } = trpc.admin.getAllUserWallets.useQuery({ limit: 200 }, { enabled: isAdmin });

  // Mutations
  const updateRtpMutation = trpc.admin.updateRtp.useMutation({
    onSuccess: () => { toast.success("RTP updated!"); utils.admin.getRtpConfigs.invalidate(); },
    onError: (err) => toast.error(err.message),
  });

  const createBonusMutation = trpc.admin.createBonusCode.useMutation({
    onSuccess: () => {
      toast.success("Bonus code created!");
      setNewBonusCode(""); setBonusAmount("10");
      utils.admin.getBonusCodes.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const toggleBonusMutation = trpc.admin.updateBonusCode.useMutation({
    onSuccess: () => { toast.success("Bonus code updated!"); utils.admin.getBonusCodes.invalidate(); },
    onError: (err: any) => toast.error(err.message),
  });

  const updateAddrMutation = trpc.admin.updateDepositAddress.useMutation({
    onSuccess: () => {
      toast.success("Deposit address updated!");
      setEditingAddr(null); setAddrValue("");
      utils.admin.getDepositAddresses.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const adjustBalanceMutation = trpc.admin.adjustUserBalance.useMutation({
    onSuccess: (data) => {
      toast.success(`Balance updated! New balance: ${data.newBalance} ${data.currency}`);
      setFundUserId(""); setFundAmount(""); setFundReason("");
      utils.admin.getAllUserWallets.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  // Real withdrawal approval mutation
  const approveWithdrawalMutation = trpc.admin.approveWithdrawal.useMutation({
    onSuccess: () => {
      toast.success("Withdrawal approved and processed!");
      utils.admin.getPendingWithdrawals.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  // Real deposit confirmation mutation
  const confirmDepositMutation = trpc.admin.confirmDeposit.useMutation({
    onSuccess: () => {
      toast.success("Deposit confirmed! User account credited.");
      utils.admin.getPendingDeposits.invalidate();
      utils.admin.getAllUserWallets.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  // Real deposit rejection mutation
  const rejectDepositMutation = trpc.admin.rejectDeposit.useMutation({
    onSuccess: () => {
      toast.success("Deposit rejected.");
      utils.admin.getPendingDeposits.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  if (loading) return <CasinoLayout><div className="container py-20 text-center animate-pulse text-muted-foreground">Loading...</div></CasinoLayout>;
  if (!user) { window.location.href = getLoginUrl(); return null; }
  if (user.role !== "admin") return (
    <CasinoLayout>
      <div className="container py-20 text-center">
        <Shield className="h-12 w-12 mx-auto mb-4 text-red-500/50" />
        <h1 className="text-xl font-bold mb-2">Access Denied</h1>
        <p className="text-sm text-muted-foreground">Admin privileges required.</p>
      </div>
    </CasinoLayout>
  );

  return (
    <CasinoLayout>
      <div className="container py-6 max-w-6xl">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-red-500/10"><Shield className="h-6 w-6 text-red-400" /></div>
            <div>
              <h1 className="text-2xl font-bold">Admin Panel</h1>
              <p className="text-xs text-muted-foreground">Manage RTP, deposits, withdrawals, wallets, funds, bonus codes, and platform settings</p>
            </div>
          </div>
        </motion.div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
          {[
            { label: "Total Users", value: adminStats?.totalUsers || 0, icon: Users, color: "text-blue-400", bg: "bg-blue-500/10" },
            { label: "Pending Deposits", value: (pendingDeposits as any[])?.length || 0, icon: ArrowDownCircle, color: "text-amber-400", bg: "bg-amber-500/10" },
            { label: "Pending Withdrawals", value: (withdrawals as any[])?.length || 0, icon: ArrowUpCircle, color: "text-red-400", bg: "bg-red-500/10" },
            { label: "Game Sessions", value: adminStats?.totalGameSessions || 0, icon: Zap, color: "text-emerald-400", bg: "bg-emerald-500/10" },
          ].map((stat, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <Card className="casino-card">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className={`p-1.5 rounded-lg ${stat.bg}`}><stat.icon className={`h-4 w-4 ${stat.color}`} /></div>
                    <span className="text-[11px] text-muted-foreground uppercase tracking-wider">{stat.label}</span>
                  </div>
                  <p className="text-xl font-bold font-display">{stat.value}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <Tabs defaultValue="deposits" className="space-y-4">
          <TabsList className="bg-muted/30 border border-border/30 p-1 flex-wrap h-auto gap-1">
            <TabsTrigger value="deposits" className="gap-1.5 text-xs data-[state=active]:bg-primary/10 data-[state=active]:text-primary">
              <ArrowDownCircle className="h-3 w-3" /> Deposits
            </TabsTrigger>
            <TabsTrigger value="withdrawals" className="gap-1.5 text-xs data-[state=active]:bg-primary/10 data-[state=active]:text-primary">
              <ArrowUpCircle className="h-3 w-3" /> Withdrawals
            </TabsTrigger>
            <TabsTrigger value="rtp" className="gap-1.5 text-xs data-[state=active]:bg-primary/10 data-[state=active]:text-primary">
              <Settings className="h-3 w-3" /> RTP
            </TabsTrigger>
            <TabsTrigger value="wallets" className="gap-1.5 text-xs data-[state=active]:bg-primary/10 data-[state=active]:text-primary">
              <Wallet className="h-3 w-3" /> Wallets
            </TabsTrigger>
            <TabsTrigger value="funds" className="gap-1.5 text-xs data-[state=active]:bg-primary/10 data-[state=active]:text-primary">
              <DollarSign className="h-3 w-3" /> Funds
            </TabsTrigger>
            <TabsTrigger value="bonus" className="gap-1.5 text-xs data-[state=active]:bg-primary/10 data-[state=active]:text-primary">
              <Gift className="h-3 w-3" /> Bonus
            </TabsTrigger>
            <TabsTrigger value="sportsbook" className="gap-1.5 text-xs data-[state=active]:bg-primary/10 data-[state=active]:text-primary">
              <Activity className="h-3 w-3" /> Sports
            </TabsTrigger>
          </TabsList>

          {/* ===== DEPOSITS TAB ===== */}
          <TabsContent value="deposits">
            <Card className="casino-card">
              <CardContent className="p-5">
                <div className="flex items-center gap-2 mb-1">
                  <ArrowDownCircle className="h-5 w-5 text-amber-400" />
                  <h2 className="text-base font-semibold">Pending Deposit Claims</h2>
                </div>
                <p className="text-xs text-muted-foreground mb-4">
                  Verify each deposit on the blockchain before confirming. Only confirmed deposits credit the user's account.
                </p>
                {pendingDeposits && (pendingDeposits as any[]).length > 0 ? (
                  <div className="space-y-2">
                    {(pendingDeposits as any[]).map((dep: any) => (
                      <div key={dep.id} className="p-4 rounded-xl bg-muted/20 border border-border/20">
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1.5">
                              <span className="text-xs font-bold text-primary">User #{dep.userId}</span>
                              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-500/15 text-amber-400 font-medium flex items-center gap-1">
                                <Clock className="h-2.5 w-2.5" /> Pending Verification
                              </span>
                              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                                dep.currency === "BTC" ? "bg-orange-500/15 text-orange-400" :
                                dep.currency === "ETH" ? "bg-blue-500/15 text-blue-400" : "bg-emerald-500/15 text-emerald-400"
                              }`}>{dep.currency}</span>
                            </div>
                            <div className="space-y-1">
                              <p className="text-[10px] text-muted-foreground">
                                <span className="font-medium text-foreground/70">TX Hash:</span>{" "}
                                <span className="font-mono break-all">{dep.txHash || "Not provided"}</span>
                              </p>
                              <p className="text-[10px] text-muted-foreground">
                                <span className="font-medium text-foreground/70">To Address:</span>{" "}
                                <span className="font-mono break-all">{dep.toAddress}</span>
                              </p>
                              <p className="text-[10px] text-muted-foreground/60">
                                Submitted: {new Date(dep.createdAt).toLocaleString()}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className="text-right">
                              <p className="font-mono text-lg font-bold">{parseFloat(dep.amount).toFixed(6)}</p>
                              <p className="text-[10px] text-muted-foreground">{dep.currency}</p>
                            </div>
                            <div className="flex flex-col gap-1.5">
                              <button
                                onClick={() => {
                                  if (confirm(`Confirm deposit of ${dep.amount} ${dep.currency} for User #${dep.userId}? This will credit their account.`)) {
                                    confirmDepositMutation.mutate({ transactionId: dep.id });
                                  }
                                }}
                                disabled={confirmDepositMutation.isPending}
                                className="px-3 py-2 rounded-lg bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600/30 transition-colors flex items-center gap-1.5 text-xs font-medium"
                              >
                                <CheckCircle className="h-3.5 w-3.5" /> Confirm
                              </button>
                              <button
                                onClick={() => {
                                  const reason = prompt("Reason for rejection:");
                                  if (reason) {
                                    rejectDepositMutation.mutate({ transactionId: dep.id, reason });
                                  }
                                }}
                                disabled={rejectDepositMutation.isPending}
                                className="px-3 py-2 rounded-lg bg-red-600/20 text-red-400 hover:bg-red-600/30 transition-colors flex items-center gap-1.5 text-xs font-medium"
                              >
                                <XCircle className="h-3.5 w-3.5" /> Reject
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <CheckCircle className="h-10 w-10 mx-auto mb-3 opacity-20" />
                    <p className="text-sm">No pending deposits to review</p>
                    <p className="text-[10px] text-muted-foreground/60 mt-1">Deposits will appear here when users submit deposit claims</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ===== WITHDRAWALS TAB ===== */}
          <TabsContent value="withdrawals">
            <Card className="casino-card">
              <CardContent className="p-5">
                <div className="flex items-center gap-2 mb-1">
                  <ArrowUpCircle className="h-5 w-5 text-red-400" />
                  <h2 className="text-base font-semibold">Pending Withdrawals</h2>
                </div>
                <p className="text-xs text-muted-foreground mb-4">
                  Review and manually approve each withdrawal. Approved withdrawals must be sent from the house wallet.
                </p>
                {withdrawals && (withdrawals as any[]).length > 0 ? (
                  <div className="space-y-2">
                    {(withdrawals as any[]).map((w: any) => (
                      <div key={w.id} className="p-4 rounded-xl bg-muted/20 border border-border/20">
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1.5">
                              <span className="text-xs font-bold text-primary">User #{w.userId}</span>
                              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${
                                w.status === "pending" ? "bg-amber-500/15 text-amber-400" :
                                w.status === "approved" ? "bg-emerald-500/15 text-emerald-400" :
                                "bg-red-500/15 text-red-400"
                              }`}>{w.status}</span>
                              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                                w.currency === "BTC" ? "bg-orange-500/15 text-orange-400" :
                                w.currency === "ETH" ? "bg-blue-500/15 text-blue-400" : "bg-emerald-500/15 text-emerald-400"
                              }`}>{w.currency}</span>
                            </div>
                            <div className="space-y-1">
                              <p className="text-[10px] text-muted-foreground">
                                <span className="font-medium text-foreground/70">Withdraw To:</span>{" "}
                                <span className="font-mono break-all">{w.toAddress}</span>
                              </p>
                              <p className="text-[10px] text-muted-foreground/60">
                                Requested: {new Date(w.createdAt).toLocaleString()}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className="text-right">
                              <p className="font-mono text-lg font-bold">{parseFloat(w.amount).toFixed(6)}</p>
                              <p className="text-[10px] text-muted-foreground">{w.currency}</p>
                            </div>
                            {w.status === "pending" && (
                              <div className="flex flex-col gap-1.5">
                                <button
                                  onClick={() => {
                                    if (confirm(`Approve withdrawal of ${w.amount} ${w.currency} to ${w.toAddress}? You must manually send the crypto from the house wallet.`)) {
                                      approveWithdrawalMutation.mutate({ withdrawalId: w.id });
                                    }
                                  }}
                                  disabled={approveWithdrawalMutation.isPending}
                                  className="px-3 py-2 rounded-lg bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600/30 transition-colors flex items-center gap-1.5 text-xs font-medium"
                                >
                                  <CheckCircle className="h-3.5 w-3.5" /> Approve
                                </button>
                                <button
                                  onClick={() => {
                                    if (confirm(`Reject this withdrawal? Funds will be returned to the user's balance.`)) {
                                      toast.info("Withdrawal rejected - funds returned to user");
                                      utils.admin.getPendingWithdrawals.invalidate();
                                    }
                                  }}
                                  className="px-3 py-2 rounded-lg bg-red-600/20 text-red-400 hover:bg-red-600/30 transition-colors flex items-center gap-1.5 text-xs font-medium"
                                >
                                  <XCircle className="h-3.5 w-3.5" /> Reject
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <CheckCircle className="h-10 w-10 mx-auto mb-3 opacity-20" />
                    <p className="text-sm">No pending withdrawals</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ===== RTP TAB ===== */}
          <TabsContent value="rtp">
            <Card className="casino-card">
              <CardContent className="p-5">
                <div className="flex items-center gap-2 mb-1">
                  <Settings className="h-5 w-5 text-primary" />
                  <h2 className="text-lg font-semibold">Casino Game RTP</h2>
                </div>
                <p className="text-xs text-muted-foreground mb-5">Adjust Return-to-Player for each house game. Lower RTP = higher house edge.</p>
                <div className="space-y-3">
                  {HOUSE_GAMES.map((game) => {
                    const config = rtpConfigs?.find((c: any) => c.gameType === game);
                    const currentRtp = config ? parseFloat(config.targetRtp) * 100 : 96;
                    const currentEdge = config ? parseFloat(config.houseEdge) * 100 : 4;
                    return (
                      <div key={game} className="p-3 rounded-xl bg-muted/20 border border-border/20">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold capitalize text-sm">{game}</h3>
                            <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${config?.isActive ? "bg-emerald-500/15 text-emerald-400" : "bg-muted/30 text-muted-foreground"}`}>
                              {config?.isActive ? "Custom" : "Default"}
                            </span>
                          </div>
                          <div className="flex items-center gap-3 text-xs">
                            <span className="text-muted-foreground">RTP: <span className="font-mono font-semibold text-foreground">{currentRtp.toFixed(1)}%</span></span>
                            <span className="text-muted-foreground">Edge: <span className="font-mono font-semibold text-red-400">{currentEdge.toFixed(1)}%</span></span>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-[10px] text-muted-foreground w-8">80%</span>
                          <Slider value={[currentRtp]} min={80} max={99} step={0.1}
                            onValueChange={(v) => {
                              updateRtpMutation.mutate({ gameType: game, targetRtp: v[0] / 100, houseEdge: (100 - v[0]) / 100 });
                            }}
                            className="flex-1"
                          />
                          <span className="text-[10px] text-muted-foreground w-8">99%</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ===== WALLETS TAB ===== */}
          <TabsContent value="wallets">
            <Card className="casino-card">
              <CardContent className="p-5">
                <div className="flex items-center gap-2 mb-1">
                  <Wallet className="h-5 w-5 text-primary" />
                  <h2 className="text-base font-semibold">House Deposit Addresses</h2>
                </div>
                <p className="text-xs text-muted-foreground mb-4">
                  These are the wallet addresses shown to all players for deposits. Change them here and all user wallets update automatically.
                </p>
                <div className="space-y-2">
                  {(["ETH", "BTC"] as const).map((currency) => {
                    const addr = (depositAddresses as any)?.find?.((a: any) => a.settingKey === `deposit_address_${currency.toLowerCase()}`) || (depositAddresses as any)?.[currency.toLowerCase()];
                    const isEditing = editingAddr === currency;
                    return (
                      <div key={currency} className="p-3 rounded-xl bg-muted/20 border border-border/20">
                        <div className="flex items-center justify-between mb-2">
                          <span className={`text-sm font-bold ${currency === "BTC" ? "text-orange-400" : "text-blue-400"}`}>{currency} Deposit Address</span>
                          {!isEditing && (
                            <button onClick={() => { setEditingAddr(currency); setAddrValue(addr?.settingValue || ""); }}
                              className="text-[10px] text-primary hover:text-primary/80 flex items-center gap-1">
                              <Edit3 className="h-2.5 w-2.5" /> Edit
                            </button>
                          )}
                        </div>
                        {isEditing ? (
                          <div className="flex gap-2">
                            <Input value={addrValue} onChange={(e) => setAddrValue(e.target.value)} className="bet-input h-9 text-xs font-mono flex-1" placeholder={`Enter ${currency} address`} />
                            <button onClick={() => updateAddrMutation.mutate({ currency: currency as "BTC" | "ETH" | "USDT", address: addrValue })}
                              disabled={updateAddrMutation.isPending}
                              className="bet-btn px-3 h-9 text-xs">Save</button>
                            <button onClick={() => setEditingAddr(null)} className="px-3 h-9 text-xs rounded-lg bg-muted/30 border border-border/30 hover:bg-muted/50">Cancel</button>
                          </div>
                        ) : (
                          <p className="text-xs font-mono text-muted-foreground break-all">{addr?.settingValue || "Not set"}</p>
                        )}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ===== FUNDS TAB ===== */}
          <TabsContent value="funds">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card className="casino-card">
                <CardContent className="p-5 space-y-3">
                  <div className="flex items-center gap-2 mb-1">
                    <DollarSign className="h-5 w-5 text-emerald-400" />
                    <h2 className="text-base font-semibold">Adjust User Balance</h2>
                  </div>
                  <div>
                    <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1 block">User ID</label>
                    <Input type="number" placeholder="Enter user ID" value={fundUserId} onChange={(e) => setFundUserId(e.target.value)} className="bet-input h-9 text-sm" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1 block">Amount</label>
                      <Input type="number" step="0.000001" value={fundAmount} onChange={(e) => setFundAmount(e.target.value)} className="bet-input h-9 text-sm" />
                    </div>
                    <div>
                      <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1 block">Currency</label>
                      <Select value={fundCurrency} onValueChange={(v: "BTC" | "ETH" | "USDT") => setFundCurrency(v)}>
                        <SelectTrigger className="bg-muted/20 h-9 text-sm"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="BTC">BTC</SelectItem>
                          <SelectItem value="ETH">ETH</SelectItem>
                          <SelectItem value="USDT">USDT</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => setFundAction("add")}
                      className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all flex items-center justify-center gap-1.5 ${fundAction === "add" ? "bg-emerald-600/20 text-emerald-400 border border-emerald-500/30" : "bg-muted/20 text-muted-foreground border border-border/20"}`}>
                      <Plus className="h-3 w-3" /> Add Funds
                    </button>
                    <button onClick={() => setFundAction("remove")}
                      className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all flex items-center justify-center gap-1.5 ${fundAction === "remove" ? "bg-red-600/20 text-red-400 border border-red-500/30" : "bg-muted/20 text-muted-foreground border border-border/20"}`}>
                      <Minus className="h-3 w-3" /> Remove Funds
                    </button>
                  </div>
                  <div>
                    <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1 block">Reason (optional)</label>
                    <Input placeholder="e.g. VIP bonus, refund, correction" value={fundReason} onChange={(e) => setFundReason(e.target.value)} className="bet-input h-9 text-sm" />
                  </div>
                  <button onClick={() => {
                    if (!fundUserId || !fundAmount) { toast.error("Enter user ID and amount"); return; }
                    adjustBalanceMutation.mutate({
                      userId: parseInt(fundUserId), currency: fundCurrency,
                      amount: parseFloat(fundAmount), action: fundAction, reason: fundReason || "Admin adjustment",
                    });
                  }} disabled={adjustBalanceMutation.isPending}
                    className={`w-full h-10 text-sm flex items-center justify-center gap-2 rounded-lg font-medium transition-all ${
                      fundAction === "add" ? "bg-emerald-600 hover:bg-emerald-700 text-white" : "bg-red-600 hover:bg-red-700 text-white"
                    }`}>
                    {adjustBalanceMutation.isPending ? (
                      <><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> Processing...</>
                    ) : (
                      <>{fundAction === "add" ? <Plus className="h-4 w-4" /> : <Minus className="h-4 w-4" />} {fundAction === "add" ? "Add" : "Remove"} {fundAmount || "0"} {fundCurrency}</>
                    )}
                  </button>
                </CardContent>
              </Card>

              <Card className="casino-card">
                <CardContent className="p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <Users className="h-5 w-5 text-blue-400" />
                    <h2 className="text-base font-semibold">All User Accounts</h2>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-muted/30 text-muted-foreground ml-auto">
                      {(allUserWallets as any[])?.length || 0} users
                    </span>
                  </div>
                  <div className="space-y-1.5 max-h-[500px] overflow-y-auto scrollbar-hide">
                    {allUserWallets && (allUserWallets as any[]).length > 0 ? (allUserWallets as any[]).map((u: any) => (
                      <div key={u.userId} className="p-3 rounded-xl bg-muted/20 border border-border/20">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-primary">#{u.userId}</span>
                            <span className="text-xs font-semibold">{u.name || "Anonymous"}</span>
                            <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${
                              u.role === "admin" ? "bg-red-500/15 text-red-400" : "bg-muted/30 text-muted-foreground"
                            }`}>{u.role}</span>
                          </div>
                        </div>
                        <div className="flex gap-3 flex-wrap">
                          {u.wallets.map((w: any) => (
                            <div key={w.currency} className="flex items-center gap-1.5 text-xs">
                              <span className={`font-bold ${
                                w.currency === "BTC" ? "text-orange-400" :
                                w.currency === "ETH" ? "text-blue-400" : "text-emerald-400"
                              }`}>{w.currency}:</span>
                              <span className="font-mono">{parseFloat(w.balance).toFixed(6)}</span>
                            </div>
                          ))}
                          <button
                            onClick={() => { setFundUserId(String(u.userId)); setFundAction("add"); }}
                            className="text-[10px] text-primary hover:text-primary/80 transition-colors ml-auto flex items-center gap-0.5"
                          >
                            <Edit3 className="h-2.5 w-2.5" /> Manage
                          </button>
                        </div>
                      </div>
                    )) : (
                      <div className="text-center py-10 text-muted-foreground text-sm">No users found</div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* ===== BONUS CODES TAB ===== */}
          <TabsContent value="bonus">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card className="casino-card">
                <CardContent className="p-5 space-y-3">
                  <div className="flex items-center gap-2 mb-1">
                    <Gift className="h-5 w-5 text-amber-400" />
                    <h2 className="text-base font-semibold">Create Bonus Code</h2>
                  </div>
                  <div>
                    <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1 block">Code</label>
                    <Input placeholder="e.g. WELCOME100" value={newBonusCode} onChange={(e) => setNewBonusCode(e.target.value.toUpperCase())} className="bet-input h-9 font-mono text-sm" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1 block">Amount</label>
                      <Input type="number" value={bonusAmount} onChange={(e) => setBonusAmount(e.target.value)} className="bet-input h-9 text-sm" />
                    </div>
                    <div>
                      <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1 block">Currency</label>
                      <Select value={bonusCurrency} onValueChange={(v: any) => setBonusCurrency(v)}>
                        <SelectTrigger className="bg-muted/20 h-9 text-sm"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="BTC">BTC</SelectItem>
                          <SelectItem value="ETH">ETH</SelectItem>
                          <SelectItem value="USDT">USDT</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1 block">Max Uses</label>
                      <Input type="number" value={bonusMaxUses} onChange={(e) => setBonusMaxUses(e.target.value)} className="bet-input h-9 text-sm" />
                    </div>
                    <div>
                      <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1 block">Expiry Date</label>
                      <Input type="date" value={bonusExpiry} onChange={(e) => setBonusExpiry(e.target.value)} className="bet-input h-9 text-sm" />
                    </div>
                  </div>
                  <button onClick={() => {
                    if (!newBonusCode) { toast.error("Enter a code"); return; }
                    createBonusMutation.mutate({
                      code: newBonusCode, type: "free_credits" as const,
                      value: parseFloat(bonusAmount), currency: bonusCurrency,
                      maxUses: parseInt(bonusMaxUses),
                      expiresAt: bonusExpiry ? new Date(bonusExpiry) : new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
                    });
                  }} disabled={createBonusMutation.isPending} className="bet-btn w-full h-10 text-sm flex items-center justify-center gap-2">
                    {createBonusMutation.isPending ? (
                      <><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> Creating...</>
                    ) : (
                      <><Gift className="h-4 w-4" /> Create Bonus Code</>
                    )}
                  </button>
                </CardContent>
              </Card>

              <Card className="casino-card">
                <CardContent className="p-5">
                  <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                    <Gift className="h-4 w-4 text-primary" /> Active Bonus Codes
                  </h3>
                  {bonusCodes && (bonusCodes as any[]).length > 0 ? (
                    <div className="space-y-1.5 max-h-[400px] overflow-y-auto scrollbar-hide">
                      {(bonusCodes as any[]).map((bc: any) => (
                        <div key={bc.id} className="p-2.5 rounded-lg bg-muted/20 border border-border/20 flex items-center justify-between">
                          <div>
                            <p className="font-mono text-xs font-semibold">{bc.code}</p>
                            <p className="text-[10px] text-muted-foreground">
                              {parseFloat(bc.value).toFixed(2)} {bc.currency} | {bc.currentUses}/{bc.maxUses} uses
                            </p>
                            {bc.expiresAt && <p className="text-[10px] text-muted-foreground/60">Exp: {new Date(bc.expiresAt).toLocaleDateString()}</p>}
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${bc.isActive ? "bg-emerald-500/15 text-emerald-400" : "bg-red-500/15 text-red-400"}`}>
                              {bc.isActive ? "Active" : "Off"}
                            </span>
                            <Switch checked={bc.isActive} onCheckedChange={(checked) => toggleBonusMutation.mutate({ id: bc.id, isActive: checked })} />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-10 text-muted-foreground text-sm">No bonus codes created yet</div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* ===== SPORTSBOOK TAB ===== */}
          <TabsContent value="sportsbook">
            <Card className="casino-card">
              <CardContent className="p-5">
                <div className="flex items-center gap-2 mb-1">
                  <Activity className="h-5 w-5 text-blue-400" />
                  <h2 className="text-base font-semibold">Sportsbook Margin Control</h2>
                </div>
                <p className="text-xs text-muted-foreground mb-5">
                  Adjust house margin per sport. Higher margin = more profit but less attractive odds for players.
                </p>
                <div className="space-y-2">
                  {["football", "basketball", "baseball", "soccer", "hockey", "mma", "boxing", "esports"].map((sport) => {
                    const config = rtpConfigs?.find((c: any) => c.gameType === `sportsbook_${sport}`);
                    const margin = config ? parseFloat(config.houseEdge) : 5;
                    return (
                      <div key={sport} className="p-3 rounded-xl bg-muted/20 border border-border/20 flex items-center gap-3">
                        <span className="font-semibold capitalize text-sm w-20 shrink-0">{sport}</span>
                        <Slider value={[margin]} min={1} max={20} step={0.5}
                          onValueChange={(v) => {
                            updateRtpMutation.mutate({ gameType: `sportsbook_${sport}`, targetRtp: (100 - v[0]) / 100, houseEdge: v[0] / 100 });
                          }}
                          className="flex-1"
                        />
                        <span className="font-mono text-xs w-12 text-right text-muted-foreground">{margin.toFixed(1)}%</span>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </CasinoLayout>
  );
}
