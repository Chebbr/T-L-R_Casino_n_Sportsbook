import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Wallet, Trophy, TrendingUp, Gamepad2, Crown, Gift, ArrowRight, Sparkles, Shield, Zap } from "lucide-react";

export default function Dashboard() {
  const { user, loading: authLoading } = useAuth();
  const { data: wallets } = trpc.wallet.getAll.useQuery(undefined, { enabled: !!user });
  const { data: stats } = trpc.stats.get.useQuery(undefined, { enabled: !!user });
  const { data: recentGames } = trpc.stats.getRecentGames.useQuery({ limit: 5 }, { enabled: !!user });
  const { data: vipInfo } = trpc.vip.getMyTier.useQuery(undefined, { enabled: !!user });

  if (authLoading) return <CasinoLayout><div className="container py-20 text-center"><div className="animate-pulse text-muted-foreground">Loading...</div></div></CasinoLayout>;
  if (!user) { window.location.href = getLoginUrl(); return null; }

  const totalBalance = wallets?.reduce((sum: number, w: any) => sum + parseFloat(w.balance || "0"), 0) || 0;

  const tierColors: Record<string, string> = {
    bronze: "from-amber-700/20 to-amber-900/10 border-amber-700/30 text-amber-500",
    silver: "from-gray-400/20 to-gray-600/10 border-gray-400/30 text-gray-300",
    gold: "from-yellow-500/20 to-yellow-700/10 border-yellow-500/30 text-yellow-400",
    platinum: "from-cyan-400/20 to-cyan-600/10 border-cyan-400/30 text-cyan-300",
    diamond: "from-violet-400/20 to-violet-600/10 border-violet-400/30 text-violet-300",
  };
  const currentTier = (vipInfo?.tier || "bronze").toLowerCase();
  const tierStyle = tierColors[currentTier] || tierColors.bronze;

  return (
    <CasinoLayout>
      <div className="container py-6 max-w-6xl">
        {/* Welcome Header */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
          <div className="flex items-center gap-3 mb-1">
            <h1 className="text-2xl font-bold">Welcome back, <span className="text-gradient-gold">{user.name || "Player"}</span></h1>
            <Sparkles className="h-5 w-5 text-primary animate-pulse" />
          </div>
          <p className="text-sm text-muted-foreground">Your casino dashboard overview</p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
          {[
            { icon: Wallet, label: "Total Balance", value: `$${totalBalance.toFixed(2)}`, color: "text-primary", bg: "bg-primary/10", delay: 0.05 },
            { icon: TrendingUp, label: "Total Wagered", value: `$${stats ? parseFloat(String(stats.totalWagered || 0)).toFixed(2) : "0.00"}`, color: "text-emerald-400", bg: "bg-emerald-500/10", delay: 0.1 },
            { icon: Trophy, label: "Win Rate", value: `${stats?.totalBets ? ((stats.totalWins / stats.totalBets) * 100).toFixed(1) : "0"}%`, color: "text-amber-400", bg: "bg-amber-500/10", delay: 0.15 },
            { icon: Crown, label: "VIP Tier", value: (vipInfo?.tier || "Bronze"), color: "text-purple-400", bg: "bg-purple-500/10", delay: 0.2 },
          ].map(({ icon: Icon, label, value, color, bg, delay }) => (
            <motion.div key={label} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay }}>
              <Card className="casino-card h-full">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className={`p-1.5 rounded-lg ${bg}`}><Icon className={`h-4 w-4 ${color}`} /></div>
                    <span className="text-[11px] text-muted-foreground uppercase tracking-wider">{label}</span>
                  </div>
                  <p className="text-xl font-bold font-display capitalize">{value}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Wallets */}
          <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
            <Card className="casino-card h-full">
              <CardHeader className="pb-2 px-4 pt-4">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Wallet className="h-4 w-4 text-primary" /> Wallets
                </CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4 space-y-2">
                {wallets?.map((w: any) => (
                  <div key={w.currency} className="flex items-center justify-between p-2.5 rounded-lg bg-muted/20 border border-border/20">
                    <div className="flex items-center gap-2">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                        w.currency === "BTC" ? "bg-orange-500/15 text-orange-400" :
                        w.currency === "ETH" ? "bg-blue-500/15 text-blue-400" :
                        "bg-green-500/15 text-green-400"
                      }`}>
                        {w.currency === "BTC" ? "B" : w.currency === "ETH" ? "E" : "$"}
                      </div>
                      <span className="text-sm font-medium">{w.currency}</span>
                    </div>
                    <span className="font-mono text-sm font-semibold">{parseFloat(w.balance || "0").toFixed(w.currency === "BTC" ? 8 : 4)}</span>
                  </div>
                ))}
                {(!wallets || wallets.length === 0) && (
                  <div className="text-center py-4 text-xs text-muted-foreground">No wallets yet. Make a deposit to get started.</div>
                )}
                <Link href="/wallet" className="flex items-center justify-center gap-2 p-2.5 rounded-lg border border-primary/20 text-primary text-sm font-medium hover:bg-primary/5 transition-colors mt-2">
                  Manage Wallet <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </CardContent>
            </Card>
          </motion.div>

          {/* Recent Games */}
          <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="lg:col-span-2">
            <Card className="casino-card h-full">
              <CardHeader className="pb-2 px-4 pt-4">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Gamepad2 className="h-4 w-4 text-primary" /> Recent Games
                </CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4">
                {recentGames && recentGames.length > 0 ? (
                  <div className="space-y-1.5">
                    {recentGames.map((game: any, i: number) => (
                      <div key={i} className="flex items-center justify-between p-2.5 rounded-lg bg-muted/20 border border-border/20">
                        <div className="flex items-center gap-3">
                          <div className={`w-2 h-2 rounded-full ${game.result === "win" ? "bg-emerald-400" : "bg-red-400"}`} />
                          <span className="text-sm font-medium capitalize">{game.gameType}</span>
                          <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${
                            game.result === "win" ? "bg-emerald-500/15 text-emerald-400" : "bg-red-500/15 text-red-400"
                          }`}>
                            {game.result}
                          </span>
                        </div>
                        <div className="text-right flex items-center gap-2">
                          <span className="font-mono text-xs text-muted-foreground">{parseFloat(game.betAmount || "0").toFixed(4)}</span>
                          {game.payout > 0 && (
                            <span className="font-mono text-xs text-emerald-400">+{parseFloat(game.payout || "0").toFixed(4)}</span>
                          )}
                          <span className="text-[10px] text-muted-foreground/60">{game.currency}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-10 text-muted-foreground">
                    <Gamepad2 className="h-10 w-10 mx-auto mb-3 opacity-20" />
                    <p className="text-sm">No games played yet</p>
                    <p className="text-xs text-muted-foreground/60 mt-1">Start playing to see your history!</p>
                    <Link href="/games/crash" className="inline-flex items-center gap-2 mt-3 px-4 py-2 rounded-lg bg-primary/10 text-primary text-sm font-medium hover:bg-primary/15 transition-colors">
                      <Zap className="h-3.5 w-3.5" /> Play Now
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* VIP Progress Card */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }} className="mt-4">
          <Card className={`border bg-gradient-to-r ${tierStyle}`}>
            <CardContent className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-background/50">
                  <Crown className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-sm font-semibold capitalize">{currentTier} VIP</p>
                  <p className="text-xs text-muted-foreground">
                    {vipInfo?.cashback ? `${(vipInfo.cashback * 100).toFixed(1)}% cashback` : "Wager more to level up"}
                  </p>
                </div>
              </div>
              <Link href="/vip" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-background/50 text-sm font-medium hover:bg-background/70 transition-colors">
                View VIP Details <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </CardContent>
          </Card>
        </motion.div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4">
          {[
            { href: "/vip", icon: Shield, label: "VIP Program", desc: "Tier rewards & cashback", color: "text-purple-400" },
            { href: "/bonus", icon: Gift, label: "Bonus Codes", desc: "Redeem exclusive codes", color: "text-amber-400" },
            { href: "/slots", icon: Sparkles, label: "Slots Lobby", desc: "Provider games", color: "text-cyan-400" },
          ].map(({ href, icon: Icon, label, desc, color }) => (
            <Link key={href} href={href}>
              <Card className="casino-card hover:border-primary/30 transition-all cursor-pointer group">
                <CardContent className="p-4 flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-muted/30 group-hover:bg-primary/10 transition-colors">
                    <Icon className={`h-5 w-5 ${color}`} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">{label}</p>
                    <p className="text-[11px] text-muted-foreground">{desc}</p>
                  </div>
                  <ArrowRight className="h-4 w-4 text-muted-foreground/30 ml-auto group-hover:text-primary transition-colors" />
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </CasinoLayout>
  );
}
