import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Headphones, Send, MessageSquare, Plus, ArrowLeft, Clock, CheckCircle, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function SupportPage() {
  const { user, loading } = useAuth();
  const [message, setMessage] = useState("");
  const [subject, setSubject] = useState("");
  const [activeTicketId, setActiveTicketId] = useState<number | null>(null);
  const [showNewTicket, setShowNewTicket] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const utils = trpc.useUtils();

  const { data: tickets } = trpc.support.getMyTickets.useQuery(undefined, { enabled: !!user });
  const { data: ticketMessages } = trpc.support.getMessages.useQuery(
    { ticketId: activeTicketId! },
    { enabled: !!activeTicketId, refetchInterval: 5000 }
  );

  const createTicketMutation = trpc.support.createTicket.useMutation({
    onSuccess: (data: any) => {
      toast.success("Support ticket created!");
      setActiveTicketId(data.id);
      setShowNewTicket(false);
      setSubject("");
      setMessage("");
      utils.support.getMyTickets.invalidate();
    },
    onError: (err: any) => toast.error(err.message),
  });

  const replyMutation = trpc.support.reply.useMutation({
    onSuccess: () => {
      setMessage("");
      utils.support.getMessages.invalidate();
    },
    onError: (err: any) => toast.error(err.message),
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [ticketMessages]);

  if (loading) return <CasinoLayout><div className="container py-20 text-center animate-pulse text-muted-foreground">Loading...</div></CasinoLayout>;
  if (!user) { window.location.href = getLoginUrl(); return null; }

  const handleCreateTicket = () => {
    if (!subject.trim() || !message.trim()) {
      toast.error("Please fill in both subject and message");
      return;
    }
    createTicketMutation.mutate({ subject: subject.trim(), message: message.trim() });
  };

  const handleReply = () => {
    if (!message.trim() || !activeTicketId) return;
    replyMutation.mutate({ ticketId: activeTicketId, message: message.trim() });
  };

  const activeTicket = tickets?.find((t: any) => t.id === activeTicketId);

  return (
    <CasinoLayout>
      <div className="container py-6 max-w-4xl">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-primary/10"><Headphones className="h-6 w-6 text-primary" /></div>
            <div>
              <h1 className="text-2xl font-bold">Support</h1>
              <p className="text-xs text-muted-foreground">Get help from our team</p>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Ticket List */}
          <div className="lg:col-span-1">
            <Card className="casino-card">
              <CardContent className="p-3">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-semibold">Tickets</h3>
                  <button
                    onClick={() => { setShowNewTicket(true); setActiveTicketId(null); }}
                    className="p-1.5 rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
                  >
                    <Plus className="h-3.5 w-3.5" />
                  </button>
                </div>
                <div className="space-y-1">
                  {tickets && tickets.length > 0 ? tickets.map((ticket: any) => (
                    <button
                      key={ticket.id}
                      onClick={() => { setActiveTicketId(ticket.id); setShowNewTicket(false); }}
                      className={`w-full text-left p-2.5 rounded-lg transition-all ${
                        activeTicketId === ticket.id
                          ? "bg-primary/10 border border-primary/20"
                          : "hover:bg-muted/30 border border-transparent"
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-medium ${
                          ticket.status === "open" ? "bg-amber-500/15 text-amber-400" :
                          ticket.status === "resolved" ? "bg-emerald-500/15 text-emerald-400" :
                          "bg-muted/30 text-muted-foreground"
                        }`}>
                          {ticket.status}
                        </span>
                      </div>
                      <p className="text-xs font-medium truncate">{ticket.subject}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">
                        {new Date(ticket.createdAt).toLocaleDateString()}
                      </p>
                    </button>
                  )) : (
                    <div className="text-center py-6 text-muted-foreground">
                      <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-20" />
                      <p className="text-xs">No tickets yet</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Ticket Content */}
          <div className="lg:col-span-2">
            {showNewTicket ? (
              <Card className="casino-card">
                <CardContent className="p-5 space-y-4">
                  <div className="flex items-center gap-2">
                    <button onClick={() => setShowNewTicket(false)} className="p-1 rounded-lg hover:bg-muted/30">
                      <ArrowLeft className="h-4 w-4 text-muted-foreground" />
                    </button>
                    <h3 className="text-lg font-semibold">New Support Ticket</h3>
                  </div>

                  <div>
                    <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">Subject</label>
                    <Input
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      placeholder="What do you need help with?"
                      className="bet-input h-10"
                      maxLength={200}
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5 block">Message</label>
                    <textarea
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Describe your issue in detail..."
                      className="w-full min-h-[120px] p-3 rounded-xl bg-muted/20 border border-border/30 text-sm text-foreground placeholder:text-muted-foreground/50 resize-none focus:outline-none focus:ring-1 focus:ring-primary/30"
                      maxLength={2000}
                    />
                  </div>

                  <button
                    onClick={handleCreateTicket}
                    disabled={createTicketMutation.isPending}
                    className="bet-btn w-full h-11 text-sm flex items-center justify-center gap-2"
                  >
                    {createTicketMutation.isPending ? (
                      <><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> Creating...</>
                    ) : (
                      <><Send className="h-4 w-4" /> Submit Ticket</>
                    )}
                  </button>
                </CardContent>
              </Card>
            ) : activeTicketId && activeTicket ? (
              <Card className="casino-card">
                <CardContent className="p-0 flex flex-col" style={{ height: "calc(100vh - 220px)", minHeight: "400px" }}>
                  {/* Ticket header */}
                  <div className="px-4 py-3 border-b border-border/20">
                    <div className="flex items-center gap-2 mb-1">
                      <button onClick={() => setActiveTicketId(null)} className="p-1 rounded-lg hover:bg-muted/30 lg:hidden">
                        <ArrowLeft className="h-4 w-4 text-muted-foreground" />
                      </button>
                      <h3 className="text-sm font-semibold truncate">{activeTicket.subject}</h3>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-medium ${
                        activeTicket.status === "open" ? "bg-amber-500/15 text-amber-400" :
                        activeTicket.status === "resolved" ? "bg-emerald-500/15 text-emerald-400" :
                        "bg-muted/30 text-muted-foreground"
                      }`}>
                        {activeTicket.status === "open" ? <><Clock className="h-2.5 w-2.5 inline mr-0.5" /> Open</> :
                         activeTicket.status === "resolved" ? <><CheckCircle className="h-2.5 w-2.5 inline mr-0.5" /> Resolved</> :
                         activeTicket.status}
                      </span>
                      <span className="text-[10px] text-muted-foreground">{new Date(activeTicket.createdAt).toLocaleString()}</span>
                    </div>
                  </div>

                  {/* Messages */}
                  <div className="flex-1 overflow-y-auto p-4 space-y-3">
                    {ticketMessages && ticketMessages.length > 0 ? ticketMessages.map((msg: any, i: number) => {
                      const isMe = msg.userId === user.id;
                      return (
                        <motion.div key={msg.id || i} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
                          className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
                          <div className="max-w-[80%]">
                            <div className={`flex items-center gap-1.5 mb-0.5 ${isMe ? "justify-end" : ""}`}>
                              <span className={`text-[10px] font-medium ${msg.isAdmin ? "text-primary" : "text-muted-foreground"}`}>
                                {msg.isAdmin ? "Support Team" : "You"}
                              </span>
                              <span className="text-[9px] text-muted-foreground/50">
                                {new Date(msg.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                              </span>
                            </div>
                            <div className={`px-3 py-2 rounded-xl text-sm ${
                              msg.isAdmin
                                ? "bg-primary/10 border border-primary/20"
                                : "bg-muted/30 border border-border/20"
                            }`}>
                              {msg.message}
                            </div>
                          </div>
                        </motion.div>
                      );
                    }) : (
                      <div className="text-center py-10 text-muted-foreground text-sm">No messages in this ticket yet</div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>

                  {/* Reply input */}
                  {activeTicket.status !== "closed" && (
                    <div className="p-3 border-t border-border/20">
                      <form onSubmit={(e) => { e.preventDefault(); handleReply(); }} className="flex items-center gap-2">
                        <Input
                          value={message}
                          onChange={(e) => setMessage(e.target.value)}
                          placeholder="Type a reply..."
                          className="bet-input h-10 flex-1"
                          maxLength={2000}
                          disabled={replyMutation.isPending}
                        />
                        <button type="submit" disabled={replyMutation.isPending || !message.trim()} className="bet-btn h-10 w-10 flex items-center justify-center shrink-0">
                          <Send className="h-4 w-4" />
                        </button>
                      </form>
                    </div>
                  )}
                </CardContent>
              </Card>
            ) : (
              <Card className="casino-card">
                <CardContent className="p-10 text-center text-muted-foreground">
                  <Headphones className="h-12 w-12 mx-auto mb-3 opacity-20" />
                  <p className="text-sm mb-1">Select a ticket or create a new one</p>
                  <p className="text-xs text-muted-foreground/60">Our support team typically responds within a few hours</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </CasinoLayout>
  );
}
