import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAudio } from "@/hooks/useAudio";
import { toast } from "sonner";
import { Gift, Ticket, Clock, CheckCircle, Sparkles, ArrowRight } from "lucide-react";

export default function BonusPage() {
  const { user, loading } = useAuth();
  const { play } = useAudio();
  const [code, setCode] = useState("");
  const [redeemSuccess, setRedeemSuccess] = useState<any>(null);

  const utils = trpc.useUtils();
  const { data: myRedemptions } = trpc.bonus.getMyRedemptions.useQuery(undefined, { enabled: !!user });

  const redeemMutation = trpc.bonus.redeem.useMutation({
    onSuccess: (data) => {
      play("bigWin");
      setRedeemSuccess(data);
      toast.success(`Bonus redeemed! ${data.amount} ${data.currency} credited!`);
      setCode("");
      utils.bonus.getMyRedemptions.invalidate();
      utils.wallet.getAll.invalidate();
      setTimeout(() => setRedeemSuccess(null), 5000);
    },
    onError: (err) => {
      play("lose");
      toast.error(err.message);
    },
  });

  const handleRedeem = () => {
    if (!code.trim()) { toast.error("Enter a bonus code"); return; }
    play("click");
    redeemMutation.mutate({ code: code.trim().toUpperCase() });
  };

  if (loading) return <CasinoLayout><div className="container py-20 text-center animate-pulse text-muted-foreground">Loading...</div></CasinoLayout>;
  if (!user) { window.location.href = getLoginUrl(); return null; }

  return (
    <CasinoLayout>
      <div className="container py-6 max-w-3xl">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-primary/10"><Gift className="h-6 w-6 text-primary" /></div>
            <div>
              <h1 className="text-2xl font-bold">Bonus Codes</h1>
              <p className="text-xs text-muted-foreground">Redeem exclusive codes for free credits and rewards</p>
            </div>
          </div>
        </motion.div>

        {/* Redeem Card */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card className="casino-card mb-5 border border-primary/15 overflow-hidden">
            <CardContent className="p-6 relative">
              {/* Background decoration */}
              <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-bl from-primary/5 to-transparent rounded-full blur-3xl pointer-events-none" />
              
              <div className="relative text-center mb-5">
                <div className="inline-flex p-3 rounded-2xl bg-primary/10 mb-3">
                  <Ticket className="h-10 w-10 text-primary" />
                </div>
                <h2 className="text-lg font-bold mb-1">Enter Your Bonus Code</h2>
                <p className="text-xs text-muted-foreground">Got a code? Enter it below to claim your reward</p>
              </div>

              <div className="flex gap-2 max-w-md mx-auto">
                <Input
                  placeholder="ENTER CODE"
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  className="bet-input text-center font-mono text-base tracking-[0.2em] h-12"
                  onKeyDown={(e) => e.key === "Enter" && handleRedeem()}
                />
                <button onClick={handleRedeem} disabled={redeemMutation.isPending} className="bet-btn px-6 h-12 shrink-0 flex items-center gap-2">
                  {redeemMutation.isPending ? (
                    <><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" /> Checking...</>
                  ) : (
                    <><Sparkles className="h-4 w-4" /> Redeem</>
                  )}
                </button>
              </div>

              {/* Success animation */}
              <AnimatePresence>
                {redeemSuccess && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="mt-4 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center"
                  >
                    <CheckCircle className="h-8 w-8 text-emerald-400 mx-auto mb-2" />
                    <p className="text-sm font-semibold text-emerald-400">Bonus Claimed!</p>
                    <p className="text-2xl font-bold font-mono mt-1">+{parseFloat(redeemSuccess.amount).toFixed(2)} {redeemSuccess.currency}</p>
                    <p className="text-xs text-muted-foreground mt-1">credited to your wallet</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>
        </motion.div>

        {/* Tips */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-5">
            {[
              { title: "Social Media", desc: "Follow us for exclusive drops", icon: "📱" },
              { title: "VIP Rewards", desc: "Higher tiers get bigger codes", icon: "👑" },
              { title: "Limited Time", desc: "Codes expire, use them fast!", icon: "⏰" },
            ].map((tip, i) => (
              <Card key={i} className="casino-card">
                <CardContent className="p-3 flex items-center gap-3">
                  <span className="text-2xl">{tip.icon}</span>
                  <div>
                    <p className="text-xs font-semibold">{tip.title}</p>
                    <p className="text-[10px] text-muted-foreground">{tip.desc}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </motion.div>

        {/* Redemption History */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card className="casino-card">
            <CardContent className="p-5">
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <Clock className="h-4 w-4 text-primary" /> Redemption History
              </h3>
              {myRedemptions && myRedemptions.length > 0 ? (
                <div className="space-y-1.5">
                  {myRedemptions.map((r: any, i: number) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.03 }}
                      className="flex items-center justify-between p-2.5 rounded-lg bg-muted/20 border border-border/20"
                    >
                      <div className="flex items-center gap-2.5">
                        <CheckCircle className="h-4 w-4 text-emerald-400 shrink-0" />
                        <div>
                          <p className="font-mono text-xs font-semibold">{r.code}</p>
                          <p className="text-[10px] text-muted-foreground">{new Date(r.redeemedAt).toLocaleDateString()}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-mono text-sm font-bold text-emerald-400">+{parseFloat(r.amount || "0").toFixed(2)}</p>
                        <p className="text-[10px] text-muted-foreground">{r.currency}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-10 text-muted-foreground">
                  <Gift className="h-10 w-10 mx-auto mb-3 opacity-20" />
                  <p className="text-sm">No codes redeemed yet</p>
                  <p className="text-xs text-muted-foreground/60 mt-1">Follow us on social media for exclusive bonus codes!</p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </CasinoLayout>
  );
}
