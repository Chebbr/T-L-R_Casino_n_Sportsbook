import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import { Gift, Copy, Users, DollarSign, TrendingUp, CheckCircle, Share2 } from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";

export default function ReferralsPage() {
  const { user, loading } = useAuth();
  const [copied, setCopied] = useState(false);

  const { data: refData } = trpc.referral.getStats.useQuery(undefined, { enabled: !!user });

  if (loading) return <CasinoLayout><div className="container py-20 text-center animate-pulse text-muted-foreground">Loading...</div></CasinoLayout>;
  if (!user) { window.location.href = getLoginUrl(); return null; }

  const referralLink = `${window.location.origin}?ref=${user.id}`;
  const referralCode = `XEBB${user.id}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    toast.success("Referral link copied!");
    setTimeout(() => setCopied(false), 2000);
  };

  const stats = refData || { totalReferred: 0, totalEarnings: "0", commissionRate: "0.05", referralCode: "", isActive: false, recentEarnings: [] };

  return (
    <CasinoLayout>
      <div className="container py-6 max-w-4xl">
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-primary/10"><Gift className="h-6 w-6 text-primary" /></div>
            <div>
              <h1 className="text-2xl font-bold">Referral Program</h1>
              <p className="text-xs text-muted-foreground">Invite friends and earn commission on their bets</p>
            </div>
          </div>
        </motion.div>

        {/* Referral Link Card */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card className="casino-card mb-6 overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_50%,oklch(0.3_0.08_85/0.1),transparent_60%)]" />
            <CardContent className="p-6 relative z-10">
              <h3 className="text-lg font-bold mb-1">Your Referral Link</h3>
              <p className="text-xs text-muted-foreground mb-4">Share this link and earn 5% commission on every bet your referrals place</p>

              <div className="flex items-center gap-2 mb-4">
                <div className="flex-1 p-3 rounded-xl bg-muted/20 border border-border/30 text-sm text-foreground font-mono truncate">
                  {referralLink}
                </div>
                <button onClick={handleCopy} className="bet-btn h-11 px-4 flex items-center gap-2 shrink-0">
                  {copied ? <><CheckCircle className="h-4 w-4" /> Copied!</> : <><Copy className="h-4 w-4" /> Copy</>}
                </button>
              </div>

              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <Share2 className="h-3.5 w-3.5 text-primary" />
                  <span>Referral Code: <strong className="text-primary">{referralCode}</strong></span>
                </div>
                <div className="flex items-center gap-1.5">
                  <DollarSign className="h-3.5 w-3.5 text-green-400" />
                  <span>5% Commission Rate</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          {[
            { label: "Total Referred", value: stats.totalReferred, icon: Users, color: "text-blue-400" },
            { label: "Commission Rate", value: `${(Number(stats.commissionRate) * 100).toFixed(0)}%`, icon: TrendingUp, color: "text-green-400" },
            { label: "Total Earnings", value: `$${Number(stats.totalEarnings).toFixed(2)}`, icon: DollarSign, color: "text-primary" },
            { label: "Recent Payouts", value: stats.recentEarnings?.length || 0, icon: Gift, color: "text-pink-400" },
          ].map((stat, i) => (
            <motion.div key={stat.label} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 + i * 0.05 }}>
              <Card className="casino-card">
                <CardContent className="p-4">
                  <stat.icon className={`h-5 w-5 ${stat.color} mb-2`} />
                  <p className="text-xl font-bold">{stat.value}</p>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{stat.label}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* How It Works */}
        <Card className="casino-card">
          <CardContent className="p-6">
            <h3 className="text-lg font-bold mb-4">How It Works</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                { step: "1", title: "Share Your Link", desc: "Copy your unique referral link and share it with friends, on social media, or in your community." },
                { step: "2", title: "Friends Sign Up", desc: "When someone clicks your link and creates an account, they're automatically linked to you as a referral." },
                { step: "3", title: "Earn Commission", desc: "You earn 5% commission on every bet your referrals place. Earnings are credited to your wallet automatically." },
              ].map((item) => (
                <div key={item.step} className="text-center">
                  <div className="w-10 h-10 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center mx-auto mb-3">
                    <span className="text-sm font-bold text-primary">{item.step}</span>
                  </div>
                  <h4 className="text-sm font-semibold mb-1">{item.title}</h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </CasinoLayout>
  );
}
