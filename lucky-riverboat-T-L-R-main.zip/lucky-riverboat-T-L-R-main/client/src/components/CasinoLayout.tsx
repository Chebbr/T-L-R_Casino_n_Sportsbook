import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Link, useLocation } from "wouter";
import {
  Wallet, User, LogOut, LayoutDashboard, Menu, X,
  ChevronDown, Volume2, VolumeX, Crown, Gift, Gamepad2,
  Home, TrendingUp, Zap, Shield, Star, Anchor,
  CircleDot, Waves, Ship, Gem, Spade, Target,
  MessageCircle, Headphones, Share2,
} from "lucide-react";
import { useState, useEffect } from "react";
import { useAudio } from "@/hooks/useAudio";
import { motion, AnimatePresence } from "framer-motion";

const LOGO_URL = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663337400304/XncsRlLSKtYQDKxq.png";

const houseGames = [
  { name: "Riverboat Keno", path: "/games/keno", icon: Target, color: "text-blue-400" },
  { name: "Beached (Crash)", path: "/games/crash", icon: Waves, color: "text-cyan-400" },
  { name: "Roulette", path: "/games/roulette", icon: CircleDot, color: "text-red-400" },
  { name: "Helm Spin", path: "/games/helm", icon: Anchor, color: "text-amber-400" },
  { name: "Walk the Plank", path: "/games/tower", icon: Ship, color: "text-emerald-400" },
  { name: "Hidden Treasure", path: "/games/mines", icon: Gem, color: "text-purple-400" },
  { name: "Hitide Lowtide", path: "/games/hilow", icon: Spade, color: "text-pink-400" },
];

const mainNav = [
  { name: "Home", path: "/", icon: Home },
  { name: "Sportsbook", path: "/sportsbook", icon: TrendingUp },
  { name: "Slots Lobby", path: "/slots", icon: Gamepad2 },
  { name: "VIP Club", path: "/vip", icon: Crown },
  { name: "Promotions", path: "/bonus", icon: Gift },
];

interface CasinoLayoutProps {
  children: React.ReactNode;
}

export default function CasinoLayout({ children }: CasinoLayoutProps) {
  const { user, loading, logout } = useAuth();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const { isMuted, toggleMute, play } = useAudio();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  const handleLogout = async () => {
    await logout();
    window.location.href = "/";
  };

  const isActive = (path: string) => {
    if (path === "/") return location === "/";
    return location.startsWith(path);
  };

  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop Sidebar */}
      <aside className={`hidden lg:flex flex-col fixed top-0 left-0 h-screen z-40 border-r border-border/40 bg-sidebar transition-all duration-300 ${sidebarCollapsed ? "w-[68px]" : "w-[220px]"}`}>
        {/* Logo */}
        <div className="h-16 flex items-center px-4 border-b border-border/30 shrink-0">
          <Link href="/" className="flex items-center gap-2.5 overflow-hidden" onClick={() => play("click")}>
            <img src={LOGO_URL} alt="Lucky Riverboat" className="h-9 w-auto shrink-0" />
            {!sidebarCollapsed && (
              <span className="font-display text-sm font-bold text-gradient-gold whitespace-nowrap">LUCKY RIVERBOAT</span>
            )}
          </Link>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
          {/* Main Nav */}
          {mainNav.map((item) => {
            const active = isActive(item.path);
            return (
              <Link key={item.path} href={item.path}>
                <div
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 group relative ${
                    active
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted/40"
                  }`}
                  onClick={() => play("click")}
                >
                  {active && (
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-primary rounded-r" />
                  )}
                  <item.icon className={`h-[18px] w-[18px] shrink-0 ${active ? "text-primary" : "text-muted-foreground group-hover:text-foreground"}`} />
                  {!sidebarCollapsed && <span className="truncate">{item.name}</span>}
                </div>
              </Link>
            );
          })}

          {/* Games Section */}
          <div className="pt-4 pb-1">
            {!sidebarCollapsed && (
              <span className="px-3 text-[10px] font-semibold uppercase tracking-[0.15em] text-muted-foreground/60">House Games</span>
            )}
          </div>
          {houseGames.map((game) => {
            const active = isActive(game.path);
            return (
              <Link key={game.path} href={game.path}>
                <div
                  className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-200 group ${
                    active
                      ? "bg-primary/10 text-foreground"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted/30"
                  }`}
                  onClick={() => play("click")}
                >
                  <game.icon className={`h-4 w-4 shrink-0 ${active ? game.color : "text-muted-foreground/70 group-hover:" + game.color}`} />
                  {!sidebarCollapsed && <span className="truncate text-[13px]">{game.name}</span>}
                </div>
              </Link>
            );
          })}

          {/* User Section */}
          {user && (
            <>
              <div className="pt-4 pb-1">
                {!sidebarCollapsed && (
                  <span className="px-3 text-[10px] font-semibold uppercase tracking-[0.15em] text-muted-foreground/60">Account</span>
                )}
              </div>
              {[
                { name: "Dashboard", path: "/dashboard", icon: LayoutDashboard },
                { name: "Wallet", path: "/wallet", icon: Wallet },
                { name: "Profile", path: "/profile", icon: User },
                { name: "Chat", path: "/chat", icon: MessageCircle },
                { name: "Support", path: "/support", icon: Headphones },
                { name: "Referrals", path: "/referrals", icon: Share2 },
              ].map((item) => {
                const active = isActive(item.path);
                return (
                  <Link key={item.path} href={item.path}>
                    <div className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-200 ${active ? "bg-primary/10 text-foreground" : "text-muted-foreground hover:text-foreground hover:bg-muted/30"}`}>
                      <item.icon className={`h-4 w-4 shrink-0 ${active ? "text-primary" : ""}`} />
                      {!sidebarCollapsed && <span className="truncate text-[13px]">{item.name}</span>}
                    </div>
                  </Link>
                );
              })}
              {user.role === "admin" && (
                <Link href="/admin">
                  <div className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-200 ${isActive("/admin") ? "bg-primary/10 text-foreground" : "text-muted-foreground hover:text-foreground hover:bg-muted/30"}`}>
                    <Shield className={`h-4 w-4 shrink-0 ${isActive("/admin") ? "text-red-400" : ""}`} />
                    {!sidebarCollapsed && <span className="truncate text-[13px]">Admin Panel</span>}
                  </div>
                </Link>
              )}
            </>
          )}
        </nav>

        {/* Sidebar Footer */}
        <div className="border-t border-border/30 p-2 shrink-0">
          <button
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs text-muted-foreground hover:text-foreground hover:bg-muted/30 transition-colors"
          >
            <ChevronDown className={`h-3.5 w-3.5 transition-transform duration-300 ${sidebarCollapsed ? "rotate-[-90deg]" : "rotate-90"}`} />
            {!sidebarCollapsed && <span>Collapse</span>}
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className={`flex-1 flex flex-col transition-all duration-300 ${sidebarCollapsed ? "lg:ml-[68px]" : "lg:ml-[220px]"}`}>
        {/* Top Header Bar */}
        <header className={`sticky top-0 z-30 transition-all duration-300 ${scrolled ? "bg-background/95 backdrop-blur-xl border-b border-border/40 shadow-lg shadow-black/10" : "bg-background border-b border-border/20"}`}>
          <div className="flex h-14 items-center justify-between px-4 lg:px-6">
            {/* Mobile: Logo + Hamburger */}
            <div className="flex items-center gap-3 lg:hidden">
              <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="p-1.5 rounded-lg hover:bg-muted/50 transition-colors">
                {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
              <Link href="/" className="flex items-center gap-2">
                <img src={LOGO_URL} alt="Lucky Riverboat" className="h-8 w-auto" />
                <span className="font-display text-xs font-bold text-gradient-gold">LUCKY RIVERBOAT</span>
              </Link>
            </div>

            {/* Desktop: Live Stats Ticker */}
            <div className="hidden lg:flex items-center gap-4 overflow-hidden flex-1">
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Zap className="h-3 w-3 text-green-400" />
                <span className="text-green-400 font-medium">LIVE</span>
              </div>
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span>BTC <span className="text-foreground font-medium">$97,245</span></span>
                <span>ETH <span className="text-foreground font-medium">$3,412</span></span>
                <span className="hidden xl:inline">Online <span className="text-green-400 font-medium">1,247</span></span>
              </div>
            </div>

            {/* Right Side Controls */}
            <div className="flex items-center gap-2">
              <button
                onClick={toggleMute}
                className="p-2 rounded-lg hover:bg-muted/40 transition-colors text-muted-foreground hover:text-foreground"
                title={isMuted ? "Unmute" : "Mute"}
              >
                {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </button>

              {loading ? (
                <div className="h-8 w-24 animate-pulse bg-muted rounded-lg" />
              ) : user ? (
                <div className="flex items-center gap-2">
                  <Link href="/wallet">
                    <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs border-primary/30 hover:border-primary/60 bg-transparent">
                      <Wallet className="h-3.5 w-3.5 text-primary" />
                      <span className="hidden sm:inline">Wallet</span>
                    </Button>
                  </Link>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-8 gap-2 px-2">
                        <Avatar className="h-6 w-6">
                          <AvatarFallback className="bg-primary/20 text-primary text-[10px] font-bold">
                            {user.name?.charAt(0)?.toUpperCase() || "U"}
                          </AvatarFallback>
                        </Avatar>
                        <span className="hidden sm:inline text-xs font-medium max-w-[80px] truncate">{user.name || "Player"}</span>
                        <ChevronDown className="h-3 w-3 text-muted-foreground" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48 bg-popover border-border/50">
                      <div className="px-3 py-2 border-b border-border/30">
                        <p className="text-sm font-medium truncate">{user.name || "Player"}</p>
                        <p className="text-[11px] text-muted-foreground truncate">{user.email || ""}</p>
                      </div>
                      <DropdownMenuItem asChild><Link href="/dashboard" className="flex items-center gap-2 cursor-pointer"><LayoutDashboard className="h-4 w-4" /> Dashboard</Link></DropdownMenuItem>
                      <DropdownMenuItem asChild><Link href="/wallet" className="flex items-center gap-2 cursor-pointer"><Wallet className="h-4 w-4" /> Wallet</Link></DropdownMenuItem>
                      <DropdownMenuItem asChild><Link href="/vip" className="flex items-center gap-2 cursor-pointer"><Crown className="h-4 w-4" /> VIP Club</Link></DropdownMenuItem>
                      <DropdownMenuItem asChild><Link href="/bonus" className="flex items-center gap-2 cursor-pointer"><Gift className="h-4 w-4" /> Bonus Codes</Link></DropdownMenuItem>
                      <DropdownMenuItem asChild><Link href="/profile" className="flex items-center gap-2 cursor-pointer"><User className="h-4 w-4" /> Profile</Link></DropdownMenuItem>
                      {user.role === "admin" && (
                        <DropdownMenuItem asChild><Link href="/admin" className="flex items-center gap-2 cursor-pointer text-red-400"><Shield className="h-4 w-4" /> Admin Panel</Link></DropdownMenuItem>
                      )}
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={handleLogout} className="text-destructive cursor-pointer">
                        <LogOut className="h-4 w-4 mr-2" /> Sign Out
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Button asChild variant="ghost" size="sm" className="h-8 text-xs">
                    <a href={getLoginUrl()}>Log In</a>
                  </Button>
                  <Button asChild size="sm" className="h-8 text-xs bg-primary hover:bg-primary/90 font-semibold">
                    <a href={getLoginUrl()}>Sign Up</a>
                  </Button>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Mobile Slide-out Menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
                onClick={() => setMobileMenuOpen(false)}
              />
              <motion.div
                initial={{ x: -280 }}
                animate={{ x: 0 }}
                exit={{ x: -280 }}
                transition={{ type: "spring", damping: 25, stiffness: 300 }}
                className="fixed top-0 left-0 bottom-0 w-[260px] z-50 bg-sidebar border-r border-border/40 overflow-y-auto lg:hidden"
              >
                <div className="h-14 flex items-center px-4 border-b border-border/30">
                  <Link href="/" className="flex items-center gap-2">
                    <img src={LOGO_URL} alt="Lucky Riverboat" className="h-8 w-auto" />
                    <span className="font-display text-xs font-bold text-gradient-gold">LUCKY RIVERBOAT</span>
                  </Link>
                </div>
                <nav className="py-3 px-2 space-y-0.5">
                  {mainNav.map((item) => (
                    <Link key={item.path} href={item.path}>
                      <div className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${isActive(item.path) ? "bg-primary/10 text-primary" : "text-muted-foreground"}`}>
                        <item.icon className="h-[18px] w-[18px]" />
                        <span>{item.name}</span>
                      </div>
                    </Link>
                  ))}
                  <div className="pt-3 pb-1">
                    <span className="px-3 text-[10px] font-semibold uppercase tracking-[0.15em] text-muted-foreground/60">House Games</span>
                  </div>
                  {houseGames.map((game) => (
                    <Link key={game.path} href={game.path}>
                      <div className={`flex items-center gap-3 px-3 py-2 rounded-lg text-[13px] transition-colors ${isActive(game.path) ? "bg-primary/10 text-foreground" : "text-muted-foreground"}`}>
                        <game.icon className={`h-4 w-4 ${isActive(game.path) ? game.color : ""}`} />
                        <span>{game.name}</span>
                      </div>
                    </Link>
                  ))}
                  {user && (
                    <>
                      <div className="pt-3 pb-1">
                        <span className="px-3 text-[10px] font-semibold uppercase tracking-[0.15em] text-muted-foreground/60">Account</span>
                      </div>
                      <Link href="/dashboard"><div className="flex items-center gap-3 px-3 py-2 rounded-lg text-[13px] text-muted-foreground"><LayoutDashboard className="h-4 w-4" /> Dashboard</div></Link>
                      <Link href="/wallet"><div className="flex items-center gap-3 px-3 py-2 rounded-lg text-[13px] text-muted-foreground"><Wallet className="h-4 w-4" /> Wallet</div></Link>
                      <Link href="/profile"><div className="flex items-center gap-3 px-3 py-2 rounded-lg text-[13px] text-muted-foreground"><User className="h-4 w-4" /> Profile</div></Link>
                    </>
                  )}
                </nav>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* Main Content */}
        <main className="flex-1">{children}</main>

        {/* Footer */}
        <footer className="border-t border-border/30 bg-sidebar/50 mt-auto">
          <div className="container py-10">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
              <div className="col-span-2 md:col-span-1">
                <div className="flex items-center gap-2 mb-3">
                  <img src={LOGO_URL} alt="Lucky Riverboat" className="h-8 w-auto opacity-80" />
                  <span className="font-display text-xs font-bold text-gradient-gold">LUCKY RIVERBOAT</span>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">The premier crypto casino and sportsbook. Provably fair games, instant crypto transactions, and an exclusive VIP program.</p>
                <div className="flex items-center gap-3 mt-4">
                  <div className="flex items-center gap-1 px-2 py-1 rounded bg-muted/30 text-[10px] text-muted-foreground">
                    <Shield className="h-3 w-3 text-green-400" /> SSL Secured
                  </div>
                  <div className="flex items-center gap-1 px-2 py-1 rounded bg-muted/30 text-[10px] text-muted-foreground">
                    <Star className="h-3 w-3 text-primary" /> Provably Fair
                  </div>
                </div>
              </div>
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-primary mb-3">Casino</h4>
                <div className="space-y-1.5">
                  {houseGames.slice(0, 5).map(g => (
                    <Link key={g.path} href={g.path}>
                      <span className="block text-xs text-muted-foreground hover:text-foreground transition-colors">{g.name}</span>
                    </Link>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-primary mb-3">More</h4>
                <div className="space-y-1.5">
                  {houseGames.slice(5).map(g => (
                    <Link key={g.path} href={g.path}>
                      <span className="block text-xs text-muted-foreground hover:text-foreground transition-colors">{g.name}</span>
                    </Link>
                  ))}
                  <Link href="/slots"><span className="block text-xs text-muted-foreground hover:text-foreground transition-colors">Slots Lobby</span></Link>
                  <Link href="/sportsbook"><span className="block text-xs text-muted-foreground hover:text-foreground transition-colors">Sportsbook</span></Link>
                </div>
              </div>
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-primary mb-3">Platform</h4>
                <div className="space-y-1.5">
                  <Link href="/vip"><span className="block text-xs text-muted-foreground hover:text-foreground transition-colors">VIP Program</span></Link>
                  <Link href="/bonus"><span className="block text-xs text-muted-foreground hover:text-foreground transition-colors">Promotions</span></Link>
                  <Link href="/wallet"><span className="block text-xs text-muted-foreground hover:text-foreground transition-colors">Deposit & Withdraw</span></Link>
                  <span className="block text-xs text-muted-foreground">Support: 24/7 Live Chat</span>
                </div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-6 border-t border-border/20">
              <span className="text-[11px] text-muted-foreground/70">&copy; 2026 The Lucky Riverboat Casino. All rights reserved. 18+ | Play Responsibly</span>
              <div className="flex items-center gap-4 text-[11px] text-muted-foreground/70">
                <span className="flex items-center gap-1"><span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-500" /> BTC</span>
                <span className="flex items-center gap-1"><span className="inline-block w-1.5 h-1.5 rounded-full bg-blue-500" /> ETH</span>
                <span className="flex items-center gap-1"><span className="inline-block w-1.5 h-1.5 rounded-full bg-green-500" /> USDT</span>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
