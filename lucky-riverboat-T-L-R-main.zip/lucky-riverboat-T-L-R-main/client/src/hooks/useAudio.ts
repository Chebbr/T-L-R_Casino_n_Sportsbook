import { useCallback, useEffect, useRef, useState } from "react";

// Audio context singleton for Web Audio API
let audioCtx: AudioContext | null = null;
function getAudioContext() {
  if (!audioCtx) audioCtx = new AudioContext();
  return audioCtx;
}

// Generate sound effects programmatically using Web Audio API
function createOscillatorSound(
  frequency: number,
  duration: number,
  type: OscillatorType = "sine",
  volume: number = 0.3
) {
  const ctx = getAudioContext();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(frequency, ctx.currentTime);
  gain.gain.setValueAtTime(volume, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(ctx.currentTime);
  osc.stop(ctx.currentTime + duration);
}

function playChord(frequencies: number[], duration: number, type: OscillatorType = "sine", volume = 0.15) {
  frequencies.forEach((f) => createOscillatorSound(f, duration, type, volume));
}

// Sound effect definitions
const SOUNDS = {
  click: () => createOscillatorSound(800, 0.08, "square", 0.1),
  bet: () => {
    createOscillatorSound(400, 0.1, "sine", 0.2);
    setTimeout(() => createOscillatorSound(600, 0.1, "sine", 0.2), 50);
  },
  spin: () => {
    const ctx = getAudioContext();
    for (let i = 0; i < 10; i++) {
      setTimeout(() => createOscillatorSound(300 + i * 50, 0.05, "square", 0.1), i * 40);
    }
  },
  win: () => {
    const notes = [523, 659, 784, 1047]; // C5, E5, G5, C6
    notes.forEach((f, i) => {
      setTimeout(() => createOscillatorSound(f, 0.3, "sine", 0.2), i * 100);
    });
  },
  bigWin: () => {
    const notes = [523, 659, 784, 1047, 1319, 1568]; // ascending major
    notes.forEach((f, i) => {
      setTimeout(() => {
        playChord([f, f * 1.25, f * 1.5], 0.4, "sine", 0.12);
      }, i * 120);
    });
  },
  lose: () => {
    createOscillatorSound(400, 0.2, "sawtooth", 0.15);
    setTimeout(() => createOscillatorSound(300, 0.3, "sawtooth", 0.15), 150);
  },
  cardFlip: () => {
    createOscillatorSound(1200, 0.05, "square", 0.08);
    setTimeout(() => createOscillatorSound(1500, 0.05, "square", 0.08), 30);
  },
  reveal: () => createOscillatorSound(1000, 0.1, "sine", 0.15),
  cashout: () => {
    const notes = [880, 1100, 1320, 1760];
    notes.forEach((f, i) => {
      setTimeout(() => createOscillatorSound(f, 0.15, "sine", 0.2), i * 60);
    });
  },
  crash: () => {
    const ctx = getAudioContext();
    const bufferSize = ctx.sampleRate * 0.3;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.2));
    }
    const source = ctx.createBufferSource();
    const gain = ctx.createGain();
    source.buffer = buffer;
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    source.connect(gain);
    gain.connect(ctx.destination);
    source.start();
  },
  tick: () => createOscillatorSound(1200, 0.03, "square", 0.05),
  levelUp: () => {
    const notes = [440, 554, 659, 880, 1100, 1320];
    notes.forEach((f, i) => {
      setTimeout(() => createOscillatorSound(f, 0.2, "triangle", 0.15), i * 80);
    });
  },
  bonus: () => {
    playChord([523, 659, 784], 0.3, "sine", 0.15);
    setTimeout(() => playChord([587, 740, 880], 0.3, "sine", 0.15), 200);
    setTimeout(() => playChord([659, 831, 988], 0.4, "sine", 0.15), 400);
  },
  deposit: () => {
    const notes = [660, 880, 1100];
    notes.forEach((f, i) => setTimeout(() => createOscillatorSound(f, 0.15, "sine", 0.2), i * 100));
  },
  withdraw: () => {
    createOscillatorSound(880, 0.1, "sine", 0.15);
    setTimeout(() => createOscillatorSound(660, 0.15, "sine", 0.15), 80);
  },
};

export type SoundType = keyof typeof SOUNDS;

export function useAudio() {
  const [isMuted, setIsMuted] = useState(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("casino_muted") === "true";
    }
    return false;
  });
  const [volume, setVolumeState] = useState(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("casino_volume");
      return saved ? parseFloat(saved) : 0.7;
    }
    return 0.7;
  });

  const play = useCallback(
    (sound: SoundType) => {
      if (isMuted) return;
      try {
        // Resume audio context if suspended (browser autoplay policy)
        if (audioCtx?.state === "suspended") {
          audioCtx.resume();
        }
        SOUNDS[sound]();
      } catch (e) {
        // Silently fail - audio is non-critical
      }
    },
    [isMuted]
  );

  const toggleMute = useCallback(() => {
    setIsMuted((prev) => {
      const newVal = !prev;
      localStorage.setItem("casino_muted", String(newVal));
      return newVal;
    });
  }, []);

  const setVolume = useCallback((v: number) => {
    setVolumeState(v);
    localStorage.setItem("casino_volume", String(v));
  }, []);

  return { play, isMuted, toggleMute, volume, setVolume };
}

// Ambient background music using Web Audio API oscillators
export function useAmbientMusic() {
  const [isPlaying, setIsPlaying] = useState(false);
  const nodesRef = useRef<{ oscs: OscillatorNode[]; gains: GainNode[] } | null>(null);

  const startAmbient = useCallback(() => {
    if (nodesRef.current) return;
    const ctx = getAudioContext();
    if (ctx.state === "suspended") ctx.resume();

    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(0.03, ctx.currentTime);
    masterGain.connect(ctx.destination);

    const oscs: OscillatorNode[] = [];
    const gains: GainNode[] = [];

    // Create a soft ambient pad with detuned oscillators
    const frequencies = [110, 165, 220, 330]; // Am chord low
    frequencies.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      osc.detune.setValueAtTime(Math.random() * 10 - 5, ctx.currentTime);
      gain.gain.setValueAtTime(0.02, ctx.currentTime);
      osc.connect(gain);
      gain.connect(masterGain);
      osc.start();
      oscs.push(osc);
      gains.push(gain);
    });

    gains.push(masterGain);
    nodesRef.current = { oscs, gains };
    setIsPlaying(true);
  }, []);

  const stopAmbient = useCallback(() => {
    if (!nodesRef.current) return;
    nodesRef.current.oscs.forEach((osc) => {
      try { osc.stop(); } catch {}
    });
    nodesRef.current = null;
    setIsPlaying(false);
  }, []);

  useEffect(() => {
    return () => {
      if (nodesRef.current) {
        nodesRef.current.oscs.forEach((osc) => { try { osc.stop(); } catch {} });
      }
    };
  }, []);

  return { isPlaying, startAmbient, stopAmbient };
}
