import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import {
  getOrCreateWallets, getWalletBalance, updateWalletBalance,
  createTransaction, getTransactions, createGameSession, completeGameSession,
  getRecentGames, updatePlayerStats, getPlayerStats, getAllPlayerStats,
  getHouseWallet, initializeHouseWallets, updateHouseWalletBalance,
  getSportsEvents, createSportsBet, getUserSportsBets, settleSportsBet,
  createStripePayment, getUserStripePayments,
  createNotification, getUserNotifications, markNotificationAsRead, getUnreadNotificationCount,
  checkAndUpdateVipTier, getVipTierInfo, getAllVipTiers, updateUserTotalWagered,
  createBonusCode, getBonusCodeByCode, getAllBonusCodes, redeemBonusCode,
  getUserRedemptions, updateBonusCode, deleteBonusCode,
  getRtpConfig, getAllRtpConfigs, upsertRtpConfig, initializeRtpConfigs, applyRtp,
  getDepositAddress, submitDepositClaim, confirmDeposit, rejectDeposit, getPendingDeposits,
  createWithdrawalRequest, getUserWithdrawals, processWithdrawal,
  getPendingWithdrawals, createAuditLog, getAuditLogs,
  createSlotsSession, getSlotsSession, closeSlotsSession,
  getAllUsers, getAdminStats, getUserById,
  getDepositAddresses, updateDepositAddress,
  adminAdjustUserBalance, adminGetAllUserWallets,
  getSiteSetting, upsertSiteSetting, getAllSiteSettings,
  getChatMessages, sendChatMessage, deleteChatMessage,
  createSupportTicket, getUserSupportTickets, getAllSupportTickets,
  getSupportMessages, addSupportMessage, closeSupportTicket,
  getOrCreateReferralCode, getReferralByCode, applyReferralCode, getReferralStats,
  createSportsEvent, updateSportsEvent, deleteSportsEvent,
} from "./db";

// Protected procedure helper
const protectedProcedure = publicProcedure.use(({ ctx, next }) => {
  if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED", message: "You must be logged in" });
  return next({ ctx: { ...ctx, user: ctx.user } });
});

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  return next({ ctx });
});

// ==================== GAME HELPERS ====================
function generateDeck() {
  const suits = ["hearts", "diamonds", "clubs", "spades"];
  const values = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];
  const deck: string[] = [];
  for (const suit of suits) for (const value of values) deck.push(`${value}_${suit}`);
  for (let i = deck.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [deck[i], deck[j]] = [deck[j], deck[i]]; }
  return deck;
}
function getCardValue(card: string): number {
  const value = card.split("_")[0];
  if (value === "A") return 14; if (value === "K") return 13; if (value === "Q") return 12; if (value === "J") return 11;
  return parseInt(value);
}

// Active game state (in-memory)
const activeMinesGames = new Map<number, any>();
const activeHiLowGames = new Map<number, any>();
const activeTowerGames = new Map<number, any>();

// Initialize on startup
initializeHouseWallets().catch(console.error);
initializeRtpConfigs().catch(console.error);

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ==================== WALLET ====================
  wallet: router({
    getAll: protectedProcedure.query(async ({ ctx }) => {
      return getOrCreateWallets(ctx.user.id);
    }),
    getBalance: protectedProcedure
      .input(z.object({ currency: z.enum(["BTC", "ETH", "USDT"]) }))
      .query(async ({ ctx, input }) => {
        return getWalletBalance(ctx.user.id, input.currency);
      }),
    getTransactions: protectedProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ ctx, input }) => {
        return getTransactions(ctx.user.id, input.limit || 20);
      }),
    getDepositAddress: protectedProcedure
      .input(z.object({ currency: z.enum(["BTC", "ETH", "USDT"]) }))
      .query(async ({ ctx, input }) => {
        return getDepositAddress(ctx.user.id, input.currency);
      }),
    submitDeposit: protectedProcedure
      .input(z.object({
        currency: z.enum(["BTC", "ETH", "USDT"]),
        amount: z.number().positive(),
        txHash: z.string().min(10, "Valid transaction hash required"),
      }))
      .mutation(async ({ ctx, input }) => {
        return submitDepositClaim(ctx.user.id, input.currency, input.amount, input.txHash);
      }),
    withdraw: protectedProcedure
      .input(z.object({
        currency: z.enum(["BTC", "ETH", "USDT"]),
        amount: z.number().positive(),
        toAddress: z.string().min(10),
      }))
      .mutation(async ({ ctx, input }) => {
        return createWithdrawalRequest(ctx.user.id, input.currency, input.amount, input.toAddress);
      }),
    getWithdrawals: protectedProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ ctx, input }) => {
        return getUserWithdrawals(ctx.user.id, input.limit || 20);
      }),
  }),

  // ==================== PLAYER STATS ====================
  stats: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      return getPlayerStats(ctx.user.id);
    }),
    getAll: protectedProcedure.query(async ({ ctx }) => {
      return getAllPlayerStats(ctx.user.id);
    }),
    getRecentGames: protectedProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ ctx, input }) => {
        return getRecentGames(ctx.user.id, input.limit || 10);
      }),
  }),

  // ==================== VIP SYSTEM ====================
  vip: router({
    getMyTier: protectedProcedure.query(async ({ ctx }) => {
      const user = await getUserById(ctx.user.id);
      if (!user) return null;
      const tierInfo = getVipTierInfo(user.vipTier);
      return { ...tierInfo, currentWagered: parseFloat(user.totalWagered), vipPoints: user.vipPoints };
    }),
    getAllTiers: publicProcedure.query(() => {
      return getAllVipTiers();
    }),
    checkUpgrade: protectedProcedure.mutation(async ({ ctx }) => {
      return checkAndUpdateVipTier(ctx.user.id);
    }),
  }),

  // ==================== BONUS CODES ====================
  bonus: router({
    redeem: protectedProcedure
      .input(z.object({ code: z.string().min(1) }))
      .mutation(async ({ ctx, input }) => {
        const result = await redeemBonusCode(ctx.user.id, input.code.toUpperCase());
        if (!result.success) throw new TRPCError({ code: "BAD_REQUEST", message: result.error });
        return result;
      }),
    getMyRedemptions: protectedProcedure.query(async ({ ctx }) => {
      return getUserRedemptions(ctx.user.id);
    }),
  }),

  // ==================== CASINO GAMES ====================
  casino: router({
    getRtp: publicProcedure
      .input(z.object({ gameType: z.string() }))
      .query(async ({ input }) => {
        const config = await getRtpConfig(input.gameType);
        return config ? { targetRtp: parseFloat(config.targetRtp), houseEdge: parseFloat(config.houseEdge) } : { targetRtp: 0.96, houseEdge: 0.04 };
      }),

    // ---- KENO ----
    playKeno: protectedProcedure
      .input(z.object({
        selectedNumbers: z.array(z.number().min(1).max(40)).min(1).max(10),
        betAmount: z.number().positive(),
        currency: z.enum(["BTC", "ETH", "USDT"]),
      }))
      .mutation(async ({ ctx, input }) => {
        const wallet = await getWalletBalance(ctx.user.id, input.currency);
        if (!wallet || parseFloat(wallet.balance) < input.betAmount) throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient balance" });
        await updateWalletBalance(ctx.user.id, input.currency, input.betAmount, "subtract");

        const rtpConfig = await getRtpConfig("keno");
        const targetRtp = rtpConfig ? parseFloat(rtpConfig.targetRtp) : 0.96;

        // Draw 20 numbers
        const allNumbers = Array.from({ length: 40 }, (_, i) => i + 1);
        for (let i = allNumbers.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [allNumbers[i], allNumbers[j]] = [allNumbers[j], allNumbers[i]]; }
        const drawnNumbers = allNumbers.slice(0, 20);
        const matches = input.selectedNumbers.filter(n => drawnNumbers.includes(n)).length;

        const kenoPaytable: Record<number, Record<number, number>> = {
          1: { 1: 3.5 }, 2: { 1: 1, 2: 9 }, 3: { 1: 0.5, 2: 3, 3: 26 },
          4: { 1: 0.5, 2: 2, 3: 6, 4: 75 }, 5: { 2: 1, 3: 3, 4: 15, 5: 250 },
          6: { 3: 2, 4: 8, 5: 50, 6: 500 }, 7: { 3: 1, 4: 5, 5: 20, 6: 100, 7: 1000 },
          8: { 4: 3, 5: 10, 6: 50, 7: 250, 8: 2500 }, 9: { 4: 2, 5: 5, 6: 25, 7: 100, 8: 500, 9: 5000 },
          10: { 5: 3, 6: 15, 7: 50, 8: 250, 9: 1000, 10: 10000 },
        };

        let baseMultiplier = kenoPaytable[input.selectedNumbers.length]?.[matches] || 0;
        let multiplier = baseMultiplier * targetRtp;
        let payout = input.betAmount * multiplier;
        const isWin = payout > 0;

        if (isWin) await updateWalletBalance(ctx.user.id, input.currency, payout, "add");

        const session = await createGameSession({ userId: ctx.user.id, gameType: "keno", betAmount: input.betAmount, currency: input.currency });
        if (session) await completeGameSession(session.id, isWin ? "win" : "loss", payout, multiplier);
        await updatePlayerStats(ctx.user.id, "keno", input.betAmount, payout, isWin);

        return { drawnNumbers, matches, multiplier, payout, isWin };
      }),

    // ---- CRASH ----
    playCrash: protectedProcedure
      .input(z.object({
        betAmount: z.number().positive(),
        currency: z.enum(["BTC", "ETH", "USDT"]),
        autoCashout: z.number().min(1.01).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const wallet = await getWalletBalance(ctx.user.id, input.currency);
        if (!wallet || parseFloat(wallet.balance) < input.betAmount) throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient balance" });
        await updateWalletBalance(ctx.user.id, input.currency, input.betAmount, "subtract");

        const rtpConfig = await getRtpConfig("crash");
        const targetRtp = rtpConfig ? parseFloat(rtpConfig.targetRtp) : 0.96;

        // Generate crash point using house edge
        const houseEdge = 1 - targetRtp;
        const r = Math.random();
        const crashPoint = r < houseEdge ? 1.0 : Math.max(1, Math.floor(100 / (r * 100)) * 100) / 100;

        const cashoutAt = input.autoCashout || crashPoint;
        const didCashout = cashoutAt <= crashPoint;
        const multiplier = didCashout ? cashoutAt : 0;
        const payout = didCashout ? input.betAmount * multiplier : 0;

        if (payout > 0) await updateWalletBalance(ctx.user.id, input.currency, payout, "add");

        const session = await createGameSession({ userId: ctx.user.id, gameType: "crash", betAmount: input.betAmount, currency: input.currency });
        if (session) await completeGameSession(session.id, didCashout ? "win" : "loss", payout, multiplier);
        await updatePlayerStats(ctx.user.id, "crash", input.betAmount, payout, didCashout);

        return { crashPoint, cashoutAt, multiplier, payout, didCashout };
      }),

    // ---- ROULETTE ----
    playRoulette: protectedProcedure
      .input(z.object({
        betAmount: z.number().positive(),
        currency: z.enum(["BTC", "ETH", "USDT"]),
        betType: z.enum(["red", "black", "green", "odd", "even", "number"]),
        betNumber: z.number().min(0).max(36).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const wallet = await getWalletBalance(ctx.user.id, input.currency);
        if (!wallet || parseFloat(wallet.balance) < input.betAmount) throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient balance" });
        await updateWalletBalance(ctx.user.id, input.currency, input.betAmount, "subtract");

        const rtpConfig = await getRtpConfig("roulette");
        const targetRtp = rtpConfig ? parseFloat(rtpConfig.targetRtp) : 0.96;

        const result = Math.floor(Math.random() * 37); // 0-36
        const redNumbers = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];
        const isRed = redNumbers.includes(result);
        const isBlack = result > 0 && !isRed;
        const isGreen = result === 0;

        let isWin = false;
        let baseMultiplier = 0;
        if (input.betType === "red" && isRed) { isWin = true; baseMultiplier = 2; }
        else if (input.betType === "black" && isBlack) { isWin = true; baseMultiplier = 2; }
        else if (input.betType === "green" && isGreen) { isWin = true; baseMultiplier = 35; }
        else if (input.betType === "odd" && result > 0 && result % 2 === 1) { isWin = true; baseMultiplier = 2; }
        else if (input.betType === "even" && result > 0 && result % 2 === 0) { isWin = true; baseMultiplier = 2; }
        else if (input.betType === "number" && result === input.betNumber) { isWin = true; baseMultiplier = 35; }

        const multiplier = isWin ? baseMultiplier * targetRtp : 0;
        const payout = isWin ? input.betAmount * multiplier : 0;

        if (payout > 0) await updateWalletBalance(ctx.user.id, input.currency, payout, "add");

        const session = await createGameSession({ userId: ctx.user.id, gameType: "roulette", betAmount: input.betAmount, currency: input.currency });
        if (session) await completeGameSession(session.id, isWin ? "win" : "loss", payout, multiplier);
        await updatePlayerStats(ctx.user.id, "roulette", input.betAmount, payout, isWin);

        return { result, isRed, isBlack, isGreen, isWin, multiplier, payout };
      }),

    // ---- HELM (Wheel Spin) ----
    playHelm: protectedProcedure
      .input(z.object({
        betAmount: z.number().positive(),
        currency: z.enum(["BTC", "ETH", "USDT"]),
      }))
      .mutation(async ({ ctx, input }) => {
        const wallet = await getWalletBalance(ctx.user.id, input.currency);
        if (!wallet || parseFloat(wallet.balance) < input.betAmount) throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient balance" });
        await updateWalletBalance(ctx.user.id, input.currency, input.betAmount, "subtract");

        const rtpConfig = await getRtpConfig("helm");
        const targetRtp = rtpConfig ? parseFloat(rtpConfig.targetRtp) : 0.96;

        const segments = [
          { label: "0x", multiplier: 0, weight: 15 },
          { label: "0.5x", multiplier: 0.5, weight: 20 },
          { label: "1x", multiplier: 1, weight: 25 },
          { label: "1.5x", multiplier: 1.5, weight: 18 },
          { label: "2x", multiplier: 2, weight: 12 },
          { label: "3x", multiplier: 3, weight: 6 },
          { label: "5x", multiplier: 5, weight: 3 },
          { label: "10x", multiplier: 10, weight: 1 },
        ];

        // Weighted random with RTP adjustment
        const totalWeight = segments.reduce((sum, s) => sum + s.weight, 0);
        let random = Math.random() * totalWeight;
        let selectedSegment = segments[0];
        for (const segment of segments) {
          random -= segment.weight;
          if (random <= 0) { selectedSegment = segment; break; }
        }

        const multiplier = selectedSegment.multiplier * targetRtp;
        const payout = input.betAmount * multiplier;
        const isWin = payout > 0;

        if (payout > 0) await updateWalletBalance(ctx.user.id, input.currency, payout, "add");

        const session = await createGameSession({ userId: ctx.user.id, gameType: "helm", betAmount: input.betAmount, currency: input.currency });
        if (session) await completeGameSession(session.id, isWin ? "win" : "loss", payout, multiplier);
        await updatePlayerStats(ctx.user.id, "helm", input.betAmount, payout, isWin);

        const segmentIndex = segments.indexOf(selectedSegment);
        return { segmentIndex, segment: selectedSegment.label, multiplier, payout, isWin };
      }),

    // ---- TOWER ----
    startTower: protectedProcedure
      .input(z.object({
        betAmount: z.number().positive(),
        currency: z.enum(["BTC", "ETH", "USDT"]),
        difficulty: z.enum(["easy", "medium", "hard"]),
      }))
      .mutation(async ({ ctx, input }) => {
        const wallet = await getWalletBalance(ctx.user.id, input.currency);
        if (!wallet || parseFloat(wallet.balance) < input.betAmount) throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient balance" });
        await updateWalletBalance(ctx.user.id, input.currency, input.betAmount, "subtract");

        const columns = input.difficulty === "easy" ? 4 : input.difficulty === "medium" ? 3 : 2;
        const rows = 8;
        const safeColumns: number[][] = [];
        for (let i = 0; i < rows; i++) {
          const safe = Math.floor(Math.random() * columns);
          safeColumns.push([safe]);
        }

        const session = await createGameSession({ userId: ctx.user.id, gameType: "tower", betAmount: input.betAmount, currency: input.currency });

        activeTowerGames.set(ctx.user.id, {
          safeColumns, betAmount: input.betAmount, difficulty: input.difficulty,
          currentRow: 0, columns, sessionId: session?.id,
        });

        return { columns, rows, currentRow: 0 };
      }),

    climbTower: protectedProcedure
      .input(z.object({ column: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const game = activeTowerGames.get(ctx.user.id);
        if (!game) throw new TRPCError({ code: "BAD_REQUEST", message: "No active tower game" });

        const isSafe = game.safeColumns[game.currentRow].includes(input.column);
        if (isSafe) {
          game.currentRow += 1;
          const multiplierTable: Record<string, number[]> = {
            easy: [1.2, 1.4, 1.7, 2.1, 2.6, 3.2, 4.0, 5.0],
            medium: [1.4, 1.9, 2.6, 3.5, 4.8, 6.5, 8.8, 12.0],
            hard: [1.8, 3.2, 5.8, 10.4, 18.7, 33.6, 60.5, 108.9],
          };
          const multiplier = multiplierTable[game.difficulty]?.[game.currentRow - 1] || 1;
          activeTowerGames.set(ctx.user.id, { ...game, multiplier });

          return { safe: true, currentRow: game.currentRow, multiplier, gameOver: game.currentRow >= 8 };
        } else {
          if (game.sessionId) await completeGameSession(game.sessionId, "loss", 0);
          await updatePlayerStats(ctx.user.id, "tower", game.betAmount, 0, false);
          const safeColumns = game.safeColumns;
          activeTowerGames.delete(ctx.user.id);
          return { safe: false, currentRow: game.currentRow, multiplier: 0, gameOver: true, safeColumns };
        }
      }),

    cashoutTower: protectedProcedure.mutation(async ({ ctx }) => {
      const game = activeTowerGames.get(ctx.user.id);
      if (!game) throw new TRPCError({ code: "BAD_REQUEST", message: "No active tower game" });
      const multiplier = game.multiplier || 1;
      const payout = game.betAmount * multiplier;
      await updateWalletBalance(ctx.user.id, "USDT", payout, "add");
      if (game.sessionId) await completeGameSession(game.sessionId, "win", payout, multiplier);
      await updatePlayerStats(ctx.user.id, "tower", game.betAmount, payout, true);
      activeTowerGames.delete(ctx.user.id);
      return { payout, multiplier };
    }),

    // ---- MINES ----
    startMines: protectedProcedure
      .input(z.object({
        betAmount: z.number().positive(),
        currency: z.enum(["BTC", "ETH", "USDT"]),
        mineCount: z.number().min(1).max(24),
      }))
      .mutation(async ({ ctx, input }) => {
        const wallet = await getWalletBalance(ctx.user.id, input.currency);
        if (!wallet || parseFloat(wallet.balance) < input.betAmount) throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient balance" });
        await updateWalletBalance(ctx.user.id, input.currency, input.betAmount, "subtract");

        const minePositions: number[] = [];
        while (minePositions.length < input.mineCount) {
          const pos = Math.floor(Math.random() * 25);
          if (!minePositions.includes(pos)) minePositions.push(pos);
        }

        const session = await createGameSession({ userId: ctx.user.id, gameType: "mines", betAmount: input.betAmount, currency: input.currency });
        if (session) {
          activeMinesGames.set(ctx.user.id, {
            minePositions, betAmount: input.betAmount, mineCount: input.mineCount, sessionId: session.id,
          });
        }
        return { minePositions };
      }),

    revealMine: protectedProcedure
      .input(z.object({ position: z.number().min(0).max(24) }))
      .mutation(async ({ ctx, input }) => {
        const game = activeMinesGames.get(ctx.user.id);
        if (!game) throw new TRPCError({ code: "BAD_REQUEST", message: "No active mines game" });
        const isMine = game.minePositions.includes(input.position);
        if (isMine) {
          await completeGameSession(game.sessionId, "loss", 0);
          await updatePlayerStats(ctx.user.id, "mines", game.betAmount, 0, false);
          const minePositions = game.minePositions;
          activeMinesGames.delete(ctx.user.id);
          return { isMine: true, minePositions, gameOver: true };
        }
        return { isMine: false, gameOver: false };
      }),

    cashoutMines: protectedProcedure
      .input(z.object({ revealedCount: z.number(), multiplier: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const game = activeMinesGames.get(ctx.user.id);
        if (!game) throw new TRPCError({ code: "BAD_REQUEST", message: "No active game" });
        const payout = game.betAmount * input.multiplier;
        await updateWalletBalance(ctx.user.id, "USDT", payout, "add");
        await completeGameSession(game.sessionId, "win", payout, input.multiplier);
        await updatePlayerStats(ctx.user.id, "mines", game.betAmount, payout, true);
        activeMinesGames.delete(ctx.user.id);
        return { payout };
      }),

    // ---- HI-LOW ----
    playHiLow: protectedProcedure
      .input(z.object({
        betAmount: z.number().positive(),
        currency: z.enum(["BTC", "ETH", "USDT"]),
      }))
      .mutation(async ({ ctx, input }) => {
        const wallet = await getWalletBalance(ctx.user.id, input.currency);
        if (!wallet || parseFloat(wallet.balance) < input.betAmount) throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient balance" });
        await updateWalletBalance(ctx.user.id, input.currency, input.betAmount, "subtract");

        const deck = generateDeck();
        const currentCard = deck.pop()!;
        const session = await createGameSession({ userId: ctx.user.id, gameType: "hilow", betAmount: input.betAmount, currency: input.currency });
        if (session) {
          activeHiLowGames.set(ctx.user.id, {
            deck, currentCard, betAmount: input.betAmount, streak: 0, multiplier: 1, sessionId: session.id,
          });
        }
        return { currentCard };
      }),

    guessHiLow: protectedProcedure
      .input(z.object({ guess: z.enum(["high", "low", "same"]) }))
      .mutation(async ({ ctx, input }) => {
        const game = activeHiLowGames.get(ctx.user.id);
        if (!game) throw new TRPCError({ code: "BAD_REQUEST", message: "No active game" });

        const nextCard = game.deck.pop()!;
        const currentValue = getCardValue(game.currentCard);
        const nextValue = getCardValue(nextCard);

        let correct = false;
        if (input.guess === "high") correct = nextValue > currentValue;
        else if (input.guess === "low") correct = nextValue < currentValue;
        else correct = nextValue === currentValue;

        if (correct) {
          game.currentCard = nextCard;
          game.streak += 1;
          game.multiplier = Math.pow(1.5, game.streak);
          activeHiLowGames.set(ctx.user.id, game);
          return { nextCard, correct: true, streak: game.streak, multiplier: game.multiplier };
        } else {
          await completeGameSession(game.sessionId, "loss", 0);
          await updatePlayerStats(ctx.user.id, "hilow", game.betAmount, 0, false);
          activeHiLowGames.delete(ctx.user.id);
          return { nextCard, correct: false, streak: game.streak, multiplier: game.multiplier };
        }
      }),

    cashoutHiLow: protectedProcedure
      .input(z.object({ streak: z.number(), multiplier: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const game = activeHiLowGames.get(ctx.user.id);
        if (!game) throw new TRPCError({ code: "BAD_REQUEST", message: "No active game" });
        const payout = game.betAmount * input.multiplier;
        await updateWalletBalance(ctx.user.id, "USDT", payout, "add");
        await completeGameSession(game.sessionId, "win", payout, input.multiplier);
        await updatePlayerStats(ctx.user.id, "hilow", game.betAmount, payout, true);
        activeHiLowGames.delete(ctx.user.id);
        return { payout };
      }),
  }),

  // ==================== SPORTSBOOK ====================
  sportsbook: router({
    getEvents: publicProcedure
      .input(z.object({ status: z.enum(["upcoming", "live", "completed", "cancelled"]).optional() }))
      .query(async ({ input }) => {
        return getSportsEvents(input.status);
      }),
    placeBet: protectedProcedure
      .input(z.object({
        eventId: z.number(),
        prediction: z.enum(["home", "draw", "away"]),
        betAmount: z.number().positive(),
        currency: z.enum(["BTC", "ETH", "USDT"]),
        odds: z.number().positive(),
      }))
      .mutation(async ({ ctx, input }) => {
        const wallet = await getWalletBalance(ctx.user.id, input.currency);
        if (!wallet || parseFloat(wallet.balance) < input.betAmount) throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient balance" });
        await updateWalletBalance(ctx.user.id, input.currency, input.betAmount, "subtract");
        const bet = await createSportsBet({
          userId: ctx.user.id, eventId: input.eventId, prediction: input.prediction,
          betAmount: input.betAmount, currency: input.currency, odds: input.odds,
        });
        await updatePlayerStats(ctx.user.id, "sportsbook", input.betAmount, 0, false);
        return bet;
      }),
    getMyBets: protectedProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ ctx, input }) => {
        return getUserSportsBets(ctx.user.id, input.limit || 20);
      }),
  }),

  // ==================== SLOTS ====================
  slots: router({
    getProviders: publicProcedure.query(() => {
      return [
        { id: "hacksaw", name: "Hacksaw Gaming", logo: "hacksaw", games: [
          { id: "hack_wanted", name: "Wanted Dead or a Wild", rtp: 96.38 },
          { id: "hack_chaos", name: "Chaos Crew", rtp: 96.09 },
          { id: "hack_dork", name: "Dork Unit", rtp: 96.20 },
          { id: "hack_stick", name: "Stick Em", rtp: 96.29 },
        ]},
        { id: "pragmatic", name: "Pragmatic Play", logo: "pragmatic", games: [
          { id: "prag_gates", name: "Gates of Olympus", rtp: 96.50 },
          { id: "prag_dog", name: "The Dog House", rtp: 96.51 },
          { id: "prag_sweet", name: "Sweet Bonanza", rtp: 96.48 },
          { id: "prag_wolf", name: "Wolf Gold", rtp: 96.01 },
        ]},
        { id: "massive_studios", name: "Massive Studios", logo: "massive", games: [
          { id: "mass_mega", name: "Mega Fortune", rtp: 96.60 },
          { id: "mass_cosmic", name: "Cosmic Cash", rtp: 95.80 },
          { id: "mass_pirate", name: "Pirate's Bounty", rtp: 96.10 },
          { id: "mass_neon", name: "Neon Nights", rtp: 96.30 },
        ]},
        { id: "lady_shady", name: "Lady Shady", logo: "ladyshady", games: [
          { id: "lady_mystic", name: "Mystic Gems", rtp: 96.40 },
          { id: "lady_shadow", name: "Shadow Spins", rtp: 95.90 },
          { id: "lady_fortune", name: "Fortune's Kiss", rtp: 96.20 },
          { id: "lady_midnight", name: "Midnight Riches", rtp: 96.50 },
        ]},
      ];
    }),
    launchGame: protectedProcedure
      .input(z.object({
        provider: z.enum(["hacksaw", "pragmatic", "massive_studios", "lady_shady"]),
        gameId: z.string(),
        gameName: z.string().optional(),
        currency: z.enum(["BTC", "ETH", "USDT"]),
      }))
      .mutation(async ({ ctx, input }) => {
        const wallet = await getWalletBalance(ctx.user.id, input.currency);
        if (!wallet) throw new TRPCError({ code: "BAD_REQUEST", message: "Wallet not found" });
        const session = await createSlotsSession({
          userId: ctx.user.id, provider: input.provider, gameId: input.gameId,
          gameName: input.gameName, currency: input.currency,
          initialBalance: parseFloat(wallet.balance),
        });
        return { sessionToken: session?.sessionToken, balance: wallet.balance };
      }),
  }),

  // ==================== NOTIFICATIONS ====================
  notifications: router({
    getAll: protectedProcedure
      .input(z.object({ unreadOnly: z.boolean().optional() }))
      .query(async ({ ctx, input }) => {
        return getUserNotifications(ctx.user.id, input.unreadOnly || false);
      }),
    markAsRead: protectedProcedure
      .input(z.object({ notificationId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await markNotificationAsRead(input.notificationId);
        return { success: true };
      }),
    getUnreadCount: protectedProcedure.query(async ({ ctx }) => {
      return getUnreadNotificationCount(ctx.user.id);
    }),
  }),

  // ==================== ADMIN ====================
  admin: router({
    getStats: adminProcedure.query(async () => {
      return getAdminStats();
    }),
    getUsers: adminProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ input }) => {
        return getAllUsers(input.limit || 100);
      }),
    getRtpConfigs: adminProcedure.query(async () => {
      return getAllRtpConfigs();
    }),
    updateRtp: adminProcedure
      .input(z.object({
        gameType: z.string(),
        targetRtp: z.number().min(0).max(1),
        houseEdge: z.number().min(0).max(1),
        adjustmentNotes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await upsertRtpConfig(input);
        await createAuditLog({
          userId: ctx.user.id, action: "update_rtp", entity: "rtp_configs",
          details: `Updated ${input.gameType} RTP to ${input.targetRtp}, house edge ${input.houseEdge}`,
        });
        return { success: true };
      }),
    getBonusCodes: adminProcedure.query(async () => {
      return getAllBonusCodes();
    }),
    createBonusCode: adminProcedure
      .input(z.object({
        code: z.string().min(1),
        description: z.string().optional(),
        type: z.enum(["deposit_match", "free_credits", "free_spins", "cashback"]),
        value: z.number().positive(),
        currency: z.enum(["BTC", "ETH", "USDT"]).optional(),
        maxUses: z.number().optional(),
        expiresAt: z.date().optional(),
        vipTierRequired: z.enum(["bronze", "silver", "gold", "platinum", "diamond"]).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const result = await createBonusCode({ ...input, code: input.code.toUpperCase() });
        await createAuditLog({
          userId: ctx.user.id, action: "create_bonus_code", entity: "bonus_codes",
          details: `Created bonus code ${input.code.toUpperCase()} worth ${input.value}`,
        });
        return result;
      }),
    updateBonusCode: adminProcedure
      .input(z.object({
        id: z.number(),
        isActive: z.boolean().optional(),
        maxUses: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        await updateBonusCode(input.id, input);
        return { success: true };
      }),
    deleteBonusCode: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteBonusCode(input.id);
        return { success: true };
      }),
    getAuditLogs: adminProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ input }) => {
        return getAuditLogs(input.limit || 100);
      }),
    getPendingWithdrawals: adminProcedure.query(async () => {
      return getPendingWithdrawals();
    }),
    approveWithdrawal: adminProcedure
      .input(z.object({ withdrawalId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await processWithdrawal(input.withdrawalId);
        await createAuditLog({
          userId: ctx.user.id, action: "approve_withdrawal", entity: "withdrawal_requests",
          entityId: input.withdrawalId, details: "Admin approved withdrawal",
        });
        return { success: true };
      }),
    rejectWithdrawal: adminProcedure
      .input(z.object({ withdrawalId: z.number(), reason: z.string().min(1) }))
      .mutation(async ({ ctx, input }) => {
        const db = await import("./db").then(m => m.getDb());
        if (db) {
          const { withdrawalRequests } = await import("../drizzle/schema");
          const { eq } = await import("drizzle-orm");
          const requests = await db.select().from(withdrawalRequests).where(eq(withdrawalRequests.id, input.withdrawalId)).limit(1);
          if (requests[0] && requests[0].status === "pending") {
            // Refund the user
            const amount = parseFloat(requests[0].amount);
            const currency = requests[0].currency as "BTC" | "ETH" | "USDT";
            await updateWalletBalance(requests[0].userId, currency, amount, "add");
            await db.update(withdrawalRequests).set({ status: "cancelled", failureReason: input.reason, processedAt: new Date() }).where(eq(withdrawalRequests.id, input.withdrawalId));
            await createNotification({
              userId: requests[0].userId, title: "Withdrawal Rejected",
              message: `Your withdrawal of ${amount} ${currency} was rejected. Reason: ${input.reason}. Funds have been returned.`,
              type: "error",
            });
          }
        }
        await createAuditLog({
          userId: ctx.user.id, action: "reject_withdrawal", entity: "withdrawal_requests",
          entityId: input.withdrawalId, details: input.reason,
        });
        return { success: true };
      }),
    // Pending deposits
    getPendingDeposits: adminProcedure.query(async () => {
      return getPendingDeposits();
    }),
    confirmDeposit: adminProcedure
      .input(z.object({ transactionId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const result = await confirmDeposit(input.transactionId, ctx.user.id);
        if (!result.success) throw new TRPCError({ code: "BAD_REQUEST", message: result.error || "Failed" });
        return result;
      }),
    rejectDeposit: adminProcedure
      .input(z.object({ transactionId: z.number(), reason: z.string().min(1) }))
      .mutation(async ({ ctx, input }) => {
        const result = await rejectDeposit(input.transactionId, ctx.user.id, input.reason);
        if (!result.success) throw new TRPCError({ code: "BAD_REQUEST", message: result.error || "Failed" });
        return result;
      }),
    // Deposit address management
    getDepositAddresses: adminProcedure.query(async () => {
      return getDepositAddresses();
    }),
    updateDepositAddress: adminProcedure
      .input(z.object({
        currency: z.enum(["BTC", "ETH", "USDT"]),
        address: z.string().min(10),
      }))
      .mutation(async ({ ctx, input }) => {
        await updateDepositAddress(input.currency, input.address);
        await createAuditLog({
          userId: ctx.user.id, action: "update_deposit_address", entity: "site_settings",
          details: `Updated ${input.currency} deposit address to ${input.address}`,
        });
        return { success: true };
      }),
    // User fund management
    getAllUserWallets: adminProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ input }) => {
        return adminGetAllUserWallets(input.limit || 100);
      }),
    adjustUserBalance: adminProcedure
      .input(z.object({
        userId: z.number(),
        currency: z.enum(["BTC", "ETH", "USDT"]),
        amount: z.number().positive(),
        action: z.enum(["add", "remove"]),
        reason: z.string().min(1),
      }))
      .mutation(async ({ ctx, input }) => {
        const result = await adminAdjustUserBalance(
          ctx.user.id, input.userId, input.currency, input.amount, input.action, input.reason
        );
        if (!result.success) throw new TRPCError({ code: "BAD_REQUEST", message: result.error || "Failed to adjust balance" });
        return result;
      }),
    // Site settings
    getSiteSettings: adminProcedure.query(async () => {
      return getAllSiteSettings();
    }),
    updateSiteSetting: adminProcedure
      .input(z.object({
        key: z.string().min(1),
        value: z.string().min(1),
        description: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await upsertSiteSetting(input.key, input.value, input.description);
        await createAuditLog({
          userId: ctx.user.id, action: "update_site_setting", entity: "site_settings",
          details: `Updated setting ${input.key}`,
        });
        return { success: true };
      }),
  }),

  // ==================== CHAT ====================
  chat: router({
    getMessages: publicProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ input }) => {
        return getChatMessages(input.limit || 50);
      }),
    send: protectedProcedure
      .input(z.object({ message: z.string().min(1).max(500) }))
      .mutation(async ({ ctx, input }) => {
        return sendChatMessage(ctx.user.id, ctx.user.name || "Anonymous", input.message);
      }),
    delete: adminProcedure
      .input(z.object({ messageId: z.number() }))
      .mutation(async ({ input }) => {
        await deleteChatMessage(input.messageId);
        return { success: true };
      }),
  }),

  // ==================== SUPPORT ====================
  support: router({
    createTicket: protectedProcedure
      .input(z.object({ subject: z.string().min(1), message: z.string().min(1) }))
      .mutation(async ({ ctx, input }) => {
        return createSupportTicket(ctx.user.id, ctx.user.name || "Anonymous", input.subject, input.message);
      }),
    getMyTickets: protectedProcedure.query(async ({ ctx }) => {
      return getUserSupportTickets(ctx.user.id);
    }),
    getMessages: protectedProcedure
      .input(z.object({ ticketId: z.number() }))
      .query(async ({ input }) => {
        return getSupportMessages(input.ticketId);
      }),
    reply: protectedProcedure
      .input(z.object({ ticketId: z.number(), message: z.string().min(1) }))
      .mutation(async ({ ctx, input }) => {
        const isAdmin = ctx.user.role === "admin";
        return addSupportMessage(input.ticketId, ctx.user.id, isAdmin, input.message);
      }),
    // Admin
    getAllTickets: adminProcedure
      .input(z.object({ status: z.string().optional() }))
      .query(async ({ input }) => {
        return getAllSupportTickets(input.status);
      }),
    closeTicket: adminProcedure
      .input(z.object({ ticketId: z.number() }))
      .mutation(async ({ input }) => {
        await closeSupportTicket(input.ticketId);
        return { success: true };
      }),
  }),

  // ==================== REFERRALS ====================
  referral: router({
    getMyCode: protectedProcedure.query(async ({ ctx }) => {
      return getOrCreateReferralCode(ctx.user.id);
    }),
    getStats: protectedProcedure.query(async ({ ctx }) => {
      return getReferralStats(ctx.user.id);
    }),
    useCode: protectedProcedure
      .input(z.object({ code: z.string().min(1) }))
      .mutation(async ({ ctx, input }) => {
        const result = await applyReferralCode(ctx.user.id, input.code.toUpperCase());
        if (!result.success) throw new TRPCError({ code: "BAD_REQUEST", message: result.error || "Failed" });
        return result;
      }),
  }),

  // ==================== ADMIN SPORTSBOOK ====================
  adminSports: router({
    createEvent: adminProcedure
      .input(z.object({
        sport: z.string().min(1),
        league: z.string().optional(),
        homeTeam: z.string().min(1),
        awayTeam: z.string().min(1),
        homeOdds: z.number().positive(),
        drawOdds: z.number().positive().optional(),
        awayOdds: z.number().positive(),
        eventDate: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const result = await createSportsEvent({
          ...input, eventDate: new Date(input.eventDate),
        });
        await createAuditLog({
          userId: ctx.user.id, action: "create_sports_event", entity: "sports_events",
          details: `Created ${input.homeTeam} vs ${input.awayTeam}`,
        });
        return result;
      }),
    updateEvent: adminProcedure
      .input(z.object({
        eventId: z.number(),
        homeOdds: z.number().positive().optional(),
        drawOdds: z.number().positive().optional(),
        awayOdds: z.number().positive().optional(),
        status: z.enum(["upcoming", "live", "completed", "cancelled"]).optional(),
        result: z.enum(["home", "draw", "away"]).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { eventId, ...data } = input;
        await updateSportsEvent(eventId, data);
        // If settling with a result, settle all bets
        if (input.result && input.status === "completed") {
          // settleSportsBet expects the winning outcome, pass it through
          await settleSportsBet(eventId, input.result as any);
        }
        await createAuditLog({
          userId: ctx.user.id, action: "update_sports_event", entity: "sports_events",
          entityId: eventId, details: JSON.stringify(data),
        });
        return { success: true };
      }),
    deleteEvent: adminProcedure
      .input(z.object({ eventId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await deleteSportsEvent(input.eventId);
        await createAuditLog({
          userId: ctx.user.id, action: "delete_sports_event", entity: "sports_events",
          entityId: input.eventId, details: "Cancelled event",
        });
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
