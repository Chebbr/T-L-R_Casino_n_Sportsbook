import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock the database module
vi.mock("./db", () => ({
  getOrCreateWallets: vi.fn().mockResolvedValue([
    { id: 1, userId: 1, currency: "BTC", balance: "1.5", depositAddress: "bc1qtest123" },
    { id: 2, userId: 1, currency: "ETH", balance: "10.0", depositAddress: "0xtest456" },
    { id: 3, userId: 1, currency: "USDT", balance: "500.0", depositAddress: "0xtest789" },
  ]),
  getWalletBalance: vi.fn().mockResolvedValue({ balance: "500.0" }),
  updateWalletBalance: vi.fn().mockResolvedValue(undefined),
  createTransaction: vi.fn().mockResolvedValue({ id: 1 }),
  getTransactions: vi.fn().mockResolvedValue([]),
  createGameSession: vi.fn().mockResolvedValue({ id: 1 }),
  completeGameSession: vi.fn().mockResolvedValue(undefined),
  getRecentGames: vi.fn().mockResolvedValue([]),
  updatePlayerStats: vi.fn().mockResolvedValue(undefined),
  getPlayerStats: vi.fn().mockResolvedValue({ totalWagered: "100", totalWon: "95", gamesPlayed: 10, biggestWin: "50" }),
  getAllPlayerStats: vi.fn().mockResolvedValue([]),
  getHouseWallet: vi.fn().mockResolvedValue({ balance: "100.0" }),
  initializeHouseWallets: vi.fn().mockResolvedValue(undefined),
  updateHouseWalletBalance: vi.fn().mockResolvedValue(undefined),
  getSportsEvents: vi.fn().mockResolvedValue([]),
  createSportsBet: vi.fn().mockResolvedValue({ id: 1 }),
  getUserSportsBets: vi.fn().mockResolvedValue([]),
  settleSportsBet: vi.fn().mockResolvedValue(undefined),
  createStripePayment: vi.fn().mockResolvedValue({ id: 1 }),
  getUserStripePayments: vi.fn().mockResolvedValue([]),
  createNotification: vi.fn().mockResolvedValue({ id: 1 }),
  getUserNotifications: vi.fn().mockResolvedValue([]),
  markNotificationAsRead: vi.fn().mockResolvedValue(undefined),
  getUnreadNotificationCount: vi.fn().mockResolvedValue(0),
  checkAndUpdateVipTier: vi.fn().mockResolvedValue("bronze"),
  getVipTierInfo: vi.fn().mockResolvedValue({ tier: "bronze", vipPoints: 100, currentWagered: 500, nextTierWager: 1000, cashback: 1, depositBonus: 5 }),
  getAllVipTiers: vi.fn().mockResolvedValue([]),
  updateUserTotalWagered: vi.fn().mockResolvedValue(undefined),
  createBonusCode: vi.fn().mockResolvedValue({ id: 1 }),
  getBonusCodeByCode: vi.fn().mockResolvedValue(null),
  getAllBonusCodes: vi.fn().mockResolvedValue([]),
  redeemBonusCode: vi.fn().mockResolvedValue({ amount: "10", currency: "USDT" }),
  getUserRedemptions: vi.fn().mockResolvedValue([]),
  updateBonusCode: vi.fn().mockResolvedValue(undefined),
  deleteBonusCode: vi.fn().mockResolvedValue(undefined),
  getRtpConfig: vi.fn().mockResolvedValue({ targetRtp: "0.96", houseEdge: "0.04", isActive: true }),
  getAllRtpConfigs: vi.fn().mockResolvedValue([]),
  upsertRtpConfig: vi.fn().mockResolvedValue(undefined),
  initializeRtpConfigs: vi.fn().mockResolvedValue(undefined),
  applyRtp: vi.fn().mockImplementation((gameType: string, fairResult: boolean) => fairResult),
  getDepositAddress: vi.fn().mockResolvedValue({ address: "bc1qtest123", currency: "BTC" }),
  processDeposit: vi.fn().mockResolvedValue(undefined),
  createWithdrawalRequest: vi.fn().mockResolvedValue({ id: 1 }),
  getUserWithdrawals: vi.fn().mockResolvedValue([]),
  getPendingWithdrawals: vi.fn().mockResolvedValue([]),
  createAuditLog: vi.fn().mockResolvedValue(undefined),
  getAuditLogs: vi.fn().mockResolvedValue([]),
  createSlotsSession: vi.fn().mockResolvedValue({ id: 1, sessionToken: "test-token" }),
  getSlotsSession: vi.fn().mockResolvedValue(null),
  closeSlotsSession: vi.fn().mockResolvedValue(undefined),
  getAllUsers: vi.fn().mockResolvedValue([]),
  getAdminStats: vi.fn().mockResolvedValue({ totalUsers: 10, totalGameSessions: 100, totalSportsBets: 50, houseWallets: [] }),
  getUserById: vi.fn().mockResolvedValue(null),
  getDepositAddresses: vi.fn().mockResolvedValue({ BTC: "bc1qele3fkgum6k2p0lny8zsp7evsyy2s5dj4eau82", ETH: "0xbe5dC0679845123d870695E98F20934992B8b7f5", USDT: "0xbe5dC0679845123d870695E98F20934992B8b7f5" }),
  updateDepositAddress: vi.fn().mockResolvedValue(undefined),
  adminAdjustUserBalance: vi.fn().mockResolvedValue({ success: true, newBalance: "100.5", currency: "USDT" }),
  adminGetAllUserWallets: vi.fn().mockResolvedValue([{ userId: 1, name: "Test", email: "t@t.com", role: "user", vipTier: "bronze", wallets: [] }]),
  getSiteSetting: vi.fn().mockResolvedValue(null),
  upsertSiteSetting: vi.fn().mockResolvedValue(undefined),
  getAllSiteSettings: vi.fn().mockResolvedValue([]),
}));

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createUserContext(role: "user" | "admin" = "user"): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user-001",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

function createAnonContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("Casino Platform Tests", () => {
  describe("auth.me", () => {
    it("returns user for authenticated context", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.auth.me();
      expect(result).toBeDefined();
      expect(result?.openId).toBe("test-user-001");
      expect(result?.role).toBe("user");
    });

    it("returns null for anonymous context", async () => {
      const ctx = createAnonContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.auth.me();
      expect(result).toBeNull();
    });
  });

  describe("wallet.getAll", () => {
    it("returns wallets for authenticated user", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);
      const wallets = await caller.wallet.getAll();
      expect(wallets).toHaveLength(3);
      expect(wallets[0].currency).toBe("BTC");
      expect(wallets[1].currency).toBe("ETH");
      expect(wallets[2].currency).toBe("USDT");
    });

    it("rejects unauthenticated wallet access", async () => {
      const ctx = createAnonContext();
      const caller = appRouter.createCaller(ctx);
      await expect(caller.wallet.getAll()).rejects.toThrow();
    });
  });

  describe("wallet.getBalance", () => {
    it("returns balance for specific currency", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.wallet.getBalance({ currency: "USDT" });
      expect(result).toBeDefined();
      expect(result.balance).toBe("500.0");
    });
  });

  describe("vip.getMyTier", () => {
    it("returns null when user not found in db", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.vip.getMyTier();
      // getUserById returns null in mock, so result is null
      expect(result).toBeNull();
    });

    it("rejects unauthenticated VIP access", async () => {
      const ctx = createAnonContext();
      const caller = appRouter.createCaller(ctx);
      await expect(caller.vip.getMyTier()).rejects.toThrow();
    });
  });

  describe("bonus.getMyRedemptions", () => {
    it("returns redemptions for authenticated user", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.bonus.getMyRedemptions();
      expect(result).toBeDefined();
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("admin procedures", () => {
    it("rejects non-admin from admin stats", async () => {
      const ctx = createUserContext("user");
      const caller = appRouter.createCaller(ctx);
      await expect(caller.admin.getStats()).rejects.toThrow("Admin access required");
    });

    it("allows admin to get stats", async () => {
      const ctx = createUserContext("admin");
      const caller = appRouter.createCaller(ctx);
      const stats = await caller.admin.getStats();
      expect(stats).toBeDefined();
      expect(stats.totalUsers).toBe(10);
      expect(stats.totalGameSessions).toBe(100);
    });

    it("allows admin to get RTP configs", async () => {
      const ctx = createUserContext("admin");
      const caller = appRouter.createCaller(ctx);
      const configs = await caller.admin.getRtpConfigs();
      expect(configs).toBeDefined();
      expect(Array.isArray(configs)).toBe(true);
    });

    it("allows admin to get bonus codes", async () => {
      const ctx = createUserContext("admin");
      const caller = appRouter.createCaller(ctx);
      const codes = await caller.admin.getBonusCodes();
      expect(codes).toBeDefined();
      expect(Array.isArray(codes)).toBe(true);
    });

    it("allows admin to get pending withdrawals", async () => {
      const ctx = createUserContext("admin");
      const caller = appRouter.createCaller(ctx);
      const withdrawals = await caller.admin.getPendingWithdrawals();
      expect(withdrawals).toBeDefined();
      expect(Array.isArray(withdrawals)).toBe(true);
    });

    it("rejects non-admin from creating bonus codes", async () => {
      const ctx = createUserContext("user");
      const caller = appRouter.createCaller(ctx);
      await expect(
        caller.admin.createBonusCode({
          code: "TEST100",
          type: "free_credits",
          value: 100,
          currency: "USDT",
          maxUses: 10,
        })
      ).rejects.toThrow("Admin access required");
    });

    it("rejects non-admin from updating RTP", async () => {
      const ctx = createUserContext("user");
      const caller = appRouter.createCaller(ctx);
      await expect(
        caller.admin.updateRtp({
          gameType: "crash",
          targetRtp: 0.96,
          houseEdge: 0.04,
        })
      ).rejects.toThrow("Admin access required");
    });
  });

  describe("sportsbook.getEvents", () => {
    it("returns events for authenticated user", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);
      const events = await caller.sportsbook.getEvents({ status: "upcoming" });
      expect(events).toBeDefined();
      expect(Array.isArray(events)).toBe(true);
    });
  });

  describe("sportsbook.getMyBets", () => {
    it("returns user bets", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);
      const bets = await caller.sportsbook.getMyBets({ limit: 10 });
      expect(bets).toBeDefined();
      expect(Array.isArray(bets)).toBe(true);
    });
  });

  describe("wallet.getDepositAddress", () => {
    it("returns deposit address for currency", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.wallet.getDepositAddress({ currency: "BTC" });
      expect(result).toBeDefined();
      expect(result.address).toBe("bc1qtest123");
    });

    it("rejects unauthenticated deposit address request", async () => {
      const ctx = createAnonContext();
      const caller = appRouter.createCaller(ctx);
      await expect(caller.wallet.getDepositAddress({ currency: "BTC" })).rejects.toThrow();
    });
  });

  describe("wallet.getWithdrawals", () => {
    it("returns withdrawal history", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.wallet.getWithdrawals({ limit: 10 });
      expect(result).toBeDefined();
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("stats.get", () => {
    it("returns player stats", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);
      const stats = await caller.stats.get();
      expect(stats).toBeDefined();
      expect(stats.totalWagered).toBe("100");
      expect(stats.gamesPlayed).toBe(10);
    });
  });

  describe("admin.getDepositAddresses", () => {
    it("returns house deposit addresses for admin", async () => {
      const ctx = createUserContext("admin");
      const caller = appRouter.createCaller(ctx);
      const addrs = await caller.admin.getDepositAddresses();
      expect(addrs).toBeDefined();
      expect(addrs.BTC).toBe("bc1qele3fkgum6k2p0lny8zsp7evsyy2s5dj4eau82");
      expect(addrs.ETH).toBe("0xbe5dC0679845123d870695E98F20934992B8b7f5");
    });

    it("rejects non-admin from getting deposit addresses", async () => {
      const ctx = createUserContext("user");
      const caller = appRouter.createCaller(ctx);
      await expect(caller.admin.getDepositAddresses()).rejects.toThrow("Admin access required");
    });
  });

  describe("admin.updateDepositAddress", () => {
    it("allows admin to update deposit address", async () => {
      const ctx = createUserContext("admin");
      const caller = appRouter.createCaller(ctx);
      const result = await caller.admin.updateDepositAddress({ currency: "BTC", address: "bc1qnewaddress123456789" });
      expect(result).toEqual({ success: true });
    });

    it("rejects non-admin from updating deposit address", async () => {
      const ctx = createUserContext("user");
      const caller = appRouter.createCaller(ctx);
      await expect(caller.admin.updateDepositAddress({ currency: "BTC", address: "bc1qnewaddress123456789" })).rejects.toThrow("Admin access required");
    });
  });

  describe("admin.getAllUserWallets", () => {
    it("returns all user wallets for admin", async () => {
      const ctx = createUserContext("admin");
      const caller = appRouter.createCaller(ctx);
      const users = await caller.admin.getAllUserWallets({ limit: 50 });
      expect(users).toBeDefined();
      expect(Array.isArray(users)).toBe(true);
      expect(users[0].userId).toBe(1);
    });

    it("rejects non-admin from viewing user wallets", async () => {
      const ctx = createUserContext("user");
      const caller = appRouter.createCaller(ctx);
      await expect(caller.admin.getAllUserWallets({ limit: 50 })).rejects.toThrow("Admin access required");
    });
  });

  describe("admin.adjustUserBalance", () => {
    it("allows admin to add funds to user", async () => {
      const ctx = createUserContext("admin");
      const caller = appRouter.createCaller(ctx);
      const result = await caller.admin.adjustUserBalance({
        userId: 2, currency: "USDT", amount: 100, action: "add", reason: "Manual deposit credit",
      });
      expect(result).toBeDefined();
      expect(result.success).toBe(true);
      expect(result.newBalance).toBe("100.5");
    });

    it("allows admin to remove funds from user", async () => {
      const ctx = createUserContext("admin");
      const caller = appRouter.createCaller(ctx);
      const result = await caller.admin.adjustUserBalance({
        userId: 2, currency: "ETH", amount: 0.5, action: "remove", reason: "Correction",
      });
      expect(result).toBeDefined();
      expect(result.success).toBe(true);
    });

    it("rejects non-admin from adjusting balances", async () => {
      const ctx = createUserContext("user");
      const caller = appRouter.createCaller(ctx);
      await expect(caller.admin.adjustUserBalance({
        userId: 2, currency: "USDT", amount: 100, action: "add", reason: "Test",
      })).rejects.toThrow("Admin access required");
    });
  });

  describe("admin.getSiteSettings", () => {
    it("returns site settings for admin", async () => {
      const ctx = createUserContext("admin");
      const caller = appRouter.createCaller(ctx);
      const settings = await caller.admin.getSiteSettings();
      expect(settings).toBeDefined();
      expect(Array.isArray(settings)).toBe(true);
    });
  });

  describe("admin.updateSiteSetting", () => {
    it("allows admin to update site setting", async () => {
      const ctx = createUserContext("admin");
      const caller = appRouter.createCaller(ctx);
      const result = await caller.admin.updateSiteSetting({ key: "test_key", value: "test_value" });
      expect(result).toEqual({ success: true });
    });
  });
});
