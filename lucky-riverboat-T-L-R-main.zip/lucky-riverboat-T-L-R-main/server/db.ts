import { eq, and, desc, sql, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser, users, wallets, transactions, gameSessions, playerStats,
  houseWallet, sportsEvents, sportsBets, stripePayments, notifications,
  InsertStripePayment, InsertNotification, vipTiers, bonusCodes,
  bonusRedemptions, rtpConfigs, cryptoDepositAddresses, withdrawalRequests,
  auditLogs, slotsSessions, siteSettings, chatMessages, supportTickets,
  supportMessages, referrals, referralEarnings
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ==================== USER FUNCTIONS ====================

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }

  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
    else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) { console.error("[Database] Failed to upsert user:", error); throw error; }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateUserVipTier(userId: number, tier: "bronze" | "silver" | "gold" | "platinum" | "diamond", points: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ vipTier: tier, vipPoints: points }).where(eq(users.id, userId));
}

export async function updateUserTotalWagered(userId: number, amount: number) {
  const db = await getDb();
  if (!db) return;
  const user = await getUserById(userId);
  if (!user) return;
  const newTotal = parseFloat(user.totalWagered) + amount;
  await db.update(users).set({ totalWagered: newTotal.toFixed(8) }).where(eq(users.id, userId));
  return newTotal;
}

// ==================== WALLET FUNCTIONS ====================

export async function getOrCreateWallets(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const existingWallets = await db.select().from(wallets).where(eq(wallets.userId, userId));
  const currencies = ["BTC", "ETH", "USDT"] as const;
  const missingCurrencies = currencies.filter(c => !existingWallets.find(w => w.currency === c));
  for (const currency of missingCurrencies) {
    const depositAddr = await getHouseDepositAddress(currency);
    await db.insert(wallets).values({
      userId, currency, balance: "0",
      address: depositAddr,
    });
  }
  // Update existing wallets to use current house deposit addresses
  for (const w of existingWallets) {
    const currentAddr = await getHouseDepositAddress(w.currency);
    if (w.address !== currentAddr) {
      await db.update(wallets).set({ address: currentAddr }).where(eq(wallets.id, w.id));
    }
  }
  return db.select().from(wallets).where(eq(wallets.userId, userId));
}

// Fixed house deposit addresses - all deposits go to these addresses
const DEFAULT_DEPOSIT_ADDRESSES: Record<string, string> = {
  BTC: "bc1qele3fkgum6k2p0lny8zsp7evsyy2s5dj4eau82",
  ETH: "0xbe5dC0679845123d870695E98F20934992B8b7f5",
  USDT: "0xbe5dC0679845123d870695E98F20934992B8b7f5", // Same as ETH (ERC-20)
};

async function getHouseDepositAddress(currency: string): Promise<string> {
  const db = await getDb();
  if (db) {
    const setting = await db.select().from(siteSettings)
      .where(eq(siteSettings.settingKey, `deposit_address_${currency}`))
      .limit(1);
    if (setting[0]) return setting[0].settingValue;
  }
  return DEFAULT_DEPOSIT_ADDRESSES[currency] || DEFAULT_DEPOSIT_ADDRESSES.ETH;
}

export async function getWalletBalance(userId: number, currency: "BTC" | "ETH" | "USDT") {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(wallets)
    .where(and(eq(wallets.userId, userId), eq(wallets.currency, currency))).limit(1);
  return result[0] || null;
}

export async function updateWalletBalance(userId: number, currency: "BTC" | "ETH" | "USDT", amount: number, operation: "add" | "subtract") {
  const db = await getDb();
  if (!db) return null;
  const wallet = await getWalletBalance(userId, currency);
  if (!wallet) return null;
  const currentBalance = parseFloat(wallet.balance);
  const newBalance = operation === "add" ? currentBalance + amount : currentBalance - amount;
  if (newBalance < 0) throw new Error("Insufficient balance");
  await db.update(wallets).set({ balance: newBalance.toFixed(8) }).where(eq(wallets.id, wallet.id));
  return { ...wallet, balance: newBalance.toFixed(8) };
}

// ==================== TRANSACTION FUNCTIONS ====================

export async function createTransaction(data: {
  userId: number; walletId: number;
  type: "deposit" | "withdrawal" | "bet" | "win" | "refund" | "bonus" | "vip_reward";
  amount: number; currency: "BTC" | "ETH" | "USDT";
  status?: "pending" | "completed" | "failed" | "cancelled";
  txHash?: string; gameId?: number; description?: string;
}) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(transactions).values({
    ...data, amount: data.amount.toFixed(8), status: data.status || "completed",
  });
  return result;
}

export async function getTransactions(userId: number, limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(transactions).where(eq(transactions.userId, userId))
    .orderBy(desc(transactions.createdAt)).limit(limit);
}

// ==================== GAME SESSION FUNCTIONS ====================

export async function createGameSession(data: {
  userId: number; gameType: string; betAmount: number;
  currency: "BTC" | "ETH" | "USDT"; gameData?: string;
}) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(gameSessions).values({
    ...data, betAmount: data.betAmount.toFixed(8), result: "pending",
  });
  return { id: Number(result[0].insertId) };
}

export async function completeGameSession(sessionId: number, result: "win" | "loss", payout: number, multiplier?: number) {
  const db = await getDb();
  if (!db) return null;
  await db.update(gameSessions).set({
    result, payout: payout.toFixed(8),
    multiplier: multiplier?.toFixed(4), completedAt: new Date(),
  }).where(eq(gameSessions.id, sessionId));
}

export async function getRecentGames(userId: number, limit = 10) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(gameSessions).where(eq(gameSessions.userId, userId))
    .orderBy(desc(gameSessions.createdAt)).limit(limit);
}

// ==================== PLAYER STATS ====================

export async function updatePlayerStats(userId: number, gameType: string, betAmount: number, payout: number, isWin: boolean) {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select().from(playerStats)
    .where(and(eq(playerStats.userId, userId), eq(playerStats.gameType, gameType))).limit(1);

  if (existing.length === 0) {
    await db.insert(playerStats).values({
      userId, gameType, totalBets: 1,
      totalWins: isWin ? 1 : 0, totalLosses: isWin ? 0 : 1,
      totalWagered: betAmount.toFixed(8), totalPayout: payout.toFixed(8),
      biggestWin: isWin ? payout.toFixed(8) : "0",
      currentStreak: isWin ? 1 : 0, longestStreak: isWin ? 1 : 0,
    });
  } else {
    const stats = existing[0];
    const newStreak = isWin ? (stats.currentStreak || 0) + 1 : 0;
    const longestStreak = Math.max(stats.longestStreak || 0, newStreak);
    const biggestWin = Math.max(parseFloat(stats.biggestWin || "0"), isWin ? payout : 0);
    await db.update(playerStats).set({
      totalBets: (stats.totalBets || 0) + 1,
      totalWins: (stats.totalWins || 0) + (isWin ? 1 : 0),
      totalLosses: (stats.totalLosses || 0) + (isWin ? 0 : 1),
      totalWagered: (parseFloat(stats.totalWagered) + betAmount).toFixed(8),
      totalPayout: (parseFloat(stats.totalPayout) + payout).toFixed(8),
      biggestWin: biggestWin.toFixed(8),
      currentStreak: newStreak, longestStreak,
    }).where(eq(playerStats.id, stats.id));
  }
  // Update user total wagered and VIP
  await updateUserTotalWagered(userId, betAmount);
  await checkAndUpdateVipTier(userId);
}

export async function getPlayerStats(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const stats = await db.select().from(playerStats).where(eq(playerStats.userId, userId));
  if (stats.length === 0) return null;
  const totals = stats.reduce((acc, s) => ({
    totalBets: acc.totalBets + (s.totalBets || 0),
    totalWins: acc.totalWins + (s.totalWins || 0),
    totalLosses: acc.totalLosses + (s.totalLosses || 0),
    totalWagered: acc.totalWagered + parseFloat(s.totalWagered),
    totalPayout: acc.totalPayout + parseFloat(s.totalPayout),
    biggestWin: Math.max(acc.biggestWin, parseFloat(s.biggestWin || "0")),
  }), { totalBets: 0, totalWins: 0, totalLosses: 0, totalWagered: 0, totalPayout: 0, biggestWin: 0 });
  return totals;
}

export async function getAllPlayerStats(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(playerStats).where(eq(playerStats.userId, userId));
}

// ==================== HOUSE WALLET ====================

export async function getHouseWallet(currency: "BTC" | "ETH" | "USDT") {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(houseWallet).where(eq(houseWallet.currency, currency)).limit(1);
  return result[0] || null;
}

export async function initializeHouseWallets() {
  const db = await getDb();
  if (!db) return;
  const currencies = ["BTC", "ETH", "USDT"] as const;
  for (const currency of currencies) {
    const existing = await getHouseWallet(currency);
    if (!existing) {
      await db.insert(houseWallet).values({ currency, balance: "0", totalEarnings: "0", totalPayouts: "0" });
    }
  }
}

export async function updateHouseWalletBalance(currency: "BTC" | "ETH" | "USDT", amount: number, operation: "add" | "subtract", isEarning = false) {
  const db = await getDb();
  if (!db) return null;
  const wallet = await getHouseWallet(currency);
  if (!wallet) return null;
  const currentBalance = parseFloat(wallet.balance);
  const newBalance = operation === "add" ? currentBalance + amount : currentBalance - amount;
  const updates: any = { balance: newBalance.toFixed(8) };
  if (isEarning && operation === "add") updates.totalEarnings = (parseFloat(wallet.totalEarnings) + amount).toFixed(8);
  else if (!isEarning && operation === "subtract") updates.totalPayouts = (parseFloat(wallet.totalPayouts) + amount).toFixed(8);
  await db.update(houseWallet).set(updates).where(eq(houseWallet.id, wallet.id));
  return { ...wallet, ...updates };
}

// ==================== SPORTSBOOK ====================

export async function getSportsEvents(status?: "upcoming" | "live" | "completed" | "cancelled") {
  const db = await getDb();
  if (!db) return [];
  if (status) return db.select().from(sportsEvents).where(eq(sportsEvents.status, status)).orderBy(sportsEvents.eventDate);
  return db.select().from(sportsEvents).orderBy(sportsEvents.eventDate);
}

export async function createSportsBet(data: {
  userId: number; eventId: number; prediction: "home" | "draw" | "away";
  betAmount: number; currency: "BTC" | "ETH" | "USDT"; odds: number;
}) {
  const db = await getDb();
  if (!db) return null;
  const potentialPayout = (data.betAmount * data.odds).toFixed(8);
  const result = await db.insert(sportsBets).values({
    ...data, betAmount: data.betAmount.toFixed(8), odds: data.odds.toFixed(2), potentialPayout,
  });
  return { id: Number(result[0].insertId) };
}

export async function getUserSportsBets(userId: number, limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(sportsBets).where(eq(sportsBets.userId, userId))
    .orderBy(desc(sportsBets.createdAt)).limit(limit);
}

export async function settleSportsBet(betId: number, result: "won" | "lost" | "cancelled", actualPayout?: number) {
  const db = await getDb();
  if (!db) return null;
  const updates: any = { status: result, settledAt: new Date() };
  if (actualPayout !== undefined) updates.actualPayout = actualPayout.toFixed(8);
  await db.update(sportsBets).set(updates).where(eq(sportsBets.id, betId));
}

// ==================== STRIPE PAYMENTS ====================

export async function createStripePayment(data: InsertStripePayment) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(stripePayments).values(data);
  return { id: Number(result[0].insertId) };
}

export async function getStripePayment(stripePaymentIntentId: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(stripePayments)
    .where(eq(stripePayments.stripePaymentIntentId, stripePaymentIntentId)).limit(1);
  return result[0] || null;
}

export async function updateStripePaymentStatus(stripePaymentIntentId: string, status: "pending" | "succeeded" | "failed" | "canceled", completedAt?: Date) {
  const db = await getDb();
  if (!db) return null;
  await db.update(stripePayments).set({ status, completedAt: completedAt || new Date() })
    .where(eq(stripePayments.stripePaymentIntentId, stripePaymentIntentId));
}

export async function getUserStripePayments(userId: number, limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(stripePayments).where(eq(stripePayments.userId, userId))
    .orderBy(desc(stripePayments.createdAt)).limit(limit);
}

// ==================== NOTIFICATIONS ====================

export async function createNotification(data: InsertNotification) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(notifications).values(data);
  return { id: Number(result[0].insertId) };
}

export async function getUserNotifications(userId: number, unreadOnly = false, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  if (unreadOnly) {
    return db.select().from(notifications)
      .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)))
      .orderBy(desc(notifications.createdAt)).limit(limit);
  }
  return db.select().from(notifications).where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt)).limit(limit);
}

export async function markNotificationAsRead(notificationId: number) {
  const db = await getDb();
  if (!db) return null;
  await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, notificationId));
}

export async function markAllNotificationsAsRead(userId: number) {
  const db = await getDb();
  if (!db) return null;
  await db.update(notifications).set({ isRead: true })
    .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
}

export async function getUnreadNotificationCount(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select().from(notifications)
    .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
  return result.length;
}

// ==================== VIP TIER SYSTEM ====================

const VIP_THRESHOLDS = [
  { tier: "bronze" as const, minWagered: 0, cashback: 0.5, depositBonus: 0, weeklyBonus: 0, levelUpBonus: 0 },
  { tier: "silver" as const, minWagered: 100, cashback: 1.0, depositBonus: 5, weeklyBonus: 5, levelUpBonus: 10 },
  { tier: "gold" as const, minWagered: 500, cashback: 2.0, depositBonus: 10, weeklyBonus: 15, levelUpBonus: 50 },
  { tier: "platinum" as const, minWagered: 2000, cashback: 3.5, depositBonus: 15, weeklyBonus: 50, levelUpBonus: 200 },
  { tier: "diamond" as const, minWagered: 10000, cashback: 5.0, depositBonus: 25, weeklyBonus: 200, levelUpBonus: 1000 },
];

export async function checkAndUpdateVipTier(userId: number) {
  const user = await getUserById(userId);
  if (!user) return null;
  const totalWagered = parseFloat(user.totalWagered);
  let newTier = VIP_THRESHOLDS[0];
  for (const threshold of VIP_THRESHOLDS) {
    if (totalWagered >= threshold.minWagered) newTier = threshold;
  }
  if (newTier.tier !== user.vipTier) {
    await updateUserVipTier(userId, newTier.tier, Math.floor(totalWagered));
    if (newTier.levelUpBonus > 0) {
      await updateWalletBalance(userId, "USDT", newTier.levelUpBonus, "add");
      await createNotification({
        userId, title: "VIP Level Up!",
        message: `Congratulations! You've reached ${newTier.tier.toUpperCase()} tier! You received a ${newTier.levelUpBonus} USDT bonus!`,
        type: "vip",
      });
    }
    return newTier;
  }
  return null;
}

export function getVipTierInfo(tier: string) {
  return VIP_THRESHOLDS.find(t => t.tier === tier) || VIP_THRESHOLDS[0];
}

export function getAllVipTiers() {
  return VIP_THRESHOLDS;
}

// ==================== BONUS CODE SYSTEM ====================

export async function createBonusCode(data: {
  code: string; description?: string;
  type: "deposit_match" | "free_credits" | "free_spins" | "cashback";
  value: number; currency?: "BTC" | "ETH" | "USDT";
  maxUses?: number; minDeposit?: number; maxPayout?: number;
  expiresAt?: Date; vipTierRequired?: "bronze" | "silver" | "gold" | "platinum" | "diamond";
}) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(bonusCodes).values({
    ...data, value: data.value.toFixed(8),
    currency: data.currency || "USDT",
    minDeposit: data.minDeposit?.toFixed(8),
    maxPayout: data.maxPayout?.toFixed(8),
  });
  return { id: Number(result[0].insertId) };
}

export async function getBonusCodeByCode(code: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(bonusCodes).where(eq(bonusCodes.code, code.toUpperCase())).limit(1);
  return result[0] || null;
}

export async function getAllBonusCodes() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(bonusCodes).orderBy(desc(bonusCodes.createdAt));
}

export async function redeemBonusCode(userId: number, code: string) {
  const db = await getDb();
  if (!db) return { success: false, error: "Database not available" };

  const bonus = await getBonusCodeByCode(code);
  if (!bonus) return { success: false, error: "Invalid bonus code" };
  if (!bonus.isActive) return { success: false, error: "This bonus code is no longer active" };
  if (bonus.expiresAt && new Date(bonus.expiresAt) < new Date()) return { success: false, error: "This bonus code has expired" };
  if (bonus.maxUses && bonus.maxUses > 0 && bonus.currentUses >= bonus.maxUses) return { success: false, error: "This bonus code has reached its maximum uses" };

  // Check if user already redeemed
  const existing = await db.select().from(bonusRedemptions)
    .where(and(eq(bonusRedemptions.userId, userId), eq(bonusRedemptions.bonusCodeId, bonus.id))).limit(1);
  if (existing.length > 0) return { success: false, error: "You have already redeemed this bonus code" };

  // Check VIP tier requirement
  if (bonus.vipTierRequired) {
    const user = await getUserById(userId);
    const tierOrder = ["bronze", "silver", "gold", "platinum", "diamond"];
    if (user && tierOrder.indexOf(user.vipTier) < tierOrder.indexOf(bonus.vipTierRequired)) {
      return { success: false, error: `This code requires ${bonus.vipTierRequired.toUpperCase()} VIP tier or higher` };
    }
  }

  const creditAmount = parseFloat(bonus.value);
  const currency = bonus.currency as "BTC" | "ETH" | "USDT";

  // Credit user wallet
  await updateWalletBalance(userId, currency, creditAmount, "add");

  // Record redemption
  await db.insert(bonusRedemptions).values({
    userId, bonusCodeId: bonus.id, code: bonus.code,
    amountCredited: creditAmount.toFixed(8), currency,
  });

  // Update usage count
  await db.update(bonusCodes).set({ currentUses: bonus.currentUses + 1 }).where(eq(bonusCodes.id, bonus.id));

  await createNotification({
    userId, title: "Bonus Code Redeemed!",
    message: `You received ${creditAmount} ${currency} from bonus code ${bonus.code}!`,
    type: "bonus",
  });

  return { success: true, amount: creditAmount, currency };
}

export async function getUserRedemptions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(bonusRedemptions).where(eq(bonusRedemptions.userId, userId))
    .orderBy(desc(bonusRedemptions.redeemedAt));
}

export async function updateBonusCode(id: number, data: { isActive?: boolean; maxUses?: number; expiresAt?: Date }) {
  const db = await getDb();
  if (!db) return;
  await db.update(bonusCodes).set(data).where(eq(bonusCodes.id, id));
}

export async function deleteBonusCode(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(bonusCodes).set({ isActive: false }).where(eq(bonusCodes.id, id));
}

// ==================== RTP CONFIGURATION ====================

export async function getRtpConfig(gameType: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(rtpConfigs).where(eq(rtpConfigs.gameType, gameType)).limit(1);
  return result[0] || null;
}

export async function getAllRtpConfigs() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(rtpConfigs).orderBy(rtpConfigs.gameType);
}

export async function upsertRtpConfig(data: {
  gameType: string; targetRtp: number; minRtp?: number; maxRtp?: number;
  houseEdge: number; adjustmentNotes?: string;
}) {
  const db = await getDb();
  if (!db) return null;
  const existing = await getRtpConfig(data.gameType);
  if (existing) {
    await db.update(rtpConfigs).set({
      targetRtp: data.targetRtp.toFixed(4),
      minRtp: data.minRtp?.toFixed(4) || existing.minRtp,
      maxRtp: data.maxRtp?.toFixed(4) || existing.maxRtp,
      houseEdge: data.houseEdge.toFixed(4),
      adjustmentNotes: data.adjustmentNotes,
    }).where(eq(rtpConfigs.id, existing.id));
    return existing.id;
  } else {
    const result = await db.insert(rtpConfigs).values({
      gameType: data.gameType,
      targetRtp: data.targetRtp.toFixed(4),
      minRtp: (data.minRtp || 0.90).toFixed(4),
      maxRtp: (data.maxRtp || 1.00).toFixed(4),
      houseEdge: data.houseEdge.toFixed(4),
      adjustmentNotes: data.adjustmentNotes,
    });
    return Number(result[0].insertId);
  }
}

export async function initializeRtpConfigs() {
  const db = await getDb();
  if (!db) return;
  const gameTypes = ["keno", "crash", "roulette", "helm", "tower", "mines", "hilow", "sportsbook"];
  for (const gameType of gameTypes) {
    const existing = await getRtpConfig(gameType);
    if (!existing) {
      await db.insert(rtpConfigs).values({
        gameType, targetRtp: "0.9600", minRtp: "0.9000", maxRtp: "1.0000", houseEdge: "0.0400",
      });
    }
  }
}

// Apply RTP to game outcome
export async function applyRtp(gameType: string, baseOutcome: number): Promise<number> {
  const config = await getRtpConfig(gameType);
  if (!config) return baseOutcome;
  const targetRtp = parseFloat(config.targetRtp);
  // Adjust outcome probability based on target RTP
  return baseOutcome * targetRtp;
}

// ==================== CRYPTO DEPOSIT MONITORING ====================

export async function getDepositAddress(userId: number, currency: "BTC" | "ETH" | "USDT") {
  // All users share the same house deposit address per currency
  const address = await getHouseDepositAddress(currency);
  const db = await getDb();
  if (!db) return { userId, currency, address, isActive: true };
  // Upsert the deposit address record
  const result = await db.select().from(cryptoDepositAddresses)
    .where(and(eq(cryptoDepositAddresses.userId, userId), eq(cryptoDepositAddresses.currency, currency), eq(cryptoDepositAddresses.isActive, true)))
    .limit(1);
  if (result[0]) {
    if (result[0].address !== address) {
      await db.update(cryptoDepositAddresses).set({ address }).where(eq(cryptoDepositAddresses.id, result[0].id));
    }
    return { ...result[0], address };
  }
  await db.insert(cryptoDepositAddresses).values({ userId, currency, address });
  return { userId, currency, address, isActive: true };
}

// Submit a deposit claim - does NOT credit until blockchain confirmation verified by admin
export async function submitDepositClaim(userId: number, currency: "BTC" | "ETH" | "USDT", amount: number, txHash: string) {
  const db = await getDb();
  if (!db) return null;
  // Check for duplicate tx
  const existing = await db.select().from(transactions).where(eq(transactions.txHash, txHash)).limit(1);
  if (existing.length > 0) return { success: false, error: "Transaction already submitted" };

  const wallet = await getWalletBalance(userId, currency);
  if (!wallet) {
    await getOrCreateWallets(userId);
  }
  const w = await getWalletBalance(userId, currency);
  if (w) {
    // Create PENDING transaction - NOT credited yet
    await createTransaction({
      userId, walletId: w.id, type: "deposit", amount, currency, status: "pending", txHash,
      description: `Deposit claim of ${amount} ${currency} - awaiting blockchain confirmation`,
    });
  }
  await createNotification({
    userId, title: "Deposit Submitted",
    message: `Your deposit claim of ${amount} ${currency} (TX: ${txHash.slice(0, 16)}...) is pending blockchain verification.`,
    type: "info",
  });
  return { success: true, amount, currency, status: "pending_verification" };
}

// Admin confirms deposit after verifying on blockchain - ONLY then credit the account
export async function confirmDeposit(transactionId: number, adminUserId: number) {
  const db = await getDb();
  if (!db) return { success: false, error: "Database unavailable" };
  const txResult = await db.select().from(transactions).where(eq(transactions.id, transactionId)).limit(1);
  if (!txResult[0]) return { success: false, error: "Transaction not found" };
  const tx = txResult[0];
  if (tx.status !== "pending") return { success: false, error: `Transaction already ${tx.status}` };
  if (tx.type !== "deposit") return { success: false, error: "Not a deposit transaction" };

  // NOW credit the user's wallet
  const amount = parseFloat(tx.amount);
  const currency = tx.currency as "BTC" | "ETH" | "USDT";
  await updateWalletBalance(tx.userId, currency, amount, "add");

  // Mark transaction as completed
  await db.update(transactions).set({ status: "completed", description: `Deposit of ${amount} ${currency} - blockchain confirmed` }).where(eq(transactions.id, transactionId));

  await createAuditLog({
    userId: adminUserId, action: "confirm_deposit",
    entity: "transaction", entityId: transactionId,
    details: JSON.stringify({ userId: tx.userId, amount, currency, txHash: tx.txHash }),
  });

  await createNotification({
    userId: tx.userId, title: "Deposit Confirmed!",
    message: `Your deposit of ${amount} ${currency} has been verified on the blockchain and credited to your account.`,
    type: "success",
  });
  return { success: true, amount, currency, userId: tx.userId };
}

// Admin rejects a deposit claim
export async function rejectDeposit(transactionId: number, adminUserId: number, reason: string) {
  const db = await getDb();
  if (!db) return { success: false, error: "Database unavailable" };
  const txResult = await db.select().from(transactions).where(eq(transactions.id, transactionId)).limit(1);
  if (!txResult[0]) return { success: false, error: "Transaction not found" };
  const tx = txResult[0];
  if (tx.status !== "pending") return { success: false, error: `Transaction already ${tx.status}` };

  await db.update(transactions).set({ status: "failed", description: `Deposit rejected: ${reason}` }).where(eq(transactions.id, transactionId));

  await createAuditLog({
    userId: adminUserId, action: "reject_deposit",
    entity: "transaction", entityId: transactionId,
    details: JSON.stringify({ userId: tx.userId, reason }),
  });

  await createNotification({
    userId: tx.userId, title: "Deposit Rejected",
    message: `Your deposit claim was rejected. Reason: ${reason}`,
    type: "error",
  });
  return { success: true };
}

// Get pending deposits for admin review
export async function getPendingDeposits() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(transactions)
    .where(and(eq(transactions.type, "deposit"), eq(transactions.status, "pending")))
    .orderBy(transactions.createdAt);
}

// ==================== WITHDRAWAL SYSTEM ====================

export async function createWithdrawalRequest(userId: number, currency: "BTC" | "ETH" | "USDT", amount: number, toAddress: string) {
  const db = await getDb();
  if (!db) return { success: false, error: "Database not available" };

  // Validate address format
  if (currency === "BTC" && !toAddress.match(/^(bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}$/)) {
    return { success: false, error: "Invalid BTC address format" };
  }
  if (currency === "ETH" && !toAddress.match(/^0x[a-fA-F0-9]{40}$/)) {
    return { success: false, error: "Invalid ETH address format" };
  }

  // Check balance
  const wallet = await getWalletBalance(userId, currency);
  if (!wallet || parseFloat(wallet.balance) < amount) {
    return { success: false, error: "Insufficient balance" };
  }

  // Deduct from user wallet
  await updateWalletBalance(userId, currency, amount, "subtract");

  // Create withdrawal request
  const result = await db.insert(withdrawalRequests).values({
    userId, currency, amount: amount.toFixed(8), toAddress, status: "pending",
  });

  // Create transaction record
  if (wallet) {
    await createTransaction({
      userId, walletId: wallet.id, type: "withdrawal", amount, currency,
      status: "pending", description: `Withdrawal of ${amount} ${currency} to ${toAddress}`,
    });
  }

  // Withdrawal requires manual admin approval - do NOT auto-process
  const withdrawalId = Number(result[0].insertId);

  await createNotification({
    userId, title: "Withdrawal Submitted",
    message: `Your withdrawal of ${amount} ${currency} to ${toAddress} is pending admin approval.`,
    type: "info",
  });

  return { success: true, withdrawalId, status: "pending_approval" };
}

export async function processWithdrawal(withdrawalId: number) {
  const db = await getDb();
  if (!db) return;
  const requests = await db.select().from(withdrawalRequests).where(eq(withdrawalRequests.id, withdrawalId)).limit(1);
  if (requests.length === 0) return;
  const request = requests[0];

  try {
    // Simulate blockchain transaction
    const txHash = "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("");

    // Deduct from house wallet
    await updateHouseWalletBalance(request.currency, parseFloat(request.amount), "subtract", false);

    // Update withdrawal status
    await db.update(withdrawalRequests).set({
      status: "completed", txHash, processedAt: new Date(),
    }).where(eq(withdrawalRequests.id, withdrawalId));

    // Notify user
    await createNotification({
      userId: request.userId, title: "Withdrawal Processed!",
      message: `Your withdrawal of ${request.amount} ${request.currency} has been sent to ${request.toAddress}. TX: ${txHash}`,
      type: "success",
    });
  } catch (error) {
    await db.update(withdrawalRequests).set({
      status: "failed", failureReason: String(error),
    }).where(eq(withdrawalRequests.id, withdrawalId));
  }
}

export async function getUserWithdrawals(userId: number, limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(withdrawalRequests).where(eq(withdrawalRequests.userId, userId))
    .orderBy(desc(withdrawalRequests.createdAt)).limit(limit);
}

export async function getPendingWithdrawals() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(withdrawalRequests).where(eq(withdrawalRequests.status, "pending"))
    .orderBy(withdrawalRequests.createdAt);
}

// ==================== AUDIT LOGS ====================

export async function createAuditLog(data: {
  userId?: number; action: string; entity?: string;
  entityId?: number; details?: string; ipAddress?: string;
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(auditLogs).values(data);
}

export async function getAuditLogs(limit = 100) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(limit);
}

// ==================== SLOTS SESSIONS ====================

export async function createSlotsSession(data: {
  userId: number; provider: "hacksaw" | "pragmatic" | "massive_studios" | "lady_shady";
  gameId: string; gameName?: string; currency: "BTC" | "ETH" | "USDT";
  initialBalance: number;
}) {
  const db = await getDb();
  if (!db) return null;
  const sessionToken = Array.from({ length: 32 }, () => Math.floor(Math.random() * 36).toString(36)).join("");
  const result = await db.insert(slotsSessions).values({
    ...data, sessionToken,
    initialBalance: data.initialBalance.toFixed(8),
    currentBalance: data.initialBalance.toFixed(8),
  });
  return { id: Number(result[0].insertId), sessionToken };
}

export async function getSlotsSession(sessionToken: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(slotsSessions)
    .where(eq(slotsSessions.sessionToken, sessionToken)).limit(1);
  return result[0] || null;
}

export async function updateSlotsSessionBalance(sessionToken: string, newBalance: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(slotsSessions).set({ currentBalance: newBalance.toFixed(8) })
    .where(eq(slotsSessions.sessionToken, sessionToken));
}

export async function closeSlotsSession(sessionToken: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(slotsSessions).set({ status: "completed", closedAt: new Date() })
    .where(eq(slotsSessions.sessionToken, sessionToken));
}

// ==================== ADMIN HELPERS ====================

export async function getAllUsers(limit = 100) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).orderBy(desc(users.createdAt)).limit(limit);
}

export async function getAdminStats() {
  const db = await getDb();
  if (!db) return null;
  const allUsers = await db.select().from(users);
  const allSessions = await db.select().from(gameSessions);
  const allBets = await db.select().from(sportsBets);
  const houseWallets = await db.select().from(houseWallet);

  return {
    totalUsers: allUsers.length,
    totalGameSessions: allSessions.length,
    totalSportsBets: allBets.length,
    houseWallets: houseWallets.map(w => ({
      currency: w.currency,
      balance: w.balance,
      totalEarnings: w.totalEarnings,
      totalPayouts: w.totalPayouts,
    })),
  };
}

// ==================== SITE SETTINGS (Admin Wallet Addresses) ====================

export async function getSiteSetting(key: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(siteSettings).where(eq(siteSettings.settingKey, key)).limit(1);
  return result[0] || null;
}

export async function upsertSiteSetting(key: string, value: string, description?: string) {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select().from(siteSettings).where(eq(siteSettings.settingKey, key)).limit(1);
  if (existing[0]) {
    await db.update(siteSettings).set({ settingValue: value, ...(description ? { description } : {}) }).where(eq(siteSettings.id, existing[0].id));
  } else {
    await db.insert(siteSettings).values({ settingKey: key, settingValue: value, description: description || null });
  }
}

export async function getAllSiteSettings() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(siteSettings).orderBy(siteSettings.settingKey);
}

export async function getDepositAddresses() {
  return {
    BTC: await getHouseDepositAddress("BTC"),
    ETH: await getHouseDepositAddress("ETH"),
    USDT: await getHouseDepositAddress("USDT"),
  };
}

export async function updateDepositAddress(currency: "BTC" | "ETH" | "USDT", newAddress: string) {
  await upsertSiteSetting(`deposit_address_${currency}`, newAddress, `House deposit address for ${currency}`);
  const db = await getDb();
  if (!db) return;
  await db.update(wallets).set({ address: newAddress }).where(eq(wallets.currency, currency));
  await db.update(cryptoDepositAddresses).set({ address: newAddress })
    .where(and(eq(cryptoDepositAddresses.currency, currency), eq(cryptoDepositAddresses.isActive, true)));
}

export async function adminAdjustUserBalance(
  adminUserId: number,
  targetUserId: number,
  currency: "BTC" | "ETH" | "USDT",
  amount: number,
  action: "add" | "remove",
  reason: string
) {
  const db = await getDb();
  if (!db) return { success: false, error: "Database unavailable" };
  await getOrCreateWallets(targetUserId);
  const wallet = await getWalletBalance(targetUserId, currency);
  if (!wallet) return { success: false, error: "Wallet not found" };
  const currentBalance = parseFloat(wallet.balance);
  if (action === "remove" && currentBalance < amount) {
    return { success: false, error: `Insufficient balance. User has ${currentBalance} ${currency}` };
  }
  await updateWalletBalance(targetUserId, currency, amount, action === "add" ? "add" : "subtract");
  await createTransaction({
    userId: targetUserId, walletId: wallet.id,
    type: action === "add" ? "bonus" : "refund",
    amount, currency, status: "completed",
    description: `Admin ${action === "add" ? "credit" : "debit"}: ${reason}`,
  });
  await createAuditLog({
    userId: adminUserId, action: `admin_${action}_funds`,
    entity: "wallet", entityId: wallet.id,
    details: JSON.stringify({ targetUserId, currency, amount, action, reason }),
  });
  await createNotification({
    userId: targetUserId,
    title: action === "add" ? "Funds Added" : "Funds Removed",
    message: action === "add"
      ? `${amount} ${currency} has been credited to your account. Reason: ${reason}`
      : `${amount} ${currency} has been debited from your account. Reason: ${reason}`,
    type: action === "add" ? "success" : "warning",
  });
  const updatedWallet = await getWalletBalance(targetUserId, currency);
  return { success: true, newBalance: updatedWallet?.balance || "0", currency };
}

export async function adminGetAllUserWallets(limit = 100) {
  const db = await getDb();
  if (!db) return [];
  const allUsers = await db.select().from(users).orderBy(desc(users.createdAt)).limit(limit);
  const result = [];
  for (const user of allUsers) {
    const userWallets = await db.select().from(wallets).where(eq(wallets.userId, user.id));
    result.push({
      userId: user.id, name: user.name, email: user.email,
      role: user.role, vipTier: user.vipTier, createdAt: user.createdAt,
      wallets: userWallets.map(w => ({ currency: w.currency, balance: w.balance, address: w.address })),
    });
  }
  return result;
}


// ==================== CHAT SYSTEM ====================

export async function getChatMessages(limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(chatMessages)
    .where(eq(chatMessages.isDeleted, false))
    .orderBy(desc(chatMessages.createdAt)).limit(limit);
}

export async function sendChatMessage(userId: number, userName: string, message: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(chatMessages).values({ userId, userName, message, type: "chat" });
  return { id: Number(result[0].insertId), userId, userName, message, type: "chat", createdAt: new Date() };
}

export async function deleteChatMessage(messageId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(chatMessages).set({ isDeleted: true }).where(eq(chatMessages.id, messageId));
}

// ==================== SUPPORT TICKETS ====================

export async function createSupportTicket(userId: number, userName: string, subject: string, initialMessage: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(supportTickets).values({ userId, userName, subject, status: "open" });
  const ticketId = Number(result[0].insertId);
  await db.insert(supportMessages).values({ ticketId, userId, isAdmin: false, message: initialMessage });
  return { ticketId };
}

export async function getUserSupportTickets(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(supportTickets).where(eq(supportTickets.userId, userId))
    .orderBy(desc(supportTickets.createdAt));
}

export async function getAllSupportTickets(status?: string) {
  const db = await getDb();
  if (!db) return [];
  if (status) {
    return db.select().from(supportTickets)
      .where(eq(supportTickets.status, status as any))
      .orderBy(desc(supportTickets.createdAt));
  }
  return db.select().from(supportTickets).orderBy(desc(supportTickets.createdAt));
}

export async function getSupportMessages(ticketId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(supportMessages).where(eq(supportMessages.ticketId, ticketId))
    .orderBy(supportMessages.createdAt);
}

export async function addSupportMessage(ticketId: number, userId: number, isAdmin: boolean, message: string) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(supportMessages).values({ ticketId, userId, isAdmin, message });
  // Update ticket status
  if (isAdmin) {
    await db.update(supportTickets).set({ status: "in_progress" }).where(eq(supportTickets.id, ticketId));
  }
  return { success: true };
}

export async function closeSupportTicket(ticketId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(supportTickets).set({ status: "resolved" }).where(eq(supportTickets.id, ticketId));
}

// ==================== REFERRAL SYSTEM ====================

export async function getOrCreateReferralCode(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const existing = await db.select().from(referrals).where(eq(referrals.referrerId, userId)).limit(1);
  if (existing[0]) return existing[0];
  // Generate unique referral code
  const code = "TLR" + Array.from({ length: 6 }, () => Math.floor(Math.random() * 36).toString(36).toUpperCase()).join("");
  const result = await db.insert(referrals).values({
    referrerId: userId, referralCode: code, commissionRate: "0.0500",
  });
  return { id: Number(result[0].insertId), referrerId: userId, referralCode: code, commissionRate: "0.0500", totalEarnings: "0", totalReferred: 0, isActive: true, createdAt: new Date() };
}

export async function getReferralByCode(code: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(referrals).where(eq(referrals.referralCode, code)).limit(1);
  return result[0] || null;
}

export async function applyReferralCode(referredUserId: number, code: string) {
  const db = await getDb();
  if (!db) return { success: false, error: "Database unavailable" };
  const referral = await getReferralByCode(code);
  if (!referral) return { success: false, error: "Invalid referral code" };
  if (referral.referrerId === referredUserId) return { success: false, error: "Cannot use your own referral code" };
  // Check if already referred
  const existingEarnings = await db.select().from(referralEarnings)
    .where(eq(referralEarnings.referredUserId, referredUserId)).limit(1);
  if (existingEarnings.length > 0) return { success: false, error: "You have already used a referral code" };
  // Update referral count
  await db.update(referrals).set({ totalReferred: referral.totalReferred + 1, referredUserId: referredUserId })
    .where(eq(referrals.id, referral.id));
  return { success: true, referrerId: referral.referrerId };
}

export async function getReferralStats(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const referral = await db.select().from(referrals).where(eq(referrals.referrerId, userId)).limit(1);
  if (!referral[0]) return null;
  const earnings = await db.select().from(referralEarnings).where(eq(referralEarnings.referrerId, userId))
    .orderBy(desc(referralEarnings.createdAt));
  return {
    referralCode: referral[0].referralCode,
    commissionRate: referral[0].commissionRate,
    totalEarnings: referral[0].totalEarnings,
    totalReferred: referral[0].totalReferred,
    isActive: referral[0].isActive,
    recentEarnings: earnings.slice(0, 20),
  };
}

// ==================== SPORTSBOOK ADMIN ====================

export async function createSportsEvent(data: {
  sport: string; league?: string; homeTeam: string; awayTeam: string;
  homeOdds: number; drawOdds?: number; awayOdds: number; eventDate: Date;
}) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(sportsEvents).values({
    sport: data.sport,
    league: data.league || null,
    homeTeam: data.homeTeam,
    awayTeam: data.awayTeam,
    homeOdds: data.homeOdds.toFixed(2),
    drawOdds: data.drawOdds?.toFixed(2) || "3.00",
    awayOdds: data.awayOdds.toFixed(2),
    eventDate: data.eventDate,
    status: "upcoming",
  });
  return { id: Number(result[0].insertId) };
}

export async function updateSportsEvent(eventId: number, data: {
  homeOdds?: number; drawOdds?: number; awayOdds?: number;
  status?: "upcoming" | "live" | "completed" | "cancelled";
  result?: "home" | "draw" | "away";
}) {
  const db = await getDb();
  if (!db) return;
  const updateData: Record<string, any> = {};
  if (data.homeOdds !== undefined) updateData.homeOdds = data.homeOdds.toFixed(2);
  if (data.drawOdds !== undefined) updateData.drawOdds = data.drawOdds.toFixed(2);
  if (data.awayOdds !== undefined) updateData.awayOdds = data.awayOdds.toFixed(2);
  if (data.status !== undefined) updateData.status = data.status;
  if (data.result !== undefined) updateData.result = data.result;
  if (Object.keys(updateData).length > 0) {
    await db.update(sportsEvents).set(updateData).where(eq(sportsEvents.id, eventId));
  }
}

export async function deleteSportsEvent(eventId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(sportsEvents).set({ status: "cancelled" }).where(eq(sportsEvents.id, eventId));
}
