import { Server as HTTPServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { getDb } from "./db";
import { chatMessages, onlinePlayers, wagerFeed } from "../drizzle/schema";
import { eq, desc } from "drizzle-orm";

interface ChatUser {
  userId: number;
  userName: string;
  sessionId: string;
}

let io: SocketIOServer | null = null;
const connectedUsers = new Map<string, ChatUser>();

export function initializeChat(httpServer: HTTPServer) {
  io = new SocketIOServer(httpServer, {
    cors: {
      origin: process.env.NODE_ENV === "production" ? undefined : "*",
      methods: ["GET", "POST"],
    },
  });

  io.on("connection", (socket) => {
    console.log(`[Chat] User connected: ${socket.id}`);

    // User joins chat
    socket.on("join", async (data: { userId: number; userName: string }) => {
      const chatUser: ChatUser = {
        userId: data.userId,
        userName: data.userName,
        sessionId: socket.id,
      };

      connectedUsers.set(socket.id, chatUser);

      // Add to online players
      const db = await getDb();
      if (db) {
        await db.insert(onlinePlayers).values({
          userId: data.userId,
          userName: data.userName,
          sessionId: socket.id,
        });

        // Broadcast user joined
        const systemMessage = `${data.userName} joined the chat`;
        await db.insert(chatMessages).values({
          userId: 0,
          userName: "System",
          message: systemMessage,
          isSystemMessage: true,
        });

        io?.emit("user_joined", {
          userName: data.userName,
          onlineCount: connectedUsers.size,
          message: systemMessage,
        });

        // Send recent messages to new user
        const recentMessages = await db
          .select()
          .from(chatMessages)
          .orderBy(desc(chatMessages.createdAt))
          .limit(50);

        socket.emit("chat_history", recentMessages.reverse());

        // Send online players list
        const onlinePlayersList = await db.select().from(onlinePlayers);
        io?.emit("online_players", {
          count: onlinePlayersList.length,
          players: onlinePlayersList.map((p) => p.userName),
        });
      }
    });

    // Handle chat messages
    socket.on("send_message", async (data: { message: string }) => {
      const user = connectedUsers.get(socket.id);
      if (!user) return;

      // Validate message
      if (!data.message || data.message.trim().length === 0) return;
      if (data.message.length > 500) return; // Max 500 chars

      const db = await getDb();
      if (db) {
        // Save to database
        await db.insert(chatMessages).values({
          userId: user.userId,
          userName: user.userName,
          message: data.message.trim(),
          isSystemMessage: false,
        });

        // Broadcast to all users
        io?.emit("new_message", {
          userId: user.userId,
          userName: user.userName,
          message: data.message.trim(),
          timestamp: new Date(),
        });
      }
    });

    // Handle wager feed updates
    socket.on("wager_placed", async (data: {
      gameType: string;
      betAmount: number;
      multiplier: number;
      payout: number;
      result: "win" | "loss" | "pending";
    }) => {
      const user = connectedUsers.get(socket.id);
      if (!user) return;

      const db = await getDb();
      if (db) {
        // Save to wager feed
        await db.insert(wagerFeed).values({
          userId: user.userId,
          userName: user.userName,
          gameType: data.gameType,
          betAmount: data.betAmount.toFixed(2),
          multiplier: data.multiplier.toFixed(4),
          payout: data.payout.toFixed(2),
          result: data.result,
        });

        // Broadcast wager to all users
        io?.emit("wager_update", {
          userName: user.userName,
          gameType: data.gameType,
          betAmount: data.betAmount,
          multiplier: data.multiplier,
          payout: data.payout,
          result: data.result,
          timestamp: new Date(),
        });
      }
    });

    // Handle heartbeat (keep-alive)
    socket.on("heartbeat", async () => {
      const user = connectedUsers.get(socket.id);
      if (!user) return;

      const db = await getDb();
      if (db) {
        await db
          .update(onlinePlayers)
          .set({ lastHeartbeat: new Date() })
          .where(eq(onlinePlayers.sessionId, socket.id));
      }
    });

    // User disconnects
    socket.on("disconnect", async () => {
      const user = connectedUsers.get(socket.id);
      if (!user) return;

      connectedUsers.delete(socket.id);

      const db = await getDb();
      if (db) {
        // Remove from online players
        await db
          .delete(onlinePlayers)
          .where(eq(onlinePlayers.sessionId, socket.id));

        // Broadcast user left
        const systemMessage = `${user.userName} left the chat`;
        await db.insert(chatMessages).values({
          userId: 0,
          userName: "System",
          message: systemMessage,
          isSystemMessage: true,
        });

        io?.emit("user_left", {
          userName: user.userName,
          onlineCount: connectedUsers.size,
          message: systemMessage,
        });

        // Update online players list
        const onlinePlayersList = await db.select().from(onlinePlayers);
        io?.emit("online_players", {
          count: onlinePlayersList.length,
          players: onlinePlayersList.map((p) => p.userName),
        });
      }

      console.log(`[Chat] User disconnected: ${socket.id}`);
    });
  });

  return io;
}

export function getIO() {
  return io;
}

export function getConnectedUsersCount() {
  return connectedUsers.size;
}
