import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(overrides?: Partial<AuthenticatedUser>): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user-123",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
    ...overrides,
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: { origin: "https://test.example.com" },
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("Auth Router", () => {
  it("returns null for unauthenticated user", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });

  it("returns user data for authenticated user", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.me();
    expect(result).toBeDefined();
    expect(result?.openId).toBe("test-user-123");
    expect(result?.email).toBe("test@example.com");
    expect(result?.name).toBe("Test User");
  });

  it("logout clears cookie and returns success", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result).toEqual({ success: true });
  });
});

describe("Sportsbook Router", () => {
  it("getEvents returns an array (may be empty if ESPN API is down)", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const events = await caller.sportsbook.getEvents();
    expect(Array.isArray(events)).toBe(true);
  }, 30000);

  it("getEvents returns events with correct structure when available", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const events = await caller.sportsbook.getEvents();
    if (events.length > 0) {
      const event = events[0];
      expect(event).toHaveProperty("id");
      expect(event).toHaveProperty("sport");
      expect(event).toHaveProperty("homeTeam");
      expect(event).toHaveProperty("awayTeam");
      expect(event).toHaveProperty("homeOdds");
      expect(event).toHaveProperty("awayOdds");
      expect(event).toHaveProperty("status");
      expect(["live", "upcoming"]).toContain(event.status);
    }
  }, 30000);
});

describe("Wallet Router - Input Validation", () => {
  it("deposit rejects amount below $5", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.wallet.deposit({ amount: 2, method: "btc" })
    ).rejects.toThrow();
  });

  it("deposit rejects amount above $500", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.wallet.deposit({ amount: 600, method: "stripe" })
    ).rejects.toThrow();
  });

  it("deposit accepts valid crypto method", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    // This will fail at DB level but validates input schema
    try {
      await caller.wallet.deposit({ amount: 25, method: "btc" });
    } catch (e: any) {
      // Expected to fail at DB level, not input validation
      expect(e.message).not.toContain("Invalid");
    }
  });

  it("deposit accepts valid stripe method", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    try {
      await caller.wallet.deposit({ amount: 100, method: "stripe", stripePaymentId: "pi_test_123" });
    } catch (e: any) {
      expect(e.message).not.toContain("Invalid");
    }
  });
});

describe("Games Router - Input Validation", () => {
  it("playKeno validates bet amount minimum", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.games.playKeno({ betAmount: 0, selectedNumbers: [1, 2, 3] })
    ).rejects.toThrow();
  });

  it("playKeno validates selectedNumbers is required", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.games.playKeno({ betAmount: 5, selectedNumbers: [] })
    ).rejects.toThrow();
  });

  it("playCrash validates bet amount minimum", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.games.playCrash({ betAmount: 0 })
    ).rejects.toThrow();
  });

  it("playRoulette with empty bets returns result with zero payout", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    // Empty bets array is allowed but results in 0 payout
    const result = await caller.games.playRoulette({ bets: [] });
    expect(result).toHaveProperty("result");
    expect(result.payout).toBe(0);
  });

  it("playHelm validates bet amount minimum", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.games.playHelm({ betAmount: 0, selectedSegment: 1 })
    ).rejects.toThrow();
  });

  it("playMines validates bet amount minimum", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.games.playMines({ betAmount: 0, mineCount: 5 })
    ).rejects.toThrow();
  });

  it("playHiLo validates bet amount minimum", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.games.playHiLo({ betAmount: 0 })
    ).rejects.toThrow();
  });

  it("playTower validates bet amount minimum", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.games.playTower({ betAmount: 0 })
    ).rejects.toThrow();
  });
});

describe("Player Router", () => {
  it("getStats requires authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.player.getStats()).rejects.toThrow();
  });

  it("getRecentGames requires authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.player.getRecentGames({ limit: 5 })).rejects.toThrow();
  });
});
