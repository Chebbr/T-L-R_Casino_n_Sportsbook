import Stripe from "stripe";
import { Router, raw } from "express";
import { getDb } from "./db";
import { users, transactions } from "../drizzle/schema";
import { eq, sql } from "drizzle-orm";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
  apiVersion: "2025-04-30.basil" as any,
});

export function registerStripeRoutes(app: any) {
  const router = Router();

  // Webhook endpoint - must use raw body for signature verification
  router.post(
    "/api/stripe/webhook",
    raw({ type: "application/json" }),
    async (req, res) => {
      const sig = req.headers["stripe-signature"] as string;
      const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

      let event: Stripe.Event;

      try {
        if (!webhookSecret) {
          throw new Error("Webhook secret not configured");
        }
        event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
      } catch (err: any) {
        console.error("[Stripe Webhook] Signature verification failed:", err.message);
        return res.status(400).send(`Webhook Error: ${err.message}`);
      }

      // Handle test events
      if (event.id.startsWith("evt_test_")) {
        console.log("[Webhook] Test event detected, returning verification response");
        return res.json({ verified: true });
      }

      console.log(`[Stripe Webhook] Received event: ${event.type} (${event.id})`);

      try {
        switch (event.type) {
          case "checkout.session.completed": {
            const session = event.data.object as Stripe.Checkout.Session;
            const userId = session.metadata?.user_id;
            const amount = session.amount_total ? session.amount_total / 100 : 0;

            if (userId && amount > 0) {
              const db = await getDb();
              if (db) {
                // Credit user balance
                await db
                  .update(users)
                  .set({
                    balance: sql`${users.balance} + ${amount.toFixed(2)}`,
                  })
                  .where(eq(users.id, parseInt(userId)));

                // Record transaction
                await db.insert(transactions).values({
                  userId: parseInt(userId),
                  type: "deposit",
                  method: "stripe",
                  amount: amount.toFixed(2),
                  status: "completed",
                  stripePaymentId: session.payment_intent as string || session.id,
                  description: `Debit card deposit via Stripe`,
                });

                console.log(`[Stripe Webhook] Credited $${amount} to user ${userId}`);
              }
            }
            break;
          }

          case "payment_intent.succeeded": {
            console.log(`[Stripe Webhook] Payment succeeded: ${(event.data.object as any).id}`);
            break;
          }

          default:
            console.log(`[Stripe Webhook] Unhandled event type: ${event.type}`);
        }
      } catch (err) {
        console.error("[Stripe Webhook] Error processing event:", err);
      }

      res.json({ received: true });
    }
  );

  // Create checkout session for debit card deposit
  router.post("/api/stripe/create-checkout", async (req, res) => {
    try {
      const { amount, userId, userEmail, userName } = req.body;

      if (!amount || amount < 5 || amount > 500) {
        return res.status(400).json({ error: "Amount must be between $5 and $500" });
      }

      if (!userId) {
        return res.status(400).json({ error: "User ID is required" });
      }

      const origin = req.headers.origin || req.headers.referer?.replace(/\/$/, "") || "";

      const session = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        mode: "payment",
        client_reference_id: userId.toString(),
        customer_email: userEmail || undefined,
        metadata: {
          user_id: userId.toString(),
          customer_email: userEmail || "",
          customer_name: userName || "",
          deposit_type: "debit_card",
        },
        line_items: [
          {
            price_data: {
              currency: "usd",
              product_data: {
                name: "Account Deposit",
                description: `$${amount.toFixed(2)} deposit to The Lucky Riverboat`,
              },
              unit_amount: Math.round(amount * 100),
            },
            quantity: 1,
          },
        ],
        allow_promotion_codes: true,
        success_url: `${origin}/wallet?deposit=success&amount=${amount}`,
        cancel_url: `${origin}/wallet?deposit=cancelled`,
      });

      res.json({ url: session.url });
    } catch (err: any) {
      console.error("[Stripe] Error creating checkout session:", err);
      res.status(500).json({ error: err.message || "Failed to create checkout session" });
    }
  });

  // Register webhook route BEFORE json middleware
  // This needs special handling in the main server
  app.use(router);
}

export { stripe };
