import { protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { users, supportTickets, withdrawalRequests, bonusCodes, bonusCodeUsage, rtpSettings } from "../drizzle/schema";
import { eq, desc, sql } from "drizzle-orm";

export const supportRouter = router({
  createTicket: protectedProcedure
    .input(z.object({
      category: z.string().min(1),
      subject: z.string().min(5),
      description: z.string().min(10),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");
      const [ticket] = await db.insert(supportTickets).values({
        userId: ctx.user.id,
        category: input.category,
        subject: input.subject,
        description: input.description,
        status: "open",
        priority: "medium",
      }).$returningId();
      return ticket;
    }),

  getMyTickets: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    return db.select().from(supportTickets).where(eq(supportTickets.userId, ctx.user.id)).orderBy(desc(supportTickets.createdAt));
  }),
});

export const vaultRouter = router({
  getVaultBalance: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return { vaultBalance: "0.00" };
    const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
    return { vaultBalance: user?.vaultBalance || "0.00" };
  }),

  depositToVault: protectedProcedure
    .input(z.object({ amount: z.number().min(0.1) }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");
      const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
      if (!user || Number(user.balance) < input.amount) throw new Error("Insufficient balance");
      await db.update(users).set({
        balance: sql`${users.balance} - ${input.amount.toFixed(2)}`,
        vaultBalance: sql`${users.vaultBalance} + ${input.amount.toFixed(2)}`,
      }).where(eq(users.id, ctx.user.id));
      return { success: true };
    }),

  withdrawFromVault: protectedProcedure
    .input(z.object({ amount: z.number().min(0.1) }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");
      const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
      if (!user || Number(user.vaultBalance) < input.amount) throw new Error("Insufficient vault balance");
      await db.update(users).set({
        balance: sql`${users.balance} + ${input.amount.toFixed(2)}`,
        vaultBalance: sql`${users.vaultBalance} - ${input.amount.toFixed(2)}`,
      }).where(eq(users.id, ctx.user.id));
      return { success: true };
    }),
});

export const tippingRouter = router({
  sendTip: protectedProcedure
    .input(z.object({ recipientId: z.number(), amount: z.number().min(0.1) }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");
      const [sender] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
      if (!sender || Number(sender.balance) < input.amount) throw new Error("Insufficient balance");
      const [recipient] = await db.select().from(users).where(eq(users.id, input.recipientId)).limit(1);
      if (!recipient) throw new Error("Recipient not found");
      await db.update(users).set({
        balance: sql`${users.balance} - ${input.amount.toFixed(2)}`,
      }).where(eq(users.id, ctx.user.id));
      await db.update(users).set({
        balance: sql`${users.balance} + ${input.amount.toFixed(2)}`,
      }).where(eq(users.id, input.recipientId));
      return { success: true };
    }),
});

export const bonusRouter = router({
  redeemCode: protectedProcedure
    .input(z.object({ code: z.string().min(3) }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");
      const [bonusCode] = await db.select().from(bonusCodes).where(eq(bonusCodes.code, input.code)).limit(1);
      if (!bonusCode || !bonusCode.isActive) throw new Error("Invalid or expired bonus code");
      if (bonusCode.maxUses && bonusCode.currentUses >= bonusCode.maxUses) throw new Error("Bonus code limit reached");
      if (bonusCode.expiresAt && new Date(bonusCode.expiresAt) < new Date()) throw new Error("Bonus code expired");
      await db.update(users).set({
        balance: sql`${users.balance} + ${bonusCode.bonusAmount}`,
      }).where(eq(users.id, ctx.user.id));
      await db.update(bonusCodes).set({
        currentUses: sql`${bonusCodes.currentUses} + 1`,
      }).where(eq(bonusCodes.id, bonusCode.id));
      await db.insert(bonusCodeUsage).values({
        userId: ctx.user.id,
        bonusCodeId: bonusCode.id,
      });
      return { success: true, bonusAmount: bonusCode.bonusAmount };
    }),
});

export const affiliateRouter = router({
  getAffiliateInfo: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return null;
    const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
    if (!user?.affiliateCode) return null;
    return {
      affiliateCode: user.affiliateCode,
      referrerId: user.referrerId,
      affiliateEarnings: user.affiliateEarnings,
    };
  }),

  generateAffiliateCode: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    const code = `REF${ctx.user.id}${Math.random().toString(36).substring(7).toUpperCase()}`;
    await db.update(users).set({ affiliateCode: code }).where(eq(users.id, ctx.user.id));
    return { affiliateCode: code };
  }),
});

export const vipRouter = router({
  getVipInfo: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return null;
    const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
    return {
      vipLevel: user?.vipLevel,
      vipExperience: user?.vipExperience,
      totalWagered: user?.totalWagered,
    };
  }),
});

export const adminRouter = router({
  getAllUsers: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
    const db = await getDb();
    if (!db) return [];
    return db.select().from(users).orderBy(desc(users.createdAt)).limit(100);
  }),

  updateUserBalance: protectedProcedure
    .input(z.object({ userId: z.number(), newBalance: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");
      await db.update(users).set({ balance: input.newBalance.toFixed(2) }).where(eq(users.id, input.userId));
      return { success: true };
    }),

  getPendingWithdrawals: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
    const db = await getDb();
    if (!db) return [];
    return db.select().from(withdrawalRequests).where(eq(withdrawalRequests.status, "pending")).orderBy(desc(withdrawalRequests.createdAt));
  }),

  approveWithdrawal: protectedProcedure
    .input(z.object({ withdrawalId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");
      await db.update(withdrawalRequests).set({ status: "approved", approvedAt: new Date() }).where(eq(withdrawalRequests.id, input.withdrawalId));
      return { success: true };
    }),

  rejectWithdrawal: protectedProcedure
    .input(z.object({ withdrawalId: z.number(), reason: z.string() }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");
      await db.update(withdrawalRequests).set({ status: "rejected", rejectionReason: input.reason }).where(eq(withdrawalRequests.id, input.withdrawalId));
      return { success: true };
    }),

  updateRTP: protectedProcedure
    .input(z.object({ gameType: z.string(), rtp: z.number().min(0).max(100) }))
    .mutation(async ({ ctx, input }) => {
      if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");
      const [existing] = await db.select().from(rtpSettings).where(eq(rtpSettings.gameType, input.gameType)).limit(1);
      if (existing) {
        await db.update(rtpSettings).set({ currentRtp: input.rtp.toFixed(2) }).where(eq(rtpSettings.gameType, input.gameType));
      } else {
        await db.insert(rtpSettings).values({ gameType: input.gameType, baseRtp: input.rtp.toFixed(2), currentRtp: input.rtp.toFixed(2) });
      }
      return { success: true };
    }),
});
