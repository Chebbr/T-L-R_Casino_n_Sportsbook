import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { users, transactions, gameSessions, sportsBets } from "../drizzle/schema";
import { supportRouter, vaultRouter, tippingRouter, bonusRouter, affiliateRouter, vipRouter, adminRouter } from "./routers-extended";
import { eq, desc, sql, and } from "drizzle-orm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  wallet: router({
    getBalance: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return { balance: "0.00" };
      const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
      return { balance: user?.balance || "0.00" };
    }),

    getBalances: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return { wallets: [] };
      const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
      return {
        wallets: [
          { id: 1, currency: "USDT", balance: user?.balance || "0.00" },
        ],
      };
    }),

    getTransactions: protectedProcedure
      .input(z.object({ limit: z.number().optional().default(20) }))
      .query(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) return [];
        return db
          .select()
          .from(transactions)
          .where(eq(transactions.userId, ctx.user.id))
          .orderBy(desc(transactions.createdAt))
          .limit(input.limit);
      }),

    deposit: protectedProcedure
      .input(z.object({
        amount: z.number().min(5).max(500),
        method: z.enum(["btc", "eth", "stripe"]),
        txHash: z.string().optional(),
        stripePaymentId: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        await db.insert(transactions).values({
          userId: ctx.user.id,
          type: "deposit",
          method: input.method,
          amount: input.amount.toFixed(2),
          status: input.method === "stripe" ? "completed" : "pending",
          txHash: input.txHash || null,
          stripePaymentId: input.stripePaymentId || null,
          description: `${input.method.toUpperCase()} deposit`,
        });

        if (input.method === "stripe") {
          await db
            .update(users)
            .set({
              balance: sql`${users.balance} + ${input.amount.toFixed(2)}`,
            })
            .where(eq(users.id, ctx.user.id));
        }

        return { success: true };
      }),

    confirmCryptoDeposit: protectedProcedure
      .input(z.object({ transactionId: z.number(), txHash: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        await db
          .update(transactions)
          .set({ status: "completed", txHash: input.txHash })
          .where(and(eq(transactions.id, input.transactionId), eq(transactions.userId, ctx.user.id)));

        const [tx] = await db
          .select()
          .from(transactions)
          .where(eq(transactions.id, input.transactionId))
          .limit(1);

        if (tx) {
          await db
            .update(users)
            .set({ balance: sql`${users.balance} + ${tx.amount}` })
            .where(eq(users.id, ctx.user.id));
        }

        return { success: true };
      }),
  }),

  player: router({
    getStats: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return { totalBets: 0, totalWins: 0, totalLosses: 0, totalWagered: 0, totalPayout: 0, biggestWin: 0 };

      const result = await db
        .select({
          totalBets: sql<number>`COUNT(*)`,
          totalWins: sql<number>`SUM(CASE WHEN ${gameSessions.payout} > ${gameSessions.betAmount} THEN 1 ELSE 0 END)`,
          totalLosses: sql<number>`SUM(CASE WHEN ${gameSessions.payout} <= 0 AND ${gameSessions.status} = 'completed' THEN 1 ELSE 0 END)`,
          totalWagered: sql<number>`COALESCE(SUM(${gameSessions.betAmount}), 0)`,
          totalPayout: sql<number>`COALESCE(SUM(${gameSessions.payout}), 0)`,
          biggestWin: sql<number>`COALESCE(MAX(${gameSessions.payout}), 0)`,
        })
        .from(gameSessions)
        .where(and(eq(gameSessions.userId, ctx.user.id), eq(gameSessions.status, "completed")));

      return result[0] || { totalBets: 0, totalWins: 0, totalLosses: 0, totalWagered: 0, totalPayout: 0, biggestWin: 0 };
    }),

    getRecentGames: protectedProcedure
      .input(z.object({ limit: z.number().optional().default(10) }))
      .query(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) return [];
        const rows = await db
          .select()
          .from(gameSessions)
          .where(and(eq(gameSessions.userId, ctx.user.id), eq(gameSessions.status, "completed")))
          .orderBy(desc(gameSessions.createdAt))
          .limit(input.limit);
        return rows.map((r) => ({
          ...r,
          result: Number(r.payout) > Number(r.betAmount) ? "win" : "loss",
        }));
      }),

    getAllStats: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db
        .select({
          gameType: gameSessions.gameType,
          totalBets: sql<number>`COUNT(*)`,
          totalWins: sql<number>`SUM(CASE WHEN ${gameSessions.payout} > ${gameSessions.betAmount} THEN 1 ELSE 0 END)`,
          totalWagered: sql<string>`COALESCE(SUM(${gameSessions.betAmount}), 0)`,
          biggestWin: sql<string>`COALESCE(MAX(${gameSessions.payout}), 0)`,
          longestStreak: sql<number>`0`,
        })
        .from(gameSessions)
        .where(and(eq(gameSessions.userId, ctx.user.id), eq(gameSessions.status, "completed")))
        .groupBy(gameSessions.gameType);
    }),
  }),

  games: router({
    // ===== KENO =====
    playKeno: protectedProcedure
      .input(z.object({
        betAmount: z.number().min(0.1),
        selectedNumbers: z.array(z.number().min(1).max(40)).min(1).max(10),
        currency: z.string().default("USDT"),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        if (!user || Number(user.balance) < input.betAmount) throw new Error("Insufficient balance");

        // Draw 10 random numbers
        const drawnNumbers: number[] = [];
        while (drawnNumbers.length < 10) {
          const n = Math.floor(Math.random() * 40) + 1;
          if (!drawnNumbers.includes(n)) drawnNumbers.push(n);
        }

        const hits = input.selectedNumbers.filter((n) => drawnNumbers.includes(n)).length;
        const totalSelected = input.selectedNumbers.length;

        // Payout table (0% house edge style)
        const payoutMultipliers: Record<number, Record<number, number>> = {
          1: { 0: 0, 1: 3.9 },
          2: { 0: 0, 1: 1.5, 2: 8 },
          3: { 0: 0, 1: 0.5, 2: 3, 3: 25 },
          4: { 0: 0, 1: 0, 2: 2, 3: 8, 4: 75 },
          5: { 0: 0, 1: 0, 2: 1, 3: 4, 4: 20, 5: 200 },
          6: { 0: 0, 1: 0, 2: 0.5, 3: 2, 4: 10, 5: 80, 6: 500 },
          7: { 0: 0, 1: 0, 2: 0, 3: 1.5, 4: 5, 5: 30, 6: 200, 7: 1000 },
          8: { 0: 0, 1: 0, 2: 0, 3: 1, 4: 3, 5: 15, 6: 80, 7: 500, 8: 2500 },
          9: { 0: 0, 1: 0, 2: 0, 3: 0.5, 4: 2, 5: 8, 6: 40, 7: 200, 8: 1000, 9: 5000 },
          10: { 0: 0, 1: 0, 2: 0, 3: 0, 4: 1.5, 5: 5, 6: 20, 7: 100, 8: 500, 9: 2500, 10: 10000 },
        };

        const multiplier = payoutMultipliers[totalSelected]?.[hits] || 0;
        const payout = input.betAmount * multiplier;

        // Update balance
        const newBalance = Number(user.balance) - input.betAmount + payout;
        await db.update(users).set({
          balance: newBalance.toFixed(2),
          totalWagered: sql`${users.totalWagered} + ${input.betAmount.toFixed(2)}`,
          totalWon: sql`${users.totalWon} + ${payout.toFixed(2)}`,
          gamesPlayed: sql`${users.gamesPlayed} + 1`,
        }).where(eq(users.id, ctx.user.id));

        await db.insert(gameSessions).values({
          userId: ctx.user.id,
          gameType: "keno",
          betAmount: input.betAmount.toFixed(2),
          multiplier: multiplier.toFixed(4),
          payout: payout.toFixed(2),
          result: JSON.stringify({ selectedNumbers: input.selectedNumbers, drawnNumbers, hits }),
          status: "completed",
        });

        return { drawnNumbers, hits, multiplier, payout };
      }),

    // ===== CRASH (BEACHED) =====
    playCrash: protectedProcedure
      .input(z.object({
        betAmount: z.number().min(0.1),
        currency: z.string().default("USDT"),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        if (!user || Number(user.balance) < input.betAmount) throw new Error("Insufficient balance");

        // Deduct bet
        await db.update(users).set({
          balance: sql`${users.balance} - ${input.betAmount.toFixed(2)}`,
          totalWagered: sql`${users.totalWagered} + ${input.betAmount.toFixed(2)}`,
          gamesPlayed: sql`${users.gamesPlayed} + 1`,
        }).where(eq(users.id, ctx.user.id));

        // Generate crash point (fair distribution)
        const r = Math.random();
        const crashPoint = Math.max(1, parseFloat((1 / (1 - r)).toFixed(2)));
        const cappedCrash = Math.min(crashPoint, 100);

        // Store active game session
        const [session] = await db.insert(gameSessions).values({
          userId: ctx.user.id,
          gameType: "beached",
          betAmount: input.betAmount.toFixed(2),
          multiplier: "0",
          payout: "0.00",
          result: JSON.stringify({ crashPoint: cappedCrash }),
          status: "active",
        }).$returningId();

        return { crashPoint: cappedCrash, sessionId: session.id };
      }),

    cashoutCrash: protectedProcedure
      .input(z.object({ multiplier: z.number().min(1) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        // Find active crash session
        const [session] = await db
          .select()
          .from(gameSessions)
          .where(and(eq(gameSessions.userId, ctx.user.id), eq(gameSessions.gameType, "beached"), eq(gameSessions.status, "active")))
          .orderBy(desc(gameSessions.createdAt))
          .limit(1);

        if (!session) throw new Error("No active game");

        const payout = Number(session.betAmount) * input.multiplier;

        await db.update(gameSessions).set({
          multiplier: input.multiplier.toFixed(4),
          payout: payout.toFixed(2),
          status: "completed",
        }).where(eq(gameSessions.id, session.id));

        await db.update(users).set({
          balance: sql`${users.balance} + ${payout.toFixed(2)}`,
          totalWon: sql`${users.totalWon} + ${payout.toFixed(2)}`,
        }).where(eq(users.id, ctx.user.id));

        return { multiplier: input.multiplier, payout };
      }),

    // ===== ROULETTE =====
    playRoulette: protectedProcedure
      .input(z.object({
        bets: z.array(z.object({
          type: z.string(),
          value: z.number().optional(),
          amount: z.number().min(0.1),
        })),
        currency: z.string().default("USDT"),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const totalBet = input.bets.reduce((s, b) => s + b.amount, 0);
        const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        if (!user || Number(user.balance) < totalBet) throw new Error("Insufficient balance");

        const result = Math.floor(Math.random() * 37); // 0-36
        const redNumbers = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];
        const isRed = redNumbers.includes(result);
        const isBlack = result > 0 && !isRed;

        let totalPayout = 0;
        for (const bet of input.bets) {
          let win = false;
          let multiplier = 0;
          switch (bet.type) {
            case "number": win = bet.value === result; multiplier = 36; break;
            case "red": win = isRed; multiplier = 2; break;
            case "black": win = isBlack; multiplier = 2; break;
            case "odd": win = result > 0 && result % 2 === 1; multiplier = 2; break;
            case "even": win = result > 0 && result % 2 === 0; multiplier = 2; break;
            case "1-18": win = result >= 1 && result <= 18; multiplier = 2; break;
            case "19-36": win = result >= 19 && result <= 36; multiplier = 2; break;
            case "1-12": win = result >= 1 && result <= 12; multiplier = 3; break;
            case "13-24": win = result >= 13 && result <= 24; multiplier = 3; break;
            case "25-36": win = result >= 25 && result <= 36; multiplier = 3; break;
          }
          if (win) totalPayout += bet.amount * multiplier;
        }

        const netChange = totalPayout - totalBet;
        await db.update(users).set({
          balance: sql`${users.balance} + ${netChange.toFixed(2)}`,
          totalWagered: sql`${users.totalWagered} + ${totalBet.toFixed(2)}`,
          totalWon: sql`${users.totalWon} + ${totalPayout.toFixed(2)}`,
          gamesPlayed: sql`${users.gamesPlayed} + 1`,
        }).where(eq(users.id, ctx.user.id));

        await db.insert(gameSessions).values({
          userId: ctx.user.id,
          gameType: "roulette",
          betAmount: totalBet.toFixed(2),
          multiplier: totalBet > 0 ? (totalPayout / totalBet).toFixed(4) : "0",
          payout: totalPayout.toFixed(2),
          result: JSON.stringify({ number: result, bets: input.bets }),
          status: "completed",
        });

        return { result, payout: totalPayout };
      }),

    // ===== HELM =====
    playHelm: protectedProcedure
      .input(z.object({
        betAmount: z.number().min(0.1),
        selectedSegment: z.number(),
        currency: z.string().default("USDT"),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        if (!user || Number(user.balance) < input.betAmount) throw new Error("Insufficient balance");

        const segments = [
          { id: 1, multiplier: 1 }, { id: 2, multiplier: 2 }, { id: 3, multiplier: 1 },
          { id: 4, multiplier: 3 }, { id: 5, multiplier: 1 }, { id: 6, multiplier: 2 },
          { id: 7, multiplier: 1 }, { id: 8, multiplier: 5 }, { id: 9, multiplier: 1 },
          { id: 10, multiplier: 2 }, { id: 11, multiplier: 1 }, { id: 12, multiplier: 10 },
        ];

        const winningSegment = segments[Math.floor(Math.random() * segments.length)];
        const isWin = winningSegment.multiplier === input.selectedSegment;
        const payoutMultiplier = isWin ? (segments.length / segments.filter(s => s.multiplier === input.selectedSegment).length) : 0;
        const payout = input.betAmount * payoutMultiplier;

        const netChange = payout - input.betAmount;
        await db.update(users).set({
          balance: sql`${users.balance} + ${netChange.toFixed(2)}`,
          totalWagered: sql`${users.totalWagered} + ${input.betAmount.toFixed(2)}`,
          totalWon: sql`${users.totalWon} + ${payout.toFixed(2)}`,
          gamesPlayed: sql`${users.gamesPlayed} + 1`,
        }).where(eq(users.id, ctx.user.id));

        await db.insert(gameSessions).values({
          userId: ctx.user.id,
          gameType: "helm",
          betAmount: input.betAmount.toFixed(2),
          multiplier: payoutMultiplier.toFixed(4),
          payout: payout.toFixed(2),
          result: JSON.stringify({ segmentId: winningSegment.id, selectedSegment: input.selectedSegment }),
          status: "completed",
        });

        return { segmentId: winningSegment.id, payout };
      }),

    // ===== TOWER (Walk the Plank) =====
    playTower: protectedProcedure
      .input(z.object({
        betAmount: z.number().min(0.1),
        currency: z.string().default("USDT"),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        if (!user || Number(user.balance) < input.betAmount) throw new Error("Insufficient balance");

        await db.update(users).set({
          balance: sql`${users.balance} - ${input.betAmount.toFixed(2)}`,
          totalWagered: sql`${users.totalWagered} + ${input.betAmount.toFixed(2)}`,
          gamesPlayed: sql`${users.gamesPlayed} + 1`,
        }).where(eq(users.id, ctx.user.id));

        // Generate safe tiles for each level
        const safeTiles = Array.from({ length: 8 }, () => Math.floor(Math.random() * 3));

        const [session] = await db.insert(gameSessions).values({
          userId: ctx.user.id,
          gameType: "walk-the-plank",
          betAmount: input.betAmount.toFixed(2),
          multiplier: "0",
          payout: "0.00",
          result: JSON.stringify({ safeTiles }),
          status: "active",
        }).$returningId();

        return { safeTiles, sessionId: session.id };
      }),

    cashoutTower: protectedProcedure
      .input(z.object({ level: z.number(), multiplier: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [session] = await db
          .select()
          .from(gameSessions)
          .where(and(eq(gameSessions.userId, ctx.user.id), eq(gameSessions.gameType, "walk-the-plank"), eq(gameSessions.status, "active")))
          .orderBy(desc(gameSessions.createdAt))
          .limit(1);

        if (!session) throw new Error("No active game");

        const payout = Number(session.betAmount) * input.multiplier;

        await db.update(gameSessions).set({
          multiplier: input.multiplier.toFixed(4),
          payout: payout.toFixed(2),
          status: "completed",
        }).where(eq(gameSessions.id, session.id));

        await db.update(users).set({
          balance: sql`${users.balance} + ${payout.toFixed(2)}`,
          totalWon: sql`${users.totalWon} + ${payout.toFixed(2)}`,
        }).where(eq(users.id, ctx.user.id));

        return { payout };
      }),

    // ===== MINES (Hidden Treasure) =====
    playMines: protectedProcedure
      .input(z.object({
        betAmount: z.number().min(0.1),
        mineCount: z.number().min(1).max(24),
        currency: z.string().default("USDT"),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        if (!user || Number(user.balance) < input.betAmount) throw new Error("Insufficient balance");

        await db.update(users).set({
          balance: sql`${users.balance} - ${input.betAmount.toFixed(2)}`,
          totalWagered: sql`${users.totalWagered} + ${input.betAmount.toFixed(2)}`,
          gamesPlayed: sql`${users.gamesPlayed} + 1`,
        }).where(eq(users.id, ctx.user.id));

        // Generate mine positions
        const minePositions: number[] = [];
        while (minePositions.length < input.mineCount) {
          const pos = Math.floor(Math.random() * 25);
          if (!minePositions.includes(pos)) minePositions.push(pos);
        }

        const [session] = await db.insert(gameSessions).values({
          userId: ctx.user.id,
          gameType: "hidden-treasure",
          betAmount: input.betAmount.toFixed(2),
          multiplier: "0",
          payout: "0.00",
          result: JSON.stringify({ minePositions, mineCount: input.mineCount }),
          status: "active",
        }).$returningId();

        return { minePositions, sessionId: session.id };
      }),

    cashoutMines: protectedProcedure
      .input(z.object({ revealedCount: z.number(), multiplier: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [session] = await db
          .select()
          .from(gameSessions)
          .where(and(eq(gameSessions.userId, ctx.user.id), eq(gameSessions.gameType, "hidden-treasure"), eq(gameSessions.status, "active")))
          .orderBy(desc(gameSessions.createdAt))
          .limit(1);

        if (!session) throw new Error("No active game");

        const payout = Number(session.betAmount) * input.multiplier;

        await db.update(gameSessions).set({
          multiplier: input.multiplier.toFixed(4),
          payout: payout.toFixed(2),
          status: "completed",
        }).where(eq(gameSessions.id, session.id));

        await db.update(users).set({
          balance: sql`${users.balance} + ${payout.toFixed(2)}`,
          totalWon: sql`${users.totalWon} + ${payout.toFixed(2)}`,
        }).where(eq(users.id, ctx.user.id));

        return { payout };
      }),

    // ===== HI-LOW (Hitide Lowtide) =====
    playHiLow: protectedProcedure
      .input(z.object({
        betAmount: z.number().min(0.1),
        currency: z.string().default("USDT"),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        if (!user || Number(user.balance) < input.betAmount) throw new Error("Insufficient balance");

        await db.update(users).set({
          balance: sql`${users.balance} - ${input.betAmount.toFixed(2)}`,
          totalWagered: sql`${users.totalWagered} + ${input.betAmount.toFixed(2)}`,
          gamesPlayed: sql`${users.gamesPlayed} + 1`,
        }).where(eq(users.id, ctx.user.id));

        const values = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"];
        const suits = ["♠","♥","♦","♣"];
        const randomCard = () => values[Math.floor(Math.random() * values.length)] + suits[Math.floor(Math.random() * suits.length)];

        const currentCard = randomCard();

        const [session] = await db.insert(gameSessions).values({
          userId: ctx.user.id,
          gameType: "hitide-lowtide",
          betAmount: input.betAmount.toFixed(2),
          multiplier: "1",
          payout: "0.00",
          result: JSON.stringify({ currentCard, streak: 0 }),
          status: "active",
        }).$returningId();

        return { currentCard, sessionId: session.id };
      }),

    guessHiLow: protectedProcedure
      .input(z.object({ guess: z.enum(["high", "low", "same"]) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [session] = await db
          .select()
          .from(gameSessions)
          .where(and(eq(gameSessions.userId, ctx.user.id), eq(gameSessions.gameType, "hitide-lowtide"), eq(gameSessions.status, "active")))
          .orderBy(desc(gameSessions.createdAt))
          .limit(1);

        if (!session) throw new Error("No active game");

        const values = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"];
        const suits = ["♠","♥","♦","♣"];
        const getVal = (card: string) => values.indexOf(card.slice(0, -1)) + 1;
        const randomCard = () => values[Math.floor(Math.random() * values.length)] + suits[Math.floor(Math.random() * suits.length)];

        const gameData = session.result as any;
        const currentCard = gameData.currentCard;
        const nextCard = randomCard();
        const currentVal = getVal(currentCard);
        const nextVal = getVal(nextCard);

        let correct = false;
        if (input.guess === "high") correct = nextVal > currentVal;
        else if (input.guess === "low") correct = nextVal < currentVal;
        else correct = nextVal === currentVal;

        if (correct) {
          const newStreak = (gameData.streak || 0) + 1;
          const newMultiplier = Math.pow(1.5, newStreak);

          await db.update(gameSessions).set({
            multiplier: newMultiplier.toFixed(4),
            result: JSON.stringify({ ...gameData, currentCard: nextCard, streak: newStreak }),
          }).where(eq(gameSessions.id, session.id));

          return { correct: true, nextCard, streak: newStreak, multiplier: newMultiplier };
        } else {
          await db.update(gameSessions).set({
            status: "completed",
            payout: "0.00",
          }).where(eq(gameSessions.id, session.id));

          return { correct: false, nextCard, streak: 0, multiplier: 0 };
        }
      }),

    cashoutHiLow: protectedProcedure
      .input(z.object({ streak: z.number(), multiplier: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [session] = await db
          .select()
          .from(gameSessions)
          .where(and(eq(gameSessions.userId, ctx.user.id), eq(gameSessions.gameType, "hitide-lowtide"), eq(gameSessions.status, "active")))
          .orderBy(desc(gameSessions.createdAt))
          .limit(1);

        if (!session) throw new Error("No active game");

        const payout = Number(session.betAmount) * input.multiplier;

        await db.update(gameSessions).set({
          multiplier: input.multiplier.toFixed(4),
          payout: payout.toFixed(2),
          status: "completed",
        }).where(eq(gameSessions.id, session.id));

        await db.update(users).set({
          balance: sql`${users.balance} + ${payout.toFixed(2)}`,
          totalWon: sql`${users.totalWon} + ${payout.toFixed(2)}`,
        }).where(eq(users.id, ctx.user.id));

        return { payout };
      }),
  }),

  support: supportRouter,
  vault: vaultRouter,
  tipping: tippingRouter,
  bonus: bonusRouter,
  affiliate: affiliateRouter,
  vip: vipRouter,
  admin: adminRouter,

  sportsbook: router({
    getEvents: publicProcedure.query(async () => {
      // Fetch live events from ESPN API
      try {
        const sports = [
          { key: "football/nfl", name: "Football", league: "NFL" },
          { key: "basketball/nba", name: "Basketball", league: "NBA" },
          { key: "hockey/nhl", name: "Hockey", league: "NHL" },
          { key: "baseball/mlb", name: "Baseball", league: "MLB" },
          { key: "soccer/usa.1", name: "Soccer", league: "MLS" },
        ];

        const allEvents: any[] = [];

        for (const sport of sports) {
          try {
            const res = await fetch(`https://site.api.espn.com/apis/site/v2/sports/${sport.key}/scoreboard`);
            if (!res.ok) continue;
            const data = await res.json();

            for (const event of (data.events || [])) {
              const competition = event.competitions?.[0];
              if (!competition) continue;

              const homeTeam = competition.competitors?.find((c: any) => c.homeAway === "home");
              const awayTeam = competition.competitors?.find((c: any) => c.homeAway === "away");

              if (!homeTeam || !awayTeam) continue;

              const status = competition.status?.type?.state;
              const isLive = status === "in";
              const isUpcoming = status === "pre";

              if (!isLive && !isUpcoming) continue;

              // Generate fair odds based on team rankings/records
              const homeScore = parseFloat(homeTeam.score || "0");
              const awayScore = parseFloat(awayTeam.score || "0");

              let homeOdds = 1.90 + Math.random() * 0.3;
              let awayOdds = 1.90 + Math.random() * 0.3;

              if (isLive) {
                if (homeScore > awayScore) {
                  homeOdds = 1.40 + Math.random() * 0.4;
                  awayOdds = 2.50 + Math.random() * 0.8;
                } else if (awayScore > homeScore) {
                  awayOdds = 1.40 + Math.random() * 0.4;
                  homeOdds = 2.50 + Math.random() * 0.8;
                }
              }

              allEvents.push({
                id: event.id,
                sport: sport.name,
                league: sport.league,
                homeTeam: homeTeam.team?.displayName || "Home",
                awayTeam: awayTeam.team?.displayName || "Away",
                homeScore: isLive ? homeScore : undefined,
                awayScore: isLive ? awayScore : undefined,
                eventDate: event.date,
                homeOdds: parseFloat(homeOdds.toFixed(2)),
                awayOdds: parseFloat(awayOdds.toFixed(2)),
                drawOdds: sport.name === "Soccer" ? parseFloat((3.0 + Math.random() * 1.5).toFixed(2)) : undefined,
                status: isLive ? "live" : "upcoming",
                statusDetail: competition.status?.type?.shortDetail || "",
                homeLogo: homeTeam.team?.logo,
                awayLogo: awayTeam.team?.logo,
              });
            }
          } catch (e) {
            // Skip failed sport
          }
        }

        return allEvents;
      } catch (error) {
        return [];
      }
    }),

    placeBet: protectedProcedure
      .input(z.object({
        eventId: z.string(),
        sport: z.string(),
        eventName: z.string(),
        selection: z.string(),
        odds: z.number(),
        betAmount: z.number().min(0.1),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        if (!user || Number(user.balance) < input.betAmount) throw new Error("Insufficient balance");

        const potentialPayout = input.betAmount * input.odds;

        await db.update(users).set({
          balance: sql`${users.balance} - ${input.betAmount.toFixed(2)}`,
        }).where(eq(users.id, ctx.user.id));

        await db.insert(sportsBets).values({
          userId: ctx.user.id,
          eventId: input.eventId,
          sport: input.sport,
          eventName: input.eventName,
          selection: input.selection,
          odds: input.odds.toFixed(2),
          betAmount: input.betAmount.toFixed(2),
          potentialPayout: potentialPayout.toFixed(2),
          status: "pending",
        });

        return { success: true, potentialPayout };
      }),

    getMyBets: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db
        .select()
        .from(sportsBets)
        .where(eq(sportsBets.userId, ctx.user.id))
        .orderBy(desc(sportsBets.createdAt))
        .limit(20);
    }),
  }),
});

export type AppRouter = typeof appRouter;
