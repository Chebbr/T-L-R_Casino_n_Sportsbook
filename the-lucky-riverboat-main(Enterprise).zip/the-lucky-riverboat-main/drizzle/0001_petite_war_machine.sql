CREATE TABLE `gameSessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`gameType` enum('keno','beached','roulette','helm','walk-the-plank','hidden-treasure','hitide-lowtide') NOT NULL,
	`betAmount` decimal(18,2) NOT NULL,
	`multiplier` decimal(10,4) DEFAULT '0.0000',
	`payout` decimal(18,2) NOT NULL DEFAULT '0.00',
	`result` json,
	`status` enum('active','completed','cancelled') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `gameSessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sportsBets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`eventId` varchar(128) NOT NULL,
	`sport` varchar(64) NOT NULL,
	`eventName` text,
	`selection` text NOT NULL,
	`odds` decimal(10,2) NOT NULL,
	`betAmount` decimal(18,2) NOT NULL,
	`potentialPayout` decimal(18,2) NOT NULL,
	`status` enum('pending','won','lost','cancelled','void') NOT NULL DEFAULT 'pending',
	`settledAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sportsBets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('deposit','withdrawal','bet','win','refund') NOT NULL,
	`method` enum('btc','eth','stripe','game') NOT NULL DEFAULT 'game',
	`amount` decimal(18,2) NOT NULL,
	`status` enum('pending','completed','failed','cancelled') NOT NULL DEFAULT 'pending',
	`txHash` varchar(128),
	`stripePaymentId` varchar(128),
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `balance` decimal(18,2) DEFAULT '1000.00' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `totalWagered` decimal(18,2) DEFAULT '0.00' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `totalWon` decimal(18,2) DEFAULT '0.00' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `gamesPlayed` int DEFAULT 0 NOT NULL;