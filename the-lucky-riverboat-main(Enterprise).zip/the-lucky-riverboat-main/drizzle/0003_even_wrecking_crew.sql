CREATE TABLE `chatMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`userName` varchar(255) NOT NULL,
	`message` text NOT NULL,
	`isSystemMessage` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chatMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `onlinePlayers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`userName` varchar(255) NOT NULL,
	`sessionId` varchar(128) NOT NULL,
	`lastHeartbeat` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `onlinePlayers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wagerFeed` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`userName` varchar(255) NOT NULL,
	`gameType` varchar(64) NOT NULL,
	`betAmount` decimal(18,2) NOT NULL,
	`multiplier` decimal(10,4) NOT NULL,
	`payout` decimal(18,2) NOT NULL,
	`result` enum('win','loss','pending') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `wagerFeed_id` PRIMARY KEY(`id`)
);
