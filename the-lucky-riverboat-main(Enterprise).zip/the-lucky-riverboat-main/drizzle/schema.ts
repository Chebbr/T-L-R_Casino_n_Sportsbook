import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, bigint, boolean, json } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  balance: decimal("balance", { precision: 18, scale: 2 }).default("1000.00").notNull(),
  totalWagered: decimal("totalWagered", { precision: 18, scale: 2 }).default("0.00").notNull(),
  totalWon: decimal("totalWon", { precision: 18, scale: 2 }).default("0.00").notNull(),
  gamesPlayed: int("gamesPlayed").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
  vipLevel: mysqlEnum("vipLevel", ["bronze", "silver", "gold", "platinum", "diamond", "elite"]).default("bronze").notNull(),
  vipExperience: int("vipExperience").default(0).notNull(),
  vaultBalance: decimal("vaultBalance", { precision: 18, scale: 2 }).default("0.00").notNull(),
  affiliateCode: varchar("affiliateCode", { length: 32 }).unique(),
  referrerId: int("referrerId"),
  affiliateEarnings: decimal("affiliateEarnings", { precision: 18, scale: 2 }).default("0.00").notNull(),
});

export const transactions = mysqlTable("transactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["deposit", "withdrawal", "bet", "win", "refund"]).notNull(),
  method: mysqlEnum("method", ["btc", "eth", "stripe", "game"]).default("game").notNull(),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "completed", "failed", "cancelled"]).default("pending").notNull(),
  txHash: varchar("txHash", { length: 128 }),
  stripePaymentId: varchar("stripePaymentId", { length: 128 }),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const gameSessions = mysqlTable("gameSessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  gameType: mysqlEnum("gameType", ["keno", "beached", "roulette", "helm", "walk-the-plank", "hidden-treasure", "hitide-lowtide", "blackjack", "plinko", "slots"]).notNull(),
  betAmount: decimal("betAmount", { precision: 18, scale: 2 }).notNull(),
  multiplier: decimal("multiplier", { precision: 10, scale: 4 }).default("0.0000"),
  payout: decimal("payout", { precision: 18, scale: 2 }).default("0.00").notNull(),
  result: json("result"),
  status: mysqlEnum("status", ["active", "completed", "cancelled"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const withdrawalRequests = mysqlTable("withdrawalRequests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  method: mysqlEnum("method", ["btc", "eth", "stripe"]).notNull(),
  address: varchar("address", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "completed"]).default("pending").notNull(),
  txHash: varchar("txHash", { length: 128 }),
  rejectionReason: text("rejectionReason"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  approvedAt: timestamp("approvedAt"),
  completedAt: timestamp("completedAt"),
});

export const bonusCodes = mysqlTable("bonusCodes", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(),
  bonusAmount: decimal("bonusAmount", { precision: 18, scale: 2 }).notNull(),
  wageringRequirement: decimal("wageringRequirement", { precision: 10, scale: 2 }).notNull(),
  maxUses: int("maxUses"),
  currentUses: int("currentUses").default(0).notNull(),
  expiresAt: timestamp("expiresAt"),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const bonusCodeUsage = mysqlTable("bonusCodeUsage", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  bonusCodeId: int("bonusCodeId").notNull(),
  wageringProgress: decimal("wageringProgress", { precision: 18, scale: 2 }).default("0.00").notNull(),
  isCompleted: boolean("isCompleted").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
});

export const affiliates = mysqlTable("affiliates", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  affiliateCode: varchar("affiliateCode", { length: 32 }).notNull().unique(),
  commissionRate: decimal("commissionRate", { precision: 5, scale: 2 }).default("5.00").notNull(),
  totalEarnings: decimal("totalEarnings", { precision: 18, scale: 2 }).default("0.00").notNull(),
  totalReferrals: int("totalReferrals").default(0).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const supportTickets = mysqlTable("supportTickets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  category: varchar("category", { length: 64 }).notNull(),
  subject: varchar("subject", { length: 255 }).notNull(),
  description: text("description").notNull(),
  status: mysqlEnum("status", ["open", "in-progress", "resolved", "closed"]).default("open").notNull(),
  priority: mysqlEnum("priority", ["low", "medium", "high", "urgent"]).default("medium").notNull(),
  assignedAdminId: int("assignedAdminId"),
  resolution: text("resolution"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  resolvedAt: timestamp("resolvedAt"),
});

export const rtpSettings = mysqlTable("rtpSettings", {
  id: int("id").autoincrement().primaryKey(),
  gameType: varchar("gameType", { length: 64 }).notNull().unique(),
  baseRtp: decimal("baseRtp", { precision: 5, scale: 2 }).default("100.00").notNull(),
  currentRtp: decimal("currentRtp", { precision: 5, scale: 2 }).default("100.00").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const chatMessages = mysqlTable("chatMessages", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  userName: varchar("userName", { length: 255 }).notNull(),
  message: text("message").notNull(),
  isSystemMessage: boolean("isSystemMessage").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const onlinePlayers = mysqlTable("onlinePlayers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  userName: varchar("userName", { length: 255 }).notNull(),
  sessionId: varchar("sessionId", { length: 128 }).notNull(),
  lastHeartbeat: timestamp("lastHeartbeat").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const wagerFeed = mysqlTable("wagerFeed", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  userName: varchar("userName", { length: 255 }).notNull(),
  gameType: varchar("gameType", { length: 64 }).notNull(),
  betAmount: decimal("betAmount", { precision: 18, scale: 2 }).notNull(),
  multiplier: decimal("multiplier", { precision: 10, scale: 4 }).notNull(),
  payout: decimal("payout", { precision: 18, scale: 2 }).notNull(),
  result: mysqlEnum("result", ["win", "loss", "pending"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const sportsBets = mysqlTable("sportsBets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  eventId: varchar("eventId", { length: 128 }).notNull(),
  sport: varchar("sport", { length: 64 }).notNull(),
  eventName: text("eventName"),
  selection: text("selection").notNull(),
  odds: decimal("odds", { precision: 10, scale: 2 }).notNull(),
  betAmount: decimal("betAmount", { precision: 18, scale: 2 }).notNull(),
  potentialPayout: decimal("potentialPayout", { precision: 18, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "won", "lost", "cancelled", "void"]).default("pending").notNull(),
  settledAt: timestamp("settledAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;
export type GameSession = typeof gameSessions.$inferSelect;
export type InsertGameSession = typeof gameSessions.$inferInsert;
export type SportsBet = typeof sportsBets.$inferSelect;
export type InsertSportsBet = typeof sportsBets.$inferInsert;
export type WithdrawalRequest = typeof withdrawalRequests.$inferSelect;
export type InsertWithdrawalRequest = typeof withdrawalRequests.$inferInsert;
export type BonusCode = typeof bonusCodes.$inferSelect;
export type InsertBonusCode = typeof bonusCodes.$inferInsert;
export type BonusCodeUsage = typeof bonusCodeUsage.$inferSelect;
export type InsertBonusCodeUsage = typeof bonusCodeUsage.$inferInsert;
export type Affiliate = typeof affiliates.$inferSelect;
export type InsertAffiliate = typeof affiliates.$inferInsert;
export type SupportTicket = typeof supportTickets.$inferSelect;
export type InsertSupportTicket = typeof supportTickets.$inferInsert;
export type RtpSetting = typeof rtpSettings.$inferSelect;
export type InsertRtpSetting = typeof rtpSettings.$inferInsert;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = typeof chatMessages.$inferInsert;
export type OnlinePlayer = typeof onlinePlayers.$inferSelect;
export type InsertOnlinePlayer = typeof onlinePlayers.$inferInsert;
export type WagerFeed = typeof wagerFeed.$inferSelect;
export type InsertWagerFeed = typeof wagerFeed.$inferInsert;
