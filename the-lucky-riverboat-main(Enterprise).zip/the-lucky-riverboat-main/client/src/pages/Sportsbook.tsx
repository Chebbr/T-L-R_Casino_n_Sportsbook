import CasinoLayout from "@/components/CasinoLayout";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { Trophy, Clock, Zap, RefreshCw } from "lucide-react";

const sportFilters = ["All", "Football", "Basketball", "Hockey", "Baseball", "Soccer"];

export default function Sportsbook() {
  const { user, isAuthenticated, loading } = useAuth();
  const [selectedSport, setSelectedSport] = useState("All");
  const [betSlip, setBetSlip] = useState<{ eventId: string; eventName: string; selection: string; odds: number } | null>(null);
  const [betAmount, setBetAmount] = useState("10");

  const eventsQuery = trpc.sportsbook.getEvents.useQuery(undefined, {
    refetchInterval: 30000,
  });
  const balanceQuery = trpc.wallet.getBalance.useQuery(undefined, { enabled: isAuthenticated });
  const placeBetMutation = trpc.sportsbook.placeBet.useMutation({
    onSuccess: (data) => {
      toast.success(`Bet placed! Potential payout: $${data.potentialPayout.toFixed(2)}`);
      setBetSlip(null);
      setBetAmount("10");
      balanceQuery.refetch();
    },
    onError: (err) => toast.error(err.message),
  });

  const filteredEvents = useMemo(() => {
    const events = eventsQuery.data || [];
    if (selectedSport === "All") return events;
    return events.filter((e: any) => e.sport === selectedSport);
  }, [eventsQuery.data, selectedSport]);

  const liveEvents = filteredEvents.filter((e: any) => e.status === "live");
  const upcomingEvents = filteredEvents.filter((e: any) => e.status === "upcoming");

  const addToBetSlip = (eventId: string, eventName: string, selection: string, odds: number) => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl("/sportsbook");
      return;
    }
    setBetSlip({ eventId, eventName, selection, odds });
  };

  const handlePlaceBet = () => {
    if (!betSlip) return;
    const amount = parseFloat(betAmount);
    if (isNaN(amount) || amount < 0.1) {
      toast.error("Minimum bet is $0.10");
      return;
    }
    placeBetMutation.mutate({
      eventId: betSlip.eventId,
      sport: selectedSport === "All" ? "Mixed" : selectedSport,
      eventName: betSlip.eventName,
      selection: betSlip.selection,
      odds: betSlip.odds,
      betAmount: amount,
    });
  };

  return (
    <CasinoLayout>
      <div className="container py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold" style={{ fontFamily: "'Cinzel', serif" }}>
              <span className="text-gold">Sportsbook</span>
            </h1>
            <p className="text-muted-foreground mt-1">Live odds powered by ESPN</p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => eventsQuery.refetch()}
            disabled={eventsQuery.isFetching}
            className="gap-2"
          >
            <RefreshCw className={`h-4 w-4 ${eventsQuery.isFetching ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>

        {/* Sport Filters */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          {sportFilters.map((sport) => (
            <Button
              key={sport}
              variant={selectedSport === sport ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedSport(sport)}
              className={selectedSport === sport ? "bg-primary text-primary-foreground" : "border-border/50"}
            >
              {sport}
            </Button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Events List */}
          <div className="lg:col-span-2 space-y-8">
            {/* Live Events */}
            {liveEvents.length > 0 && (
              <div>
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <Zap className="h-5 w-5 text-red-500" />
                  <span className="text-red-400">Live Events</span>
                  <span className="ml-2 px-2 py-0.5 bg-red-500/20 text-red-400 text-xs rounded-full animate-pulse">
                    LIVE
                  </span>
                </h2>
                <div className="space-y-4">
                  {liveEvents.map((event: any) => (
                    <EventCard key={event.id} event={event} onBet={addToBetSlip} isLive />
                  ))}
                </div>
              </div>
            )}

            {/* Upcoming Events */}
            {upcomingEvents.length > 0 && (
              <div>
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  Upcoming Events
                </h2>
                <div className="space-y-4">
                  {upcomingEvents.map((event: any) => (
                    <EventCard key={event.id} event={event} onBet={addToBetSlip} />
                  ))}
                </div>
              </div>
            )}

            {filteredEvents.length === 0 && !eventsQuery.isLoading && (
              <Card className="border-border/50">
                <CardContent className="p-12 text-center">
                  <Trophy className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-bold mb-2">No Events Available</h3>
                  <p className="text-muted-foreground">
                    {selectedSport === "All"
                      ? "No live or upcoming events right now. Check back soon!"
                      : `No ${selectedSport} events available. Try another sport or check back later.`}
                  </p>
                </CardContent>
              </Card>
            )}

            {eventsQuery.isLoading && (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <Card key={i} className="border-border/50 animate-pulse">
                    <CardContent className="p-6">
                      <div className="h-6 bg-muted rounded w-1/3 mb-4" />
                      <div className="h-4 bg-muted rounded w-2/3 mb-2" />
                      <div className="h-4 bg-muted rounded w-1/2" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Bet Slip */}
          <div className="lg:col-span-1">
            <Card className="border-primary/30 sticky top-20">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-primary" />
                  Bet Slip
                </CardTitle>
              </CardHeader>
              <CardContent>
                <AnimatePresence mode="wait">
                  {betSlip ? (
                    <motion.div
                      key="bet"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="space-y-4"
                    >
                      <div className="p-3 rounded-lg bg-muted/50">
                        <p className="text-sm font-medium">{betSlip.eventName}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Selection: <span className="text-primary">{betSlip.selection}</span>
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Odds: <span className="text-primary font-bold">{betSlip.odds.toFixed(2)}</span>
                        </p>
                      </div>

                      <div>
                        <label className="text-sm text-muted-foreground mb-1 block">Bet Amount ($)</label>
                        <Input
                          type="number"
                          value={betAmount}
                          onChange={(e) => setBetAmount(e.target.value)}
                          min="0.1"
                          step="0.1"
                          className="bg-muted/50"
                        />
                      </div>

                      <div className="p-3 rounded-lg bg-muted/50">
                        <p className="text-sm text-muted-foreground">Potential Payout</p>
                        <p className="text-2xl font-bold text-green-500">
                          ${(parseFloat(betAmount || "0") * betSlip.odds).toFixed(2)}
                        </p>
                      </div>

                      {isAuthenticated && (
                        <p className="text-xs text-muted-foreground">
                          Balance: ${balanceQuery.data?.balance || "0.00"}
                        </p>
                      )}

                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          className="flex-1"
                          onClick={() => setBetSlip(null)}
                        >
                          Clear
                        </Button>
                        <Button
                          className="flex-1 bg-primary hover:bg-primary/90"
                          onClick={handlePlaceBet}
                          disabled={placeBetMutation.isPending}
                        >
                          {placeBetMutation.isPending ? "Placing..." : "Place Bet"}
                        </Button>
                      </div>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="empty"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="text-center py-8"
                    >
                      <p className="text-muted-foreground text-sm">
                        Click on odds to add to your bet slip
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </CasinoLayout>
  );
}

function EventCard({
  event,
  onBet,
  isLive,
}: {
  event: any;
  onBet: (eventId: string, eventName: string, selection: string, odds: number) => void;
  isLive?: boolean;
}) {
  const eventName = `${event.awayTeam} vs ${event.homeTeam}`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <Card className={`border-border/50 hover:border-primary/30 transition-colors ${isLive ? "border-red-500/30" : ""}`}>
        <CardContent className="p-4 md:p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <span className="text-xs px-2 py-0.5 rounded bg-muted text-muted-foreground font-medium">
                {event.league}
              </span>
              {isLive && (
                <span className="text-xs px-2 py-0.5 rounded bg-red-500/20 text-red-400 font-medium animate-pulse">
                  LIVE
                </span>
              )}
            </div>
            <span className="text-xs text-muted-foreground">
              {isLive ? event.statusDetail : new Date(event.eventDate).toLocaleString()}
            </span>
          </div>

          {/* Teams */}
          <div className="grid grid-cols-3 gap-4 items-center mb-4">
            <div className="text-center">
              {event.awayLogo && (
                <img src={event.awayLogo} alt={event.awayTeam} className="h-10 w-10 mx-auto mb-1 object-contain" />
              )}
              <p className="text-sm font-medium truncate">{event.awayTeam}</p>
              {isLive && <p className="text-2xl font-bold text-primary">{event.awayScore}</p>}
            </div>

            <div className="text-center">
              <p className="text-xs text-muted-foreground uppercase">vs</p>
            </div>

            <div className="text-center">
              {event.homeLogo && (
                <img src={event.homeLogo} alt={event.homeTeam} className="h-10 w-10 mx-auto mb-1 object-contain" />
              )}
              <p className="text-sm font-medium truncate">{event.homeTeam}</p>
              {isLive && <p className="text-2xl font-bold text-primary">{event.homeScore}</p>}
            </div>
          </div>

          {/* Odds Buttons */}
          <div className={`grid ${event.drawOdds ? "grid-cols-3" : "grid-cols-2"} gap-2`}>
            <Button
              variant="outline"
              className="flex flex-col py-3 h-auto border-border/50 hover:border-primary/50 hover:bg-primary/5"
              onClick={() => onBet(event.id, eventName, event.awayTeam, event.awayOdds)}
            >
              <span className="text-xs text-muted-foreground">{event.awayTeam.split(" ").pop()}</span>
              <span className="text-lg font-bold text-primary">{event.awayOdds.toFixed(2)}</span>
            </Button>

            {event.drawOdds && (
              <Button
                variant="outline"
                className="flex flex-col py-3 h-auto border-border/50 hover:border-primary/50 hover:bg-primary/5"
                onClick={() => onBet(event.id, eventName, "Draw", event.drawOdds)}
              >
                <span className="text-xs text-muted-foreground">Draw</span>
                <span className="text-lg font-bold text-primary">{event.drawOdds.toFixed(2)}</span>
              </Button>
            )}

            <Button
              variant="outline"
              className="flex flex-col py-3 h-auto border-border/50 hover:border-primary/50 hover:bg-primary/5"
              onClick={() => onBet(event.id, eventName, event.homeTeam, event.homeOdds)}
            >
              <span className="text-xs text-muted-foreground">{event.homeTeam.split(" ").pop()}</span>
              <span className="text-lg font-bold text-primary">{event.homeOdds.toFixed(2)}</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
