import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Film, Upload, Link as LinkIcon, Play } from "lucide-react";
import { toast } from "sonner";

export default function Studio() {
  const { user, isAuthenticated, loading } = useAuth();
  const [contentType, setContentType] = useState<"upload" | "link">("link");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [contentUrl, setContentUrl] = useState("");
  const [submitting, setSubmitting] = useState(false);

  if (!loading && !isAuthenticated) {
    window.location.href = getLoginUrl("/studio");
    return null;
  }

  const handleSubmit = async () => {
    if (!title.trim() || !contentUrl.trim()) {
      toast.error("Please fill in all fields");
      return;
    }

    setSubmitting(true);
    try {
      // In production, this would upload to S3 or save to database
      toast.success("Content submitted successfully!");
      setTitle("");
      setDescription("");
      setContentUrl("");
    } catch (err) {
      toast.error("Failed to submit content");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading || !user) {
    return (
      <CasinoLayout>
        <div className="container py-12">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-48" />
            <div className="h-96 bg-muted rounded-lg" />
          </div>
        </div>
      </CasinoLayout>
    );
  }

  return (
    <CasinoLayout>
      <div className="container py-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-3" style={{ fontFamily: "'Cinzel', serif" }}>
              <Film className="h-8 w-8 text-primary" />
              <span className="text-gold">Studio</span>
            </h1>
            <p className="text-muted-foreground">Share your gameplay videos and content with the community.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Content Upload Form */}
            <div className="lg:col-span-2">
              <Card className="border-primary/30">
                <CardHeader>
                  <CardTitle>Upload Gameplay Content</CardTitle>
                  <CardDescription>Share your best moments and strategies</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Content Type Selector */}
                  <div className="flex gap-4">
                    <button
                      onClick={() => setContentType("link")}
                      className={`flex-1 p-4 rounded-lg border-2 transition-all ${
                        contentType === "link"
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <LinkIcon className="h-5 w-5 mx-auto mb-2" />
                      <p className="text-sm font-medium">Paste Link</p>
                    </button>
                    <button
                      onClick={() => setContentType("upload")}
                      className={`flex-1 p-4 rounded-lg border-2 transition-all ${
                        contentType === "upload"
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <Upload className="h-5 w-5 mx-auto mb-2" />
                      <p className="text-sm font-medium">Upload File</p>
                    </button>
                  </div>

                  {/* Title */}
                  <div>
                    <label className="text-sm font-medium mb-2 block">Title</label>
                    <Input
                      placeholder="e.g., Epic Keno Winning Streak"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      disabled={submitting}
                    />
                  </div>

                  {/* Description */}
                  <div>
                    <label className="text-sm font-medium mb-2 block">Description</label>
                    <Textarea
                      placeholder="Describe your gameplay, strategy, or highlights..."
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      disabled={submitting}
                      rows={4}
                    />
                  </div>

                  {/* Content Input */}
                  <div>
                    <label className="text-sm font-medium mb-2 block">
                      {contentType === "link" ? "Video Link" : "Upload Video"}
                    </label>
                    {contentType === "link" ? (
                      <Input
                        placeholder="https://youtu.be/... or https://kick.com/..."
                        value={contentUrl}
                        onChange={(e) => setContentUrl(e.target.value)}
                        disabled={submitting}
                      />
                    ) : (
                      <div className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-primary/50 transition-colors">
                        <Upload className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                        <p className="text-sm text-muted-foreground">Click to upload or drag and drop</p>
                        <p className="text-xs text-muted-foreground mt-1">MP4, WebM up to 500MB</p>
                      </div>
                    )}
                  </div>

                  <Button
                    className="w-full bg-primary hover:bg-primary/90"
                    onClick={handleSubmit}
                    disabled={submitting}
                  >
                    {submitting ? "Uploading..." : "Submit Content"}
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Featured Content */}
            <div>
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-lg">Featured Content</CardTitle>
                  <CardDescription>Community highlights</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="group cursor-pointer">
                      <div className="relative mb-2 rounded-lg overflow-hidden bg-muted aspect-video flex items-center justify-center group-hover:bg-muted/80 transition-colors">
                        <Play className="h-8 w-8 text-muted-foreground group-hover:text-foreground transition-colors" />
                      </div>
                      <p className="text-sm font-medium truncate">Amazing Win #{i}</p>
                      <p className="text-xs text-muted-foreground">by Player {i}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </CasinoLayout>
  );
}
