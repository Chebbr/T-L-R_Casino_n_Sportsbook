import CasinoLayout from "@/components/CasinoLayout";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useEffect } from "react";
import { User, Mail, Calendar, Gamepad2, TrendingUp, Trophy } from "lucide-react";

export default function Profile() {
  const { user, isAuthenticated, loading } = useAuth();

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      window.location.href = getLoginUrl("/profile");
    }
  }, [loading, isAuthenticated]);

  const statsQuery = trpc.player.getStats.useQuery(undefined, { enabled: isAuthenticated });

  if (loading || !user) {
    return (
      <CasinoLayout>
        <div className="container py-12">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-48" />
            <div className="h-48 bg-muted rounded-lg" />
          </div>
        </div>
      </CasinoLayout>
    );
  }

  const stats = statsQuery.data;

  return (
    <CasinoLayout>
      <div className="container py-8 max-w-3xl">
        <h1 className="text-3xl font-bold mb-8" style={{ fontFamily: "'Cinzel', serif" }}>
          <span className="text-gold">Profile</span>
        </h1>

        {/* User Info */}
        <Card className="border-primary/30 mb-8">
          <CardContent className="p-8">
            <div className="flex items-center gap-6">
              <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center">
                <span className="text-3xl font-bold text-primary">
                  {user.name?.charAt(0)?.toUpperCase() || "U"}
                </span>
              </div>
              <div>
                <h2 className="text-2xl font-bold">{user.name || "Player"}</h2>
                {user.email && (
                  <p className="text-muted-foreground flex items-center gap-2 mt-1">
                    <Mail className="h-4 w-4" />
                    {user.email}
                  </p>
                )}
                <p className="text-muted-foreground flex items-center gap-2 mt-1">
                  <Calendar className="h-4 w-4" />
                  Member since {new Date(user.createdAt).toLocaleDateString()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <Card className="border-border/50">
            <CardContent className="p-6 text-center">
              <Gamepad2 className="h-6 w-6 text-primary mx-auto mb-2" />
              <p className="text-2xl font-bold">{stats?.totalBets || 0}</p>
              <p className="text-sm text-muted-foreground">Games Played</p>
            </CardContent>
          </Card>
          <Card className="border-border/50">
            <CardContent className="p-6 text-center">
              <TrendingUp className="h-6 w-6 text-blue-400 mx-auto mb-2" />
              <p className="text-2xl font-bold">${Number(stats?.totalWagered || 0).toFixed(2)}</p>
              <p className="text-sm text-muted-foreground">Total Wagered</p>
            </CardContent>
          </Card>
          <Card className="border-border/50">
            <CardContent className="p-6 text-center">
              <Trophy className="h-6 w-6 text-amber-400 mx-auto mb-2" />
              <p className="text-2xl font-bold">${Number(stats?.biggestWin || 0).toFixed(2)}</p>
              <p className="text-sm text-muted-foreground">Biggest Win</p>
            </CardContent>
          </Card>
        </div>

        <div className="flex gap-4">
          <Button asChild className="bg-primary hover:bg-primary/90">
            <Link href="/dashboard">View Dashboard</Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/wallet">Manage Wallet</Link>
          </Button>
        </div>
      </div>
    </CasinoLayout>
  );
}
