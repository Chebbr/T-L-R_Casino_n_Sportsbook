import { useParams } from "wouter";
import { lazy, Suspense } from "react";

const KenoBoardGame = lazy(() => import("@/components/games/KenoBoardGame"));
const BeachedGame = lazy(() => import("@/components/games/BeachedGame"));
const RouletteGame = lazy(() => import("@/components/games/RouletteGame"));
const HelmGame = lazy(() => import("@/components/games/HelmGame"));
const WalkThePlankGame = lazy(() => import("@/components/games/WalkThePlankGame"));
const HiddenTreasureGame = lazy(() => import("@/components/games/HiddenTreasureGame"));
const HitideLowtideGame = lazy(() => import("@/components/games/HitideLowtideGame"));
const BlackjackGame = lazy(() => import("@/components/games/BlackjackGame"));
const PlinkoGame = lazy(() => import("@/components/games/PlinkoGame"));
const SlotsGame = lazy(() => import("@/components/games/SlotsGame"));
import CasinoLayout from "@/components/CasinoLayout";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const GAME_MAP: Record<string, { component: React.LazyExoticComponent<React.ComponentType>; title: string }> = {
  keno: { component: KenoBoardGame, title: "Riverboat Keno" },
  crash: { component: BeachedGame, title: "Beached" },
  roulette: { component: RouletteGame, title: "Roulette" },
  helm: { component: HelmGame, title: "Helm" },
  tower: { component: WalkThePlankGame, title: "Walk the Plank" },
  mines: { component: HiddenTreasureGame, title: "Hidden Treasure" },
  hilow: { component: HitideLowtideGame, title: "Hitide Lowtide" },
  blackjack: { component: BlackjackGame, title: "Blackjack" },
  plinko: { component: PlinkoGame, title: "Plinko" },
  slots: { component: SlotsGame, title: "Slots" },
};

function GameLoading() {
  return (
    <div className="container py-12 text-center">
      <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
      <p className="text-muted-foreground">Loading game...</p>
    </div>
  );
}

export default function GamePage() {
  const params = useParams<{ gameId: string }>();
  const gameId = params.gameId || "";
  const game = GAME_MAP[gameId];

  if (!game) {
    return (
      <CasinoLayout>
        <div className="container py-16 text-center">
          <h1 className="text-3xl font-bold mb-4">Game Not Found</h1>
          <p className="text-muted-foreground mb-6">The game you're looking for doesn't exist.</p>
          <Button asChild>
            <Link href="/">Back to Home</Link>
          </Button>
        </div>
      </CasinoLayout>
    );
  }

  const GameComponent = game.component;

  return (
    <Suspense fallback={<CasinoLayout><GameLoading /></CasinoLayout>}>
      <GameComponent />
    </Suspense>
  );
}
