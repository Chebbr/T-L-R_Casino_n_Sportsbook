import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import CasinoLayout from "@/components/CasinoLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LifeBuoy, Send, CheckCircle } from "lucide-react";
import { toast } from "sonner";

export default function Support() {
  const { user, isAuthenticated, loading } = useAuth();
  const [category, setCategory] = useState("general");
  const [subject, setSubject] = useState("");
  const [description, setDescription] = useState("");
  const [submitted, setSubmitted] = useState(false);

  if (!loading && !isAuthenticated) {
    window.location.href = getLoginUrl("/support");
    return null;
  }

  const createTicketMutation = trpc.support.createTicket.useMutation({
    onSuccess: () => {
      toast.success("Support ticket created successfully!");
      setSubmitted(true);
      setSubject("");
      setDescription("");
      setTimeout(() => setSubmitted(false), 3000);
    },
    onError: (err) => toast.error(err.message),
  });

  const getMyTicketsQuery = trpc.support.getMyTickets.useQuery(undefined, { enabled: isAuthenticated });

  const handleSubmit = () => {
    if (!subject.trim() || !description.trim()) {
      toast.error("Please fill in all fields");
      return;
    }
    createTicketMutation.mutate({ category, subject, description });
  };

  if (loading || !user) {
    return (
      <CasinoLayout>
        <div className="container py-12">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-48" />
            <div className="h-96 bg-muted rounded-lg" />
          </div>
        </div>
      </CasinoLayout>
    );
  }

  return (
    <CasinoLayout>
      <div className="container py-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-3" style={{ fontFamily: "'Cinzel', serif" }}>
              <LifeBuoy className="h-8 w-8 text-primary" />
              <span className="text-gold">Support</span>
            </h1>
            <p className="text-muted-foreground">Need help? Submit a support ticket and our team will get back to you shortly.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Create Ticket Form */}
            <div className="lg:col-span-2">
              <Card className="border-primary/30">
                <CardHeader>
                  <CardTitle>Create a Support Ticket</CardTitle>
                  <CardDescription>Tell us what you need help with</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Category</label>
                    <Select value={category} onValueChange={setCategory}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">General Inquiry</SelectItem>
                        <SelectItem value="payment">Payment Issue</SelectItem>
                        <SelectItem value="withdrawal">Withdrawal Problem</SelectItem>
                        <SelectItem value="account">Account Issue</SelectItem>
                        <SelectItem value="game">Game Problem</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Subject</label>
                    <Input
                      placeholder="Brief description of your issue"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      disabled={createTicketMutation.isPending}
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Description</label>
                    <Textarea
                      placeholder="Please provide detailed information about your issue..."
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      disabled={createTicketMutation.isPending}
                      rows={6}
                    />
                  </div>

                  <Button
                    className="w-full bg-primary hover:bg-primary/90"
                    onClick={handleSubmit}
                    disabled={createTicketMutation.isPending}
                  >
                    {createTicketMutation.isPending ? (
                      "Submitting..."
                    ) : (
                      <>
                        <Send className="h-4 w-4 mr-2" />
                        Submit Ticket
                      </>
                    )}
                  </Button>

                  {submitted && (
                    <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/30 flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <p className="text-sm text-green-500">Ticket submitted successfully!</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Ticket History */}
            <div>
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-lg">Your Tickets</CardTitle>
                  <CardDescription>Recent support requests</CardDescription>
                </CardHeader>
                <CardContent>
                  {getMyTicketsQuery.data && getMyTicketsQuery.data.length > 0 ? (
                    <div className="space-y-3">
                      {getMyTicketsQuery.data.slice(0, 5).map((ticket: any) => (
                        <div key={ticket.id} className="p-3 rounded-lg bg-muted/50 border border-border/50">
                          <p className="text-sm font-medium truncate">{ticket.subject}</p>
                          <div className="flex items-center gap-2 mt-2">
                            <span className={`text-xs px-2 py-1 rounded ${
                              ticket.status === "open" ? "bg-yellow-500/20 text-yellow-600" :
                              ticket.status === "in-progress" ? "bg-blue-500/20 text-blue-600" :
                              "bg-green-500/20 text-green-600"
                            }`}>
                              {ticket.status}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              {new Date(ticket.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6">
                      <LifeBuoy className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">No support tickets yet</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </CasinoLayout>
  );
}
