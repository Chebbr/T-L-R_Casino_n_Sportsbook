import CasinoLayout from "@/components/CasinoLayout";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { Wallet as WalletIcon, Bitcoin, CreditCard, Copy, Check, ArrowUpRight, ArrowDownLeft } from "lucide-react";

const BTC_ADDRESS = "bc1qele3fkgum6k2p0lny8zsp7evsyy2s5dj4eau82";
const ETH_ADDRESS = "0xbe5dC0679845123d870695E98F20934992B8b7f5";

type DepositMethod = "btc" | "eth" | "stripe" | null;

export default function Wallet() {
  const { user, isAuthenticated, loading } = useAuth();
  const [selectedMethod, setSelectedMethod] = useState<DepositMethod>(null);
  const [depositAmount, setDepositAmount] = useState("25");
  const [copiedAddress, setCopiedAddress] = useState(false);

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      window.location.href = getLoginUrl("/wallet");
    }
  }, [loading, isAuthenticated]);

  const balanceQuery = trpc.wallet.getBalance.useQuery(undefined, { enabled: isAuthenticated });
  const transactionsQuery = trpc.wallet.getTransactions.useQuery({ limit: 20 }, { enabled: isAuthenticated });
  const depositMutation = trpc.wallet.deposit.useMutation({
    onSuccess: () => {
      toast.success("Deposit recorded successfully!");
      balanceQuery.refetch();
      transactionsQuery.refetch();
      setSelectedMethod(null);
    },
    onError: (err) => toast.error(err.message),
  });

  const copyAddress = (address: string) => {
    navigator.clipboard.writeText(address);
    setCopiedAddress(true);
    toast.success("Address copied to clipboard!");
    setTimeout(() => setCopiedAddress(false), 2000);
  };

  const [stripeLoading, setStripeLoading] = useState(false);

  // Check for deposit success/cancel from URL params
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("deposit") === "success") {
      toast.success(`Deposit successful! Your balance will be updated shortly.`);
      balanceQuery.refetch();
      transactionsQuery.refetch();
      window.history.replaceState({}, "", "/wallet");
    } else if (params.get("deposit") === "cancelled") {
      toast.error("Deposit cancelled.");
      window.history.replaceState({}, "", "/wallet");
    }
  }, []);

  const handleStripeDeposit = async () => {
    const amount = parseFloat(depositAmount);
    if (isNaN(amount) || amount < 5) {
      toast.error("Minimum deposit is $5.00");
      return;
    }
    if (amount > 500) {
      toast.error("Maximum deposit is $500.00");
      return;
    }
    setStripeLoading(true);
    try {
      const res = await fetch("/api/stripe/create-checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount,
          userId: user?.id,
          userEmail: user?.email,
          userName: user?.name,
        }),
      });
      const data = await res.json();
      if (data.url) {
        toast.info("Redirecting to Stripe checkout...");
        window.open(data.url, "_blank");
      } else {
        toast.error(data.error || "Failed to create checkout session");
      }
    } catch (err) {
      toast.error("Failed to connect to payment processor");
    } finally {
      setStripeLoading(false);
    }
  };

  const handleCryptoDeposit = (method: "btc" | "eth") => {
    const amount = parseFloat(depositAmount);
    if (isNaN(amount) || amount < 5) {
      toast.error("Minimum deposit is $5.00");
      return;
    }
    depositMutation.mutate({
      amount,
      method,
    });
  };

  if (loading || !user) {
    return (
      <CasinoLayout>
        <div className="container py-12">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-48" />
            <div className="h-48 bg-muted rounded-lg" />
          </div>
        </div>
      </CasinoLayout>
    );
  }

  return (
    <CasinoLayout>
      <div className="container py-8">
        <h1 className="text-3xl font-bold mb-2" style={{ fontFamily: "'Cinzel', serif" }}>
          <span className="text-gold">Wallet</span>
        </h1>
        <p className="text-muted-foreground mb-8">Manage your deposits and withdrawals</p>

        {/* Balance Card */}
        <Card className="border-primary/30 mb-8 glow-gold-sm">
          <CardContent className="p-8">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Available Balance</p>
                <p className="text-4xl font-bold text-primary">
                  ${balanceQuery.data?.balance || "0.00"}
                </p>
              </div>
              <WalletIcon className="h-12 w-12 text-primary/30" />
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Deposit Methods */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold">Deposit Methods</h2>

            {/* Deposit Amount */}
            <Card className="border-border/50">
              <CardContent className="p-6">
                <label className="text-sm text-muted-foreground mb-2 block">Deposit Amount (USD)</label>
                <Input
                  type="number"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  min="5"
                  max="500"
                  step="1"
                  className="bg-muted/50 text-lg"
                  placeholder="Enter amount ($5 - $500)"
                />
                <div className="flex gap-2 mt-3">
                  {[10, 25, 50, 100, 250, 500].map((amt) => (
                    <Button
                      key={amt}
                      variant="outline"
                      size="sm"
                      onClick={() => setDepositAmount(amt.toString())}
                      className={`flex-1 ${depositAmount === amt.toString() ? "border-primary text-primary" : "border-border/50"}`}
                    >
                      ${amt}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Bitcoin */}
            <Card
              className={`border-border/50 cursor-pointer transition-all hover:border-amber-500/50 ${selectedMethod === "btc" ? "border-amber-500 bg-amber-500/5" : ""}`}
              onClick={() => setSelectedMethod(selectedMethod === "btc" ? null : "btc")}
            >
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-amber-500/10 flex items-center justify-center">
                    <Bitcoin className="h-6 w-6 text-amber-500" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold">Bitcoin (BTC)</h3>
                    <p className="text-sm text-muted-foreground">Send BTC to deposit</p>
                  </div>
                </div>

                <AnimatePresence>
                  {selectedMethod === "btc" && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="mt-4 pt-4 border-t border-border/50">
                        <p className="text-sm text-muted-foreground mb-2">Send BTC to this address:</p>
                        <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50">
                          <code className="text-xs flex-1 break-all text-amber-400">{BTC_ADDRESS}</code>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => { e.stopPropagation(); copyAddress(BTC_ADDRESS); }}
                          >
                            {copiedAddress ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground mt-2">
                          After sending, click below to record your deposit. Deposits are credited after confirmation.
                        </p>
                        <Button
                          className="w-full mt-3 bg-amber-600 hover:bg-amber-700"
                          onClick={(e) => { e.stopPropagation(); handleCryptoDeposit("btc"); }}
                          disabled={depositMutation.isPending}
                        >
                          {depositMutation.isPending ? "Processing..." : `I've Sent $${depositAmount} in BTC`}
                        </Button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>

            {/* Ethereum */}
            <Card
              className={`border-border/50 cursor-pointer transition-all hover:border-blue-500/50 ${selectedMethod === "eth" ? "border-blue-500 bg-blue-500/5" : ""}`}
              onClick={() => setSelectedMethod(selectedMethod === "eth" ? null : "eth")}
            >
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-blue-500/10 flex items-center justify-center">
                    <svg className="h-6 w-6 text-blue-400" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M11.944 17.97L4.58 13.62 11.943 24l7.37-10.38-7.372 4.35h.003zM12.056 0L4.69 12.223l7.365 4.354 7.365-4.35L12.056 0z" />
                    </svg>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold">Ethereum (ETH)</h3>
                    <p className="text-sm text-muted-foreground">Send ETH to deposit</p>
                  </div>
                </div>

                <AnimatePresence>
                  {selectedMethod === "eth" && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="mt-4 pt-4 border-t border-border/50">
                        <p className="text-sm text-muted-foreground mb-2">Send ETH to this address:</p>
                        <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50">
                          <code className="text-xs flex-1 break-all text-blue-400">{ETH_ADDRESS}</code>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => { e.stopPropagation(); copyAddress(ETH_ADDRESS); }}
                          >
                            {copiedAddress ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground mt-2">
                          After sending, click below to record your deposit. Deposits are credited after confirmation.
                        </p>
                        <Button
                          className="w-full mt-3 bg-blue-600 hover:bg-blue-700"
                          onClick={(e) => { e.stopPropagation(); handleCryptoDeposit("eth"); }}
                          disabled={depositMutation.isPending}
                        >
                          {depositMutation.isPending ? "Processing..." : `I've Sent $${depositAmount} in ETH`}
                        </Button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>

            {/* Debit Card (Stripe) */}
            <Card
              className={`border-border/50 cursor-pointer transition-all hover:border-green-500/50 ${selectedMethod === "stripe" ? "border-green-500 bg-green-500/5" : ""}`}
              onClick={() => setSelectedMethod(selectedMethod === "stripe" ? null : "stripe")}
            >
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-green-500/10 flex items-center justify-center">
                    <CreditCard className="h-6 w-6 text-green-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold">Debit Card</h3>
                    <p className="text-sm text-muted-foreground">$5 min - $500 max &bull; Powered by Stripe</p>
                  </div>
                </div>

                <AnimatePresence>
                  {selectedMethod === "stripe" && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="mt-4 pt-4 border-t border-border/50">
                        <p className="text-sm text-muted-foreground mb-3">
                          Deposit ${depositAmount} via debit card. Processed securely by Stripe.
                        </p>
                        <Button
                          className="w-full bg-green-600 hover:bg-green-700"
                          onClick={(e) => { e.stopPropagation(); handleStripeDeposit(); }}
                          disabled={stripeLoading}
                        >
                          {stripeLoading ? "Redirecting to Stripe..." : `Deposit $${depositAmount} with Debit Card`}
                        </Button>
                        <p className="text-xs text-muted-foreground mt-2 text-center">
                          Minimum: $5.00 &bull; Maximum: $500.00
                        </p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>
          </div>

          {/* Transaction History */}
          <div>
            <h2 className="text-xl font-bold mb-6">Transaction History</h2>
            <Card className="border-border/50">
              <CardContent className="p-6">
                {transactionsQuery.data && transactionsQuery.data.length > 0 ? (
                  <div className="space-y-3">
                    {transactionsQuery.data.map((tx: any) => (
                      <div key={tx.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                            tx.type === "deposit" ? "bg-green-500/10" : tx.type === "withdrawal" ? "bg-red-500/10" : "bg-primary/10"
                          }`}>
                            {tx.type === "deposit" ? (
                              <ArrowDownLeft className="h-4 w-4 text-green-500" />
                            ) : tx.type === "withdrawal" ? (
                              <ArrowUpRight className="h-4 w-4 text-red-400" />
                            ) : (
                              <WalletIcon className="h-4 w-4 text-primary" />
                            )}
                          </div>
                          <div>
                            <p className="text-sm font-medium capitalize">{tx.type}</p>
                            <p className="text-xs text-muted-foreground">
                              {tx.method?.toUpperCase()} &bull; {new Date(tx.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={`font-bold text-sm ${
                            tx.type === "deposit" || tx.type === "win" ? "text-green-500" : "text-red-400"
                          }`}>
                            {tx.type === "deposit" || tx.type === "win" ? "+" : "-"}${Number(tx.amount).toFixed(2)}
                          </p>
                          <p className={`text-xs ${
                            tx.status === "completed" ? "text-green-500" : tx.status === "pending" ? "text-amber-400" : "text-red-400"
                          }`}>
                            {tx.status}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <WalletIcon className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                    <p className="text-muted-foreground">No transactions yet</p>
                    <p className="text-sm text-muted-foreground mt-1">Make your first deposit to get started</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </CasinoLayout>
  );
}
