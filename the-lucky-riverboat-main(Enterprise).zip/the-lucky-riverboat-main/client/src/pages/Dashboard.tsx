import CasinoLayout from "@/components/CasinoLayout";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useEffect } from "react";
import { motion } from "framer-motion";
import { BarChart3, TrendingUp, Gamepad2, Trophy, Wallet, DollarSign } from "lucide-react";

export default function Dashboard() {
  const { user, isAuthenticated, loading } = useAuth();

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      window.location.href = getLoginUrl("/dashboard");
    }
  }, [loading, isAuthenticated]);

  const balanceQuery = trpc.wallet.getBalance.useQuery(undefined, { enabled: isAuthenticated });
  const statsQuery = trpc.player.getStats.useQuery(undefined, { enabled: isAuthenticated });
  const recentGamesQuery = trpc.player.getRecentGames.useQuery({ limit: 10 }, { enabled: isAuthenticated });
  const allStatsQuery = trpc.player.getAllStats.useQuery(undefined, { enabled: isAuthenticated });

  if (loading || !user) {
    return (
      <CasinoLayout>
        <div className="container py-12">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-48" />
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-32 bg-muted rounded-lg" />
              ))}
            </div>
          </div>
        </div>
      </CasinoLayout>
    );
  }

  const stats = statsQuery.data;
  const gameNameMap: Record<string, string> = {
    keno: "Riverboat Keno",
    beached: "Beached",
    roulette: "Roulette",
    helm: "Helm",
    "walk-the-plank": "Walk the Plank",
    "hidden-treasure": "Hidden Treasure",
    "hitide-lowtide": "Hitide Lowtide",
  };

  return (
    <CasinoLayout>
      <div className="container py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold" style={{ fontFamily: "'Cinzel', serif" }}>
              <span className="text-gold">Dashboard</span>
            </h1>
            <p className="text-muted-foreground mt-1">Welcome back, {user.name || "Player"}</p>
          </div>
          <Button asChild className="bg-primary hover:bg-primary/90">
            <Link href="/wallet">
              <Wallet className="h-4 w-4 mr-2" />
              Deposit
            </Link>
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            {
              icon: <DollarSign className="h-5 w-5" />,
              label: "Balance",
              value: `$${balanceQuery.data?.balance || "0.00"}`,
              color: "text-green-500",
            },
            {
              icon: <Gamepad2 className="h-5 w-5" />,
              label: "Games Played",
              value: stats?.totalBets || 0,
              color: "text-primary",
            },
            {
              icon: <TrendingUp className="h-5 w-5" />,
              label: "Total Wagered",
              value: `$${Number(stats?.totalWagered || 0).toFixed(2)}`,
              color: "text-blue-400",
            },
            {
              icon: <Trophy className="h-5 w-5" />,
              label: "Biggest Win",
              value: `$${Number(stats?.biggestWin || 0).toFixed(2)}`,
              color: "text-amber-400",
            },
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="border-border/50">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-2">
                    <div className={`${stat.color}`}>{stat.icon}</div>
                    <span className="text-sm text-muted-foreground">{stat.label}</span>
                  </div>
                  <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Games */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                Recent Games
              </CardTitle>
            </CardHeader>
            <CardContent>
              {recentGamesQuery.data && recentGamesQuery.data.length > 0 ? (
                <div className="space-y-3">
                  {recentGamesQuery.data.map((game: any, i: number) => (
                    <div
                      key={i}
                      className="flex items-center justify-between p-3 rounded-lg bg-muted/30"
                    >
                      <div>
                        <p className="font-medium text-sm">
                          {gameNameMap[game.gameType] || game.gameType}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Bet: ${Number(game.betAmount).toFixed(2)}
                        </p>
                      </div>
                      <div className="text-right">
                        <p
                          className={`font-bold text-sm ${
                            game.result === "win" ? "text-green-500" : "text-red-400"
                          }`}
                        >
                          {game.result === "win"
                            ? `+$${Number(game.payout).toFixed(2)}`
                            : `-$${Number(game.betAmount).toFixed(2)}`}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(game.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Gamepad2 className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground">No games played yet</p>
                  <Button asChild variant="outline" className="mt-4">
                    <Link href="/games/keno">Play Now</Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Game Stats */}
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-primary" />
                Game Statistics
              </CardTitle>
            </CardHeader>
            <CardContent>
              {allStatsQuery.data && allStatsQuery.data.length > 0 ? (
                <div className="space-y-3">
                  {allStatsQuery.data.map((stat: any, i: number) => (
                    <div
                      key={i}
                      className="flex items-center justify-between p-3 rounded-lg bg-muted/30"
                    >
                      <div>
                        <p className="font-medium text-sm">
                          {gameNameMap[stat.gameType] || stat.gameType}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {stat.totalBets} bets &bull; {stat.totalWins || 0} wins
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-bold text-primary">
                          ${Number(stat.totalWagered || 0).toFixed(2)}
                        </p>
                        <p className="text-xs text-muted-foreground">wagered</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <BarChart3 className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground">No statistics yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </CasinoLayout>
  );
}
