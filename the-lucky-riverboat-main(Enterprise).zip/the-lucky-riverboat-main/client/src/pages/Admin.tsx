import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertCircle, Users, TrendingUp, DollarSign, Zap, Gift, Users2, LifeBuoy } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Admin() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("overview");

  // Redirect non-admins
  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <AlertCircle className="h-5 w-5" />
              Access Denied
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">You don't have permission to access the admin dashboard.</p>
            <Button onClick={() => setLocation("/")} className="w-full">
              Return to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b border-border/50 bg-background/95 backdrop-blur-md sticky top-0 z-40">
        <div className="container py-4">
          <h1 className="text-3xl font-bold text-gold">Admin Dashboard</h1>
          <p className="text-sm text-muted-foreground">Manage platform, users, games, and operations</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="rtp">RTP</TabsTrigger>
            <TabsTrigger value="withdrawals">Withdrawals</TabsTrigger>
            <TabsTrigger value="bonuses">Bonuses</TabsTrigger>
            <TabsTrigger value="vip">VIP</TabsTrigger>
            <TabsTrigger value="affiliates">Affiliates</TabsTrigger>
            <TabsTrigger value="support">Support</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Users className="h-4 w-4" /> Total Users
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">1,234</div>
                  <p className="text-xs text-muted-foreground">+12 this week</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <DollarSign className="h-4 w-4" /> Total Wagered
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">$456,789</div>
                  <p className="text-xs text-muted-foreground">+$45,000 this week</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <TrendingUp className="h-4 w-4" /> House Edge
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">2.5%</div>
                  <p className="text-xs text-muted-foreground">Platform average</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Zap className="h-4 w-4" /> Active Sessions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">87</div>
                  <p className="text-xs text-muted-foreground">Players online now</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>User Management</CardTitle>
                <CardDescription>Search, edit, and manage user accounts</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input placeholder="Search by username or email..." className="flex-1" />
                  <Button>Search</Button>
                </div>

                <div className="border border-border rounded-lg overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-muted/50 border-b border-border">
                      <tr>
                        <th className="px-4 py-2 text-left">User</th>
                        <th className="px-4 py-2 text-left">Email</th>
                        <th className="px-4 py-2 text-right">Balance</th>
                        <th className="px-4 py-2 text-left">VIP</th>
                        <th className="px-4 py-2 text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[1, 2, 3, 4, 5].map((i) => (
                        <tr key={i} className="border-b border-border hover:bg-muted/50">
                          <td className="px-4 py-2">User #{i}</td>
                          <td className="px-4 py-2">user{i}@example.com</td>
                          <td className="px-4 py-2 text-right font-mono">$1,234.56</td>
                          <td className="px-4 py-2">
                            <span className="text-xs bg-gold/20 text-gold px-2 py-1 rounded">Gold</span>
                          </td>
                          <td className="px-4 py-2 text-center">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button variant="outline" size="sm">Edit</Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Edit User</DialogTitle>
                                  <DialogDescription>Modify user account details</DialogDescription>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <div>
                                    <Label>Balance</Label>
                                    <Input type="number" placeholder="1234.56" defaultValue="1234.56" />
                                  </div>
                                  <div>
                                    <Label>VIP Level</Label>
                                    <Select defaultValue="gold">
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="bronze">Bronze</SelectItem>
                                        <SelectItem value="silver">Silver</SelectItem>
                                        <SelectItem value="gold">Gold</SelectItem>
                                        <SelectItem value="platinum">Platinum</SelectItem>
                                        <SelectItem value="diamond">Diamond</SelectItem>
                                        <SelectItem value="elite">Elite</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>
                                  <Button className="w-full">Save Changes</Button>
                                </div>
                              </DialogContent>
                            </Dialog>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* RTP Tab */}
          <TabsContent value="rtp" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>RTP Management</CardTitle>
                <CardDescription>Adjust Return to Player percentages for each game</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {["keno", "beached", "roulette", "helm", "walk-the-plank", "hidden-treasure", "hitide-lowtide"].map((game) => (
                  <div key={game} className="flex items-center justify-between p-3 border border-border rounded-lg">
                    <div>
                      <p className="font-medium capitalize">{game.replace("-", " ")}</p>
                      <p className="text-xs text-muted-foreground">Base RTP: 100%</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Input type="number" placeholder="100" defaultValue="100" className="w-20" />
                      <span className="text-sm">%</span>
                      <Button size="sm">Update</Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Withdrawals Tab */}
          <TabsContent value="withdrawals" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Pending Withdrawals</CardTitle>
                <CardDescription>Review and approve/reject withdrawal requests</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border border-border rounded-lg overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-muted/50 border-b border-border">
                      <tr>
                        <th className="px-4 py-2 text-left">User</th>
                        <th className="px-4 py-2 text-right">Amount</th>
                        <th className="px-4 py-2 text-left">Method</th>
                        <th className="px-4 py-2 text-left">Date</th>
                        <th className="px-4 py-2 text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[1, 2, 3].map((i) => (
                        <tr key={i} className="border-b border-border hover:bg-muted/50">
                          <td className="px-4 py-2">User #{i}</td>
                          <td className="px-4 py-2 text-right font-mono">$500.00</td>
                          <td className="px-4 py-2">BTC</td>
                          <td className="px-4 py-2 text-xs text-muted-foreground">2 hours ago</td>
                          <td className="px-4 py-2 text-center space-x-2">
                            <Button size="sm" variant="outline" className="text-green-500 hover:bg-green-500/10">Approve</Button>
                            <Button size="sm" variant="outline" className="text-destructive hover:bg-destructive/10">Reject</Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Bonuses Tab */}
          <TabsContent value="bonuses" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gift className="h-5 w-5" /> Bonus Code Management
                </CardTitle>
                <CardDescription>Create and manage promotional bonus codes</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button>Create New Bonus Code</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Create Bonus Code</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label>Code</Label>
                        <Input placeholder="WELCOME50" />
                      </div>
                      <div>
                        <Label>Bonus Amount ($)</Label>
                        <Input type="number" placeholder="50" />
                      </div>
                      <div>
                        <Label>Wagering Requirement (x)</Label>
                        <Input type="number" placeholder="5" />
                      </div>
                      <div>
                        <Label>Max Uses</Label>
                        <Input type="number" placeholder="100" />
                      </div>
                      <Button className="w-full">Create Code</Button>
                    </div>
                  </DialogContent>
                </Dialog>

                <div className="border border-border rounded-lg overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-muted/50 border-b border-border">
                      <tr>
                        <th className="px-4 py-2 text-left">Code</th>
                        <th className="px-4 py-2 text-right">Bonus</th>
                        <th className="px-4 py-2 text-right">Uses</th>
                        <th className="px-4 py-2 text-left">Status</th>
                        <th className="px-4 py-2 text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {["WELCOME50", "RELOAD25", "VIP100"].map((code) => (
                        <tr key={code} className="border-b border-border hover:bg-muted/50">
                          <td className="px-4 py-2 font-mono">{code}</td>
                          <td className="px-4 py-2 text-right">${code === "WELCOME50" ? "50" : code === "RELOAD25" ? "25" : "100"}</td>
                          <td className="px-4 py-2 text-right">45/100</td>
                          <td className="px-4 py-2">
                            <span className="text-xs bg-green-500/20 text-green-500 px-2 py-1 rounded">Active</span>
                          </td>
                          <td className="px-4 py-2 text-center">
                            <Button size="sm" variant="outline">Edit</Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* VIP Tab */}
          <TabsContent value="vip" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>VIP Tier Management</CardTitle>
                <CardDescription>Configure VIP benefits and requirements</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {["bronze", "silver", "gold", "platinum", "diamond", "elite"].map((tier) => (
                  <div key={tier} className="p-4 border border-border rounded-lg space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="font-medium capitalize">{tier}</h3>
                      <Button size="sm" variant="outline">Configure</Button>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div>
                        <p className="text-muted-foreground">Deposit Bonus</p>
                        <p className="font-mono">10%</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Cashback</p>
                        <p className="font-mono">2%</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Withdrawal Limit</p>
                        <p className="font-mono">$10,000/day</p>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Affiliates Tab */}
          <TabsContent value="affiliates" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users2 className="h-5 w-5" /> Affiliate Management
                </CardTitle>
                <CardDescription>Manage affiliate programs and commissions</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border border-border rounded-lg overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-muted/50 border-b border-border">
                      <tr>
                        <th className="px-4 py-2 text-left">Affiliate</th>
                        <th className="px-4 py-2 text-right">Commission Rate</th>
                        <th className="px-4 py-2 text-right">Referrals</th>
                        <th className="px-4 py-2 text-right">Earnings</th>
                        <th className="px-4 py-2 text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[1, 2, 3].map((i) => (
                        <tr key={i} className="border-b border-border hover:bg-muted/50">
                          <td className="px-4 py-2">Affiliate #{i}</td>
                          <td className="px-4 py-2 text-right">5%</td>
                          <td className="px-4 py-2 text-right">{i * 12}</td>
                          <td className="px-4 py-2 text-right font-mono">${i * 500}.00</td>
                          <td className="px-4 py-2 text-center">
                            <Button size="sm" variant="outline">Edit</Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Support Tab */}
          <TabsContent value="support" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LifeBuoy className="h-5 w-5" /> Support Tickets
                </CardTitle>
                <CardDescription>Manage customer support requests</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border border-border rounded-lg overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-muted/50 border-b border-border">
                      <tr>
                        <th className="px-4 py-2 text-left">Ticket ID</th>
                        <th className="px-4 py-2 text-left">User</th>
                        <th className="px-4 py-2 text-left">Subject</th>
                        <th className="px-4 py-2 text-left">Status</th>
                        <th className="px-4 py-2 text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[1, 2, 3].map((i) => (
                        <tr key={i} className="border-b border-border hover:bg-muted/50">
                          <td className="px-4 py-2 font-mono">#TKT{i}001</td>
                          <td className="px-4 py-2">User #{i}</td>
                          <td className="px-4 py-2">Withdrawal issue</td>
                          <td className="px-4 py-2">
                            <span className="text-xs bg-yellow-500/20 text-yellow-600 px-2 py-1 rounded">Open</span>
                          </td>
                          <td className="px-4 py-2 text-center">
                            <Button size="sm" variant="outline">View</Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
