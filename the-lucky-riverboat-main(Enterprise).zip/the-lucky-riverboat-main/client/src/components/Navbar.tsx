import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Link, useLocation } from "wouter";
import { useState } from "react";
import { Menu, X, ChevronDown, Wallet, LayoutDashboard, Trophy, Home as HomeIcon, Gamepad2 } from "lucide-react";

const LOGO_URL = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663338939905/sZTAlCtTfzcSKFDx.jpg";

const GAMES = [
  { id: "keno", name: "Riverboat Keno", emoji: "🎱" },
  { id: "beached", name: "Beached", emoji: "🚀" },
  { id: "roulette", name: "Roulette", emoji: "🎰" },
  { id: "helm", name: "Helm", emoji: "🎡" },
  { id: "walk-the-plank", name: "Walk the Plank", emoji: "🏴‍☠️" },
  { id: "hidden-treasure", name: "Hidden Treasure", emoji: "💎" },
  { id: "hitide-lowtide", name: "Hitide Lowtide", emoji: "🃏" },
];

export default function Navbar() {
  const { user, isAuthenticated } = useAuth();
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [gamesOpen, setGamesOpen] = useState(false);

  const navLinks = [
    { href: "/", label: "Home", icon: HomeIcon },
    { href: "/sportsbook", label: "Sportsbook", icon: Trophy },
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/wallet", label: "Wallet", icon: Wallet },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/90 backdrop-blur-md border-b border-border">
      <div className="container flex items-center justify-between h-16">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 shrink-0">
          <img src={LOGO_URL} alt="The Lucky Riverboat" className="w-10 h-10 rounded-lg object-cover" />
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-1">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                location === link.href
                  ? "text-primary bg-primary/10"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary"
              }`}
            >
              {link.label}
            </Link>
          ))}

          {/* Games Dropdown */}
          <div className="relative" onMouseEnter={() => setGamesOpen(true)} onMouseLeave={() => setGamesOpen(false)}>
            <button
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1 ${
                location.startsWith("/games")
                  ? "text-primary bg-primary/10"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary"
              }`}
            >
              <Gamepad2 className="w-4 h-4" />
              Games
              <ChevronDown className={`w-3 h-3 transition-transform ${gamesOpen ? "rotate-180" : ""}`} />
            </button>
            {gamesOpen && (
              <div className="absolute top-full left-0 mt-1 w-56 bg-card border border-border rounded-xl shadow-xl py-2 animate-in fade-in slide-in-from-top-2 duration-200">
                {GAMES.map((game) => (
                  <Link
                    key={game.id}
                    href={`/games/${game.id}`}
                    className="flex items-center gap-3 px-4 py-2.5 text-sm text-card-foreground hover:bg-secondary transition-colors"
                    onClick={() => setGamesOpen(false)}
                  >
                    <span className="text-lg">{game.emoji}</span>
                    <span>{game.name}</span>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Auth / User */}
        <div className="flex items-center gap-3">
          {isAuthenticated && user ? (
            <Link href="/dashboard" className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors">
              <div className="w-7 h-7 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-xs font-bold">
                {user.name?.charAt(0) || "U"}
              </div>
              <span className="text-sm font-medium hidden sm:inline">{user.name || "Player"}</span>
            </Link>
          ) : (
            <a
              href={getLoginUrl("/")}
              className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition-colors"
            >
              Sign In
            </a>
          )}

          {/* Mobile menu toggle */}
          <button
            className="md:hidden p-2 rounded-lg hover:bg-secondary transition-colors"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      {mobileOpen && (
        <div className="md:hidden border-t border-border bg-background/95 backdrop-blur-md animate-in slide-in-from-top-2 duration-200">
          <div className="container py-4 space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  location === link.href
                    ? "text-primary bg-primary/10"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                }`}
                onClick={() => setMobileOpen(false)}
              >
                <link.icon className="w-4 h-4" />
                {link.label}
              </Link>
            ))}
            <div className="pt-2 border-t border-border mt-2">
              <p className="px-4 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Games</p>
              {GAMES.map((game) => (
                <Link
                  key={game.id}
                  href={`/games/${game.id}`}
                  className="flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm text-foreground hover:bg-secondary transition-colors"
                  onClick={() => setMobileOpen(false)}
                >
                  <span>{game.emoji}</span>
                  <span>{game.name}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
