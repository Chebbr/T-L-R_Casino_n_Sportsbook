import { useEffect, useRef, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageCircle, X, Users } from "lucide-react";
import { io, Socket } from "socket.io-client";
import { toast } from "sonner";

interface ChatMessage {
  userId: number;
  userName: string;
  message: string;
  timestamp?: Date;
  isSystemMessage?: boolean;
}

interface OnlinePlayer {
  userName: string;
  count: number;
}

export default function ChatOverlay() {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [onlinePlayers, setOnlinePlayers] = useState<OnlinePlayer>({ userName: "", count: 0 });
  const [messageInput, setMessageInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const socketRef = useRef<Socket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize Socket.IO connection
  useEffect(() => {
    if (!user) return;

    const socket = io(window.location.origin, {
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      reconnectionAttempts: 5,
    });

    socketRef.current = socket;

    socket.on("connect", () => {
      console.log("[Chat] Connected to server");
      // Join chat room
      socket.emit("join", {
        userId: user.id,
        userName: user.name || `User ${user.id}`,
      });
    });

    socket.on("chat_history", (history: ChatMessage[]) => {
      setMessages(history);
    });

    socket.on("new_message", (message: ChatMessage) => {
      setMessages((prev) => [...prev, message]);
    });

    socket.on("user_joined", (data: { userName: string; onlineCount: number; message: string }) => {
      setMessages((prev) => [
        ...prev,
        {
          userId: 0,
          userName: "System",
          message: data.message,
          isSystemMessage: true,
        },
      ]);
      setOnlinePlayers({ ...onlinePlayers, count: data.onlineCount });
    });

    socket.on("user_left", (data: { userName: string; onlineCount: number; message: string }) => {
      setMessages((prev) => [
        ...prev,
        {
          userId: 0,
          userName: "System",
          message: data.message,
          isSystemMessage: true,
        },
      ]);
      setOnlinePlayers({ ...onlinePlayers, count: data.onlineCount });
    });

    socket.on("online_players", (data: { count: number; players: string[] }) => {
      setOnlinePlayers({ count: data.count, userName: data.players.join(", ") });
    });

    socket.on("disconnect", () => {
      console.log("[Chat] Disconnected from server");
    });

    // Heartbeat every 30 seconds to keep connection alive
    const heartbeatInterval = setInterval(() => {
      socket.emit("heartbeat");
    }, 30000);

    return () => {
      clearInterval(heartbeatInterval);
      socket.disconnect();
    };
  }, [user]);

  // Auto-scroll to latest message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!messageInput.trim() || !socketRef.current) return;

    setIsSending(true);
    try {
      socketRef.current.emit("send_message", {
        message: messageInput,
      });
      setMessageInput("");
    } catch (error) {
      toast.error("Failed to send message");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <>
      {/* Chat Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-40 rounded-full shadow-lg transition-all flex items-center justify-center"
        title="Open chat"
        style={{
          backgroundColor: '#000000',
          color: '#eef075',
          width: '70px',
          height: '70px',
          borderWidth: '8px',
          borderStyle: 'dotted',
          borderColor: '#313cdd',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}
      >
        <MessageCircle size={28} />
      </button>

      {/* Chat Overlay */}
      {isOpen && (
        <Card className="fixed bottom-20 right-6 z-50 w-96 max-h-96 border-border/50 bg-card/95 backdrop-blur-sm shadow-xl flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-border/50">
            <div className="flex items-center gap-2">
              <MessageCircle size={20} className="text-gold" />
              <span className="font-semibold text-gold">Live Chat</span>
              <span className="text-xs bg-gold/20 text-gold px-2 py-1 rounded-full flex items-center gap-1">
                <Users size={12} />
                {onlinePlayers.count}
              </span>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-foreground/60 hover:text-foreground transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          {/* Messages */}
          <ScrollArea className="flex-1 p-4 space-y-3">
            {messages.length === 0 ? (
              <div className="text-center text-foreground/50 text-sm py-8">
                No messages yet. Be the first to chat!
              </div>
            ) : (
              messages.map((msg, idx) => (
                <div key={idx} className="text-sm">
                  {msg.isSystemMessage ? (
                    <div className="text-center text-foreground/50 italic text-xs py-1">
                      {msg.message}
                    </div>
                  ) : (
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-gold text-xs">{msg.userName}</span>
                        <span className="text-foreground/40 text-xs">
                          {msg.timestamp ? new Date(msg.timestamp).toLocaleTimeString() : ""}
                        </span>
                      </div>
                      <p className="text-foreground/80 break-words">{msg.message}</p>
                    </div>
                  )}
                </div>
              ))
            )}
            <div ref={messagesEndRef} />
          </ScrollArea>

          {/* Input */}
          <div className="p-4 border-t border-border/50 space-y-2">
            <div className="flex gap-2">
              <Input
                type="text"
                placeholder="Type a message..."
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                disabled={isSending}
                className="text-sm"
              />
              <Button
                onClick={handleSendMessage}
                disabled={isSending || !messageInput.trim()}
                className="bg-gold hover:bg-gold/90 text-black px-3"
              >
                Send
              </Button>
            </div>
            <p className="text-xs text-foreground/50">
              {onlinePlayers.count} players online
            </p>
          </div>
        </Card>
      )}
    </>
  );
}
