const WATERMARK_URL = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663338939905/qTsAAkeXCYpkVSJi.jpg";

export default function GameBackground({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative">
      <div
        className="absolute inset-0 pointer-events-none z-0"
        style={{
          backgroundImage: `url(${WATERMARK_URL})`,
          backgroundRepeat: "repeat",
          backgroundSize: "400px",
          opacity: 0.04,
          mixBlendMode: "lighten",
        }}
      />
      <div className="relative z-10">{children}</div>
    </div>
  );
}
