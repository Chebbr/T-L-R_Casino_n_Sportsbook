import { Card, CardContent } from "@/components/ui/card";
import { ExternalLink } from "lucide-react";

const KICK_CHANNEL = "x3bb3r";
const KICK_URL = `https://kick.com/${KICK_CHANNEL}`;
const THUMBNAIL_FALLBACK = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663338939905/OPWMLGADysgCkqzo.png";

export default function KickStreamWidget() {
  return (
    <Card className="border-primary/30 bg-card/50 overflow-hidden hover:border-primary/50 transition-all">
      <CardContent className="p-0">
        <a
          href={KICK_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="block group relative"
        >
          {/* Thumbnail */}
          <div className="relative aspect-video bg-black overflow-hidden">
            <img
              src={THUMBNAIL_FALLBACK}
              alt="Watch Xebb live on Kick"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
            {/* Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
            
            {/* Live Badge (optional - can be toggled based on actual stream status) */}
            <div className="absolute top-3 left-3 px-3 py-1 bg-red-600 text-white text-xs font-bold rounded-full flex items-center gap-1.5">
              <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
              OFFLINE
            </div>

            {/* Channel Info */}
            <div className="absolute bottom-0 left-0 right-0 p-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-primary/20 border-2 border-primary flex items-center justify-center text-xl font-bold text-primary">
                  X
                </div>
                <div className="flex-1">
                  <h3 className="text-white font-bold text-lg">Xebb</h3>
                  <p className="text-gray-300 text-sm">Watch live gameplay on Kick</p>
                </div>
                <ExternalLink className="h-5 w-5 text-primary group-hover:text-primary/80 transition-colors" />
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="p-4 bg-card border-t border-border/50">
            <p className="text-sm text-muted-foreground text-center">
              Click to watch <span className="text-primary font-semibold">@{KICK_CHANNEL}</span> on Kick.com
            </p>
          </div>
        </a>
      </CardContent>
    </Card>
  );
}
