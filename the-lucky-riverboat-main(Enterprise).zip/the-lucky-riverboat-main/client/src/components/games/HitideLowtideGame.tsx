import { useState, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import CasinoLayout from "@/components/CasinoLayout";
import GameBackground from "@/components/GameBackground";

const SUITS = ["♠", "♥", "♦", "♣"];
const VALUES = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
const SUIT_COLORS: Record<string, string> = { "♠": "text-white", "♥": "text-red-500", "♦": "text-red-500", "♣": "text-white" };

function getRandomCard() {
  return {
    suit: SUITS[Math.floor(Math.random() * 4)],
    value: VALUES[Math.floor(Math.random() * 13)],
    numValue: 0,
  };
}

function cardNumValue(value: string): number {
  if (value === "A") return 1;
  if (value === "J") return 11;
  if (value === "Q") return 12;
  if (value === "K") return 13;
  return parseInt(value);
}

function getMultiplier(currentValue: number, guess: "hi" | "lo"): number {
  if (guess === "hi") {
    const cardsAbove = 13 - currentValue;
    if (cardsAbove <= 0) return 13;
    return parseFloat((13 / cardsAbove * 0.97).toFixed(2));
  } else {
    const cardsBelow = currentValue - 1;
    if (cardsBelow <= 0) return 13;
    return parseFloat((13 / cardsBelow * 0.97).toFixed(2));
  }
}

function PlayingCard({ suit, value, flipping = false, small = false }: { suit: string; value: string; flipping?: boolean; small?: boolean }) {
  const isRed = suit === "♥" || suit === "♦";
  return (
    <motion.div
      className={`${small ? "w-16 h-22" : "w-28 h-40"} rounded-xl border-2 border-border bg-gradient-to-br from-card to-secondary flex flex-col items-center justify-center relative overflow-hidden shadow-lg`}
      animate={flipping ? { rotateY: [0, 90, 0], scale: [1, 0.9, 1] } : {}}
      transition={{ duration: 0.6 }}
    >
      <div className="absolute top-2 left-2">
        <p className={`${small ? "text-xs" : "text-sm"} font-bold ${isRed ? "text-red-500" : "text-white"}`}>{value}</p>
        <p className={`${small ? "text-xs" : "text-sm"} ${isRed ? "text-red-500" : "text-white"}`}>{suit}</p>
      </div>
      <p className={`${small ? "text-2xl" : "text-4xl"} ${isRed ? "text-red-500" : "text-white"}`}>{suit}</p>
      <div className="absolute bottom-2 right-2 rotate-180">
        <p className={`${small ? "text-xs" : "text-sm"} font-bold ${isRed ? "text-red-500" : "text-white"}`}>{value}</p>
        <p className={`${small ? "text-xs" : "text-sm"} ${isRed ? "text-red-500" : "text-white"}`}>{suit}</p>
      </div>
      {/* Card shine effect */}
      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent pointer-events-none" />
    </motion.div>
  );
}

export default function HitideLowtideGame() {
  const { user, isAuthenticated, loading } = useAuth();
  const [betAmount, setBetAmount] = useState("5");
  const [gameActive, setGameActive] = useState(false);
  const [currentCard, setCurrentCard] = useState<{ suit: string; value: string } | null>(null);
  const [nextCard, setNextCard] = useState<{ suit: string; value: string } | null>(null);
  const [history, setHistory] = useState<{ suit: string; value: string }[]>([]);
  const [streak, setStreak] = useState(0);
  const [totalMultiplier, setTotalMultiplier] = useState(1);
  const [gameOver, setGameOver] = useState(false);
  const [cashedOut, setCashedOut] = useState(false);
  const [winAmount, setWinAmount] = useState(0);
  const [showFlip, setShowFlip] = useState(false);
  const [lastGuessCorrect, setLastGuessCorrect] = useState<boolean | null>(null);

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      window.location.href = getLoginUrl("/games/hilow");
    }
  }, [loading, isAuthenticated]);

  const balanceQuery = trpc.wallet.getBalance.useQuery(undefined, { enabled: isAuthenticated });
  const playMutation = trpc.games.playHiLow.useMutation({
    onSuccess: (data) => {
      // Backend returns card as string like "5♠", parse it
      const cardStr = data.currentCard as string;
      const suits = ["♠","♥","♦","♣"];
      let suit = "♠";
      let value = "A";
      for (const s of suits) {
        if (cardStr.endsWith(s)) {
          suit = s;
          value = cardStr.slice(0, -1);
          break;
        }
      }
      const card = { suit, value };
      setCurrentCard(card);
      setNextCard(null);
      setHistory([]);
      setStreak(0);
      setTotalMultiplier(1);
      setGameActive(true);
      setGameOver(false);
      setCashedOut(false);
      setWinAmount(0);
      setLastGuessCorrect(null);
      balanceQuery.refetch();
    },
    onError: (err) => toast.error(err.message),
  });

  const guessMutation = trpc.games.guessHiLow.useMutation({
    onSuccess: (data) => {
      // Parse next card string
      const ncStr = data.nextCard as string;
      const ncSuits = ["♠","♥","♦","♣"];
      let ncSuit = "♠";
      let ncValue = "A";
      for (const s of ncSuits) {
        if (ncStr.endsWith(s)) {
          ncSuit = s;
          ncValue = ncStr.slice(0, -1);
          break;
        }
      }
      const newCard = { suit: ncSuit, value: ncValue };
      setShowFlip(true);
      setNextCard(newCard);
      setLastGuessCorrect(data.correct);

      setTimeout(() => {
        setShowFlip(false);
        if (data.correct) {
          setHistory((prev) => [...prev, currentCard!]);
          setCurrentCard(newCard);
          setNextCard(null);
          setStreak((s) => s + 1);
          setTotalMultiplier(data.multiplier);
        } else {
          setGameOver(true);
          setGameActive(false);
          setHistory((prev) => [...prev, currentCard!]);
        }
      }, 1000);
    },
    onError: (err) => toast.error(err.message),
  });

  const cashoutMutation = trpc.games.cashoutHiLow.useMutation({
    onSuccess: (data) => {
      setCashedOut(true);
      setWinAmount(data.payout);
      setGameActive(false);
      balanceQuery.refetch();
      toast.success(`Cashed out $${data.payout.toFixed(2)}!`);
    },
    onError: (err) => toast.error(err.message),
  });

  const startGame = useCallback(() => {
    const amount = parseFloat(betAmount);
    if (isNaN(amount) || amount < 0.1) { toast.error("Invalid bet amount"); return; }
    playMutation.mutate({ betAmount: amount });
  }, [betAmount, playMutation]);

  const makeGuess = useCallback((guess: "hi" | "lo") => {
    if (!gameActive || !currentCard || guessMutation.isPending) return;
    const guessMap = { hi: "high" as const, lo: "low" as const };
    guessMutation.mutate({ guess: guessMap[guess] });
  }, [gameActive, currentCard, guessMutation]);

  const handleCashout = useCallback(() => {
    if (!gameActive || streak === 0) return;
    cashoutMutation.mutate({ streak, multiplier: totalMultiplier });
  }, [gameActive, streak, totalMultiplier, cashoutMutation]);

  const resetGame = () => {
    setGameActive(false);
    setGameOver(false);
    setCashedOut(false);
    setCurrentCard(null);
    setNextCard(null);
    setHistory([]);
    setStreak(0);
    setTotalMultiplier(1);
    setWinAmount(0);
    setLastGuessCorrect(null);
  };

  if (loading || !user) {
    return (
      <CasinoLayout><GameBackground>
        <div className="container py-12 text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
        </div>
      </GameBackground></CasinoLayout>
    );
  }

  const hiMultiplier = currentCard ? getMultiplier(cardNumValue(currentCard.value), "hi") : 0;
  const loMultiplier = currentCard ? getMultiplier(cardNumValue(currentCard.value), "lo") : 0;

  return (
    <CasinoLayout><GameBackground>
      <div className="container py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-6">
            <h1 className="text-3xl font-bold" style={{ fontFamily: "'Cinzel', serif" }}>
              <span className="text-primary">Hitide</span> Lowtide
            </h1>
            <p className="text-muted-foreground text-sm mt-1">Guess if the next card is higher or lower</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Card Area */}
            <div className="lg:col-span-2">
              <Card className="border-border/50 bg-card/50">
                <CardContent className="p-8">
                  {/* History */}
                  {history.length > 0 && (
                    <div className="flex flex-wrap gap-2 justify-center mb-6">
                      {history.map((card, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, scale: 0.5 }}
                          animate={{ opacity: 0.6, scale: 1 }}
                          className="opacity-60"
                        >
                          <PlayingCard suit={card.suit} value={card.value} small />
                        </motion.div>
                      ))}
                    </div>
                  )}

                  {/* Current Card */}
                  <div className="flex items-center justify-center gap-8 mb-8">
                    {currentCard ? (
                      <motion.div
                        key={`${currentCard.suit}-${currentCard.value}-${streak}`}
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{ type: "spring", stiffness: 300 }}
                      >
                        <PlayingCard suit={currentCard.suit} value={currentCard.value} />
                      </motion.div>
                    ) : (
                      <div className="w-28 h-40 rounded-xl border-2 border-dashed border-border flex items-center justify-center">
                        <span className="text-muted-foreground text-sm">?</span>
                      </div>
                    )}

                    {nextCard && (
                      <motion.div
                        initial={{ rotateY: 180, opacity: 0 }}
                        animate={{ rotateY: 0, opacity: 1 }}
                        transition={{ duration: 0.6 }}
                      >
                        <PlayingCard suit={nextCard.suit} value={nextCard.value} flipping={showFlip} />
                      </motion.div>
                    )}
                  </div>

                  {/* Result Flash */}
                  <AnimatePresence>
                    {lastGuessCorrect !== null && showFlip && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.5 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0 }}
                        className={`text-center text-2xl font-bold mb-4 ${
                          lastGuessCorrect ? "text-green-500" : "text-red-500"
                        }`}
                      >
                        {lastGuessCorrect ? "Correct!" : "Wrong!"}
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Hi/Lo Buttons */}
                  {gameActive && !guessMutation.isPending && !showFlip && (
                    <div className="flex justify-center gap-4">
                      <Button
                        size="lg"
                        className="bg-green-600 hover:bg-green-700 px-8 text-lg"
                        onClick={() => makeGuess("hi")}
                      >
                        ↑ Higher ({hiMultiplier.toFixed(2)}x)
                      </Button>
                      <Button
                        size="lg"
                        className="bg-red-600 hover:bg-red-700 px-8 text-lg"
                        onClick={() => makeGuess("lo")}
                      >
                        ↓ Lower ({loMultiplier.toFixed(2)}x)
                      </Button>
                    </div>
                  )}

                  {guessMutation.isPending && (
                    <div className="text-center">
                      <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
                    </div>
                  )}

                  {!gameActive && !gameOver && !cashedOut && (
                    <div className="text-center text-muted-foreground">
                      Place a bet to start playing
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Controls */}
            <div className="space-y-4">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">Balance</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-primary">${balanceQuery.data?.balance || "0.00"}</p>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">Bet Amount</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Input
                    type="number"
                    value={betAmount}
                    onChange={(e) => setBetAmount(e.target.value)}
                    min="0.1"
                    step="0.1"
                    disabled={gameActive}
                    className="bg-muted/50"
                  />
                  <div className="grid grid-cols-4 gap-1">
                    {[1, 5, 10, 25].map((v) => (
                      <Button key={v} variant="outline" size="sm" onClick={() => setBetAmount(v.toString())} disabled={gameActive} className="text-xs">
                        ${v}
                      </Button>
                    ))}
                  </div>

                  {!gameActive && !gameOver && !cashedOut ? (
                    <Button
                      className="w-full bg-primary hover:bg-primary/90"
                      onClick={startGame}
                      disabled={playMutation.isPending}
                    >
                      {playMutation.isPending ? "Starting..." : "Deal Card"}
                    </Button>
                  ) : gameActive ? (
                    <>
                      <div className="text-center p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">Streak</p>
                        <p className="text-2xl font-bold text-primary">{streak}</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">Multiplier</p>
                        <p className="text-xl font-bold text-green-500">{totalMultiplier.toFixed(2)}x</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">Potential Win</p>
                        <p className="text-xl font-bold text-green-500">
                          ${(parseFloat(betAmount) * totalMultiplier).toFixed(2)}
                        </p>
                      </div>
                      <Button
                        className="w-full bg-green-600 hover:bg-green-700"
                        onClick={handleCashout}
                        disabled={cashoutMutation.isPending || streak === 0}
                      >
                        {cashoutMutation.isPending ? "Cashing out..." : "Cash Out"}
                      </Button>
                    </>
                  ) : null}
                </CardContent>
              </Card>

              {/* Result */}
              <AnimatePresence>
                {(gameOver || cashedOut) && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                  >
                    <Card className={`${cashedOut ? "border-green-500/50" : "border-red-500/50"}`}>
                      <CardContent className="p-6 text-center">
                        <p className="text-lg mb-2">
                          {cashedOut ? `${streak} correct guesses!` : "Wrong guess!"}
                        </p>
                        <p className={`text-3xl font-bold ${cashedOut ? "text-green-500" : "text-red-500"}`}>
                          {cashedOut ? `+$${winAmount.toFixed(2)}` : `-$${betAmount}`}
                        </p>
                        <Button variant="outline" className="mt-4" onClick={resetGame}>
                          Play Again
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                )}
              </AnimatePresence>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">How to Play</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>1. Place your bet and get a card</p>
                  <p>2. Guess if the next card is higher or lower</p>
                  <p>3. Build a streak for bigger multipliers</p>
                  <p>4. Cash out anytime to lock in your win!</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </GameBackground></CasinoLayout>
  );
}
