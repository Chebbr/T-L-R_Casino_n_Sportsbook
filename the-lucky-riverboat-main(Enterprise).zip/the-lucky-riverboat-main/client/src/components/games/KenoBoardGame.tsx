import { useState, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import CasinoLayout from "@/components/CasinoLayout";
import GameBackground from "@/components/GameBackground";

const TOTAL_NUMBERS = 40;
const MAX_PICKS = 10;
const DRAW_COUNT = 10;

function getRandomNumbers(count: number, max: number): number[] {
  const nums: number[] = [];
  while (nums.length < count) {
    const n = Math.floor(Math.random() * max) + 1;
    if (!nums.includes(n)) nums.push(n);
  }
  return nums;
}

const payoutTable: Record<number, Record<number, number>> = {
  1: { 0: 0, 1: 3.9 },
  2: { 0: 0, 1: 1.5, 2: 8 },
  3: { 0: 0, 1: 0.5, 2: 3, 3: 25 },
  4: { 0: 0, 1: 0, 2: 2, 3: 8, 4: 75 },
  5: { 0: 0, 1: 0, 2: 1, 3: 4, 4: 20, 5: 200 },
  6: { 0: 0, 1: 0, 2: 0.5, 3: 2, 4: 10, 5: 80, 6: 500 },
  7: { 0: 0, 1: 0, 2: 0, 3: 1.5, 4: 5, 5: 30, 6: 200, 7: 1000 },
  8: { 0: 0, 1: 0, 2: 0, 3: 1, 4: 3, 5: 15, 6: 80, 7: 500, 8: 2500 },
  9: { 0: 0, 1: 0, 2: 0, 3: 0.5, 4: 2, 5: 8, 6: 40, 7: 200, 8: 1000, 9: 5000 },
  10: { 0: 0, 1: 0, 2: 0, 3: 0, 4: 1.5, 5: 5, 6: 20, 7: 100, 8: 500, 9: 2500, 10: 10000 },
};

export default function KenoBoardGame() {
  const { user, isAuthenticated, loading } = useAuth();
  const [selectedNumbers, setSelectedNumbers] = useState<number[]>([]);
  const [drawnNumbers, setDrawnNumbers] = useState<number[]>([]);
  const [revealedCount, setRevealedCount] = useState(0);
  const [betAmount, setBetAmount] = useState("1");
  const [isDrawing, setIsDrawing] = useState(false);
  const [result, setResult] = useState<{ hits: number; payout: number; multiplier: number } | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      window.location.href = getLoginUrl("/games/keno");
    }
  }, [loading, isAuthenticated]);

  const balanceQuery = trpc.wallet.getBalance.useQuery(undefined, { enabled: isAuthenticated });
  const playMutation = trpc.games.playKeno.useMutation({
    onSuccess: (data) => {
      setDrawnNumbers(data.drawnNumbers);
      setRevealedCount(0);
      setIsDrawing(true);
      setResult({ hits: data.hits, payout: data.payout, multiplier: data.multiplier });
      if (data.payout > 0) setShowConfetti(true);
      balanceQuery.refetch();
    },
    onError: (err) => toast.error(err.message),
  });

  const toggleNumber = useCallback((num: number) => {
    if (isDrawing) return;
    setSelectedNumbers((prev) => {
      if (prev.includes(num)) return prev.filter((n) => n !== num);
      if (prev.length >= MAX_PICKS) { toast.error(`Max ${MAX_PICKS} numbers`); return prev; }
      return [...prev, num];
    });
    setDrawnNumbers([]);
    setRevealedCount(0);
    setResult(null);
    setShowConfetti(false);
  }, [isDrawing]);

  const quickPick = useCallback(() => {
    if (isDrawing) return;
    setSelectedNumbers(getRandomNumbers(MAX_PICKS, TOTAL_NUMBERS));
    setDrawnNumbers([]);
    setRevealedCount(0);
    setResult(null);
    setShowConfetti(false);
  }, [isDrawing]);

  const startDraw = useCallback(() => {
    if (selectedNumbers.length === 0) { toast.error("Pick at least 1 number"); return; }
    const amount = parseFloat(betAmount);
    if (isNaN(amount) || amount < 0.1) { toast.error("Invalid bet amount"); return; }
    playMutation.mutate({ betAmount: amount, selectedNumbers });
  }, [selectedNumbers, betAmount, playMutation]);

  // Reveal animation
  useEffect(() => {
    if (!isDrawing || drawnNumbers.length === 0) return;
    if (revealedCount >= DRAW_COUNT) {
      setIsDrawing(false);
      return;
    }
    const timer = setTimeout(() => setRevealedCount((c) => c + 1), 250);
    return () => clearTimeout(timer);
  }, [revealedCount, isDrawing, drawnNumbers]);

  const revealedDrawn = drawnNumbers.slice(0, revealedCount);

  if (loading || !user) {
    return (
      <CasinoLayout><GameBackground>
        <div className="container py-12 text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
        </div>
      </GameBackground></CasinoLayout>
    );
  }

  return (
    <CasinoLayout><GameBackground>
      <div className="container py-8">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-6">
            <h1 className="text-3xl font-bold" style={{ fontFamily: "'Cinzel', serif" }}>
              <span className="text-primary">Riverboat</span> Keno
            </h1>
            <p className="text-muted-foreground text-sm mt-1">Pick up to 10 numbers, match the draw to win</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Game Board */}
            <div className="lg:col-span-2">
              <Card className="border-border/50 bg-card/50">
                <CardContent className="p-4 sm:p-6">
                  {/* Board Grid */}
                  <div className="grid grid-cols-8 gap-1.5 sm:gap-2 mb-6">
                    {Array.from({ length: TOTAL_NUMBERS }, (_, i) => i + 1).map((num) => {
                      const isSelected = selectedNumbers.includes(num);
                      const isDrawn = revealedDrawn.includes(num);
                      const isHit = isSelected && isDrawn;
                      const isMiss = isDrawn && !isSelected;

                      return (
                        <motion.button
                          key={num}
                          onClick={() => toggleNumber(num)}
                          disabled={isDrawing}
                          className={`aspect-square rounded-lg text-sm font-bold flex items-center justify-center transition-all border cursor-pointer ${
                            isHit
                              ? "bg-green-500 border-green-400 text-white shadow-lg shadow-green-500/40"
                              : isMiss
                              ? "bg-red-500/30 border-red-400/50 text-red-300"
                              : isSelected
                              ? "bg-primary border-primary text-primary-foreground shadow-md shadow-primary/20"
                              : isDrawn
                              ? "bg-secondary border-border text-muted-foreground"
                              : "bg-card border-border text-foreground hover:border-primary/50 hover:bg-secondary"
                          }`}
                          whileHover={!isDrawing ? { scale: 1.12 } : {}}
                          whileTap={!isDrawing ? { scale: 0.92 } : {}}
                          animate={
                            isHit
                              ? { scale: [1, 1.35, 1.1], rotate: [0, 12, -12, 0] }
                              : isMiss
                              ? { scale: [1, 0.85, 1] }
                              : {}
                          }
                          transition={{ duration: 0.35, type: "spring" }}
                        >
                          {num}
                        </motion.button>
                      );
                    })}
                  </div>

                  {/* Drawn Numbers Display */}
                  {drawnNumbers.length > 0 && (
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-3">Drawn Numbers:</p>
                      <div className="flex flex-wrap justify-center gap-2">
                        {drawnNumbers.map((num, i) => (
                          <AnimatePresence key={`drawn-${num}`}>
                            {i < revealedCount && (
                              <motion.span
                                initial={{ scale: 0, opacity: 0, rotateY: 180 }}
                                animate={{ scale: 1, opacity: 1, rotateY: 0 }}
                                transition={{ type: "spring", stiffness: 300, damping: 15 }}
                                className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold ${
                                  selectedNumbers.includes(num)
                                    ? "bg-green-500 text-white shadow-lg shadow-green-500/40"
                                    : "bg-secondary text-foreground"
                                }`}
                              >
                                {num}
                              </motion.span>
                            )}
                          </AnimatePresence>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Result */}
                  <AnimatePresence>
                    {result && !isDrawing && (
                      <motion.div
                        initial={{ opacity: 0, y: 20, scale: 0.9 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0 }}
                        className={`text-center p-6 rounded-2xl border mt-6 ${
                          result.payout > 0
                            ? "bg-green-500/10 border-green-500/30"
                            : "bg-card border-border"
                        }`}
                      >
                        <p className="text-lg font-bold mb-1">
                          {result.hits} Hit{result.hits !== 1 ? "s" : ""} out of {selectedNumbers.length} picks
                        </p>
                        {result.payout > 0 ? (
                          <>
                            <motion.p
                              className="text-4xl font-bold text-green-400"
                              style={{ textShadow: "0 0 20px rgba(34,197,94,0.4)" }}
                              animate={{ scale: [1, 1.2, 1] }}
                              transition={{ duration: 0.6 }}
                            >
                              +${result.payout.toFixed(2)}
                            </motion.p>
                            <p className="text-sm text-green-300 mt-1">{result.multiplier}x multiplier</p>
                          </>
                        ) : (
                          <p className="text-muted-foreground">No win this round. Try again!</p>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </CardContent>
              </Card>
            </div>

            {/* Controls Panel */}
            <div className="space-y-4">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">Balance</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-primary">${balanceQuery.data?.balance || "0.00"}</p>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">Bet Amount</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Input
                    type="number"
                    value={betAmount}
                    onChange={(e) => setBetAmount(e.target.value)}
                    min="0.1"
                    step="0.1"
                    disabled={isDrawing}
                    className="bg-muted/50"
                  />
                  <div className="grid grid-cols-4 gap-1">
                    {[1, 5, 10, 25].map((v) => (
                      <Button key={v} variant="outline" size="sm" onClick={() => setBetAmount(v.toString())} disabled={isDrawing} className="text-xs">
                        ${v}
                      </Button>
                    ))}
                  </div>

                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1" onClick={quickPick} disabled={isDrawing}>
                      Quick Pick
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => {
                        setSelectedNumbers([]);
                        setDrawnNumbers([]);
                        setRevealedCount(0);
                        setResult(null);
                        setShowConfetti(false);
                      }}
                      disabled={isDrawing}
                    >
                      Clear
                    </Button>
                  </div>

                  <Button
                    className="w-full bg-primary hover:bg-primary/90 text-lg py-6"
                    onClick={startDraw}
                    disabled={isDrawing || selectedNumbers.length === 0 || playMutation.isPending}
                  >
                    {playMutation.isPending ? "Drawing..." : isDrawing ? "Drawing..." : `Draw! (${selectedNumbers.length} picks)`}
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">Payout Table</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-xs space-y-1 max-h-48 overflow-y-auto">
                    {selectedNumbers.length > 0 && payoutTable[selectedNumbers.length] ? (
                      Object.entries(payoutTable[selectedNumbers.length]).map(([hits, mult]) => (
                        <div key={hits} className="flex justify-between text-muted-foreground">
                          <span>{hits} hits</span>
                          <span className={mult > 0 ? "text-primary font-medium" : ""}>{mult}x</span>
                        </div>
                      ))
                    ) : (
                      <p className="text-muted-foreground">Select numbers to see payouts</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">How to Play</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>1. Pick up to 10 numbers from the board</p>
                  <p>2. Set your bet amount</p>
                  <p>3. Hit Draw and watch 10 numbers get drawn</p>
                  <p>4. More matches = bigger payouts!</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </GameBackground></CasinoLayout>
  );
}
