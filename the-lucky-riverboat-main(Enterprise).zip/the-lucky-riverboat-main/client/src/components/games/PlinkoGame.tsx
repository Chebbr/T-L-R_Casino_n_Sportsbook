import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import CasinoLayout from "@/components/CasinoLayout";
import GameBackground from "@/components/GameBackground";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function PlinkoGame() {
  const { user } = useAuth();
  const [betAmount, setBetAmount] = useState(10);
  const [gameActive, setGameActive] = useState(false);
  const [ballPosition, setBallPosition] = useState(0);
  const [ballPath, setBallPath] = useState<number[]>([]);
  const [result, setResult] = useState<string | null>(null);
  const [payout, setPayout] = useState(0);

  const rows = 8;
  const multipliers = [0.5, 1, 1.5, 2, 2.5, 2, 1.5, 1, 0.5];

  const startGame = () => {
    if (!user || Number(user.balance) < betAmount) {
      toast.error("Insufficient balance");
      return;
    }

    setGameActive(true);
    setResult(null);
    setPayout(0);
    setBallPath([]);

    // Simulate ball falling through pegs
    let position = 4; // Start in middle
    const path: number[] = [position];

    for (let i = 0; i < rows; i++) {
      position += Math.random() > 0.5 ? 1 : -1;
      position = Math.max(0, Math.min(8, position));
      path.push(position);
    }

    setBallPath(path);

    // Animate ball
    let step = 0;
    const interval = setInterval(() => {
      step++;
      if (step <= rows) {
        setBallPosition(step);
      } else {
        clearInterval(interval);
        const finalPosition = path[rows];
        const multiplier = multipliers[finalPosition];
        const payout = betAmount * multiplier;

        setResult(`Ball landed on ${multiplier}x!`);
        setPayout(payout);
        setGameActive(false);
      }
    }, 300);
  };

  return (
    <CasinoLayout><GameBackground>
      <div className="min-h-screen bg-background text-foreground py-8">
        <div className="container max-w-2xl">
          <Card className="border-border/50 bg-card/50">
            <CardHeader>
              <CardTitle className="text-gold">🎯 Plinko</CardTitle>
              <CardDescription>Watch the ball fall and multiply your winnings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Plinko Board */}
              <div className="bg-gradient-to-b from-amber-900/20 to-amber-950/20 rounded-lg p-8">
                <div className="space-y-4">
                  {/* Multiplier Row */}
                  <div className="flex justify-between px-2">
                    {multipliers.map((mult, i) => (
                      <div key={i} className="text-xs font-bold text-gold">
                        {mult}x
                      </div>
                    ))}
                  </div>

                  {/* Peg Rows */}
                  {Array.from({ length: rows }).map((_, row) => (
                    <div key={row} className="flex justify-center gap-6">
                      {Array.from({ length: row + 2 }).map((_, col) => (
                        <div
                          key={col}
                          className={`w-3 h-3 rounded-full ${
                            ballPath[row] === col && ballPosition === row
                              ? "bg-red-500 shadow-lg shadow-red-500"
                              : "bg-gold/50"
                          }`}
                        />
                      ))}
                    </div>
                  ))}

                  {/* Ball Start */}
                  {!gameActive && ballPath.length === 0 && (
                    <div className="flex justify-center">
                      <div className="w-6 h-6 rounded-full bg-red-500 shadow-lg shadow-red-500" />
                    </div>
                  )}
                </div>
              </div>

              {/* Result */}
              {result && (
                <div className="p-4 rounded-lg text-center font-semibold bg-green-500/20 text-green-500">
                  {result}
                  <p className="text-sm mt-1">Payout: ${payout.toFixed(2)}</p>
                </div>
              )}

              {/* Betting */}
              {!gameActive && !result && (
                <div className="space-y-3">
                  <div>
                    <Label>Bet Amount ($)</Label>
                    <Input
                      type="number"
                      value={betAmount}
                      onChange={(e) => setBetAmount(Number(e.target.value))}
                      min="1"
                      max={Number(user?.balance || 0)}
                      className="mt-1"
                    />
                  </div>
                  <Button onClick={startGame} className="w-full bg-gold hover:bg-gold/90 text-black font-bold">
                    Drop Ball
                  </Button>
                </div>
              )}

              {result && (
                <Button onClick={() => setResult(null)} className="w-full bg-gold hover:bg-gold/90 text-black font-bold">
                  Play Again
                </Button>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </GameBackground></CasinoLayout>
  );
}
