import { useState, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import CasinoLayout from "@/components/CasinoLayout";
import GameBackground from "@/components/GameBackground";

const GRID_SIZE = 25;
const ROWS = 5;
const COLS = 5;

function calculateMultiplier(revealed: number, mines: number): number {
  const safe = GRID_SIZE - mines;
  let mult = 1;
  for (let i = 0; i < revealed; i++) {
    mult *= safe - i;
    mult /= GRID_SIZE - mines - i + (GRID_SIZE - i - safe);
  }
  return Math.max(1, parseFloat((mult * 0.97 + 0.03).toFixed(2)));
}

export default function HiddenTreasureGame() {
  const { user, isAuthenticated, loading } = useAuth();
  const [betAmount, setBetAmount] = useState("5");
  const [mineCount, setMineCount] = useState(5);
  const [gameActive, setGameActive] = useState(false);
  const [minePositions, setMinePositions] = useState<number[]>([]);
  const [revealedTiles, setRevealedTiles] = useState<number[]>([]);
  const [gameOver, setGameOver] = useState(false);
  const [cashedOut, setCashedOut] = useState(false);
  const [winAmount, setWinAmount] = useState(0);
  const [currentMultiplier, setCurrentMultiplier] = useState(1);

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      window.location.href = getLoginUrl("/games/mines");
    }
  }, [loading, isAuthenticated]);

  const balanceQuery = trpc.wallet.getBalance.useQuery(undefined, { enabled: isAuthenticated });
  const playMutation = trpc.games.playMines.useMutation({
    onSuccess: (data) => {
      setMinePositions(data.minePositions);
      setGameActive(true);
      setRevealedTiles([]);
      setGameOver(false);
      setCashedOut(false);
      setWinAmount(0);
      setCurrentMultiplier(1);
      balanceQuery.refetch();
    },
    onError: (err) => toast.error(err.message),
  });

  const cashoutMutation = trpc.games.cashoutMines.useMutation({
    onSuccess: (data) => {
      setCashedOut(true);
      setWinAmount(data.payout);
      setGameActive(false);
      balanceQuery.refetch();
      toast.success(`Cashed out $${data.payout.toFixed(2)}!`);
    },
    onError: (err) => toast.error(err.message),
  });

  const startGame = useCallback(() => {
    const amount = parseFloat(betAmount);
    if (isNaN(amount) || amount < 0.1) { toast.error("Invalid bet amount"); return; }
    playMutation.mutate({ betAmount: amount, mineCount });
  }, [betAmount, mineCount, playMutation]);

  const revealTile = useCallback((index: number) => {
    if (!gameActive || revealedTiles.includes(index) || gameOver) return;

    const isMine = minePositions.includes(index);
    const newRevealed = [...revealedTiles, index];
    setRevealedTiles(newRevealed);

    if (isMine) {
      setGameOver(true);
      setGameActive(false);
    } else {
      const safeRevealed = newRevealed.filter((t) => !minePositions.includes(t)).length;
      const newMult = calculateMultiplier(safeRevealed, mineCount);
      setCurrentMultiplier(newMult);

      // Check if all safe tiles revealed
      if (safeRevealed >= GRID_SIZE - mineCount) {
        cashoutMutation.mutate({ revealedCount: safeRevealed, multiplier: newMult });
      }
    }
  }, [gameActive, revealedTiles, minePositions, gameOver, mineCount, cashoutMutation]);

  const handleCashout = useCallback(() => {
    if (!gameActive || revealedTiles.length === 0) return;
    const safeRevealed = revealedTiles.filter((t) => !minePositions.includes(t)).length;
    cashoutMutation.mutate({ revealedCount: safeRevealed, multiplier: currentMultiplier });
  }, [gameActive, revealedTiles, minePositions, currentMultiplier, cashoutMutation]);

  const resetGame = () => {
    setGameActive(false);
    setGameOver(false);
    setCashedOut(false);
    setRevealedTiles([]);
    setMinePositions([]);
    setWinAmount(0);
    setCurrentMultiplier(1);
  };

  if (loading || !user) {
    return (
      <CasinoLayout><GameBackground>
        <div className="container py-12 text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
        </div>
      </GameBackground></CasinoLayout>
    );
  }

  return (
    <CasinoLayout><GameBackground>
      <div className="container py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-6">
            <h1 className="text-3xl font-bold" style={{ fontFamily: "'Cinzel', serif" }}>
              <span className="text-primary">Hidden</span> Treasure
            </h1>
            <p className="text-muted-foreground text-sm mt-1">Uncover gems while avoiding hidden mines</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Mine Grid */}
            <div className="lg:col-span-2">
              <Card className="border-border/50 bg-card/50">
                <CardContent className="p-6">
                  <div className="grid grid-cols-5 gap-2 max-w-md mx-auto">
                    {Array.from({ length: GRID_SIZE }).map((_, index) => {
                      const isRevealed = revealedTiles.includes(index);
                      const isMine = minePositions.includes(index);
                      const isRevealedMine = isRevealed && isMine;
                      const isRevealedSafe = isRevealed && !isMine;
                      const showMine = (gameOver || cashedOut) && isMine && !isRevealed;

                      let tileClass = "bg-secondary border-border hover:bg-secondary/80 hover:border-primary/50";
                      let content = "";

                      if (isRevealedSafe) {
                        tileClass = "bg-green-500/20 border-green-500/50";
                        content = "💎";
                      } else if (isRevealedMine) {
                        tileClass = "bg-red-500/20 border-red-500/50";
                        content = "💣";
                      } else if (showMine) {
                        tileClass = "bg-red-500/10 border-red-500/30";
                        content = "💣";
                      } else if (!gameActive && !gameOver && !cashedOut) {
                        tileClass = "bg-muted/30 border-border/50";
                      }

                      return (
                        <motion.button
                          key={index}
                          onClick={() => revealTile(index)}
                          disabled={!gameActive || isRevealed}
                          className={`aspect-square rounded-lg border-2 flex items-center justify-center text-2xl transition-all ${tileClass} ${
                            gameActive && !isRevealed ? "cursor-pointer" : ""
                          }`}
                          whileHover={gameActive && !isRevealed ? { scale: 1.08 } : {}}
                          whileTap={gameActive && !isRevealed ? { scale: 0.92 } : {}}
                          animate={
                            isRevealedMine
                              ? { rotate: [0, -10, 10, -10, 0], scale: [1, 1.3, 1] }
                              : isRevealedSafe
                              ? { scale: [0.8, 1.2, 1] }
                              : {}
                          }
                          transition={{ duration: 0.4 }}
                        >
                          {content || (gameActive && !isRevealed ? (
                            <span className="text-muted-foreground text-sm">?</span>
                          ) : null)}
                        </motion.button>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Controls */}
            <div className="space-y-4">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">Balance</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-primary">${balanceQuery.data?.balance || "0.00"}</p>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">Game Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Bet Amount</label>
                    <Input
                      type="number"
                      value={betAmount}
                      onChange={(e) => setBetAmount(e.target.value)}
                      min="0.1"
                      step="0.1"
                      disabled={gameActive}
                      className="bg-muted/50"
                    />
                  </div>
                  <div className="grid grid-cols-4 gap-1">
                    {[1, 5, 10, 25].map((v) => (
                      <Button key={v} variant="outline" size="sm" onClick={() => setBetAmount(v.toString())} disabled={gameActive} className="text-xs">
                        ${v}
                      </Button>
                    ))}
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground mb-1 block">Mines: {mineCount}</label>
                    <div className="grid grid-cols-5 gap-1">
                      {[1, 3, 5, 10, 15].map((v) => (
                        <Button
                          key={v}
                          variant="outline"
                          size="sm"
                          onClick={() => setMineCount(v)}
                          disabled={gameActive}
                          className={`text-xs ${mineCount === v ? "border-primary text-primary" : ""}`}
                        >
                          {v}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {!gameActive && !gameOver && !cashedOut ? (
                    <Button
                      className="w-full bg-primary hover:bg-primary/90"
                      onClick={startGame}
                      disabled={playMutation.isPending}
                    >
                      {playMutation.isPending ? "Starting..." : "Start Game"}
                    </Button>
                  ) : gameActive ? (
                    <>
                      <div className="text-center p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">Current Multiplier</p>
                        <p className="text-2xl font-bold text-primary">{currentMultiplier.toFixed(2)}x</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">Potential Win</p>
                        <p className="text-xl font-bold text-green-500">
                          ${(parseFloat(betAmount) * currentMultiplier).toFixed(2)}
                        </p>
                      </div>
                      <Button
                        className="w-full bg-green-600 hover:bg-green-700"
                        onClick={handleCashout}
                        disabled={cashoutMutation.isPending || revealedTiles.length === 0}
                      >
                        {cashoutMutation.isPending ? "Cashing out..." : "Cash Out"}
                      </Button>
                    </>
                  ) : null}
                </CardContent>
              </Card>

              {/* Result */}
              <AnimatePresence>
                {(gameOver || cashedOut) && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                  >
                    <Card className={`${cashedOut ? "border-green-500/50" : "border-red-500/50"}`}>
                      <CardContent className="p-6 text-center">
                        <p className="text-lg mb-2">
                          {cashedOut
                            ? `${revealedTiles.filter((t) => !minePositions.includes(t)).length} gems found!`
                            : "You hit a mine!"}
                        </p>
                        <p className={`text-3xl font-bold ${cashedOut ? "text-green-500" : "text-red-500"}`}>
                          {cashedOut ? `+$${winAmount.toFixed(2)}` : `-$${betAmount}`}
                        </p>
                        <Button variant="outline" className="mt-4" onClick={resetGame}>
                          Play Again
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                )}
              </AnimatePresence>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">How to Play</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>1. Set your bet and number of mines</p>
                  <p>2. Click tiles to reveal gems or mines</p>
                  <p>3. More gems = higher multiplier</p>
                  <p>4. Cash out before hitting a mine!</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </GameBackground></CasinoLayout>
  );
}
