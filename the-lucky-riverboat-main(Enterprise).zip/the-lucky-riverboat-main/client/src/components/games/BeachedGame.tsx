import { useState, useCallback, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import CasinoLayout from "@/components/CasinoLayout";
import GameBackground from "@/components/GameBackground";

export default function BeachedGame() {
  const { user, isAuthenticated, loading } = useAuth();
  const [betAmount, setBetAmount] = useState("5");
  const [multiplier, setMultiplier] = useState(1.0);
  const [crashPoint, setCrashPoint] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [hasCashedOut, setHasCashedOut] = useState(false);
  const [cashOutAt, setCashOutAt] = useState(0);
  const [history, setHistory] = useState<number[]>([]);
  const [sessionId, setSessionId] = useState<number | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const startTimeRef = useRef(0);

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      window.location.href = getLoginUrl("/games/crash");
    }
  }, [loading, isAuthenticated]);

  const balanceQuery = trpc.wallet.getBalance.useQuery(undefined, { enabled: isAuthenticated });
  const playMutation = trpc.games.playCrash.useMutation({
    onSuccess: (data) => {
      setCrashPoint(data.crashPoint);
      setSessionId(data.sessionId);
      setMultiplier(1.0);
      setIsRunning(true);
      setHasCashedOut(false);
      setCashOutAt(0);
      startTimeRef.current = Date.now();
      balanceQuery.refetch();
    },
    onError: (err) => toast.error(err.message),
  });

  const cashoutMutation = trpc.games.cashoutCrash.useMutation({
    onSuccess: (data) => {
      setHasCashedOut(true);
      setCashOutAt(multiplier);
      balanceQuery.refetch();
      toast.success(`Cashed out at ${multiplier.toFixed(2)}x! Won $${data.payout.toFixed(2)}`);
    },
    onError: (err) => toast.error(err.message),
  });

  const drawGraph = useCallback((mult: number, crashed: boolean) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    // Grid lines
    ctx.strokeStyle = "rgba(255,255,255,0.04)";
    ctx.lineWidth = 1;
    for (let i = 0; i < 6; i++) {
      const y = (h / 6) * i;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
    }
    for (let i = 0; i < 8; i++) {
      const x = (w / 8) * i;
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
    }

    // Curve
    ctx.strokeStyle = crashed ? "#ef4444" : "#22c55e";
    ctx.lineWidth = 3;
    ctx.shadowColor = crashed ? "#ef4444" : "#22c55e";
    ctx.shadowBlur = 8;
    ctx.beginPath();
    const points = Math.min(200, Math.floor((mult - 1) * 30));
    for (let i = 0; i <= points; i++) {
      const x = (i / 200) * w;
      const progress = i / Math.max(points, 1);
      const currentMult = 1 + (mult - 1) * progress;
      const y = h - ((currentMult - 1) / Math.max(mult - 1, 0.1)) * (h * 0.8);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Fill under curve
    const lastX = (points / 200) * w;
    ctx.lineTo(lastX, h);
    ctx.lineTo(0, h);
    ctx.closePath();
    const fillGrad = ctx.createLinearGradient(0, 0, 0, h);
    fillGrad.addColorStop(0, crashed ? "rgba(239,68,68,0.12)" : "rgba(34,197,94,0.12)");
    fillGrad.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = fillGrad;
    ctx.fill();

    // Glow dot at tip
    if (!crashed) {
      const tipY = h - ((mult - 1) / Math.max(mult - 1, 0.1)) * (h * 0.8);
      ctx.beginPath();
      ctx.arc(lastX, tipY, 5, 0, Math.PI * 2);
      ctx.fillStyle = "#22c55e";
      ctx.shadowColor = "#22c55e";
      ctx.shadowBlur = 15;
      ctx.fill();
      ctx.shadowBlur = 0;
    }
  }, []);

  const startGame = useCallback(() => {
    const amount = parseFloat(betAmount);
    if (isNaN(amount) || amount < 0.1) { toast.error("Invalid bet amount"); return; }
    playMutation.mutate({ betAmount: amount });
  }, [betAmount, playMutation]);

  const cashOut = useCallback(() => {
    if (!isRunning || hasCashedOut) return;
    cashoutMutation.mutate({ multiplier: multiplier });
  }, [isRunning, hasCashedOut, multiplier, cashoutMutation]);

  useEffect(() => {
    if (!isRunning) return;

    const tick = () => {
      const elapsed = (Date.now() - startTimeRef.current) / 1000;
      const newMult = Math.pow(Math.E, elapsed * 0.15);
      const rounded = Math.floor(newMult * 100) / 100;

      if (rounded >= crashPoint) {
        setMultiplier(crashPoint);
        setIsRunning(false);
        drawGraph(crashPoint, true);
        setHistory((h) => [crashPoint, ...h.slice(0, 14)]);
        return;
      }

      setMultiplier(rounded);
      drawGraph(rounded, false);
      animRef.current = requestAnimationFrame(tick);
    };

    animRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animRef.current);
  }, [isRunning, crashPoint, drawGraph]);

  if (loading || !user) {
    return (
      <CasinoLayout><GameBackground>
        <div className="container py-12 text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
        </div>
      </GameBackground></CasinoLayout>
    );
  }

  return (
    <CasinoLayout><GameBackground>
      <div className="container py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-6">
            <h1 className="text-3xl font-bold" style={{ fontFamily: "'Cinzel', serif" }}>
              <span className="text-primary">Beached</span>
            </h1>
            <p className="text-muted-foreground text-sm mt-1">Ride the wave and cash out before the crash</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Game Canvas */}
            <div className="lg:col-span-2">
              <Card className="border-border/50 bg-card/50 overflow-hidden">
                <CardContent className="p-0 relative">
                  <canvas ref={canvasRef} width={800} height={400} className="w-full h-64 sm:h-80" />
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <AnimatePresence mode="wait">
                      {isRunning ? (
                        <motion.div key="running" initial={{ scale: 0.8 }} animate={{ scale: 1 }} className="text-center">
                          <motion.p
                            className="text-6xl sm:text-8xl font-bold text-green-400 drop-shadow-lg"
                            style={{ textShadow: "0 0 30px rgba(34,197,94,0.5)" }}
                            animate={{ scale: [1, 1.03, 1] }}
                            transition={{ repeat: Infinity, duration: 0.4 }}
                          >
                            {multiplier.toFixed(2)}x
                          </motion.p>
                        </motion.div>
                      ) : crashPoint > 0 ? (
                        <motion.div key="result" initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center">
                          {hasCashedOut ? (
                            <>
                              <p className="text-lg text-green-400 font-medium mb-1">Cashed Out!</p>
                              <motion.p
                                className="text-6xl font-bold text-green-400"
                                style={{ textShadow: "0 0 30px rgba(34,197,94,0.5)" }}
                                animate={{ scale: [1, 1.15, 1] }}
                                transition={{ duration: 0.5 }}
                              >
                                {cashOutAt.toFixed(2)}x
                              </motion.p>
                              <p className="text-lg text-green-300 mt-2">+${(parseFloat(betAmount) * cashOutAt).toFixed(2)}</p>
                            </>
                          ) : (
                            <>
                              <p className="text-lg text-red-400 font-medium mb-1">Crashed!</p>
                              <motion.p
                                className="text-6xl font-bold text-red-400"
                                style={{ textShadow: "0 0 30px rgba(239,68,68,0.5)" }}
                                animate={{ x: [0, -8, 8, -8, 0], rotate: [0, -2, 2, -2, 0] }}
                                transition={{ duration: 0.4 }}
                              >
                                {crashPoint.toFixed(2)}x
                              </motion.p>
                            </>
                          )}
                        </motion.div>
                      ) : (
                        <motion.p key="idle" className="text-2xl text-muted-foreground font-medium">
                          Place your bet
                        </motion.p>
                      )}
                    </AnimatePresence>
                  </div>
                </CardContent>
              </Card>

              {/* History */}
              {history.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-4 justify-center">
                  {history.map((cp, i) => (
                    <motion.span
                      key={`${i}-${cp}`}
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className={`px-3 py-1 rounded-full text-xs font-bold ${
                        cp >= 2 ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"
                      }`}
                    >
                      {cp.toFixed(2)}x
                    </motion.span>
                  ))}
                </div>
              )}
            </div>

            {/* Controls */}
            <div className="space-y-4">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">Balance</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-primary">${balanceQuery.data?.balance || "0.00"}</p>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">Bet Amount</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Input
                    type="number"
                    value={betAmount}
                    onChange={(e) => setBetAmount(e.target.value)}
                    min="0.1"
                    step="0.1"
                    disabled={isRunning}
                    className="bg-muted/50"
                  />
                  <div className="grid grid-cols-4 gap-1">
                    {[1, 5, 10, 25].map((v) => (
                      <Button key={v} variant="outline" size="sm" onClick={() => setBetAmount(v.toString())} disabled={isRunning} className="text-xs">
                        ${v}
                      </Button>
                    ))}
                  </div>

                  {!isRunning ? (
                    <Button
                      className="w-full bg-primary hover:bg-primary/90 text-lg py-6"
                      onClick={startGame}
                      disabled={playMutation.isPending}
                    >
                      {playMutation.isPending ? "Starting..." : "Start Round"}
                    </Button>
                  ) : (
                    <Button
                      className="w-full bg-green-600 hover:bg-green-700 text-lg py-6 animate-pulse"
                      onClick={cashOut}
                      disabled={hasCashedOut || cashoutMutation.isPending}
                    >
                      {hasCashedOut ? "Cashed Out!" : cashoutMutation.isPending ? "Cashing..." : `Cash Out (${multiplier.toFixed(2)}x)`}
                    </Button>
                  )}
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">How to Play</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>1. Place your bet and start the round</p>
                  <p>2. Watch the multiplier climb higher</p>
                  <p>3. Cash out before it crashes!</p>
                  <p>4. The longer you wait, the bigger the win</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </GameBackground></CasinoLayout>
  );
}
