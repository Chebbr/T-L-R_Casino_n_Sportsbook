import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import CasinoLayout from "@/components/CasinoLayout";
import GameBackground from "@/components/GameBackground";
import { useEffect } from "react";

const LEVELS = 8;
const COLS = 3;
const MULTIPLIERS = [1.4, 1.96, 2.74, 3.84, 5.38, 7.53, 10.54, 14.76];

export default function WalkThePlankGame() {
  const { user, isAuthenticated, loading } = useAuth();
  const [betAmount, setBetAmount] = useState("5");
  const [gameActive, setGameActive] = useState(false);
  const [currentLevel, setCurrentLevel] = useState(0);
  const [safeTiles, setSafeTiles] = useState<number[]>([]);
  const [revealedTiles, setRevealedTiles] = useState<{ level: number; col: number; safe: boolean }[]>([]);
  const [gameOver, setGameOver] = useState(false);
  const [cashedOut, setCashedOut] = useState(false);
  const [winAmount, setWinAmount] = useState(0);

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      window.location.href = getLoginUrl("/games/tower");
    }
  }, [loading, isAuthenticated]);

  const balanceQuery = trpc.wallet.getBalance.useQuery(undefined, { enabled: isAuthenticated });
  const playMutation = trpc.games.playTower.useMutation({
    onSuccess: (data) => {
      setSafeTiles(data.safeTiles);
      setGameActive(true);
      setCurrentLevel(0);
      setRevealedTiles([]);
      setGameOver(false);
      setCashedOut(false);
      setWinAmount(0);
      balanceQuery.refetch();
    },
    onError: (err) => toast.error(err.message),
  });

  const cashoutMutation = trpc.games.cashoutTower.useMutation({
    onSuccess: (data) => {
      setCashedOut(true);
      setWinAmount(data.payout);
      setGameActive(false);
      balanceQuery.refetch();
      toast.success(`Cashed out $${data.payout.toFixed(2)}!`);
    },
    onError: (err) => toast.error(err.message),
  });

  const startGame = useCallback(() => {
    const amount = parseFloat(betAmount);
    if (isNaN(amount) || amount < 0.1) { toast.error("Invalid bet amount"); return; }
    playMutation.mutate({ betAmount: amount });
  }, [betAmount, playMutation]);

  const selectTile = useCallback((level: number, col: number) => {
    if (!gameActive || level !== currentLevel || gameOver) return;

    const isSafe = safeTiles[level] === col;
    setRevealedTiles((prev) => [...prev, { level, col, safe: isSafe }]);

    if (isSafe) {
      const nextLevel = currentLevel + 1;
      setCurrentLevel(nextLevel);
      if (nextLevel >= LEVELS) {
        // Reached the top - auto cashout
        cashoutMutation.mutate({ level: LEVELS, multiplier: MULTIPLIERS[LEVELS - 1] });
      }
    } else {
      setGameOver(true);
      setGameActive(false);
      // Reveal all safe tiles
      const allRevealed = safeTiles.map((safe, lvl) => ({ level: lvl, col: safe, safe: true }));
      setRevealedTiles((prev) => [...prev, ...allRevealed.filter((r) => !prev.some((p) => p.level === r.level && p.col === r.col))]);
    }
  }, [gameActive, currentLevel, safeTiles, gameOver, cashoutMutation]);

  const handleCashout = useCallback(() => {
    if (!gameActive || currentLevel === 0) return;
    cashoutMutation.mutate({ level: currentLevel, multiplier: MULTIPLIERS[currentLevel - 1] });
  }, [gameActive, currentLevel, cashoutMutation]);

  const resetGame = () => {
    setGameActive(false);
    setGameOver(false);
    setCashedOut(false);
    setCurrentLevel(0);
    setSafeTiles([]);
    setRevealedTiles([]);
    setWinAmount(0);
  };

  if (loading || !user) {
    return (
      <CasinoLayout><GameBackground>
        <div className="container py-12 text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
        </div>
      </GameBackground></CasinoLayout>
    );
  }

  return (
    <CasinoLayout><GameBackground>
      <div className="container py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-6">
            <h1 className="text-3xl font-bold" style={{ fontFamily: "'Cinzel', serif" }}>
              <span className="text-primary">Walk the</span> Plank
            </h1>
            <p className="text-muted-foreground text-sm mt-1">Climb the tower — pick the safe tile on each level</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Tower Grid */}
            <div className="lg:col-span-2">
              <Card className="border-border/50 bg-card/50">
                <CardContent className="p-6">
                  <div className="space-y-2">
                    {Array.from({ length: LEVELS }).map((_, levelIdx) => {
                      const level = LEVELS - 1 - levelIdx;
                      const isCurrentLevel = level === currentLevel && gameActive;
                      const isAboveCurrent = level > currentLevel;
                      const isBelowCurrent = level < currentLevel;

                      return (
                        <motion.div
                          key={level}
                          className="flex items-center gap-2"
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: levelIdx * 0.05 }}
                        >
                          {/* Multiplier label */}
                          <div className={`w-16 text-right text-sm font-bold ${
                            isCurrentLevel ? "text-primary" : isBelowCurrent ? "text-green-500" : "text-muted-foreground"
                          }`}>
                            {MULTIPLIERS[level].toFixed(2)}x
                          </div>

                          {/* Tiles */}
                          <div className="flex-1 grid grid-cols-3 gap-2">
                            {Array.from({ length: COLS }).map((_, col) => {
                              const revealed = revealedTiles.find((r) => r.level === level && r.col === col);
                              const isSafeTile = safeTiles[level] === col;
                              const isRevealed = !!revealed;
                              const wasClicked = revealedTiles.some((r) => r.level === level && r.col === col && !r.safe);

                              let tileClass = "bg-secondary border-border";
                              let content = "";

                              if (isRevealed && revealed?.safe) {
                                tileClass = "bg-green-500/20 border-green-500/50";
                                content = "💎";
                              } else if (wasClicked) {
                                tileClass = "bg-red-500/20 border-red-500/50";
                                content = "💀";
                              } else if (gameOver && isSafeTile) {
                                tileClass = "bg-green-500/10 border-green-500/30";
                                content = "💎";
                              } else if (isCurrentLevel) {
                                tileClass = "bg-primary/10 border-primary/50 hover:bg-primary/20 cursor-pointer";
                                content = "?";
                              } else if (isAboveCurrent && gameActive) {
                                tileClass = "bg-muted/30 border-border/30";
                                content = "?";
                              }

                              return (
                                <motion.button
                                  key={col}
                                  onClick={() => selectTile(level, col)}
                                  disabled={!isCurrentLevel || !gameActive}
                                  className={`h-14 rounded-lg border-2 flex items-center justify-center text-lg font-bold transition-all ${tileClass}`}
                                  whileHover={isCurrentLevel && gameActive ? { scale: 1.05 } : {}}
                                  whileTap={isCurrentLevel && gameActive ? { scale: 0.95 } : {}}
                                  animate={wasClicked ? { 
                                    rotate: [0, -5, 5, -5, 0],
                                    transition: { duration: 0.5 }
                                  } : isRevealed && revealed?.safe ? {
                                    scale: [1, 1.2, 1],
                                    transition: { duration: 0.3 }
                                  } : {}}
                                >
                                  {content}
                                </motion.button>
                              );
                            })}
                          </div>

                          {/* Level indicator */}
                          <div className={`w-8 text-center text-xs ${
                            isCurrentLevel ? "text-primary font-bold" : "text-muted-foreground"
                          }`}>
                            L{level + 1}
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Controls */}
            <div className="space-y-4">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">Balance</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-primary">${balanceQuery.data?.balance || "0.00"}</p>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">Bet Amount</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Input
                    type="number"
                    value={betAmount}
                    onChange={(e) => setBetAmount(e.target.value)}
                    min="0.1"
                    step="0.1"
                    disabled={gameActive}
                    className="bg-muted/50"
                  />
                  <div className="grid grid-cols-4 gap-1">
                    {[1, 5, 10, 25].map((v) => (
                      <Button
                        key={v}
                        variant="outline"
                        size="sm"
                        onClick={() => setBetAmount(v.toString())}
                        disabled={gameActive}
                        className="text-xs"
                      >
                        ${v}
                      </Button>
                    ))}
                  </div>
                  {!gameActive ? (
                    <Button
                      className="w-full bg-primary hover:bg-primary/90"
                      onClick={startGame}
                      disabled={playMutation.isPending}
                    >
                      {playMutation.isPending ? "Starting..." : "Start Game"}
                    </Button>
                  ) : (
                    <>
                      <div className="text-center p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">Current Multiplier</p>
                        <p className="text-2xl font-bold text-primary">
                          {currentLevel > 0 ? MULTIPLIERS[currentLevel - 1].toFixed(2) : "0.00"}x
                        </p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">Potential Win</p>
                        <p className="text-xl font-bold text-green-500">
                          ${currentLevel > 0 ? (parseFloat(betAmount) * MULTIPLIERS[currentLevel - 1]).toFixed(2) : "0.00"}
                        </p>
                      </div>
                      <Button
                        className="w-full bg-green-600 hover:bg-green-700"
                        onClick={handleCashout}
                        disabled={cashoutMutation.isPending || currentLevel === 0}
                      >
                        {cashoutMutation.isPending ? "Cashing out..." : "Cash Out"}
                      </Button>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* Result */}
              <AnimatePresence>
                {(gameOver || cashedOut) && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                  >
                    <Card className={`${cashedOut ? "border-green-500/50" : "border-red-500/50"}`}>
                      <CardContent className="p-6 text-center">
                        <p className="text-lg mb-2">
                          {cashedOut ? `Reached level ${currentLevel}!` : "You hit a trap!"}
                        </p>
                        <p className={`text-3xl font-bold ${cashedOut ? "text-green-500" : "text-red-500"}`}>
                          {cashedOut ? `+$${winAmount.toFixed(2)}` : `-$${betAmount}`}
                        </p>
                        <Button variant="outline" className="mt-4" onClick={resetGame}>
                          Play Again
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* How to Play */}
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">How to Play</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>1. Place your bet and start the game</p>
                  <p>2. Pick one of three tiles on each level</p>
                  <p>3. Find the safe tile to climb higher</p>
                  <p>4. Cash out anytime for your current multiplier!</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </GameBackground></CasinoLayout>
  );
}
