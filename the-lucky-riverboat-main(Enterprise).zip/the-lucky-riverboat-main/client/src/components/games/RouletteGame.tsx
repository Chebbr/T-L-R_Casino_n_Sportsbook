import { useState, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import CasinoLayout from "@/components/CasinoLayout";
import GameBackground from "@/components/GameBackground";

const RED_NUMBERS = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];

type BetType = "number" | "red" | "black" | "odd" | "even" | "1-18" | "19-36" | "1st12" | "2nd12" | "3rd12";

interface Bet {
  type: BetType;
  value?: number;
  amount: number;
}

function getColor(n: number): string {
  if (n === 0) return "green";
  return RED_NUMBERS.includes(n) ? "red" : "black";
}

function calculateWinLocal(bet: Bet, result: number): number {
  switch (bet.type) {
    case "number": return bet.value === result ? bet.amount * 36 : 0;
    case "red": return RED_NUMBERS.includes(result) ? bet.amount * 2 : 0;
    case "black": return !RED_NUMBERS.includes(result) && result !== 0 ? bet.amount * 2 : 0;
    case "odd": return result > 0 && result % 2 !== 0 ? bet.amount * 2 : 0;
    case "even": return result > 0 && result % 2 === 0 ? bet.amount * 2 : 0;
    case "1-18": return result >= 1 && result <= 18 ? bet.amount * 2 : 0;
    case "19-36": return result >= 19 && result <= 36 ? bet.amount * 2 : 0;
    case "1st12": return result >= 1 && result <= 12 ? bet.amount * 3 : 0;
    case "2nd12": return result >= 13 && result <= 24 ? bet.amount * 3 : 0;
    case "3rd12": return result >= 25 && result <= 36 ? bet.amount * 3 : 0;
    default: return 0;
  }
}

const WHEEL_NUMBERS = [0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,28,12,35,3,26];

export default function RouletteGame() {
  const { user, isAuthenticated, loading } = useAuth();
  const [betAmount, setBetAmount] = useState("5");
  const [bets, setBets] = useState<Bet[]>([]);
  const [isSpinning, setIsSpinning] = useState(false);
  const [result, setResult] = useState<number | null>(null);
  const [winAmount, setWinAmount] = useState(0);
  const [rotation, setRotation] = useState(0);
  const [history, setHistory] = useState<number[]>([]);
  const [showResult, setShowResult] = useState(false);

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      window.location.href = getLoginUrl("/games/roulette");
    }
  }, [loading, isAuthenticated]);

  const balanceQuery = trpc.wallet.getBalance.useQuery(undefined, { enabled: isAuthenticated });
  const playMutation = trpc.games.playRoulette.useMutation({
    onSuccess: (data) => {
      const winningNumber = data.result;
      const idx = WHEEL_NUMBERS.indexOf(winningNumber);
      const targetAngle = (idx / 37) * 360;
      const spins = 5 + Math.random() * 3;
      const totalRotation = spins * 360 + (360 - targetAngle);
      setRotation(prev => prev + totalRotation);

      setTimeout(() => {
        setResult(winningNumber);
        setIsSpinning(false);
        setShowResult(true);
        setWinAmount(data.payout);
        setHistory(h => [winningNumber, ...h.slice(0, 14)]);
        setBets([]);
        balanceQuery.refetch();
      }, 4500);
    },
    onError: (err) => {
      setIsSpinning(false);
      toast.error(err.message);
    },
  });

  const placeBet = useCallback((type: BetType, value?: number) => {
    if (isSpinning) return;
    const amt = parseFloat(betAmount);
    if (isNaN(amt) || amt < 0.1) { toast.error("Invalid bet amount"); return; }
    setBets(prev => [...prev, { type, value, amount: amt }]);
    setShowResult(false);
  }, [isSpinning, betAmount]);

  const spin = useCallback(() => {
    if (bets.length === 0) { toast.error("Place at least one bet"); return; }
    const totalBet = bets.reduce((s, b) => s + b.amount, 0);
    const betStr = bets.map(b => b.type === "number" ? `number:${b.value}` : b.type).join(",");
    setIsSpinning(true);
    setResult(null);
    setWinAmount(0);
    setShowResult(false);
    playMutation.mutate({ bets: bets.map(b => ({ type: b.type, value: b.value, amount: b.amount })) });
  }, [bets, playMutation]);

  if (loading || !user) {
    return (
      <CasinoLayout><GameBackground>
        <div className="container py-12 text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
        </div>
      </GameBackground></CasinoLayout>
    );
  }

  return (
    <CasinoLayout><GameBackground>
      <div className="container py-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-6">
            <h1 className="text-3xl font-bold" style={{ fontFamily: "'Cinzel', serif" }}>
              <span className="text-primary">Roulette</span>
            </h1>
            <p className="text-muted-foreground text-sm mt-1">Place your bets and spin the wheel</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Left: Wheel + Controls */}
            <div className="space-y-4">
              <Card className="border-border/50 bg-card/50">
                <CardContent className="p-6 flex flex-col items-center">
                  {/* Wheel */}
                  <div className="relative w-64 h-64 sm:w-72 sm:h-72 mb-6">
                    {/* Pointer */}
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-2 z-10 w-0 h-0 border-l-[10px] border-r-[10px] border-t-[20px] border-l-transparent border-r-transparent border-t-primary drop-shadow-lg" />
                    {/* Outer ring glow */}
                    <div className="absolute inset-0 rounded-full" style={{ boxShadow: isSpinning ? "0 0 40px rgba(212,175,55,0.4)" : "0 0 20px rgba(212,175,55,0.15)" }} />
                    <motion.div
                      className="w-full h-full rounded-full border-4 border-primary/40 overflow-hidden relative"
                      style={{ background: "radial-gradient(circle, #1a1a2e 30%, #0a0a1a 100%)" }}
                      animate={{ rotate: rotation }}
                      transition={{ duration: 4.5, ease: [0.17, 0.67, 0.12, 0.99] }}
                    >
                      {WHEEL_NUMBERS.map((num, i) => {
                        const angle = (i / 37) * 360;
                        const color = getColor(num);
                        return (
                          <div key={num} className="absolute w-full h-full" style={{ transform: `rotate(${angle}deg)` }}>
                            <div className={`absolute top-1 left-1/2 -translate-x-1/2 w-6 h-8 flex items-center justify-center text-[9px] font-bold text-white rounded-sm ${
                              color === "red" ? "bg-red-600" : color === "black" ? "bg-gray-800" : "bg-green-600"
                            }`}>
                              {num}
                            </div>
                          </div>
                        );
                      })}
                      {/* Center */}
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary/30 to-primary/10 border-2 border-primary/30 flex items-center justify-center">
                          <span className="text-primary text-xs font-bold" style={{ fontFamily: "'Cinzel', serif" }}>LR</span>
                        </div>
                      </div>
                    </motion.div>
                  </div>

                  {/* Result Display */}
                  <AnimatePresence>
                    {showResult && result !== null && (
                      <motion.div
                        initial={{ scale: 0, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0, opacity: 0 }}
                        className="text-center mb-4"
                      >
                        <motion.div
                          className={`inline-flex items-center gap-2 px-8 py-4 rounded-xl text-white font-bold text-3xl shadow-lg ${
                            getColor(result) === "red" ? "bg-red-600 shadow-red-500/30" : getColor(result) === "black" ? "bg-gray-800 shadow-gray-500/30" : "bg-green-600 shadow-green-500/30"
                          }`}
                          animate={{ scale: [1, 1.1, 1] }}
                          transition={{ duration: 0.5 }}
                        >
                          {result}
                        </motion.div>
                        {winAmount > 0 ? (
                          <motion.p
                            className="text-green-400 font-bold text-2xl mt-3"
                            style={{ textShadow: "0 0 20px rgba(34,197,94,0.4)" }}
                            animate={{ scale: [1, 1.2, 1] }}
                            transition={{ duration: 0.6 }}
                          >
                            +${winAmount.toFixed(2)}
                          </motion.p>
                        ) : (
                          <p className="text-red-400 text-sm mt-3">No win this round</p>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <Button
                    onClick={spin}
                    disabled={isSpinning || bets.length === 0 || playMutation.isPending}
                    className="bg-primary hover:bg-primary/90 text-primary-foreground px-10 py-3 text-lg"
                  >
                    {isSpinning ? "Spinning..." : "Spin!"}
                  </Button>
                </CardContent>
              </Card>

              {/* Balance + Chip */}
              <div className="grid grid-cols-2 gap-4">
                <Card className="border-border/50">
                  <CardContent className="p-4">
                    <p className="text-xs text-muted-foreground">Balance</p>
                    <p className="text-xl font-bold text-primary">${balanceQuery.data?.balance || "0.00"}</p>
                  </CardContent>
                </Card>
                <Card className="border-border/50">
                  <CardContent className="p-4">
                    <p className="text-xs text-muted-foreground mb-1">Chip Size</p>
                    <Input
                      type="number"
                      value={betAmount}
                      onChange={(e) => setBetAmount(e.target.value)}
                      min="0.1"
                      className="bg-muted/50 h-8 text-sm"
                    />
                  </CardContent>
                </Card>
              </div>

              {/* Quick chips */}
              <div className="grid grid-cols-5 gap-1">
                {[1, 5, 10, 25, 50].map(v => (
                  <Button key={v} variant="outline" size="sm" onClick={() => setBetAmount(v.toString())} className="text-xs">
                    ${v}
                  </Button>
                ))}
              </div>

              {/* History */}
              {history.length > 0 && (
                <Card className="border-border/50">
                  <CardContent className="p-3">
                    <p className="text-xs text-muted-foreground mb-2">History</p>
                    <div className="flex flex-wrap gap-1.5">
                      {history.map((n, i) => (
                        <motion.span
                          key={`${i}-${n}`}
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className={`w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-bold text-white ${
                            getColor(n) === "red" ? "bg-red-600" : getColor(n) === "black" ? "bg-gray-700" : "bg-green-600"
                          }`}
                        >
                          {n}
                        </motion.span>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Right: Betting Board */}
            <div className="space-y-4">
              <Card className="border-border/50 bg-card/50">
                <CardHeader>
                  <CardTitle className="text-sm">Betting Board</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {/* Number grid */}
                  <div className="grid grid-cols-6 gap-1">
                    <button
                      onClick={() => placeBet("number", 0)}
                      className="col-span-6 py-2.5 rounded bg-green-700 hover:bg-green-600 text-white text-sm font-bold transition-all hover:scale-[1.02] active:scale-95"
                    >
                      0
                    </button>
                    {Array.from({ length: 36 }, (_, i) => i + 1).map(n => (
                      <motion.button
                        key={n}
                        onClick={() => placeBet("number", n)}
                        className={`py-2 rounded text-white text-xs font-bold transition-all ${
                          RED_NUMBERS.includes(n) ? "bg-red-700 hover:bg-red-600" : "bg-gray-700 hover:bg-gray-600"
                        }`}
                        whileHover={{ scale: 1.08 }}
                        whileTap={{ scale: 0.92 }}
                      >
                        {n}
                      </motion.button>
                    ))}
                  </div>

                  {/* Dozen bets */}
                  <div className="grid grid-cols-3 gap-1">
                    {[
                      { label: "1st 12", type: "1st12" as BetType },
                      { label: "2nd 12", type: "2nd12" as BetType },
                      { label: "3rd 12", type: "3rd12" as BetType },
                    ].map(b => (
                      <button key={b.type} onClick={() => placeBet(b.type)}
                        className="py-2.5 rounded bg-secondary hover:bg-secondary/80 text-foreground text-xs font-medium transition-all hover:scale-[1.02]">
                        {b.label}
                      </button>
                    ))}
                  </div>

                  {/* Outside bets */}
                  <div className="grid grid-cols-6 gap-1">
                    {[
                      { label: "1-18", type: "1-18" as BetType, cls: "bg-secondary hover:bg-secondary/80 text-foreground" },
                      { label: "Even", type: "even" as BetType, cls: "bg-secondary hover:bg-secondary/80 text-foreground" },
                      { label: "Red", type: "red" as BetType, cls: "bg-red-700 hover:bg-red-600 text-white" },
                      { label: "Black", type: "black" as BetType, cls: "bg-gray-700 hover:bg-gray-600 text-white" },
                      { label: "Odd", type: "odd" as BetType, cls: "bg-secondary hover:bg-secondary/80 text-foreground" },
                      { label: "19-36", type: "19-36" as BetType, cls: "bg-secondary hover:bg-secondary/80 text-foreground" },
                    ].map(b => (
                      <button key={b.type} onClick={() => placeBet(b.type)}
                        className={`py-2.5 rounded text-xs font-medium transition-all hover:scale-[1.02] ${b.cls}`}>
                        {b.label}
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Active Bets */}
              {bets.length > 0 && (
                <Card className="border-primary/30">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-sm font-medium">Active Bets</p>
                      <button onClick={() => setBets([])} className="text-xs text-destructive hover:underline">Clear All</button>
                    </div>
                    <div className="flex flex-wrap gap-1.5 mb-2">
                      {bets.map((b, i) => (
                        <motion.span
                          key={i}
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="px-2 py-1 rounded bg-secondary text-xs font-medium"
                        >
                          ${b.amount} on {b.type === "number" ? `#${b.value}` : b.type}
                        </motion.span>
                      ))}
                    </div>
                    <p className="text-sm text-primary font-bold">Total: ${bets.reduce((s, b) => s + b.amount, 0).toFixed(2)}</p>
                  </CardContent>
                </Card>
              )}

              {/* How to Play */}
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">How to Play</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>1. Select your chip size and place bets on the board</p>
                  <p>2. Bet on specific numbers (36x), colors (2x), or ranges (2-3x)</p>
                  <p>3. Click Spin and watch the wheel decide your fate!</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </GameBackground></CasinoLayout>
  );
}
