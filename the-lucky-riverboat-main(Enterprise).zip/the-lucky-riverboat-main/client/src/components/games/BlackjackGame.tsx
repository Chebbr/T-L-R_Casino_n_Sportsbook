import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import CasinoLayout from "@/components/CasinoLayout";
import GameBackground from "@/components/GameBackground";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

const suits = ["♠", "♥", "♦", "♣"];
const values = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];

interface GameCard {
  suit: string;
  value: string;
}

export default function BlackjackGame() {
  const { user } = useAuth();
  const [betAmount, setBetAmount] = useState(10);
  const [gameActive, setGameActive] = useState(false);
  const [playerCards, setPlayerCards] = useState<GameCard[]>([]);
  const [dealerCards, setDealerCards] = useState<GameCard[]>([]);
  const [dealerRevealed, setDealerRevealed] = useState(false);
  const [gameResult, setGameResult] = useState<string | null>(null);
  const [payout, setPayout] = useState(0);

  const getCardValue = (card: GameCard): number => {
    if (card.value === "A") return 11;
    if (["J", "Q", "K"].includes(card.value)) return 10;
    return parseInt(card.value);
  };

  const calculateHandValue = (cards: GameCard[]): number => {
    let value = 0;
    let aces = 0;
    for (const card of cards) {
      const cardValue = getCardValue(card);
      if (card.value === "A") aces++;
      value += cardValue;
    }
    while (value > 21 && aces > 0) {
      value -= 10;
      aces--;
    }
    return value;
  };

  const generateCard = (): GameCard => ({
    suit: suits[Math.floor(Math.random() * suits.length)],
    value: values[Math.floor(Math.random() * values.length)],
  });

  const startGame = () => {
    if (!user || Number(user.balance) < betAmount) {
      toast.error("Insufficient balance");
      return;
    }

    const newPlayerCards = [generateCard(), generateCard()];
    const newDealerCards = [generateCard(), generateCard()];

    setPlayerCards(newPlayerCards);
    setDealerCards(newDealerCards);
    setGameActive(true);
    setGameResult(null);
    setDealerRevealed(false);
    setPayout(0);

    // Check for blackjack
    if (calculateHandValue(newPlayerCards) === 21) {
      setGameResult("Blackjack! You win!");
      setPayout(betAmount * 2.5);
      setGameActive(false);
      setDealerRevealed(true);
    }
  };

  const hit = () => {
    const newCards = [...playerCards, generateCard()];
    setPlayerCards(newCards);

    if (calculateHandValue(newCards) > 21) {
      setGameResult("Bust! You lose!");
      setPayout(0);
      setGameActive(false);
      setDealerRevealed(true);
    }
  };

  const stand = () => {
    setDealerRevealed(true);
    let dealerHand = [...dealerCards];

    while (calculateHandValue(dealerHand) < 17) {
      dealerHand.push(generateCard());
    }

    const playerValue = calculateHandValue(playerCards);
    const dealerValue = calculateHandValue(dealerHand);

    let result = "";
    let payout = 0;

    if (dealerValue > 21) {
      result = "Dealer bust! You win!";
      payout = betAmount * 2;
    } else if (playerValue > dealerValue) {
      result = "You win!";
      payout = betAmount * 2;
    } else if (dealerValue > playerValue) {
      result = "Dealer wins!";
      payout = 0;
    } else {
      result = "Push!";
      payout = betAmount;
    }

    setGameResult(result);
    setPayout(payout);
    setGameActive(false);
    setDealerCards(dealerHand);
  };

  const playerValue = calculateHandValue(playerCards);
  const dealerValue = dealerRevealed ? calculateHandValue(dealerCards) : getCardValue(dealerCards[0]);

  return (
    <CasinoLayout><GameBackground>
      <div className="min-h-screen bg-background text-foreground py-8">
        <div className="container max-w-2xl">
          <Card className="border-border/50 bg-card/50">
            <CardHeader>
              <CardTitle className="text-gold">🎰 Blackjack</CardTitle>
              <CardDescription>Beat the dealer without going over 21</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Game Area */}
              <div className="bg-gradient-to-b from-green-900/20 to-green-950/20 rounded-lg p-8 space-y-6">
                {/* Dealer Cards */}
                <div className="space-y-2">
                  <p className="text-sm font-semibold text-muted-foreground">Dealer</p>
                  <div className="flex gap-3">
                    {dealerCards.map((card, i) => (
                      <div
                        key={i}
                        className="w-16 h-24 bg-white rounded-lg border-2 border-gold flex items-center justify-center font-bold text-lg shadow-lg"
                      >
                        {dealerRevealed ? (
                          <>
                            <span className={card.suit === "♥" || card.suit === "♦" ? "text-red-600" : "text-black"}>
                              {card.value}
                              {card.suit}
                            </span>
                          </>
                        ) : i === 0 ? (
                          <>
                            <span className={card.suit === "♥" || card.suit === "♦" ? "text-red-600" : "text-black"}>
                              {card.value}
                              {card.suit}
                            </span>
                          </>
                        ) : (
                          <span className="text-muted-foreground">?</span>
                        )}
                      </div>
                    ))}
                  </div>
                  {dealerRevealed && (
                    <p className="text-xs text-muted-foreground">
                      Dealer: {dealerValue} {dealerValue > 21 ? "(Bust!)" : ""}
                    </p>
                  )}
                </div>

                {/* Player Cards */}
                <div className="space-y-2">
                  <p className="text-sm font-semibold text-muted-foreground">Your Hand</p>
                  <div className="flex gap-3">
                    {playerCards.map((card, i) => (
                      <div
                        key={i}
                        className="w-16 h-24 bg-white rounded-lg border-2 border-gold flex items-center justify-center font-bold text-lg shadow-lg"
                      >
                        <span className={card.suit === "♥" || card.suit === "♦" ? "text-red-600" : "text-black"}>
                          {card.value}
                          {card.suit}
                        </span>
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Your Total: {playerValue} {playerValue > 21 ? "(Bust!)" : ""}
                  </p>
                </div>
              </div>

              {/* Game Result */}
              {gameResult && (
                <div className={`p-4 rounded-lg text-center font-semibold ${gameResult.includes("win") ? "bg-green-500/20 text-green-500" : gameResult.includes("Bust") ? "bg-red-500/20 text-red-500" : "bg-yellow-500/20 text-yellow-500"}`}>
                  {gameResult}
                  {payout > 0 && <p className="text-sm mt-1">Payout: ${payout.toFixed(2)}</p>}
                </div>
              )}

              {/* Betting */}
              {!gameActive && !gameResult && (
                <div className="space-y-3">
                  <div>
                    <Label>Bet Amount ($)</Label>
                    <Input
                      type="number"
                      value={betAmount}
                      onChange={(e) => setBetAmount(Number(e.target.value))}
                      min="1"
                      max={Number(user?.balance || 0)}
                      className="mt-1"
                    />
                  </div>
                  <Button onClick={startGame} className="w-full bg-gold hover:bg-gold/90 text-black font-bold">
                    Deal
                  </Button>
                </div>
              )}

              {/* Game Controls */}
              {gameActive && (
                <div className="flex gap-3">
                  <Button onClick={hit} className="flex-1 bg-blue-600 hover:bg-blue-700">
                    Hit
                  </Button>
                  <Button onClick={stand} className="flex-1 bg-red-600 hover:bg-red-700">
                    Stand
                  </Button>
                </div>
              )}

              {gameResult && (
                <Button onClick={() => setGameResult(null)} className="w-full bg-gold hover:bg-gold/90 text-black font-bold">
                  Play Again
                </Button>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </GameBackground></CasinoLayout>
  );
}
