import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import CasinoLayout from "@/components/CasinoLayout";
import GameBackground from "@/components/GameBackground";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

const symbols = ["🍒", "🍊", "🍋", "🔔", "⭐", "💎", "7️⃣"];
const symbolNames: Record<string, string> = {
  "🍒": "Cherry",
  "🍊": "Orange",
  "🍋": "Lemon",
  "🔔": "Bell",
  "⭐": "Star",
  "💎": "Diamond",
  "7️⃣": "Seven",
};

const payouts: Record<string, number> = {
  "🍒🍒🍒": 2,
  "🍊🍊🍊": 3,
  "🍋🍋🍋": 4,
  "🔔🔔🔔": 5,
  "⭐⭐⭐": 10,
  "💎💎💎": 25,
  "7️⃣7️⃣7️⃣": 100,
};

export default function SlotsGame() {
  const { user } = useAuth();
  const [betAmount, setBetAmount] = useState(10);
  const [spinning, setSpinning] = useState(false);
  const [reels, setReels] = useState<string[]>(["🍒", "🍒", "🍒"]);
  const [result, setResult] = useState<string | null>(null);
  const [payout, setPayout] = useState(0);

  const spin = () => {
    if (!user || Number(user.balance) < betAmount) {
      toast.error("Insufficient balance");
      return;
    }

    setSpinning(true);
    setResult(null);
    setPayout(0);

    // Animate spinning
    let spins = 0;
    const spinInterval = setInterval(() => {
      setReels([
        symbols[Math.floor(Math.random() * symbols.length)],
        symbols[Math.floor(Math.random() * symbols.length)],
        symbols[Math.floor(Math.random() * symbols.length)],
      ]);
      spins++;

      if (spins > 20) {
        clearInterval(spinInterval);

        // Final result
        const finalReels = [
          symbols[Math.floor(Math.random() * symbols.length)],
          symbols[Math.floor(Math.random() * symbols.length)],
          symbols[Math.floor(Math.random() * symbols.length)],
        ];
        setReels(finalReels);

        const combination = finalReels.join("");
        const multiplier = payouts[combination] || 0;

        if (multiplier > 0) {
          setResult(`🎉 ${finalReels.join(" ")} - Winner!`);
          setPayout(betAmount * multiplier);
        } else {
          setResult(`${finalReels.join(" ")} - No match`);
          setPayout(0);
        }

        setSpinning(false);
      }
    }, 100);
  };

  return (
    <CasinoLayout><GameBackground>
      <div className="min-h-screen bg-background text-foreground py-8">
        <div className="container max-w-2xl">
          <Card className="border-border/50 bg-card/50">
            <CardHeader>
              <CardTitle className="text-gold">🎰 Slots</CardTitle>
              <CardDescription>Match three symbols to win big!</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Slot Machine */}
              <div className="bg-gradient-to-b from-red-900/20 to-red-950/20 rounded-lg p-8">
                <div className="flex justify-center gap-4 mb-6">
                  {reels.map((symbol, i) => (
                    <div
                      key={i}
                      className={`w-24 h-24 bg-gradient-to-b from-yellow-600 to-yellow-800 rounded-lg border-4 border-gold flex items-center justify-center text-5xl shadow-lg ${
                        spinning ? "animate-bounce" : ""
                      }`}
                    >
                      {symbol}
                    </div>
                  ))}
                </div>

                {/* Payout Table */}
                <div className="bg-black/30 rounded-lg p-4 text-xs space-y-1">
                  <p className="text-gold font-bold mb-2">Payouts:</p>
                  <p>🍒🍒🍒 = 2x | 🍊🍊🍊 = 3x | 🍋🍋🍋 = 4x</p>
                  <p>🔔🔔🔔 = 5x | ⭐⭐⭐ = 10x | 💎💎💎 = 25x</p>
                  <p>7️⃣7️⃣7️⃣ = 100x</p>
                </div>
              </div>

              {/* Result */}
              {result && (
                <div className={`p-4 rounded-lg text-center font-semibold ${payout > 0 ? "bg-green-500/20 text-green-500" : "bg-red-500/20 text-red-500"}`}>
                  {result}
                  {payout > 0 && <p className="text-sm mt-1">Payout: ${payout.toFixed(2)}</p>}
                </div>
              )}

              {/* Betting */}
              <div className="space-y-3">
                <div>
                  <Label>Bet Amount ($)</Label>
                  <Input
                    type="number"
                    value={betAmount}
                    onChange={(e) => setBetAmount(Number(e.target.value))}
                    min="1"
                    max={Number(user?.balance || 0)}
                    disabled={spinning}
                    className="mt-1"
                  />
                </div>
                <Button
                  onClick={spin}
                  disabled={spinning}
                  className="w-full bg-gold hover:bg-gold/90 text-black font-bold disabled:opacity-50"
                >
                  {spinning ? "Spinning..." : "SPIN"}
                </Button>
              </div>

              {result && (
                <Button onClick={() => setResult(null)} className="w-full bg-gold hover:bg-gold/90 text-black font-bold">
                  Spin Again
                </Button>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </GameBackground></CasinoLayout>
  );
}
