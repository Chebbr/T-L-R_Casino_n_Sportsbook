import { useState, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import CasinoLayout from "@/components/CasinoLayout";
import GameBackground from "@/components/GameBackground";

const SEGMENTS = [
  { label: "2x", multiplier: 2, color: "#b91c1c", weight: 30 },
  { label: "3x", multiplier: 3, color: "#7c3aed", weight: 20 },
  { label: "5x", multiplier: 5, color: "#2563eb", weight: 15 },
  { label: "1x", multiplier: 1, color: "#374151", weight: 25 },
  { label: "10x", multiplier: 10, color: "#059669", weight: 6 },
  { label: "0x", multiplier: 0, color: "#1f2937", weight: 20 },
  { label: "2x", multiplier: 2, color: "#b91c1c", weight: 30 },
  { label: "50x", multiplier: 50, color: "#d97706", weight: 1 },
  { label: "3x", multiplier: 3, color: "#7c3aed", weight: 20 },
  { label: "1x", multiplier: 1, color: "#374151", weight: 25 },
  { label: "5x", multiplier: 5, color: "#2563eb", weight: 15 },
  { label: "0x", multiplier: 0, color: "#1f2937", weight: 20 },
];

export default function HelmGame() {
  const { user, isAuthenticated, loading } = useAuth();
  const [betAmount, setBetAmount] = useState("5");
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [result, setResult] = useState<{ segment: typeof SEGMENTS[0]; win: number } | null>(null);
  const [history, setHistory] = useState<{ mult: number; win: number }[]>([]);

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      window.location.href = getLoginUrl("/games/helm");
    }
  }, [loading, isAuthenticated]);

  const balanceQuery = trpc.wallet.getBalance.useQuery(undefined, { enabled: isAuthenticated });
  const playMutation = trpc.games.playHelm.useMutation({
    onSuccess: (data) => {
      const segIndex = data.segmentId - 1; // segmentId is 1-indexed
      const segAngle = 360 / SEGMENTS.length;
      const targetAngle = 360 - (segIndex * segAngle + segAngle / 2);
      const spins = 5 + Math.random() * 3;
      const totalRotation = spins * 360 + targetAngle;
      setRotation(prev => prev + totalRotation);

      setTimeout(() => {
        const seg = SEGMENTS[segIndex] || SEGMENTS[0];
        setResult({ segment: seg, win: data.payout });
        const segM = SEGMENTS[segIndex]?.multiplier || 0;
        setHistory(h => [{ mult: segM, win: data.payout }, ...h.slice(0, 14)]);
        setIsSpinning(false);
        balanceQuery.refetch();
      }, 4500);
    },
    onError: (err) => {
      setIsSpinning(false);
      toast.error(err.message);
    },
  });

  const spin = useCallback(() => {
    const amount = parseFloat(betAmount);
    if (isNaN(amount) || amount < 0.1) { toast.error("Invalid bet amount"); return; }
    setIsSpinning(true);
    setResult(null);
    playMutation.mutate({ betAmount: amount, selectedSegment: 0 });
  }, [betAmount, playMutation]);

  const segAngle = 360 / SEGMENTS.length;

  if (loading || !user) {
    return (
      <CasinoLayout><GameBackground>
        <div className="container py-12 text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
        </div>
      </GameBackground></CasinoLayout>
    );
  }

  return (
    <CasinoLayout><GameBackground>
      <div className="container py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-6">
            <h1 className="text-3xl font-bold" style={{ fontFamily: "'Cinzel', serif" }}>
              <span className="text-primary">Helm</span>
            </h1>
            <p className="text-muted-foreground text-sm mt-1">Spin the captain's wheel for treasure</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Wheel Area */}
            <div className="lg:col-span-2">
              <Card className="border-border/50 bg-card/50">
                <CardContent className="p-6 flex flex-col items-center">
                  <div className="relative w-72 h-72 sm:w-80 sm:h-80 mb-4">
                    {/* Pointer */}
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-2 z-10 w-0 h-0 border-l-[12px] border-r-[12px] border-t-[24px] border-l-transparent border-r-transparent border-t-primary drop-shadow-lg" />
                    {/* Glow effect */}
                    <div
                      className="absolute inset-0 rounded-full transition-all duration-500"
                      style={{
                        boxShadow: isSpinning
                          ? "0 0 50px rgba(212,175,55,0.5), 0 0 100px rgba(212,175,55,0.2)"
                          : "0 0 20px rgba(212,175,55,0.15)",
                      }}
                    />

                    <motion.svg
                      viewBox="0 0 200 200"
                      className="w-full h-full drop-shadow-2xl"
                      animate={{ rotate: rotation }}
                      transition={{ duration: 4.5, ease: [0.17, 0.67, 0.12, 0.99] }}
                    >
                      {/* Outer ring */}
                      <circle cx="100" cy="100" r="98" fill="none" stroke="rgba(212,168,67,0.3)" strokeWidth="2" />
                      {SEGMENTS.map((seg, i) => {
                        const startAngle = (i * segAngle * Math.PI) / 180;
                        const endAngle = ((i + 1) * segAngle * Math.PI) / 180;
                        const x1 = 100 + 95 * Math.cos(startAngle);
                        const y1 = 100 + 95 * Math.sin(startAngle);
                        const x2 = 100 + 95 * Math.cos(endAngle);
                        const y2 = 100 + 95 * Math.sin(endAngle);
                        const midAngle = (startAngle + endAngle) / 2;
                        const textX = 100 + 65 * Math.cos(midAngle);
                        const textY = 100 + 65 * Math.sin(midAngle);
                        const textRotation = (midAngle * 180) / Math.PI + 90;

                        return (
                          <g key={i}>
                            <path
                              d={`M100,100 L${x1},${y1} A95,95 0 0,1 ${x2},${y2} Z`}
                              fill={seg.color}
                              stroke="rgba(255,255,255,0.08)"
                              strokeWidth="0.5"
                            />
                            {/* Decorative dots on edge */}
                            <circle
                              cx={100 + 88 * Math.cos(midAngle)}
                              cy={100 + 88 * Math.sin(midAngle)}
                              r="2"
                              fill="rgba(255,255,255,0.3)"
                            />
                            <text
                              x={textX}
                              y={textY}
                              fill="white"
                              fontSize="11"
                              fontWeight="bold"
                              textAnchor="middle"
                              dominantBaseline="middle"
                              transform={`rotate(${textRotation}, ${textX}, ${textY})`}
                              style={{ textShadow: "0 1px 3px rgba(0,0,0,0.5)" }}
                            >
                              {seg.label}
                            </text>
                          </g>
                        );
                      })}
                      {/* Center hub */}
                      <circle cx="100" cy="100" r="22" fill="#0a0a1a" stroke="rgba(212,168,67,0.5)" strokeWidth="2" />
                      <circle cx="100" cy="100" r="18" fill="#1a1a2e" stroke="rgba(212,168,67,0.3)" strokeWidth="1" />
                      <text x="100" y="97" fill="#d4a843" fontSize="7" fontWeight="bold" textAnchor="middle" dominantBaseline="middle" style={{ fontFamily: "'Cinzel', serif" }}>THE</text>
                      <text x="100" y="106" fill="#d4a843" fontSize="8" fontWeight="bold" textAnchor="middle" dominantBaseline="middle" style={{ fontFamily: "'Cinzel', serif" }}>HELM</text>
                    </motion.svg>
                  </div>

                  {/* Result Display */}
                  <AnimatePresence>
                    {result && !isSpinning && (
                      <motion.div
                        initial={{ scale: 0, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0, opacity: 0 }}
                        className="text-center mb-4"
                      >
                        <motion.p
                          className="text-2xl font-bold mb-1"
                          style={{ color: result.segment.color }}
                          animate={{ scale: [1, 1.15, 1] }}
                          transition={{ duration: 0.5 }}
                        >
                          {result.segment.label}
                        </motion.p>
                        {result.win > 0 ? (
                          <motion.p
                            className="text-3xl font-bold text-green-400"
                            style={{ textShadow: "0 0 20px rgba(34,197,94,0.4)" }}
                            animate={{ scale: [1, 1.25, 1] }}
                            transition={{ duration: 0.6 }}
                          >
                            +${result.win.toFixed(2)}
                          </motion.p>
                        ) : (
                          <p className="text-red-400">No win this round</p>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <Button
                    onClick={spin}
                    disabled={isSpinning || playMutation.isPending}
                    className="bg-primary hover:bg-primary/90 text-primary-foreground px-10 py-3 text-lg"
                  >
                    {isSpinning ? "Spinning..." : "Spin the Helm!"}
                  </Button>
                </CardContent>
              </Card>

              {/* History */}
              {history.length > 0 && (
                <div className="flex flex-wrap justify-center gap-2 mt-4">
                  {history.map((h, i) => (
                    <motion.span
                      key={`${i}-${h.mult}`}
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className={`px-3 py-1 rounded-full text-xs font-bold ${
                        h.win > 0 ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"
                      }`}
                    >
                      {h.mult}x {h.win > 0 ? `+$${h.win.toFixed(0)}` : ""}
                    </motion.span>
                  ))}
                </div>
              )}
            </div>

            {/* Controls */}
            <div className="space-y-4">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">Balance</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-primary">${balanceQuery.data?.balance || "0.00"}</p>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">Bet Amount</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Input
                    type="number"
                    value={betAmount}
                    onChange={(e) => setBetAmount(e.target.value)}
                    min="0.1"
                    step="0.1"
                    disabled={isSpinning}
                    className="bg-muted/50"
                  />
                  <div className="grid grid-cols-4 gap-1">
                    {[1, 5, 10, 25].map((v) => (
                      <Button key={v} variant="outline" size="sm" onClick={() => setBetAmount(v.toString())} disabled={isSpinning} className="text-xs">
                        ${v}
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">Multipliers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { label: "50x", color: "#d97706", desc: "Jackpot" },
                      { label: "10x", color: "#059669", desc: "Big Win" },
                      { label: "5x", color: "#2563eb", desc: "Great" },
                      { label: "3x", color: "#7c3aed", desc: "Good" },
                      { label: "2x", color: "#b91c1c", desc: "Nice" },
                      { label: "1x", color: "#374151", desc: "Push" },
                    ].map((m) => (
                      <div key={m.label} className="flex items-center gap-2 p-2 rounded bg-muted/30">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: m.color }} />
                        <div>
                          <span className="text-xs font-bold" style={{ color: m.color }}>{m.label}</span>
                          <span className="text-[10px] text-muted-foreground ml-1">{m.desc}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-sm">How to Play</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>1. Set your bet amount</p>
                  <p>2. Spin the captain's wheel</p>
                  <p>3. Land on a multiplier to win!</p>
                  <p>4. The 50x jackpot is the ultimate prize</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </GameBackground></CasinoLayout>
  );
}
