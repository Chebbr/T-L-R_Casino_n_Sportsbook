import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { useState, useRef, useEffect } from "react";
import ChatOverlay from "./ChatOverlay";
import {
  Home,
  Gamepad2,
  Trophy,
  LayoutDashboard,
  Wallet,
  User,
  LogOut,
  Menu,
  X,
  ChevronDown,
  Settings,
  LifeBuoy,
  Film,
} from "lucide-react";

const games = [
  { name: "Riverboat Keno", path: "/games/keno", icon: "🎱" },
  { name: "Beached", path: "/games/crash", icon: "🚀" },
  { name: "Roulette", path: "/games/roulette", icon: "🎰" },
  { name: "Helm", path: "/games/helm", icon: "🎡" },
  { name: "Walk the Plank", path: "/games/tower", icon: "🏴‍☠️" },
  { name: "Hidden Treasure", path: "/games/mines", icon: "💎" },
  { name: "Hitide Lowtide", path: "/games/hilow", icon: "🃏" },
  { name: "Blackjack", path: "/games/blackjack", icon: "🂡" },
  { name: "Plinko", path: "/games/plinko", icon: "🎯" },
  { name: "Slots", path: "/games/slots", icon: "🎲" },
];

export default function CasinoLayout({ children }: { children: React.ReactNode }) {
  const { user, isAuthenticated, logout } = useAuth();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [gamesDropdownOpen, setGamesDropdownOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const gamesRef = useRef<HTMLDivElement>(null);
  const userRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (gamesRef.current && !gamesRef.current.contains(e.target as Node)) {
        setGamesDropdownOpen(false);
      }
      if (userRef.current && !userRef.current.contains(e.target as Node)) {
        setUserDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const isActive = (path: string) => location === path;
  const isGameActive = location.startsWith("/games/");

  const handleLogout = async () => {
    await logout();
    window.location.href = "/";
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 border-b border-border/50 bg-background/95 backdrop-blur-md">
        <div className="container flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 shrink-0">
            <img
              src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663338939905/jDATDafdqAAkgCRY.png"
              alt="The Lucky Riverboat"
              className="h-16 w-16 rounded-full object-cover flex-shrink-0"
            />
            <span className="text-xl font-bold text-gold hidden sm:block" style={{ fontFamily: "'Cinzel', serif" }}>
              The Lucky Riverboat
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-2">
            <Link href="/">
              <Button
                variant="ghost"
                className={`gap-2 ${isActive("/") ? "text-primary bg-primary/10" : "text-muted-foreground hover:text-foreground"}`}
              >
                <Home className="h-4 w-4" />
                Home
              </Button>
            </Link>

            {/* Games Dropdown */}
            <div className="relative" ref={gamesRef}>
              <Button
                variant="ghost"
                className={`gap-2 ${isGameActive ? "text-primary bg-primary/10" : "text-muted-foreground hover:text-foreground"}`}
                onClick={() => setGamesDropdownOpen(!gamesDropdownOpen)}
              >
                <Gamepad2 className="h-4 w-4" />
                Games
                <ChevronDown className={`h-3 w-3 transition-transform ${gamesDropdownOpen ? "rotate-180" : ""}`} />
              </Button>
              {gamesDropdownOpen && (
                <div className="absolute top-full left-0 mt-1 w-56 bg-card border border-border rounded-lg shadow-xl py-2 z-50">
                  {games.map((game) => (
                    <Link key={game.path} href={game.path}>
                      <button
                        className={`w-full text-left px-4 py-2.5 flex items-center gap-3 hover:bg-muted/50 transition-colors ${
                          isActive(game.path) ? "text-primary bg-primary/10" : "text-foreground"
                        }`}
                        onClick={() => setGamesDropdownOpen(false)}
                      >
                        <span className="text-lg">{game.icon}</span>
                        <span className="text-sm font-medium">{game.name}</span>
                      </button>
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <Link href="/sportsbook">
              <Button
                variant="ghost"
                className={`gap-2 ${isActive("/sportsbook") ? "text-primary bg-primary/10" : "text-muted-foreground hover:text-foreground"}`}
              >
                <Trophy className="h-4 w-4" />
                Sportsbook
              </Button>
            </Link>

            <Link href="/dashboard">
              <Button
                variant="ghost"
                className={`gap-2 ${isActive("/dashboard") ? "text-primary bg-primary/10" : "text-muted-foreground hover:text-foreground"}`}
              >
                <LayoutDashboard className="h-4 w-4" />
                Dashboard
              </Button>
            </Link>

            <Link href="/wallet">
              <Button
                variant="ghost"
                className={`gap-2 ${isActive("/wallet") ? "text-primary bg-primary/10" : "text-muted-foreground hover:text-foreground"}`}
              >
                <Wallet className="h-4 w-4" />
                Wallet
              </Button>
            </Link>

            <Link href="/support">
              <Button
                variant="ghost"
                className={`gap-2 ${isActive("/support") ? "text-primary bg-primary/10" : "text-muted-foreground hover:text-foreground"}`}
              >
                <LifeBuoy className="h-4 w-4" />
                Support
              </Button>
            </Link>

            <Link href="/studio">
              <Button
                variant="ghost"
                className={`gap-2 ${isActive("/studio") ? "text-primary bg-primary/10" : "text-muted-foreground hover:text-foreground"}`}
              >
                <Film className="h-4 w-4" />
                Studio
              </Button>
            </Link>
          </div>

          {/* User Area */}
          <div className="flex items-center gap-2">
            {isAuthenticated && user ? (
              <div className="relative" ref={userRef}>
                <Button
                  variant="ghost"
                  className="gap-2"
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                >
                  <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                    <span className="text-sm font-bold text-primary">
                      {user.name?.charAt(0)?.toUpperCase() || "U"}
                    </span>
                  </div>
                  <span className="hidden sm:block text-sm">{user.name || "Player"}</span>
                  <ChevronDown className="h-3 w-3" />
                </Button>
                {userDropdownOpen && (
                  <div className="absolute top-full right-0 mt-1 w-48 bg-card border border-border rounded-lg shadow-xl py-2 z-50">
                    <Link href="/profile">
                      <button
                        className="w-full text-left px-4 py-2.5 flex items-center gap-3 hover:bg-muted/50 transition-colors text-sm"
                        onClick={() => setUserDropdownOpen(false)}
                      >
                        <User className="h-4 w-4" />
                        Profile
                      </button>
                    </Link>
                    <Link href="/dashboard">
                      <button
                        className="w-full text-left px-4 py-2.5 flex items-center gap-3 hover:bg-muted/50 transition-colors text-sm"
                        onClick={() => setUserDropdownOpen(false)}
                      >
                        <LayoutDashboard className="h-4 w-4" />
                        Dashboard
                      </button>
                    </Link>
                    <Link href="/wallet">
                      <button
                        className="w-full text-left px-4 py-2.5 flex items-center gap-3 hover:bg-muted/50 transition-colors text-sm"
                        onClick={() => setUserDropdownOpen(false)}
                      >
                        <Wallet className="h-4 w-4" />
                        Wallet
                      </button>
                    </Link>
                    {user.role === "admin" && (
                      <Link href="/admin">
                        <button
                          className="w-full text-left px-4 py-2.5 flex items-center gap-3 hover:bg-muted/50 transition-colors text-sm text-gold"
                          onClick={() => setUserDropdownOpen(false)}
                        >
                          <Settings className="h-4 w-4" />
                          Admin Dashboard
                        </button>
                      </Link>
                    )}
                    <hr className="my-1 border-border" />
                    <button
                      className="w-full text-left px-4 py-2.5 flex items-center gap-3 hover:bg-muted/50 transition-colors text-sm text-red-400"
                      onClick={handleLogout}
                    >
                      <LogOut className="h-4 w-4" />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Button
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
                onClick={() => { window.location.href = getLoginUrl(); }}
              >
                Sign In
              </Button>
            )}

            {/* Mobile menu toggle */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-border bg-card">
            <div className="container py-4 space-y-1">
              <Link href="/">
                <button
                  className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 ${
                    isActive("/") ? "bg-primary/10 text-primary" : "hover:bg-muted/50"
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <Home className="h-4 w-4" />
                  Home
                </button>
              </Link>

              <div className="px-4 py-2 text-xs text-muted-foreground uppercase tracking-wider">Games</div>
              {games.map((game) => (
                <Link key={game.path} href={game.path}>
                  <button
                    className={`w-full text-left px-4 py-2.5 rounded-lg flex items-center gap-3 ${
                      isActive(game.path) ? "bg-primary/10 text-primary" : "hover:bg-muted/50"
                    }`}
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <span>{game.icon}</span>
                    {game.name}
                  </button>
                </Link>
              ))}

              <Link href="/sportsbook">
                <button
                  className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 ${
                    isActive("/sportsbook") ? "bg-primary/10 text-primary" : "hover:bg-muted/50"
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <Trophy className="h-4 w-4" />
                  Sportsbook
                </button>
              </Link>

              <Link href="/dashboard">
                <button
                  className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 ${
                    isActive("/dashboard") ? "bg-primary/10 text-primary" : "hover:bg-muted/50"
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <LayoutDashboard className="h-4 w-4" />
                  Dashboard
                </button>
              </Link>

              <Link href="/wallet">
                <button
                  className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 ${
                    isActive("/wallet") ? "bg-primary/10 text-primary" : "hover:bg-muted/50"
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <Wallet className="h-4 w-4" />
                  Wallet
                </button>
              </Link>

              <Link href="/support">
                <button
                  className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 ${
                    isActive("/support") ? "bg-primary/10 text-primary" : "hover:bg-muted/50"
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <LifeBuoy className="h-4 w-4" />
                  Support
                </button>
              </Link>

              <Link href="/studio">
                <button
                  className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 ${
                    isActive("/studio") ? "bg-primary/10 text-primary" : "hover:bg-muted/50"
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <Film className="h-4 w-4" />
                  Studio
                </button>
              </Link>
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="flex-1">{children}</main>

      {/* Chat Overlay */}
      <ChatOverlay />

      {/* Footer */}
      <footer className="border-t border-border/50 py-8 mt-auto">
        <div className="container text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} The Lucky Riverboat Casino & Sportsbook. All rights reserved.</p>
          <p className="mt-1">Play responsibly. Must be 18+ to participate.</p>
        </div>
      </footer>
    </div>
  );
}
