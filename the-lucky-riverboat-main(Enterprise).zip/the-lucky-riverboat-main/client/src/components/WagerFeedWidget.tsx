import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { TrendingUp, TrendingDown } from "lucide-react";
import { io, Socket } from "socket.io-client";

interface Wager {
  userName: string;
  gameType: string;
  betAmount: number;
  multiplier: number;
  payout: number;
  result: "win" | "loss" | "pending";
  timestamp: Date;
}

export default function WagerFeedWidget() {
  const [wagers, setWagers] = useState<Wager[]>([]);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    const socket = io(window.location.origin, {
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      reconnectionAttempts: 5,
    });

    socketRef.current = socket;

    socket.on("wager_update", (wager: Wager) => {
      setWagers((prev) => [wager, ...prev.slice(0, 19)]); // Keep last 20 wagers
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const getGameEmoji = (gameType: string) => {
    const emojis: Record<string, string> = {
      keno: "🎰",
      beached: "🏖️",
      roulette: "🎡",
      helm: "🎪",
      "walk-the-plank": "🏴‍☠️",
      "hidden-treasure": "💎",
      "hitide-lowtide": "🌊",
      blackjack: "🃏",
      plinko: "⚪",
      slots: "🎰",
    };
    return emojis[gameType] || "🎮";
  };

  return (
    <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
      <div className="p-4 border-b border-border/50">
        <h3 className="font-semibold text-gold text-sm">Live Wagers</h3>
      </div>
      <ScrollArea className="h-64">
        <div className="p-3 space-y-2">
          {wagers.length === 0 ? (
            <div className="text-center text-foreground/50 text-xs py-8">
              Waiting for wagers...
            </div>
          ) : (
            wagers.map((wager, idx) => (
              <div
                key={idx}
                className={`p-2 rounded-lg text-xs border border-border/30 transition-all ${
                  wager.result === "win"
                    ? "bg-green-500/10 border-green-500/30"
                    : wager.result === "loss"
                      ? "bg-red-500/10 border-red-500/30"
                      : "bg-yellow-500/10 border-yellow-500/30"
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{getGameEmoji(wager.gameType)}</span>
                    <div>
                      <p className="font-semibold text-foreground">{wager.userName}</p>
                      <p className="text-foreground/60 capitalize">{wager.gameType}</p>
                    </div>
                  </div>
                  {wager.result === "win" ? (
                    <TrendingUp size={16} className="text-green-500" />
                  ) : wager.result === "loss" ? (
                    <TrendingDown size={16} className="text-red-500" />
                  ) : (
                    <span className="text-yellow-500">⏳</span>
                  )}
                </div>
                <div className="flex justify-between text-foreground/70">
                  <span>Bet: ${wager.betAmount.toFixed(2)}</span>
                  <span className="font-semibold">
                    {wager.result === "win" ? (
                      <span className="text-green-500">+${wager.payout.toFixed(2)}</span>
                    ) : (
                      <span className="text-red-500">-${wager.betAmount.toFixed(2)}</span>
                    )}
                  </span>
                </div>
                {wager.multiplier > 0 && (
                  <p className="text-foreground/50 text-xs mt-1">
                    Multiplier: {wager.multiplier.toFixed(2)}x
                  </p>
                )}
              </div>
            ))
          )}
        </div>
      </ScrollArea>
    </Card>
  );
}
