import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(overrides?: Partial<AuthenticatedUser>): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user-1",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
    ...overrides,
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("tipping router", () => {
  it("should have sendTip procedure defined", () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    expect(caller.tipping.sendTip).toBeDefined();
  });

  it("should have getRecentTips procedure defined", () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    expect(caller.tipping.getRecentTips).toBeDefined();
  });

  it("should have getTipStats procedure defined", () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    expect(caller.tipping.getTipStats).toBeDefined();
  });

  it("should have getTipLeaderboard procedure defined", () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    expect(caller.tipping.getTipLeaderboard).toBeDefined();
  });

  it("should have getTipsReceived procedure defined", () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    expect(caller.tipping.getTipsReceived).toBeDefined();
  });

  it("should have getTipsGiven procedure defined", () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    expect(caller.tipping.getTipsGiven).toBeDefined();
  });

  it("should have schedulePayout procedure defined", () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    expect(caller.tipping.schedulePayout).toBeDefined();
  });

  it("should have getPayoutHistory procedure defined", () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    expect(caller.tipping.getPayoutHistory).toBeDefined();
  });

  it("sendTip should reject negative amounts via input validation", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.tipping.sendTip({
        toUserId: 2,
        amount: -10,
        tipType: "player",
      })
    ).rejects.toThrow();
  });

  it("sendTip should reject zero amount via input validation", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.tipping.sendTip({
        toUserId: 2,
        amount: 0,
        tipType: "player",
      })
    ).rejects.toThrow();
  });

  it("sendTip should accept valid tip types", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Should reject invalid tip types via zod validation
    await expect(
      caller.tipping.sendTip({
        toUserId: 2,
        amount: 10,
        tipType: "invalid_type" as any,
      })
    ).rejects.toThrow();
  });
});
