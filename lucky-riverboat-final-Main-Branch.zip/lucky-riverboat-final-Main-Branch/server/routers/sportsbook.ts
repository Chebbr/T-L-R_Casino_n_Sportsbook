import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { getDb } from "../db";
import { sportsBets, users } from "../../drizzle/schema";
import { eq, desc, sql } from "drizzle-orm";

export const sportsbookRouter = router({
  getEvents: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    
    // Return mock events for now
    return [
      {
        id: 1,
        sport: "Football",
        league: "NFL",
        homeTeam: "Kansas City Chiefs",
        awayTeam: "Buffalo Bills",
        homeOdds: 1.85,
        awayOdds: 2.1,
        drawOdds: null,
        status: "live",
        createdAt: new Date(),
      },
      {
        id: 2,
        sport: "Basketball",
        league: "NBA",
        homeTeam: "Los Angeles Lakers",
        awayTeam: "Boston Celtics",
        homeOdds: 1.95,
        awayOdds: 1.95,
        drawOdds: null,
        status: "live",
        createdAt: new Date(),
      },
      {
        id: 3,
        sport: "Soccer",
        league: "Premier League",
        homeTeam: "Manchester United",
        awayTeam: "Liverpool",
        homeOdds: 2.2,
        awayOdds: 1.75,
        drawOdds: 3.5,
        status: "live",
        createdAt: new Date(),
      },
    ];
  }),

  placeBet: protectedProcedure
    .input(
      z.object({
        eventId: z.number(),
        betType: z.enum(["moneyline", "spread", "over_under"]),
        amount: z.number().min(0.1),
        selectedTeam: z.string(),
        odds: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, ctx.user.id))
        .limit(1);

      if (!user || Number(user.balance) < input.amount) {
        throw new Error("Insufficient balance");
      }

      const payout = input.amount * input.odds;
      await db
        .update(users)
        .set({
          balance: sql`${users.balance} - ${input.amount.toString()}`,
        })
        .where(eq(users.id, ctx.user.id));

      await db.insert(sportsBets).values({
        userId: ctx.user.id,
        eventId: input.eventId.toString(),
        sport: "general",
        selection: input.selectedTeam,
        odds: input.odds.toString(),
        betAmount: input.amount.toString(),
        potentialPayout: payout.toString(),
        status: "pending",
      });

      return { success: true };
    }),

  getUserBets: protectedProcedure
    .input(z.object({ limit: z.number().optional().default(10) }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];
      const bets = await db
        .select()
        .from(sportsBets)
        .where(eq(sportsBets.userId, ctx.user.id))
        .orderBy(desc(sportsBets.createdAt))
        .limit(input.limit);
      return bets.map((bet: any) => ({
        ...bet,
        eventId: parseInt(bet.eventId),
        betType: "moneyline",
      }));
    }),
});
