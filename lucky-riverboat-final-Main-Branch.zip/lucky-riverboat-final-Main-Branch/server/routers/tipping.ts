import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { eq, desc, and } from "drizzle-orm";
import {
  tips,
  tipPayouts,
  tipLeaderboard,
  users,
  transactions,
} from "../../drizzle/schema";
import { TRPCError } from "@trpc/server";

export const tippingRouter = router({
  // Send a tip to another player or streamer
  sendTip: protectedProcedure
    .input(
      z.object({
        toUserId: z.number(),
        amount: z.number().positive(),
        message: z.string().optional(),
        tipType: z.enum(["player", "streamer", "rain"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      // Validate amount
      if (input.amount < 1) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Minimum tip amount is $1",
        });
      }

      // Check sender balance
      const sender = await db
        .select()
        .from(users)
        .where(eq(users.id, ctx.user.id))
        .limit(1);

      if (!sender.length) {
        throw new TRPCError({ code: "NOT_FOUND", message: "User not found" });
      }

      const senderBalance = Number(sender[0].balance);
      if (senderBalance < input.amount) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Insufficient balance",
        });
      }

      // Check recipient exists
      const recipient = await db
        .select()
        .from(users)
        .where(eq(users.id, input.toUserId))
        .limit(1);

      if (!recipient.length) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Recipient not found",
        });
      }

      // Calculate VIP multiplier for recipient
      const vipMultipliers: Record<string, number> = {
        bronze: 1.0,
        silver: 1.05,
        gold: 1.1,
        platinum: 1.15,
        diamond: 1.2,
      };

      const vipTier = recipient[0].vipTier || "bronze";
      const multiplier = vipMultipliers[vipTier] || 1.0;
      const actualAmount = input.amount * multiplier;

      // Create tip record
      const [tipRecord] = await db.insert(tips).values({
        fromUserId: ctx.user.id,
        toUserId: input.toUserId,
        amount: input.amount.toString(),
        message: input.message,
        tipType: input.tipType,
        vipMultiplier: multiplier.toString(),
        actualAmount: actualAmount.toString(),
        status: "completed",
      });

      // Deduct from sender
      await db
        .update(users)
        .set({
          balance: (senderBalance - input.amount).toFixed(8),
        })
        .where(eq(users.id, ctx.user.id));

      // Add to recipient
      const recipientBalance = Number(recipient[0].balance);
      await db
        .update(users)
        .set({
          balance: (recipientBalance + actualAmount).toFixed(8),
        })
        .where(eq(users.id, input.toUserId));

      // Create transaction records
      await db.insert(transactions).values({
        userId: ctx.user.id,
        type: "tip",
        method: "game",
        amount: input.amount.toString(),
        status: "completed",
        description: `Tip sent to user ${input.toUserId}`,
      });

      await db.insert(transactions).values({
        userId: input.toUserId,
        type: "tip",
        method: "game",
        amount: actualAmount.toString(),
        status: "completed",
        description: `Tip received from user ${ctx.user.id}${multiplier > 1 ? ` (${multiplier}x VIP bonus)` : ""}`,
      });

      // Update leaderboard for sender
      const senderLeaderboard = await db
        .select()
        .from(tipLeaderboard)
        .where(eq(tipLeaderboard.userId, ctx.user.id))
        .limit(1);

      if (senderLeaderboard.length) {
        await db
          .update(tipLeaderboard)
          .set({
            totalTipsGiven: (
              Number(senderLeaderboard[0].totalTipsGiven) + input.amount
            ).toString(),
            tipsGivenCount: senderLeaderboard[0].tipsGivenCount + 1,
            lastTipAt: new Date(),
          })
          .where(eq(tipLeaderboard.userId, ctx.user.id));
      } else {
        await db.insert(tipLeaderboard).values({
          userId: ctx.user.id,
          totalTipsGiven: input.amount.toString(),
          tipsGivenCount: 1,
          lastTipAt: new Date(),
        });
      }

      // Update leaderboard for recipient
      const recipientLeaderboard = await db
        .select()
        .from(tipLeaderboard)
        .where(eq(tipLeaderboard.userId, input.toUserId))
        .limit(1);

      if (recipientLeaderboard.length) {
        await db
          .update(tipLeaderboard)
          .set({
            totalTipsReceived: (
              Number(recipientLeaderboard[0].totalTipsReceived) + actualAmount
            ).toString(),
            tipsReceivedCount: recipientLeaderboard[0].tipsReceivedCount + 1,
            lastTipAt: new Date(),
          })
          .where(eq(tipLeaderboard.userId, input.toUserId));
      } else {
        await db.insert(tipLeaderboard).values({
          userId: input.toUserId,
          totalTipsReceived: actualAmount.toString(),
          tipsReceivedCount: 1,
          lastTipAt: new Date(),
        });
      }

      return {
        success: true,
        tipId: tipRecord.insertId,
        actualAmount,
        multiplier,
        message: `Tip sent! ${multiplier > 1 ? `Recipient received ${multiplier}x bonus!` : ""}`,
      };
    }),

  // Get recent tips
  getRecentTips: protectedProcedure
    .input(z.object({ limit: z.number().default(20) }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];

      const recentTips = await db
        .select({
          id: tips.id,
          fromUserId: tips.fromUserId,
          toUserId: tips.toUserId,
          amount: tips.amount,
          actualAmount: tips.actualAmount,
          message: tips.message,
          tipType: tips.tipType,
          vipMultiplier: tips.vipMultiplier,
          createdAt: tips.createdAt,
          fromUserName: users.name,
        })
        .from(tips)
        .leftJoin(users, eq(tips.fromUserId, users.id))
        .orderBy(desc(tips.createdAt))
        .limit(input.limit);

      return recentTips;
    }),

  // Get user's tip statistics
  getTipStats: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return null;

    const stats = await db
      .select()
      .from(tipLeaderboard)
      .where(eq(tipLeaderboard.userId, ctx.user.id))
      .limit(1);

    if (!stats.length) {
      return {
        totalTipsReceived: 0,
        totalTipsGiven: 0,
        tipsReceivedCount: 0,
        tipsGivenCount: 0,
        lastTipAt: null,
      };
    }

    return {
      totalTipsReceived: Number(stats[0].totalTipsReceived),
      totalTipsGiven: Number(stats[0].totalTipsGiven),
      tipsReceivedCount: stats[0].tipsReceivedCount,
      tipsGivenCount: stats[0].tipsGivenCount,
      lastTipAt: stats[0].lastTipAt,
    };
  }),

  // Get tip leaderboard
  getTipLeaderboard: protectedProcedure
    .input(
      z.object({
        type: z.enum(["received", "given"]),
        limit: z.number().default(10),
      })
    )
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];

      const column =
        input.type === "received"
          ? tipLeaderboard.totalTipsReceived
          : tipLeaderboard.totalTipsGiven;

      const leaderboard = await db
        .select({
          userId: tipLeaderboard.userId,
          userName: users.name,
          totalAmount:
            input.type === "received"
              ? tipLeaderboard.totalTipsReceived
              : tipLeaderboard.totalTipsGiven,
          count:
            input.type === "received"
              ? tipLeaderboard.tipsReceivedCount
              : tipLeaderboard.tipsGivenCount,
          vipTier: users.vipTier,
        })
        .from(tipLeaderboard)
        .leftJoin(users, eq(tipLeaderboard.userId, users.id))
        .orderBy(desc(column))
        .limit(input.limit);

      return leaderboard.map((item, index) => ({
        rank: index + 1,
        ...item,
      }));
    }),

  // Get tips received by user
  getTipsReceived: protectedProcedure
    .input(z.object({ limit: z.number().default(20) }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];

      const userTips = await db
        .select({
          id: tips.id,
          fromUserId: tips.fromUserId,
          amount: tips.amount,
          actualAmount: tips.actualAmount,
          message: tips.message,
          tipType: tips.tipType,
          vipMultiplier: tips.vipMultiplier,
          createdAt: tips.createdAt,
          fromUserName: users.name,
        })
        .from(tips)
        .leftJoin(users, eq(tips.fromUserId, users.id))
        .where(eq(tips.toUserId, ctx.user.id))
        .orderBy(desc(tips.createdAt))
        .limit(input.limit);

      return userTips;
    }),

  // Get tips given by user
  getTipsGiven: protectedProcedure
    .input(z.object({ limit: z.number().default(20) }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];

      const userTips = await db
        .select({
          id: tips.id,
          toUserId: tips.toUserId,
          amount: tips.amount,
          actualAmount: tips.actualAmount,
          message: tips.message,
          tipType: tips.tipType,
          vipMultiplier: tips.vipMultiplier,
          createdAt: tips.createdAt,
          toUserName: users.name,
        })
        .from(tips)
        .leftJoin(users, eq(tips.toUserId, users.id))
        .where(eq(tips.fromUserId, ctx.user.id))
        .orderBy(desc(tips.createdAt))
        .limit(input.limit);

      return userTips;
    }),

  // Schedule payout for tips
  schedulePayout: protectedProcedure
    .input(
      z.object({
        payoutMethod: z.enum(["wallet", "btc", "eth", "stripe"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      // Get pending tips for user
      const pendingTips = await db
        .select()
        .from(tips)
        .where(
          and(
            eq(tips.toUserId, ctx.user.id),
            eq(tips.status, "completed")
          )
        );

      if (!pendingTips.length) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "No tips to payout",
        });
      }

      // Create payout records
      const totalAmount = pendingTips.reduce(
        (sum, tip) => sum + Number(tip.actualAmount),
        0
      );

      for (const tip of pendingTips) {
        await db.insert(tipPayouts).values({
          tipId: tip.id,
          userId: ctx.user.id,
          amount: tip.actualAmount,
          payoutStatus: "scheduled",
          payoutMethod: input.payoutMethod,
          scheduledAt: new Date(),
        });
      }

      return {
        success: true,
        totalAmount,
        payoutMethod: input.payoutMethod,
        tipCount: pendingTips.length,
      };
    }),

  // Get payout history
  getPayoutHistory: protectedProcedure
    .input(z.object({ limit: z.number().default(20) }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];

      const payouts = await db
        .select()
        .from(tipPayouts)
        .where(eq(tipPayouts.userId, ctx.user.id))
        .orderBy(desc(tipPayouts.createdAt))
        .limit(input.limit);

      return payouts.map((payout) => ({
        ...payout,
        amount: Number(payout.amount),
      }));
    }),
});
