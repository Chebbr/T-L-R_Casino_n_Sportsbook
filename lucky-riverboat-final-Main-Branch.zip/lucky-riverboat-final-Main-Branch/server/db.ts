import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ==================== VIP SYSTEM ====================
export async function getVipTier(tierName: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(vipTiers).where(eq(vipTiers.name, tierName as any)).limit(1);
  return result[0];
}

// ==================== BONUS CODES ====================
export async function getActiveBonusCode(code: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(bonusCodes).where(and(eq(bonusCodes.code, code), eq(bonusCodes.isActive, true))).limit(1);
  return result[0];
}

// ==================== CHAT MESSAGES ====================
export async function getRecentChatMessages(limit: number = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(chatMessages).where(eq(chatMessages.isDeleted, false)).orderBy(desc(chatMessages.createdAt)).limit(limit);
}

// ==================== LIVE WAGERS ====================
export async function getRecentLiveWagers(limit: number = 20) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(liveWagers).orderBy(desc(liveWagers.createdAt)).limit(limit);
}

// ==================== PLAYER STATS ====================
export async function getOrCreatePlayerStats(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const existing = await db.select().from(playerStats).where(eq(playerStats.userId, userId)).limit(1);
  if (existing.length > 0) return existing[0];
  
  await db.insert(playerStats).values({ userId });
  const result = await db.select().from(playerStats).where(eq(playerStats.userId, userId)).limit(1);
  return result[0];
}

// ==================== WITHDRAWAL REQUESTS ====================
export async function getPendingWithdrawals() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(withdrawalRequests).where(eq(withdrawalRequests.status, "pending")).orderBy(asc(withdrawalRequests.createdAt));
}

// ==================== REFERRALS ====================
export async function getReferralByCode(code: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(referrals).where(eq(referrals.referralCode, code)).limit(1);
  return result[0];
}

import { desc, asc, and } from "drizzle-orm";
import { vipTiers, bonusCodes, chatMessages, liveWagers, playerStats, withdrawalRequests, referrals } from "../drizzle/schema";
