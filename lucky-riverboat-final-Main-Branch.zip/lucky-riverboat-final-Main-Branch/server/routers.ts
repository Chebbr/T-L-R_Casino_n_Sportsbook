import { COOKIE_NAME } from "@shared/const";
import { sportsbookRouter } from "./routers/sportsbook";
import { tippingRouter } from "./routers/tipping";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { 
  users, transactions, gameSessions, sportsBets, vipTiers, bonusCodes, 
  bonusRedemptions, rtpConfigs, chatMessages, supportTickets, supportMessages,
  referrals, referralEarnings, withdrawalRequests, depositRequests, auditLogs,
  playerStats, liveWagers
} from "../drizzle/schema";
import { eq, desc, sql, and, gt, lt } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

const protectedAdminProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  if (ctx.user?.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  tipping: tippingRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ==================== WALLET & BALANCE ====================
  wallet: router({
    getBalance: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return { balance: "0", vaultBalance: "0" };
      const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
      return { 
        balance: user?.balance || "0", 
        vaultBalance: user?.vaultBalance || "0" 
      };
    }),

    getTransactions: protectedProcedure
      .input(z.object({ limit: z.number().optional().default(20) }))
      .query(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) return [];
        return db
          .select()
          .from(transactions)
          .where(eq(transactions.userId, ctx.user.id))
          .orderBy(desc(transactions.createdAt))
          .limit(input.limit);
      }),

    deposit: protectedProcedure
      .input(z.object({
        amount: z.number().min(5).max(50000),
        method: z.enum(["btc", "eth", "stripe"]),
        txHash: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        await db.insert(transactions).values({
          userId: ctx.user.id,
          type: "deposit",
          method: input.method,
          amount: input.amount.toString(),
          status: "pending",
          txHash: input.txHash || null,
          description: `${input.method.toUpperCase()} deposit`,
        });

        if (input.method === "stripe") {
          await db.update(users).set({
            balance: sql`${users.balance} + ${input.amount.toString()}`,
          }).where(eq(users.id, ctx.user.id));
        }

        return { success: true };
      }),

    requestWithdrawal: protectedProcedure
      .input(z.object({
        amount: z.number().min(10),
        toAddress: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        if (!user || Number(user.balance) < input.amount) {
          throw new Error("Insufficient balance");
        }

        await db.insert(withdrawalRequests).values({
          userId: ctx.user.id,
          amount: input.amount.toString(),
          toAddress: input.toAddress,
          status: "pending",
        });

        await db.update(users).set({
          balance: sql`${users.balance} - ${input.amount.toString()}`,
        }).where(eq(users.id, ctx.user.id));

        return { success: true };
      }),

    moveToVault: protectedProcedure
      .input(z.object({ amount: z.number().min(0.1) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        if (!user || Number(user.balance) < input.amount) {
          throw new Error("Insufficient balance");
        }

        await db.update(users).set({
          balance: sql`${users.balance} - ${input.amount.toString()}`,
          vaultBalance: sql`${users.vaultBalance} + ${input.amount.toString()}`,
        }).where(eq(users.id, ctx.user.id));

        return { success: true };
      }),

    moveFromVault: protectedProcedure
      .input(z.object({ amount: z.number().min(0.1) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        if (!user || Number(user.vaultBalance) < input.amount) {
          throw new Error("Insufficient vault balance");
        }

        await db.update(users).set({
          balance: sql`${users.balance} + ${input.amount.toString()}`,
          vaultBalance: sql`${users.vaultBalance} - ${input.amount.toString()}`,
        }).where(eq(users.id, ctx.user.id));

        return { success: true };
      }),
  }),

  // ==================== VIP SYSTEM ====================
  vip: router({
    getTiers: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(vipTiers).orderBy(vipTiers.id);
    }),

    getUserVip: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return null;
      const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
      if (!user) return null;
      const [tier] = await db.select().from(vipTiers).where(eq(vipTiers.name, user.vipTier as any)).limit(1);
      return { user, tier };
    }),
  }),

  // ==================== BONUS CODES ====================
  bonus: router({
    redeemCode: protectedProcedure
      .input(z.object({ code: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [bonusCode] = await db.select().from(bonusCodes)
          .where(and(eq(bonusCodes.code, input.code), eq(bonusCodes.isActive, true)))
          .limit(1);

        if (!bonusCode) throw new Error("Invalid or inactive bonus code");
        if (bonusCode.maxUses && bonusCode.currentUses >= bonusCode.maxUses) {
          throw new Error("Bonus code usage limit reached");
        }
        if (bonusCode.expiresAt && bonusCode.expiresAt < new Date()) {
          throw new Error("Bonus code expired");
        }

        const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        if (!user) throw new Error("User not found");

        const amountToCredit = Number(bonusCode.value);
        await db.insert(bonusRedemptions).values({
          userId: ctx.user.id,
          bonusCodeId: bonusCode.id,
          code: input.code,
          amountCredited: amountToCredit.toString(),
        });

        await db.update(bonusCodes).set({
          currentUses: sql`${bonusCodes.currentUses} + 1`,
        }).where(eq(bonusCodes.id, bonusCode.id));

        await db.update(users).set({
          balance: sql`${users.balance} + ${amountToCredit.toString()}`,
        }).where(eq(users.id, ctx.user.id));

        return { success: true, amountCredited: amountToCredit };
      }),

    getActiveBonuses: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(bonusCodes)
        .where(and(eq(bonusCodes.isActive, true), gt(bonusCodes.expiresAt, new Date())))
        .orderBy(desc(bonusCodes.createdAt));
    }),
  }),

  // ==================== GAMES ====================
  games: router({
    playBlackjack: protectedProcedure
      .input(z.object({ betAmount: z.number().min(0.1) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        if (!user || Number(user.balance) < input.betAmount) throw new Error("Insufficient balance");

        const playerHand = Math.random() > 0.5 ? 21 : 18;
        const dealerHand = Math.random() > 0.5 ? 21 : 17;
        let multiplier = 0;
        if (playerHand > dealerHand) multiplier = 2;
        else if (playerHand === dealerHand) multiplier = 1;

        const payout = input.betAmount * multiplier;
        const newBalance = Number(user.balance) - input.betAmount + payout;

        await db.update(users).set({
          balance: newBalance.toString(),
          totalWagered: sql`${users.totalWagered} + ${input.betAmount.toString()}`,
          totalWon: sql`${users.totalWon} + ${payout.toString()}`,
          gamesPlayed: sql`${users.gamesPlayed} + 1`,
        }).where(eq(users.id, ctx.user.id));

        await db.insert(gameSessions).values({
          userId: ctx.user.id,
          gameType: "blackjack",
          betAmount: input.betAmount.toString(),
          multiplier: multiplier.toString(),
          payout: payout.toString(),
          result: JSON.stringify({ playerHand, dealerHand }),
          status: "completed",
        });

        await db.insert(liveWagers).values({
          userId: ctx.user.id,
          userName: user.name || "Anonymous",
          gameType: "blackjack",
          betAmount: input.betAmount.toString(),
          multiplier: multiplier.toString(),
          payout: payout.toString(),
          isWin: multiplier > 1,
        });

        return { playerHand, dealerHand, multiplier, payout };
      }),

    playPlinko: protectedProcedure
      .input(z.object({ betAmount: z.number().min(0.1) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        if (!user || Number(user.balance) < input.betAmount) throw new Error("Insufficient balance");

        const multipliers = [0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5];
        const multiplier = multipliers[Math.floor(Math.random() * multipliers.length)];
        const payout = input.betAmount * multiplier;
        const newBalance = Number(user.balance) - input.betAmount + payout;

        await db.update(users).set({
          balance: newBalance.toString(),
          totalWagered: sql`${users.totalWagered} + ${input.betAmount.toString()}`,
          totalWon: sql`${users.totalWon} + ${payout.toString()}`,
          gamesPlayed: sql`${users.gamesPlayed} + 1`,
        }).where(eq(users.id, ctx.user.id));

        await db.insert(gameSessions).values({
          userId: ctx.user.id,
          gameType: "plinko",
          betAmount: input.betAmount.toString(),
          multiplier: multiplier.toString(),
          payout: payout.toString(),
          status: "completed",
        });

        await db.insert(liveWagers).values({
          userId: ctx.user.id,
          userName: user.name || "Anonymous",
          gameType: "plinko",
          betAmount: input.betAmount.toString(),
          multiplier: multiplier.toString(),
          payout: payout.toString(),
          isWin: multiplier > 1,
        });

        return { multiplier, payout };
      }),

    playSlots: protectedProcedure
      .input(z.object({ betAmount: z.number().min(0.1) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        if (!user || Number(user.balance) < input.betAmount) throw new Error("Insufficient balance");

        const symbols = ["🎰", "🍒", "🍋", "🍊", "🍌", "⭐", "💎"];
        const reel1 = symbols[Math.floor(Math.random() * symbols.length)];
        const reel2 = symbols[Math.floor(Math.random() * symbols.length)];
        const reel3 = symbols[Math.floor(Math.random() * symbols.length)];

        let multiplier = 0;
        if (reel1 === reel2 && reel2 === reel3) multiplier = 10;
        else if (reel1 === reel2 || reel2 === reel3) multiplier = 2;

        const payout = input.betAmount * multiplier;
        const newBalance = Number(user.balance) - input.betAmount + payout;

        await db.update(users).set({
          balance: newBalance.toString(),
          totalWagered: sql`${users.totalWagered} + ${input.betAmount.toString()}`,
          totalWon: sql`${users.totalWon} + ${payout.toString()}`,
          gamesPlayed: sql`${users.gamesPlayed} + 1`,
        }).where(eq(users.id, ctx.user.id));

        await db.insert(gameSessions).values({
          userId: ctx.user.id,
          gameType: "slots",
          betAmount: input.betAmount.toString(),
          multiplier: multiplier.toString(),
          payout: payout.toString(),
          result: JSON.stringify({ reels: [reel1, reel2, reel3] }),
          status: "completed",
        });

        await db.insert(liveWagers).values({
          userId: ctx.user.id,
          userName: user.name || "Anonymous",
          gameType: "slots",
          betAmount: input.betAmount.toString(),
          multiplier: multiplier.toString(),
          payout: payout.toString(),
          isWin: multiplier > 1,
        });

        return { reels: [reel1, reel2, reel3], multiplier, payout };
      }),

    getRecentGames: protectedProcedure
      .input(z.object({ limit: z.number().optional().default(10) }))
      .query(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) return [];
        return db.select().from(gameSessions)
          .where(eq(gameSessions.userId, ctx.user.id))
          .orderBy(desc(gameSessions.createdAt))
          .limit(input.limit);
      }),
  }),

  // ==================== CHAT ====================
  chat: router({
    sendMessage: protectedProcedure
      .input(z.object({ message: z.string().min(1).max(500) }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        await db.insert(chatMessages).values({
          userId: ctx.user.id,
          userName: user?.name || "Anonymous",
          message: input.message,
          type: "chat",
        });

        return { success: true };
      }),

    getMessages: publicProcedure
      .input(z.object({ limit: z.number().optional().default(50) }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        return db.select().from(chatMessages)
          .where(eq(chatMessages.isDeleted, false))
          .orderBy(desc(chatMessages.createdAt))
          .limit(input.limit);
      }),

    getOnlineUsers: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
      return db.select({ id: users.id, name: users.name, lastSignedIn: users.lastSignedIn })
        .from(users)
        .where(gt(users.lastSignedIn, fiveMinutesAgo))
        .limit(100);
    }),
  }),

  // ==================== SUPPORT ====================
  support: router({
    createTicket: protectedProcedure
      .input(z.object({ subject: z.string(), message: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        const [ticket] = await db.insert(supportTickets).values({
          userId: ctx.user.id,
          userName: user?.name || "Anonymous",
          subject: input.subject,
          status: "open",
        }).$returningId();

        await db.insert(supportMessages).values({
          ticketId: ticket.id,
          userId: ctx.user.id,
          isAdmin: false,
          message: input.message,
        });

        return { ticketId: ticket.id };
      }),

    getTickets: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(supportTickets)
        .where(eq(supportTickets.userId, ctx.user.id))
        .orderBy(desc(supportTickets.createdAt));
    }),

    getTicketMessages: protectedProcedure
      .input(z.object({ ticketId: z.number() }))
      .query(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) return [];
        return db.select().from(supportMessages)
          .where(eq(supportMessages.ticketId, input.ticketId))
          .orderBy(supportMessages.createdAt);
      }),
  }),

  // ==================== AFFILIATE ====================
  affiliate: router({
    getReferralCode: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return null;
      const [referral] = await db.select().from(referrals)
        .where(eq(referrals.referrerId, ctx.user.id))
        .limit(1);
      return referral || null;
    }),

    getEarnings: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return { totalEarnings: "0", referredCount: 0, earnings: [] };
      const [referral] = await db.select().from(referrals)
        .where(eq(referrals.referrerId, ctx.user.id))
        .limit(1);
      if (!referral) return { totalEarnings: "0", referredCount: 0, earnings: [] };

      const earnings = await db.select().from(referralEarnings)
        .where(eq(referralEarnings.referralId, referral.id))
        .orderBy(desc(referralEarnings.createdAt));

      return {
        totalEarnings: referral.totalEarnings,
        referredCount: referral.totalReferred,
        earnings,
      };
    }),
  }),

  // ==================== ADMIN ====================
  admin: router({
    getPendingWithdrawals: protectedAdminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(withdrawalRequests)
        .where(eq(withdrawalRequests.status, "pending"))
        .orderBy(withdrawalRequests.createdAt);
    }),

    approveWithdrawal: protectedAdminProcedure
      .input(z.object({ withdrawalId: z.number(), txHash: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        await db.update(withdrawalRequests).set({
          status: "completed",
          txHash: input.txHash,
          processedAt: new Date(),
        }).where(eq(withdrawalRequests.id, input.withdrawalId));

        return { success: true };
      }),

    rejectWithdrawal: protectedAdminProcedure
      .input(z.object({ withdrawalId: z.number(), reason: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const [withdrawal] = await db.select().from(withdrawalRequests)
          .where(eq(withdrawalRequests.id, input.withdrawalId))
          .limit(1);

        if (withdrawal) {
          await db.update(users).set({
            balance: sql`${users.balance} + ${withdrawal.amount}`,
          }).where(eq(users.id, withdrawal.userId));
        }

        await db.update(withdrawalRequests).set({
          status: "failed",
          failureReason: input.reason,
          processedAt: new Date(),
        }).where(eq(withdrawalRequests.id, input.withdrawalId));

        return { success: true };
      }),

    updateRtp: protectedAdminProcedure
      .input(z.object({ gameType: z.string(), targetRtp: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        await db.update(rtpConfigs).set({
          targetRtp: input.targetRtp.toString(),
        }).where(eq(rtpConfigs.gameType, input.gameType));

        return { success: true };
      }),

    adjustUserBalance: protectedAdminProcedure
      .input(z.object({ userId: z.number(), amount: z.number(), reason: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("Database unavailable");

        const operation = input.amount > 0 ? "add" : "subtract";
        await db.update(users).set({
          balance: sql`${users.balance} + ${input.amount.toString()}`,
        }).where(eq(users.id, input.userId));

        await db.insert(auditLogs).values({
          userId: ctx.user.id,
          action: `Balance ${operation}`,
          entity: "user",
          entityId: input.userId,
          details: `${operation} ${Math.abs(input.amount)} - ${input.reason}`,
        });

        return { success: true };
      }),

    getStats: protectedAdminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return { totalUsers: 0, totalWagered: "0", totalPayouts: "0" };

      const stats = await db.select({
        totalUsers: sql<number>`COUNT(DISTINCT ${users.id})`,
        totalWagered: sql<string>`COALESCE(SUM(${users.totalWagered}), 0)`,
        totalPayouts: sql<string>`COALESCE(SUM(${users.totalWon}), 0)`,
      }).from(users);

      return stats[0] || { totalUsers: 0, totalWagered: "0", totalPayouts: "0" };
    }),
  }),

  sportsbook: sportsbookRouter,
  // ==================== LIVE FEED ====================
  feed: router({
    getLiveWagers: publicProcedure
      .input(z.object({ limit: z.number().optional().default(20) }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        return db.select().from(liveWagers)
          .orderBy(desc(liveWagers.createdAt))
          .limit(input.limit);
      }),
  }),
});

export type AppRouter = typeof appRouter;
