import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Games from "./pages/Games";
import Admin from "./pages/Admin";
import Wallet from "./pages/Wallet";
import Sportsbook from "./pages/Sportsbook";
import AdditionalGames from "./pages/AdditionalGames";
import Poker from "./pages/Poker";
import Chat from "./pages/Chat";
import Support from "./pages/Support";
import Tipping from "./pages/Tipping";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/games"} component={Games} />
      <Route path={"/games/premium"} component={AdditionalGames} />
      <Route path={"/poker"} component={Poker} />
      <Route path={"/chat"} component={Chat} />
      <Route path={"/support"} component={Support} />
      <Route path={"/wallet"} component={Wallet} />
      <Route path={"/sportsbook"} component={Sportsbook} />
      <Route path={"/tipping"} component={Tipping} />
      <Route path={"/admin"} component={Admin} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
