import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import {
  Home, Gamepad2, Trophy, Wallet, MessageCircle, Shield, Users, 
  ChevronLeft, ChevronRight, Menu, X, Zap, Star, Gift, 
  HelpCircle, TrendingUp, Crown, Coins, Heart, Volume2, VolumeX,
  BarChart3, Settings, LogOut, User, ChevronDown
} from "lucide-react";

const LOGO_URL = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663341115981/HeloXDUGeVanZOfa.png";
const RIVERBOAT_LOGO = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663341115981/wjBBYSglkzmfceOv.jpg";

interface CasinoLayoutProps {
  children: React.ReactNode;
  showChat?: boolean;
}

const navItems = [
  { icon: Home, label: "Home", path: "/" },
  { icon: Gamepad2, label: "Casino", path: "/games", children: [
    { label: "House Games", path: "/games" },
    { label: "Premium Slots", path: "/games/premium" },
    { label: "Poker", path: "/poker" },
  ]},
  { icon: Trophy, label: "Sportsbook", path: "/sportsbook" },
  { icon: Wallet, label: "Wallet", path: "/wallet" },
  { icon: Heart, label: "Tipping", path: "/tipping" },
  { icon: MessageCircle, label: "Chat", path: "/chat" },
  { icon: HelpCircle, label: "Support", path: "/support" },
];

const adminNavItems = [
  { icon: Shield, label: "Admin Panel", path: "/admin" },
];

export default function CasinoLayout({ children, showChat = false }: CasinoLayoutProps) {
  const { user, isAuthenticated, logout } = useAuth();
  const [location] = useLocation();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [expandedNav, setExpandedNav] = useState<string | null>(null);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [onlinePlayers] = useState(() => Math.floor(Math.random() * 500) + 200);
  const [totalWagered] = useState(() => (Math.random() * 50000 + 10000).toFixed(2));
  const [audioEnabled, setAudioEnabled] = useState(false);

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  const isActive = (path: string) => {
    if (path === "/") return location === "/";
    return location.startsWith(path);
  };

  return (
    <div className="min-h-screen" style={{ background: "var(--surface-0)" }}>
      {/* Sidebar */}
      <aside
        className={`casino-sidebar ${sidebarCollapsed ? "collapsed" : ""} ${mobileMenuOpen ? "mobile-open" : ""}`}
        style={{ scrollbarWidth: "none" }}
      >
        {/* Logo */}
        <div className="flex items-center justify-between p-4" style={{ borderBottom: "1px solid var(--glass-border)" }}>
          {!sidebarCollapsed && (
            <Link href="/" className="flex items-center gap-3">
              <img src={RIVERBOAT_LOGO} alt="TLR" className="w-8 h-8 rounded-lg object-cover" />
              <span style={{ fontFamily: "'Playfair Display', serif", fontSize: "16px", fontWeight: 700, color: "var(--gold)" }}>
                Lucky Riverboat
              </span>
            </Link>
          )}
          {sidebarCollapsed && (
            <Link href="/" className="mx-auto">
              <img src={RIVERBOAT_LOGO} alt="TLR" className="w-8 h-8 rounded-lg object-cover" />
            </Link>
          )}
          <button
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="hidden lg:flex items-center justify-center w-7 h-7 rounded-md hover:bg-[var(--surface-3)] transition-colors"
            style={{ color: "#64748b" }}
          >
            {sidebarCollapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
          </button>
        </div>

        {/* Nav Items */}
        <nav className="py-2">
          {navItems.map((item) => (
            <div key={item.path}>
              {item.children ? (
                <>
                  <button
                    onClick={() => setExpandedNav(expandedNav === item.label ? null : item.label)}
                    className={`nav-item w-full ${isActive(item.path) ? "active" : ""}`}
                  >
                    <span className="nav-icon"><item.icon size={18} /></span>
                    {!sidebarCollapsed && (
                      <>
                        <span className="flex-1 text-left">{item.label}</span>
                        <ChevronDown
                          size={14}
                          className="transition-transform"
                          style={{ transform: expandedNav === item.label ? "rotate(180deg)" : "rotate(0)" }}
                        />
                      </>
                    )}
                  </button>
                  {expandedNav === item.label && !sidebarCollapsed && (
                    <div className="ml-8 mt-1 space-y-1">
                      {item.children.map((child) => (
                        <Link
                          key={child.path}
                          href={child.path}
                          className={`block py-2 px-3 rounded-lg text-sm transition-colors ${
                            location === child.path
                              ? "text-[var(--gold)]"
                              : "text-[#64748b] hover:text-[#e2e8f0]"
                          }`}
                          style={{ background: location === child.path ? "rgba(212,168,67,0.08)" : "transparent" }}
                        >
                          {child.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <Link href={item.path} className={`nav-item ${isActive(item.path) ? "active" : ""}`}>
                  <span className="nav-icon"><item.icon size={18} /></span>
                  {!sidebarCollapsed && <span>{item.label}</span>}
                </Link>
              )}
            </div>
          ))}

          {/* Admin section */}
          {isAuthenticated && user?.role === "admin" && (
            <>
              <div className="mx-4 my-3" style={{ height: "1px", background: "var(--glass-border)" }} />
              {!sidebarCollapsed && (
                <div className="px-4 py-1">
                  <span style={{ fontSize: "10px", fontWeight: 600, color: "#475569", textTransform: "uppercase", letterSpacing: "0.1em" }}>
                    Administration
                  </span>
                </div>
              )}
              {adminNavItems.map((item) => (
                <Link key={item.path} href={item.path} className={`nav-item ${isActive(item.path) ? "active" : ""}`}>
                  <span className="nav-icon"><item.icon size={18} /></span>
                  {!sidebarCollapsed && <span>{item.label}</span>}
                </Link>
              ))}
            </>
          )}
        </nav>

        {/* Sidebar Footer - Online Players */}
        {!sidebarCollapsed && (
          <div className="absolute bottom-0 left-0 right-0 p-4" style={{ borderTop: "1px solid var(--glass-border)", background: "var(--surface-1)" }}>
            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 rounded-full" style={{ background: "var(--neon-green)", boxShadow: "0 0 8px var(--neon-green)" }} />
              <span style={{ fontSize: "12px", color: "#94a3b8" }}>{onlinePlayers} Online</span>
            </div>
            <div style={{ fontSize: "11px", color: "#475569" }}>
              ${Number(totalWagered).toLocaleString()} wagered today
            </div>
          </div>
        )}
      </aside>

      {/* Mobile overlay */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-30 lg:hidden"
          style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)" }}
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Header */}
      <header className={`casino-header ${sidebarCollapsed ? "sidebar-collapsed" : ""}`}>
        {/* Left: Mobile menu + Search */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden flex items-center justify-center w-9 h-9 rounded-lg hover:bg-[var(--surface-2)] transition-colors"
            style={{ color: "#94a3b8" }}
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>

          {/* Live Stats */}
          <div className="live-ticker hidden md:flex">
            <div className="stat">
              <div className="online-dot" />
              <span className="stat-value">{onlinePlayers}</span>
              <span>online</span>
            </div>
            <div className="stat">
              <Zap size={14} style={{ color: "var(--gold)" }} />
              <span className="stat-value">${Number(totalWagered).toLocaleString()}</span>
              <span>wagered</span>
            </div>
          </div>
        </div>

        {/* Right: User actions */}
        <div className="flex items-center gap-3">
          {/* Audio toggle */}
          <button
            onClick={() => setAudioEnabled(!audioEnabled)}
            className="flex items-center justify-center w-9 h-9 rounded-lg hover:bg-[var(--surface-2)] transition-colors"
            style={{ color: "#64748b" }}
          >
            {audioEnabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
          </button>

          {isAuthenticated ? (
            <>
              {/* Balance */}
              <Link href="/wallet" className="flex items-center gap-2 px-4 py-2 rounded-xl" style={{ background: "var(--surface-2)", border: "1px solid var(--glass-border)" }}>
                <Coins size={16} style={{ color: "var(--gold)" }} />
                <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "13px", fontWeight: 600, color: "#e2e8f0" }}>
                  $0.00
                </span>
              </Link>

              {/* Deposit */}
              <Link href="/wallet" className="btn-primary" style={{ padding: "8px 20px", fontSize: "13px", borderRadius: "10px" }}>
                Deposit
              </Link>

              {/* User Menu */}
              <div className="relative">
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-[var(--surface-2)] transition-colors"
                >
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "linear-gradient(135deg, var(--gold), var(--gold-dark))" }}>
                    <span style={{ fontSize: "13px", fontWeight: 700, color: "var(--surface-0)" }}>
                      {user?.name?.[0]?.toUpperCase() || "U"}
                    </span>
                  </div>
                  <ChevronDown size={14} style={{ color: "#64748b" }} />
                </button>

                {userMenuOpen && (
                  <div
                    className="absolute right-0 top-full mt-2 w-56 rounded-xl overflow-hidden z-50"
                    style={{ background: "var(--surface-2)", border: "1px solid var(--glass-border)", boxShadow: "0 20px 60px rgba(0,0,0,0.5)" }}
                  >
                    <div className="p-3" style={{ borderBottom: "1px solid var(--glass-border)" }}>
                      <div style={{ fontSize: "14px", fontWeight: 600, color: "#e2e8f0" }}>{user?.name || "Player"}</div>
                      <div style={{ fontSize: "12px", color: "#64748b" }}>{user?.email || ""}</div>
                    </div>
                    <div className="py-1">
                      <Link href="/wallet" className="flex items-center gap-3 px-3 py-2.5 hover:bg-[var(--surface-3)] transition-colors" style={{ color: "#94a3b8", fontSize: "13px" }}>
                        <Wallet size={16} /> Wallet
                      </Link>
                      <Link href="/tipping" className="flex items-center gap-3 px-3 py-2.5 hover:bg-[var(--surface-3)] transition-colors" style={{ color: "#94a3b8", fontSize: "13px" }}>
                        <Heart size={16} /> Tipping
                      </Link>
                      <Link href="/support" className="flex items-center gap-3 px-3 py-2.5 hover:bg-[var(--surface-3)] transition-colors" style={{ color: "#94a3b8", fontSize: "13px" }}>
                        <HelpCircle size={16} /> Support
                      </Link>
                      <button
                        onClick={() => { logout(); setUserMenuOpen(false); }}
                        className="flex items-center gap-3 px-3 py-2.5 w-full hover:bg-[var(--surface-3)] transition-colors"
                        style={{ color: "#ef4444", fontSize: "13px" }}
                      >
                        <LogOut size={16} /> Sign Out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <a href={getLoginUrl()} className="btn-secondary" style={{ padding: "8px 20px", fontSize: "13px", borderRadius: "10px" }}>
                Login
              </a>
              <a href={getLoginUrl()} className="btn-primary" style={{ padding: "8px 20px", fontSize: "13px", borderRadius: "10px" }}>
                Register
              </a>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main
        className="transition-all duration-300"
        style={{
          marginLeft: sidebarCollapsed ? "68px" : "240px",
          paddingTop: "60px",
          minHeight: "100vh",
        }}
      >
        <div className="p-6">
          {children}
        </div>
      </main>

      {/* Click outside to close user menu */}
      {userMenuOpen && (
        <div className="fixed inset-0 z-40" onClick={() => setUserMenuOpen(false)} />
      )}
    </div>
  );
}
