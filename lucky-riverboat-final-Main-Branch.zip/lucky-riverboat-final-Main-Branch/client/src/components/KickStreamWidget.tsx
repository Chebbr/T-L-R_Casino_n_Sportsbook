import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Play, Users, Eye, Heart } from "lucide-react";

interface StreamStatus {
  isLive: boolean;
  viewers?: number;
  title?: string;
  thumbnail?: string;
  channelName: string;
  followers?: number;
}

interface KickStreamWidgetProps {
  channelName?: string;
  className?: string;
}

export default function KickStreamWidget({ channelName = "x3bb3r", className = "" }: KickStreamWidgetProps) {
  const [streamStatus, setStreamStatus] = useState<StreamStatus>({
    isLive: false,
    channelName,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate fetching stream status from Kick API
    const checkStreamStatus = async () => {
      try {
        // In production, this would call the Kick API
        // For now, we'll simulate it
        await new Promise((resolve) => setTimeout(resolve, 1000));

        // Mock data - in production, fetch from Kick API
        setStreamStatus({
          isLive: Math.random() > 0.5, // Random for demo
          viewers: Math.floor(Math.random() * 5000) + 100,
          title: "The Lucky Riverboat - High Stakes Casino Action 🎰",
          thumbnail: "https://images.unsplash.com/photo-1511379938547-c1f69b13d835?w=800&h=450&fit=crop",
          channelName,
          followers: 15420,
        });
      } catch (error) {
        console.error("Failed to fetch stream status:", error);
      } finally {
        setLoading(false);
      }
    };

    checkStreamStatus();

    // Poll every 30 seconds
    const interval = setInterval(checkStreamStatus, 30000);
    return () => clearInterval(interval);
  }, [channelName]);

  if (loading) {
    return (
      <Card className={`card-theatrical p-4 animate-pulse ${className}`}>
        <div className="aspect-video bg-background/50 rounded mb-3" />
        <div className="h-4 bg-background/50 rounded w-3/4 mb-2" />
        <div className="h-3 bg-background/50 rounded w-1/2" />
      </Card>
    );
  }

  return (
    <Card className={`card-theatrical overflow-hidden ${className}`}>
      {streamStatus.isLive ? (
        // Live Stream View
        <div className="relative group">
          {/* Thumbnail with overlay */}
          <div className="relative aspect-video overflow-hidden bg-black">
            <img
              src={streamStatus.thumbnail}
              alt={streamStatus.title}
              className="w-full h-full object-cover"
            />

            {/* Live Badge */}
            <div className="absolute top-3 left-3 flex items-center gap-2 bg-red-600 text-white px-3 py-1 rounded-full">
              <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
              <span className="text-xs font-bold">LIVE</span>
            </div>

            {/* Viewers Count */}
            <div className="absolute bottom-3 right-3 flex items-center gap-1 bg-black/70 text-white px-2 py-1 rounded">
              <Eye className="w-3 h-3" />
              <span className="text-xs font-semibold">{streamStatus.viewers?.toLocaleString()}</span>
            </div>

            {/* Play Button Overlay */}
            <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center">
                <Play className="w-8 h-8 text-white fill-white ml-1" />
              </div>
            </div>
          </div>

          {/* Info Section */}
          <div className="p-4 bg-card">
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <h3 className="font-bold text-accent text-sm line-clamp-2">{streamStatus.title}</h3>
                <p className="text-xs text-muted-foreground mt-1">
                  Streaming on{" "}
                  <span className="text-accent font-semibold">
                    {streamStatus.channelName}
                  </span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 mb-3">
              <div className="flex items-center gap-1 text-xs">
                <Heart className="w-3 h-3 text-red-400" />
                <span className="text-muted-foreground">
                  {streamStatus.followers?.toLocaleString()} followers
                </span>
              </div>
            </div>

            <Button className="w-full btn-gold gap-2">
              <Play className="w-4 h-4" />
              Watch Live on Kick
            </Button>
          </div>
        </div>
      ) : (
        // Offline View
        <div className="aspect-video bg-gradient-to-br from-background to-background/50 flex flex-col items-center justify-center p-6 relative overflow-hidden">
          {/* Background pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,_accent_1px,_transparent_1px)] bg-[length:20px_20px]" />
          </div>

          {/* Content */}
          <div className="relative z-10 text-center">
            <div className="w-20 h-20 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <div className="w-12 h-12 bg-accent/40 rounded-full flex items-center justify-center">
                <Play className="w-6 h-6 text-accent fill-accent" />
              </div>
            </div>

            <h3 className="font-bold text-accent text-lg mb-2">Stream Offline</h3>
            <p className="text-sm text-muted-foreground mb-4">
              {streamStatus.channelName} is currently offline
            </p>
            <p className="text-xs text-muted-foreground mb-4">
              Follow to get notified when they go live!
            </p>

            <Button className="btn-gold gap-2">
              <Heart className="w-4 h-4" />
              Follow Channel
            </Button>
          </div>
        </div>
      )}
    </Card>
  );
}
