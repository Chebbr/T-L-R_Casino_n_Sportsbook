import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2, Heart, Gift, Zap, TrendingUp } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface TippingWidgetProps {
  recipientId: number;
  recipientName: string;
  tipType?: "player" | "streamer" | "rain";
  onSuccess?: () => void;
}

export function TippingWidget({
  recipientId,
  recipientName,
  tipType = "player",
  onSuccess,
}: TippingWidgetProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [message, setMessage] = useState("");
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);

  const sendTipMutation = trpc.tipping.sendTip.useMutation();
  const tipStatsQuery = trpc.tipping.getTipStats.useQuery();

  const quickAmounts = [5, 10, 25, 50, 100];

  const handleSendTip = async () => {
    const tipAmount = selectedAmount || Number(amount);

    if (!tipAmount || tipAmount <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    try {
      const result = await sendTipMutation.mutateAsync({
        toUserId: recipientId,
        amount: tipAmount,
        message: message || undefined,
        tipType,
      });

      toast.success(result.message);
      setAmount("");
      setMessage("");
      setSelectedAmount(null);
      setIsOpen(false);
      tipStatsQuery.refetch();
      onSuccess?.();
    } catch (error: any) {
      toast.error(error.message || "Failed to send tip");
    }
  };

  const tipIcon =
    tipType === "streamer" ? (
      <Heart className="w-5 h-5" />
    ) : tipType === "rain" ? (
      <Zap className="w-5 h-5" />
    ) : (
      <Gift className="w-5 h-5" />
    );

  return (
    <>
      <Button
        onClick={() => setIsOpen(true)}
        className="btn-gold gap-2"
        size="sm"
      >
        {tipIcon}
        Tip {recipientName}
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="bg-background border-border">
          <DialogHeader>
            <DialogTitle className="text-accent flex items-center gap-2">
              {tipIcon}
              Tip {recipientName}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {/* Quick Amount Buttons */}
            <div>
              <p className="text-sm font-semibold text-foreground mb-2">
                Quick Amounts
              </p>
              <div className="grid grid-cols-5 gap-2">
                {quickAmounts.map((amt) => (
                  <Button
                    key={amt}
                    variant={selectedAmount === amt ? "default" : "outline"}
                    size="sm"
                    onClick={() => {
                      setSelectedAmount(amt);
                      setAmount("");
                    }}
                    className={
                      selectedAmount === amt ? "btn-gold" : "btn-neon-green"
                    }
                  >
                    ${amt}
                  </Button>
                ))}
              </div>
            </div>

            {/* Custom Amount */}
            <div>
              <label className="text-sm font-semibold text-foreground mb-2 block">
                Custom Amount ($)
              </label>
              <Input
                type="number"
                placeholder="Enter amount"
                value={amount}
                onChange={(e) => {
                  setAmount(e.target.value);
                  setSelectedAmount(null);
                }}
                min="1"
                step="0.01"
              />
            </div>

            {/* Message */}
            <div>
              <label className="text-sm font-semibold text-foreground mb-2 block">
                Message (Optional)
              </label>
              <Input
                type="text"
                placeholder="Add a message with your tip"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                maxLength={100}
              />
              <p className="text-xs text-muted-foreground mt-1">
                {message.length}/100
              </p>
            </div>

            {/* VIP Bonus Info */}
            {tipType === "player" && (
              <div className="bg-accent/10 border border-accent/30 p-3 rounded">
                <p className="text-xs text-accent flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" />
                  VIP players receive bonus multipliers on tips!
                </p>
              </div>
            )}

            {/* Stats */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-background/50 p-2 rounded">
                <p className="text-muted-foreground">Tips Given</p>
                <p className="text-accent font-bold">
                  ${tipStatsQuery.data?.totalTipsGiven.toFixed(2) || "0.00"}
                </p>
              </div>
              <div className="bg-background/50 p-2 rounded">
                <p className="text-muted-foreground">Tips Received</p>
                <p className="text-accent font-bold">
                  ${tipStatsQuery.data?.totalTipsReceived.toFixed(2) || "0.00"}
                </p>
              </div>
            </div>

            {/* Send Button */}
            <Button
              className="w-full btn-gold"
              onClick={handleSendTip}
              disabled={Boolean(
                sendTipMutation.isPending ||
                (!selectedAmount && !amount) ||
                (amount && Number(amount) <= 0)
              )}
            >
              {sendTipMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  Sending...
                </>
              ) : (
                <>
                  {tipIcon}
                  Send Tip
                </>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
