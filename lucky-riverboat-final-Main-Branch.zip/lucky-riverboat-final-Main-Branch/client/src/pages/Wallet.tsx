import { useAuth } from "@/_core/hooks/useAuth";
import CasinoLayout from "@/components/CasinoLayout";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { Loader2, ArrowUpRight, ArrowDownLeft, Lock, Copy, Coins, Shield, Clock, CheckCircle2, XCircle, AlertCircle } from "lucide-react";

const BTC_ADDRESS = "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh";
const ETH_ADDRESS = "0x71C7656EC7ab88b098defB751B7401B5f6d8976F";

export default function Wallet() {
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState<"deposit" | "withdraw" | "vault" | "history">("deposit");
  const [depositMethod, setDepositMethod] = useState<"btc" | "eth" | "stripe">("btc");
  const [amount, setAmount] = useState("");
  const [withdrawAddress, setWithdrawAddress] = useState("");
  const [vaultAction, setVaultAction] = useState<"lock" | "unlock">("lock");

  const balanceQuery = trpc.wallet.getBalance.useQuery();
  const transactionsQuery = trpc.wallet.getTransactions.useQuery({ limit: 20 });
  const depositMutation = trpc.wallet.deposit.useMutation();
  const withdrawMutation = trpc.wallet.requestWithdrawal.useMutation();
  const moveToVaultMutation = trpc.wallet.moveToVault.useMutation();
  const moveFromVaultMutation = trpc.wallet.moveFromVault.useMutation();

  const balance = Number(balanceQuery.data?.balance || 0);
  const vaultBalance = Number(balanceQuery.data?.vaultBalance || 0);

  const handleDeposit = async () => {
    try {
      await depositMutation.mutateAsync({ amount: Number(amount), method: depositMethod, txHash: `sim_${Date.now()}` });
      toast.success("Deposit submitted! Awaiting blockchain confirmation.");
      balanceQuery.refetch();
      transactionsQuery.refetch();
      setAmount("");
    } catch (e: any) { toast.error(e.message); }
  };

  const handleWithdraw = async () => {
    try {
      await withdrawMutation.mutateAsync({ amount: Number(amount), toAddress: withdrawAddress });
      toast.success("Withdrawal submitted for admin approval.");
      balanceQuery.refetch();
      transactionsQuery.refetch();
      setAmount("");
      setWithdrawAddress("");
    } catch (e: any) { toast.error(e.message); }
  };

  const handleVault = async () => {
    try {
      if (vaultAction === "lock") {
        await moveToVaultMutation.mutateAsync({ amount: Number(amount) });
      } else {
        await moveFromVaultMutation.mutateAsync({ amount: Number(amount) });
      }
      toast.success(`${vaultAction === "lock" ? "Locked" : "Unlocked"} $${Number(amount).toFixed(2)}`);
      balanceQuery.refetch();
      setAmount("");
    } catch (e: any) { toast.error(e.message); }
  };

  const copyAddress = (addr: string) => {
    navigator.clipboard.writeText(addr);
    toast.success("Address copied!");
  };

  if (loading) {
    return <CasinoLayout><div className="flex items-center justify-center py-32"><Loader2 className="w-8 h-8 animate-spin" style={{ color: "var(--gold)" }} /></div></CasinoLayout>;
  }

  const tabs = [
    { id: "deposit", label: "Deposit", icon: ArrowDownLeft },
    { id: "withdraw", label: "Withdraw", icon: ArrowUpRight },
    { id: "vault", label: "Vault", icon: Lock },
    { id: "history", label: "History", icon: Clock },
  ];

  return (
    <CasinoLayout>
      {/* Balance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="glass-card p-5">
          <div className="flex items-center gap-2 mb-2">
            <Coins size={16} style={{ color: "var(--gold)" }} />
            <span style={{ fontSize: "12px", color: "#64748b", fontWeight: 500 }}>AVAILABLE BALANCE</span>
          </div>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "28px", fontWeight: 700, color: "var(--gold)" }}>
            ${balance.toFixed(2)}
          </div>
        </div>
        <div className="glass-card p-5">
          <div className="flex items-center gap-2 mb-2">
            <Lock size={16} style={{ color: "var(--neon-purple)" }} />
            <span style={{ fontSize: "12px", color: "#64748b", fontWeight: 500 }}>VAULT BALANCE</span>
          </div>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "28px", fontWeight: 700, color: "var(--neon-purple)" }}>
            ${vaultBalance.toFixed(2)}
          </div>
        </div>
        <div className="glass-card p-5">
          <div className="flex items-center gap-2 mb-2">
            <Shield size={16} style={{ color: "var(--neon-green)" }} />
            <span style={{ fontSize: "12px", color: "#64748b", fontWeight: 500 }}>TOTAL ASSETS</span>
          </div>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "28px", fontWeight: 700, color: "var(--neon-green)" }}>
            ${(balance + vaultBalance).toFixed(2)}
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex gap-1 mb-6 p-1 rounded-xl" style={{ background: "var(--surface-1)", border: "1px solid var(--glass-border)" }}>
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className="flex-1 flex items-center justify-center gap-2 py-3 rounded-lg transition-all"
            style={{
              background: activeTab === tab.id ? "var(--surface-3)" : "transparent",
              color: activeTab === tab.id ? "#e2e8f0" : "#64748b",
              fontSize: "13px",
              fontWeight: activeTab === tab.id ? 600 : 400,
            }}
          >
            <tab.icon size={14} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Deposit Tab */}
      {activeTab === "deposit" && (
        <div className="glass-card p-6">
          <h2 className="flex items-center gap-2 mb-6" style={{ fontSize: "18px", fontWeight: 600, color: "#e2e8f0" }}>
            <ArrowDownLeft size={18} style={{ color: "var(--neon-green)" }} /> Deposit Funds
          </h2>

          <div className="grid grid-cols-3 gap-3 mb-6">
            {[
              { id: "btc" as const, label: "Bitcoin", icon: "₿", color: "#f7931a" },
              { id: "eth" as const, label: "Ethereum", icon: "Ξ", color: "#627eea" },
              { id: "stripe" as const, label: "Card", icon: "💳", color: "var(--gold)" },
            ].map((m) => (
              <button
                key={m.id}
                onClick={() => setDepositMethod(m.id)}
                className="p-4 rounded-xl text-center transition-all"
                style={{
                  background: depositMethod === m.id ? "rgba(212,168,67,0.1)" : "var(--surface-2)",
                  border: `1px solid ${depositMethod === m.id ? "var(--gold)" : "var(--glass-border)"}`,
                }}
              >
                <div style={{ fontSize: "24px", marginBottom: "4px" }}>{m.icon}</div>
                <div style={{ fontSize: "12px", color: depositMethod === m.id ? "#e2e8f0" : "#64748b" }}>{m.label}</div>
              </button>
            ))}
          </div>

          {depositMethod !== "stripe" && (
            <div className="mb-6 p-4 rounded-xl" style={{ background: "var(--surface-2)", border: "1px solid var(--glass-border)" }}>
              <div style={{ fontSize: "12px", color: "#64748b", marginBottom: "8px" }}>
                Send {depositMethod === "btc" ? "Bitcoin" : "Ethereum"} to this address:
              </div>
              <div className="flex items-center gap-2">
                <code className="flex-1 truncate" style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "13px", color: "var(--neon-green)" }}>
                  {depositMethod === "btc" ? BTC_ADDRESS : ETH_ADDRESS}
                </code>
                <button
                  onClick={() => copyAddress(depositMethod === "btc" ? BTC_ADDRESS : ETH_ADDRESS)}
                  className="p-2 rounded-lg hover:bg-[var(--surface-3)] transition-colors"
                  style={{ color: "#64748b" }}
                >
                  <Copy size={14} />
                </button>
              </div>
              <div className="mt-3 flex items-center gap-2" style={{ fontSize: "11px", color: "#475569" }}>
                <AlertCircle size={12} />
                Funds credited after blockchain confirmation
              </div>
            </div>
          )}

          <div className="mb-4">
            <label style={{ fontSize: "12px", color: "#64748b", fontWeight: 500, marginBottom: "8px", display: "block" }}>AMOUNT</label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "#64748b" }}>$</span>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full rounded-xl py-3 pl-7 pr-3"
                style={{ background: "var(--surface-2)", border: "1px solid var(--glass-border)", color: "#e2e8f0", fontFamily: "'JetBrains Mono', monospace", fontSize: "16px", outline: "none" }}
              />
            </div>
          </div>

          <button
            onClick={handleDeposit}
            disabled={!amount || Number(amount) <= 0 || depositMutation.isPending}
            className="btn-primary w-full flex items-center justify-center gap-2"
            style={{ padding: "14px", fontSize: "15px", fontWeight: 600, borderRadius: "12px" }}
          >
            {depositMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowDownLeft size={16} />}
            {depositMutation.isPending ? "Processing..." : "Deposit"}
          </button>
        </div>
      )}

      {/* Withdraw Tab */}
      {activeTab === "withdraw" && (
        <div className="glass-card p-6">
          <h2 className="flex items-center gap-2 mb-6" style={{ fontSize: "18px", fontWeight: 600, color: "#e2e8f0" }}>
            <ArrowUpRight size={18} style={{ color: "#ef4444" }} /> Withdraw Funds
          </h2>

          <div className="mb-4">
            <label style={{ fontSize: "12px", color: "#64748b", fontWeight: 500, marginBottom: "8px", display: "block" }}>WITHDRAWAL ADDRESS</label>
            <input
              type="text"
              value={withdrawAddress}
              onChange={(e) => setWithdrawAddress(e.target.value)}
              placeholder="bc1q... or 0x..."
              className="w-full rounded-xl py-3 px-3 mb-4"
              style={{ background: "var(--surface-2)", border: "1px solid var(--glass-border)", color: "#e2e8f0", fontFamily: "'JetBrains Mono', monospace", fontSize: "14px", outline: "none" }}
            />
          </div>

          <div className="mb-4">
            <label style={{ fontSize: "12px", color: "#64748b", fontWeight: 500, marginBottom: "8px", display: "block" }}>AMOUNT</label>
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "#64748b" }}>$</span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full rounded-xl py-3 pl-7 pr-3"
                  style={{ background: "var(--surface-2)", border: "1px solid var(--glass-border)", color: "#e2e8f0", fontFamily: "'JetBrains Mono', monospace", fontSize: "16px", outline: "none" }}
                />
              </div>
              <button onClick={() => setAmount(balance.toFixed(2))} className="px-4 rounded-xl" style={{ background: "var(--surface-2)", border: "1px solid var(--glass-border)", color: "#94a3b8", fontSize: "13px" }}>
                MAX
              </button>
            </div>
          </div>

          <div className="p-3 rounded-xl mb-4" style={{ background: "rgba(239,68,68,0.05)", border: "1px solid rgba(239,68,68,0.15)" }}>
            <div className="flex items-center gap-2" style={{ fontSize: "12px", color: "#ef4444" }}>
              <AlertCircle size={12} />
              Withdrawals require admin approval and may take up to 24 hours.
            </div>
          </div>

          <button
            onClick={handleWithdraw}
            disabled={!amount || Number(amount) <= 0 || !withdrawAddress || withdrawMutation.isPending}
            className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold transition-all"
            style={{ background: "linear-gradient(135deg, #ef4444, #dc2626)", color: "#fff", fontSize: "15px" }}
          >
            {withdrawMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowUpRight size={16} />}
            {withdrawMutation.isPending ? "Processing..." : "Request Withdrawal"}
          </button>
        </div>
      )}

      {/* Vault Tab */}
      {activeTab === "vault" && (
        <div className="glass-card p-6">
          <h2 className="flex items-center gap-2 mb-6" style={{ fontSize: "18px", fontWeight: 600, color: "#e2e8f0" }}>
            <Lock size={18} style={{ color: "var(--neon-purple)" }} /> Vault
          </h2>
          <p style={{ fontSize: "14px", color: "#64748b", marginBottom: "24px" }}>
            Protect your funds by locking them in the vault. Vault funds cannot be wagered until unlocked.
          </p>

          <div className="flex gap-2 mb-6">
            {(["lock", "unlock"] as const).map((action) => (
              <button
                key={action}
                onClick={() => setVaultAction(action)}
                className="flex-1 py-3 rounded-xl capitalize transition-all"
                style={{
                  background: vaultAction === action ? "rgba(179,136,255,0.1)" : "var(--surface-2)",
                  border: `1px solid ${vaultAction === action ? "var(--neon-purple)" : "var(--glass-border)"}`,
                  color: vaultAction === action ? "#e2e8f0" : "#64748b",
                  fontSize: "14px",
                  fontWeight: vaultAction === action ? 600 : 400,
                }}
              >
                {action === "lock" ? "🔒 Lock Funds" : "🔓 Unlock Funds"}
              </button>
            ))}
          </div>

          <div className="mb-4">
            <label style={{ fontSize: "12px", color: "#64748b", fontWeight: 500, marginBottom: "8px", display: "block" }}>AMOUNT</label>
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "#64748b" }}>$</span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full rounded-xl py-3 pl-7 pr-3"
                  style={{ background: "var(--surface-2)", border: "1px solid var(--glass-border)", color: "#e2e8f0", fontFamily: "'JetBrains Mono', monospace", fontSize: "16px", outline: "none" }}
                />
              </div>
              <button
                onClick={() => setAmount((vaultAction === "lock" ? balance : vaultBalance).toFixed(2))}
                className="px-4 rounded-xl"
                style={{ background: "var(--surface-2)", border: "1px solid var(--glass-border)", color: "#94a3b8", fontSize: "13px" }}
              >
                MAX
              </button>
            </div>
          </div>

          <button
            onClick={handleVault}
            disabled={!amount || Number(amount) <= 0 || (vaultAction === "lock" ? moveToVaultMutation.isPending : moveFromVaultMutation.isPending)}
            className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold transition-all"
            style={{ background: "linear-gradient(135deg, var(--neon-purple), #7c3aed)", color: "#fff", fontSize: "15px" }}
          >
            {(vaultAction === "lock" ? moveToVaultMutation.isPending : moveFromVaultMutation.isPending) ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock size={16} />}
            {(vaultAction === "lock" ? moveToVaultMutation.isPending : moveFromVaultMutation.isPending) ? "Processing..." : vaultAction === "lock" ? "Lock in Vault" : "Unlock from Vault"}
          </button>
        </div>
      )}

      {/* History Tab */}
      {activeTab === "history" && (
        <div className="glass-card overflow-hidden">
          <div className="p-4" style={{ borderBottom: "1px solid var(--glass-border)" }}>
            <h2 className="flex items-center gap-2" style={{ fontSize: "16px", fontWeight: 600, color: "#e2e8f0" }}>
              <Clock size={16} style={{ color: "var(--gold)" }} /> Transaction History
            </h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full" style={{ fontSize: "13px" }}>
              <thead>
                <tr style={{ borderBottom: "1px solid var(--glass-border)" }}>
                  <th className="text-left py-3 px-4" style={{ color: "#64748b", fontWeight: 500 }}>Type</th>
                  <th className="text-right py-3 px-4" style={{ color: "#64748b", fontWeight: 500 }}>Amount</th>
                  <th className="text-right py-3 px-4" style={{ color: "#64748b", fontWeight: 500 }}>Status</th>
                  <th className="text-right py-3 px-4" style={{ color: "#64748b", fontWeight: 500 }}>Date</th>
                </tr>
              </thead>
              <tbody>
                {transactionsQuery.data?.length ? transactionsQuery.data.map((tx, i) => (
                  <tr key={i} style={{ borderBottom: "1px solid rgba(255,255,255,0.03)" }} className="hover:bg-[var(--surface-2)] transition-colors">
                    <td className="py-3 px-4 capitalize flex items-center gap-2" style={{ color: "#e2e8f0" }}>
                      {tx.type === "deposit" ? <ArrowDownLeft size={14} style={{ color: "var(--neon-green)" }} /> : <ArrowUpRight size={14} style={{ color: "#ef4444" }} />}
                      {tx.type}
                    </td>
                    <td className="text-right py-3 px-4" style={{ fontFamily: "'JetBrains Mono', monospace", color: tx.type === "deposit" ? "var(--neon-green)" : "#ef4444" }}>
                      {tx.type === "deposit" ? "+" : "-"}${Number(tx.amount).toFixed(2)}
                    </td>
                    <td className="text-right py-3 px-4">
                      <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md" style={{
                        fontSize: "11px",
                        background: tx.status === "completed" ? "rgba(0,230,118,0.1)" : tx.status === "pending" ? "rgba(212,168,67,0.1)" : "rgba(239,68,68,0.1)",
                        color: tx.status === "completed" ? "var(--neon-green)" : tx.status === "pending" ? "var(--gold)" : "#ef4444",
                      }}>
                        {tx.status === "completed" ? <CheckCircle2 size={10} /> : tx.status === "pending" ? <Clock size={10} /> : <XCircle size={10} />}
                        {tx.status}
                      </span>
                    </td>
                    <td className="text-right py-3 px-4" style={{ color: "#475569", fontSize: "12px" }}>
                      {new Date(tx.createdAt).toLocaleDateString()}
                    </td>
                  </tr>
                )) : (
                  <tr><td colSpan={4} className="text-center py-8" style={{ color: "#475569" }}>No transactions yet</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </CasinoLayout>
  );
}
