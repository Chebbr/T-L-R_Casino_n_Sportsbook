import { useAuth } from "@/_core/hooks/useAuth";
import CasinoLayout from "@/components/CasinoLayout";
import { useState, useRef, useEffect } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Loader2, MessageCircle, Send, Bot, User, Clock, CheckCircle, AlertCircle, HelpCircle } from "lucide-react";

interface SupportMessage {
  id: number;
  sender: "user" | "bot" | "admin";
  message: string;
  timestamp: Date;
  category?: string;
}

const QUICK_TOPICS = [
  { label: "Deposit Issue", icon: "💰", category: "deposit" },
  { label: "Withdrawal Help", icon: "🏦", category: "withdrawal" },
  { label: "Game Problem", icon: "🎮", category: "game" },
  { label: "Account Issue", icon: "👤", category: "account" },
  { label: "Bonus Question", icon: "🎁", category: "bonus" },
  { label: "Other", icon: "❓", category: "other" },
];

const BOT_RESPONSES: Record<string, string> = {
  deposit: "I understand you're having a deposit issue. Please provide your transaction hash or payment method, and I'll create a support ticket for our team to review. Typical response time is under 30 minutes.",
  withdrawal: "For withdrawal assistance, please note that all withdrawals require admin approval. If your withdrawal has been pending for more than 24 hours, I'll escalate this to our team immediately.",
  game: "I'm sorry you're experiencing a game issue. Please describe what happened, including the game name and approximate time. Our team will investigate and credit any affected funds.",
  account: "For account-related issues, I can help with password resets, verification, and profile updates. Please describe your specific issue and I'll guide you through the resolution.",
  bonus: "For bonus and promotion questions, please share the bonus code or promotion name. I can check eligibility, wagering requirements, and expiration details for you.",
  other: "I'm here to help! Please describe your issue in detail and I'll either resolve it directly or create a priority support ticket for our team.",
};

const FOLLOW_UP_RESPONSES: Record<string, string[]> = {
  deposit: [
    "I can help with that. What payment method are you using — BTC, ETH, or card?",
    "How long has it been since you initiated the deposit?",
    "Let me check the status of your transaction. Can you provide the hash?",
    "I'm escalating this to our admin team for immediate review.",
  ],
  withdrawal: [
    "What withdrawal method did you select?",
    "Our admin team reviews withdrawals every 2 hours. Let me check your queue position.",
    "I see your withdrawal is pending. I'll flag it for priority review.",
    "An admin will process your request shortly.",
  ],
  game: [
    "Which game were you playing when this occurred?",
    "What device and browser are you using?",
    "Have you tried refreshing the page and clearing your cache?",
    "Our technical team will investigate this issue.",
  ],
  account: [
    "Can you tell me when this started happening?",
    "Have you tried clearing your browser cache and cookies?",
    "Please provide your account email so I can look into this further.",
    "I'm escalating this to our admin team for immediate assistance.",
  ],
  bonus: [
    "Which bonus code are you trying to use?",
    "Have you met the wagering requirements for this bonus?",
    "Let me verify your bonus eligibility right now.",
    "I'll have an admin review your bonus status.",
  ],
  other: [
    "I'll do my best to help. Can you provide more details?",
    "Let me escalate this to the appropriate team.",
    "An admin will be with you shortly.",
    "Thank you for your patience!",
  ],
};

export default function Support() {
  const { user, loading } = useAuth();
  const [messages, setMessages] = useState<SupportMessage[]>([
    { id: 1, sender: "bot", message: "Welcome to Lucky Riverboat Support! 🚢 I'm here to help you with any issues. Select a topic below or describe your problem.", timestamp: new Date() },
  ]);
  const [input, setInput] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [ticketCreated, setTicketCreated] = useState(false);
  const [ticketId, setTicketId] = useState<string | null>(null);
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const createTicketMutation = trpc.support.createTicket.useMutation();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSelectTopic = (category: string) => {
    setSelectedCategory(category);
    const topicLabel = QUICK_TOPICS.find((t) => t.category === category)?.label || category;
    setMessages((prev) => [
      ...prev,
      { id: Date.now(), sender: "user", message: topicLabel, timestamp: new Date(), category },
      { id: Date.now() + 1, sender: "bot", message: BOT_RESPONSES[category] || BOT_RESPONSES.other, timestamp: new Date() },
    ]);
  };

  const handleSend = async () => {
    if (!input.trim()) return;
    setIsSending(true);

    const userMsg: SupportMessage = { id: Date.now(), sender: "user", message: input, timestamp: new Date() };
    setMessages((prev) => [...prev, userMsg]);
    const currentInput = input;
    setInput("");

    // Try to create a real ticket
    try {
      await createTicketMutation.mutateAsync({
        subject: selectedCategory || "general",
        message: currentInput,
      });
    } catch {
      // Silently continue with mock response
    }

    setTimeout(() => {
      if (!ticketCreated) {
        const newTicketId = `TKT-${Math.floor(10000 + Math.random() * 90000)}`;
        setTicketCreated(true);
        setTicketId(newTicketId);
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now() + 1,
            sender: "bot",
            message: `I've created support ticket ${newTicketId} for your issue. Our team has been notified and will respond shortly. You'll receive updates here. Average resolution time: 2-4 hours.`,
            timestamp: new Date(),
          },
        ]);
      } else {
        const cat = selectedCategory || "other";
        const responses = FOLLOW_UP_RESPONSES[cat] || FOLLOW_UP_RESPONSES.other;
        const response = responses[Math.floor(Math.random() * responses.length)];
        setMessages((prev) => [
          ...prev,
          { id: Date.now() + 1, sender: "bot", message: response, timestamp: new Date() },
        ]);
      }
      setIsSending(false);
    }, 1000);
  };

  if (loading) {
    return (
      <CasinoLayout>
        <div className="flex items-center justify-center py-32">
          <Loader2 className="w-8 h-8 animate-spin" style={{ color: "var(--gold)" }} />
        </div>
      </CasinoLayout>
    );
  }

  return (
    <CasinoLayout>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="flex items-center gap-2" style={{ fontSize: "24px", fontWeight: 700, color: "#e2e8f0" }}>
            <HelpCircle size={24} style={{ color: "var(--gold)" }} />
            Support Center
          </h1>
          <p style={{ fontSize: "14px", color: "#64748b", marginTop: "4px" }}>AI-powered support — get help instantly</p>
        </div>
        {ticketCreated && ticketId && (
          <div className="glass-card px-4 py-2 flex items-center gap-2">
            <CheckCircle size={14} style={{ color: "var(--neon-green)" }} />
            <span style={{ fontSize: "13px", color: "var(--neon-green)", fontWeight: 600 }}>{ticketId} Active</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Chat Panel */}
        <div className="lg:col-span-3 glass-card overflow-hidden flex flex-col" style={{ height: "calc(100vh - 220px)", border: "1px solid rgba(212,168,67,0.1)" }}>
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4" style={{ scrollbarWidth: "thin", scrollbarColor: "rgba(255,255,255,0.1) transparent" }}>
            {messages.map((msg) => (
              <div key={msg.id} className={`flex gap-3 ${msg.sender === "user" ? "flex-row-reverse" : ""}`}>
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{
                    background: msg.sender === "bot" ? "rgba(212,168,67,0.1)" : msg.sender === "admin" ? "rgba(239,68,68,0.1)" : "rgba(59,130,246,0.1)",
                    border: `1px solid ${msg.sender === "bot" ? "rgba(212,168,67,0.3)" : msg.sender === "admin" ? "rgba(239,68,68,0.3)" : "rgba(59,130,246,0.3)"}`,
                  }}
                >
                  {msg.sender === "bot" ? <Bot size={14} style={{ color: "var(--gold)" }} /> :
                   msg.sender === "admin" ? <AlertCircle size={14} style={{ color: "#ef4444" }} /> :
                   <User size={14} style={{ color: "#3b82f6" }} />}
                </div>
                <div style={{ maxWidth: "70%" }}>
                  <div
                    className="rounded-xl px-4 py-3"
                    style={{
                      background: msg.sender === "user" ? "rgba(59,130,246,0.1)" : "var(--surface-2)",
                      border: `1px solid ${msg.sender === "user" ? "rgba(59,130,246,0.2)" : "var(--glass-border)"}`,
                    }}
                  >
                    <p style={{ fontSize: "14px", color: "#e2e8f0", lineHeight: 1.5 }}>{msg.message}</p>
                  </div>
                  <div className="flex items-center gap-2 mt-1 px-1" style={{ fontSize: "11px", color: "#475569" }}>
                    <Clock size={10} />
                    {msg.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </div>
                </div>
              </div>
            ))}
            {isSending && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "rgba(212,168,67,0.1)", border: "1px solid rgba(212,168,67,0.3)" }}>
                  <Bot size={14} style={{ color: "var(--gold)" }} />
                </div>
                <div className="rounded-xl px-4 py-3" style={{ background: "var(--surface-2)", border: "1px solid var(--glass-border)" }}>
                  <div className="flex gap-1">
                    <span className="w-2 h-2 rounded-full bg-[var(--gold)] animate-bounce" style={{ animationDelay: "0ms" }} />
                    <span className="w-2 h-2 rounded-full bg-[var(--gold)] animate-bounce" style={{ animationDelay: "150ms" }} />
                    <span className="w-2 h-2 rounded-full bg-[var(--gold)] animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Topics */}
          {!selectedCategory && (
            <div className="px-4 pb-2">
              <p style={{ fontSize: "12px", color: "#64748b", marginBottom: "8px", fontWeight: 500 }}>Quick Topics:</p>
              <div className="flex flex-wrap gap-2">
                {QUICK_TOPICS.map((topic) => (
                  <button
                    key={topic.category}
                    onClick={() => handleSelectTopic(topic.category)}
                    className="rounded-xl px-3 py-2 flex items-center gap-2 transition-all hover:scale-105 cursor-pointer"
                    style={{
                      background: "var(--surface-2)",
                      border: "1px solid var(--glass-border)",
                      fontSize: "13px",
                      color: "#94a3b8",
                    }}
                  >
                    <span>{topic.icon}</span>
                    {topic.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Input */}
          <div className="p-4" style={{ borderTop: "1px solid var(--glass-border)" }}>
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && !isSending && handleSend()}
                placeholder="Describe your issue..."
                disabled={isSending}
                className="flex-1 rounded-xl py-3 px-4"
                style={{
                  background: "var(--surface-2)",
                  border: "1px solid var(--glass-border)",
                  color: "#e2e8f0",
                  fontSize: "14px",
                  outline: "none",
                }}
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || isSending}
                className="btn-primary rounded-xl px-5 flex items-center gap-2"
                style={{ opacity: !input.trim() || isSending ? 0.5 : 1 }}
              >
                {isSending ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
              </button>
            </div>
          </div>
        </div>

        {/* Info Sidebar */}
        <div className="space-y-4">
          <div className="glass-card p-4">
            <h3 className="flex items-center gap-2 mb-3" style={{ fontSize: "14px", fontWeight: 600, color: "#e2e8f0" }}>
              <MessageCircle size={14} style={{ color: "var(--gold)" }} />
              Support Stats
            </h3>
            <div className="space-y-3">
              {[
                { label: "Avg Response", value: "< 30 min", color: "var(--neon-green)" },
                { label: "Resolution Time", value: "2-4 hours", color: "var(--gold)" },
                { label: "Satisfaction", value: "98.5%", color: "var(--neon-green)" },
                { label: "Open Tickets", value: ticketCreated ? "1" : "0", color: "#3b82f6" },
              ].map((stat) => (
                <div key={stat.label} className="flex justify-between items-center">
                  <span style={{ fontSize: "12px", color: "#64748b" }}>{stat.label}</span>
                  <span style={{ fontSize: "13px", fontWeight: 600, fontFamily: "'JetBrains Mono', monospace", color: stat.color }}>{stat.value}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card p-4">
            <h3 className="flex items-center gap-2 mb-3" style={{ fontSize: "14px", fontWeight: 600, color: "#e2e8f0" }}>
              <AlertCircle size={14} style={{ color: "var(--gold)" }} />
              Common Questions
            </h3>
            <div className="space-y-2">
              {[
                "How long do withdrawals take?",
                "What are the wagering requirements?",
                "How do I verify my account?",
                "Can I change my username?",
                "How does the VIP system work?",
              ].map((q) => (
                <button
                  key={q}
                  onClick={() => { setInput(q); }}
                  className="w-full text-left rounded-lg p-2 transition-colors hover:bg-[rgba(255,255,255,0.03)] cursor-pointer"
                  style={{ fontSize: "12px", color: "#94a3b8" }}
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          <div className="glass-card p-4">
            <h3 className="flex items-center gap-2 mb-3" style={{ fontSize: "14px", fontWeight: 600, color: "#e2e8f0" }}>
              💡 Tips
            </h3>
            <ul className="space-y-2" style={{ fontSize: "12px", color: "#64748b" }}>
              <li className="flex items-start gap-2"><span style={{ color: "var(--gold)" }}>•</span> Be specific about your issue</li>
              <li className="flex items-start gap-2"><span style={{ color: "var(--gold)" }}>•</span> Include error messages if any</li>
              <li className="flex items-start gap-2"><span style={{ color: "var(--gold)" }}>•</span> Provide transaction hashes for payment issues</li>
              <li className="flex items-start gap-2"><span style={{ color: "var(--gold)" }}>•</span> Admins respond within 1 hour</li>
            </ul>
          </div>
        </div>
      </div>
    </CasinoLayout>
  );
}
