import { useAuth } from "@/_core/hooks/useAuth";
import CasinoLayout from "@/components/CasinoLayout";
import { useState } from "react";
import { toast } from "sonner";
import { Loader2, Users, Coins, Trophy, Zap, ArrowLeft } from "lucide-react";

const WATERMARK_URL = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663341115981/TtZTjkmKyKWMaHFr.jpg";

interface PokerTable {
  id: number;
  name: string;
  buyin: number;
  maxPlayers: number;
  currentPlayers: number;
  bigBlind: number;
  smallBlind: number;
  players: { id: number; name: string; chips: number; isActive: boolean }[];
}

const MOCK_TABLES: PokerTable[] = [
  {
    id: 1, name: "High Rollers Table", buyin: 100, maxPlayers: 6, currentPlayers: 4, bigBlind: 2, smallBlind: 1,
    players: [
      { id: 1, name: "HighRoller99", chips: 5000, isActive: true },
      { id: 2, name: "PokerPro", chips: 3500, isActive: true },
      { id: 3, name: "LuckyAce", chips: 2800, isActive: true },
      { id: 4, name: "CasinoKing", chips: 4200, isActive: true },
    ],
  },
  {
    id: 2, name: "Medium Stakes", buyin: 25, maxPlayers: 8, currentPlayers: 6, bigBlind: 0.5, smallBlind: 0.25,
    players: [
      { id: 5, name: "CardShark", chips: 1200, isActive: true },
      { id: 6, name: "BluffMaster", chips: 800, isActive: true },
      { id: 7, name: "RiverRat", chips: 1500, isActive: true },
      { id: 8, name: "AllInAndy", chips: 600, isActive: true },
      { id: 9, name: "TightPlayer", chips: 2000, isActive: true },
      { id: 10, name: "FishyFish", chips: 400, isActive: true },
    ],
  },
  {
    id: 3, name: "Beginner's Table", buyin: 5, maxPlayers: 6, currentPlayers: 3, bigBlind: 0.1, smallBlind: 0.05,
    players: [
      { id: 11, name: "NewbieNick", chips: 500, isActive: true },
      { id: 12, name: "FirstTimer", chips: 300, isActive: true },
      { id: 13, name: "LearningLarry", chips: 450, isActive: true },
    ],
  },
];

const HAND_RANKINGS = [
  { rank: 1, name: "Royal Flush", desc: "A, K, Q, J, 10 of the same suit", odds: "649,739:1" },
  { rank: 2, name: "Straight Flush", desc: "Five consecutive cards of the same suit", odds: "72,192:1" },
  { rank: 3, name: "Four of a Kind", desc: "Four cards of the same rank", odds: "4,164:1" },
  { rank: 4, name: "Full House", desc: "Three of a kind plus a pair", odds: "693:1" },
  { rank: 5, name: "Flush", desc: "Five cards of the same suit", odds: "508:1" },
  { rank: 6, name: "Straight", desc: "Five consecutive cards", odds: "254:1" },
  { rank: 7, name: "Three of a Kind", desc: "Three cards of the same rank", odds: "46:1" },
  { rank: 8, name: "Two Pair", desc: "Two different pairs", odds: "20:1" },
  { rank: 9, name: "One Pair", desc: "Two cards of the same rank", odds: "1.37:1" },
  { rank: 10, name: "High Card", desc: "Highest card plays", odds: "0.99:1" },
];

export default function Poker() {
  const { loading } = useAuth();
  const [selectedTable, setSelectedTable] = useState<PokerTable | null>(null);
  const [showHandRankings, setShowHandRankings] = useState(false);

  if (loading) {
    return (
      <CasinoLayout>
        <div className="flex items-center justify-center py-32">
          <Loader2 className="w-8 h-8 animate-spin" style={{ color: "var(--gold)" }} />
        </div>
      </CasinoLayout>
    );
  }

  return (
    <CasinoLayout>
      {/* Page Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="flex items-center gap-2" style={{ fontSize: "24px", fontWeight: 700, color: "#e2e8f0" }}>
            <Trophy size={24} style={{ color: "var(--gold)" }} />
            Poker Room
          </h1>
          <p style={{ fontSize: "14px", color: "#64748b", marginTop: "4px" }}>Texas Hold'em — Compete at live tables</p>
        </div>
        <button
          onClick={() => setShowHandRankings(!showHandRankings)}
          className="glass-card px-4 py-2 transition-all hover:scale-105"
          style={{ fontSize: "13px", color: "var(--gold)", fontWeight: 600, cursor: "pointer" }}
        >
          {showHandRankings ? "Hide Rankings" : "Hand Rankings"}
        </button>
      </div>

      {/* Hand Rankings Panel */}
      {showHandRankings && (
        <div className="glass-card overflow-hidden mb-6" style={{ border: "1px solid rgba(212,168,67,0.2)" }}>
          <div className="p-4" style={{ borderBottom: "1px solid var(--glass-border)" }}>
            <h2 className="flex items-center gap-2" style={{ fontSize: "16px", fontWeight: 600, color: "#e2e8f0" }}>
              <Zap size={16} style={{ color: "var(--gold)" }} />
              Hand Rankings (Best to Worst)
            </h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full" style={{ fontSize: "13px" }}>
              <thead>
                <tr style={{ borderBottom: "1px solid var(--glass-border)" }}>
                  <th className="text-left py-3 px-4" style={{ color: "#64748b", fontWeight: 500 }}>#</th>
                  <th className="text-left py-3 px-4" style={{ color: "#64748b", fontWeight: 500 }}>Hand</th>
                  <th className="text-left py-3 px-4" style={{ color: "#64748b", fontWeight: 500 }}>Description</th>
                  <th className="text-right py-3 px-4" style={{ color: "#64748b", fontWeight: 500 }}>Odds</th>
                </tr>
              </thead>
              <tbody>
                {HAND_RANKINGS.map((h) => (
                  <tr key={h.rank} style={{ borderBottom: "1px solid rgba(255,255,255,0.03)" }} className="hover:bg-[var(--surface-2)] transition-colors">
                    <td className="py-2 px-4" style={{ color: "var(--gold)", fontWeight: 700, fontFamily: "'JetBrains Mono', monospace" }}>{h.rank}</td>
                    <td className="py-2 px-4" style={{ color: "#e2e8f0", fontWeight: 600 }}>{h.name}</td>
                    <td className="py-2 px-4" style={{ color: "#94a3b8" }}>{h.desc}</td>
                    <td className="text-right py-2 px-4" style={{ fontFamily: "'JetBrains Mono', monospace", color: "#64748b" }}>{h.odds}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {!selectedTable ? (
        <>
          {/* Table Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {MOCK_TABLES.map((table) => (
              <button
                key={table.id}
                onClick={() => setSelectedTable(table)}
                className="game-card-premium text-left group"
              >
                <div className="relative overflow-hidden" style={{ aspectRatio: "16/10" }}>
                  {/* Watermark Background */}
                  <div
                    className="absolute inset-0"
                    style={{
                      backgroundImage: `url(${WATERMARK_URL})`,
                      backgroundSize: "cover",
                      backgroundPosition: "center",
                      filter: "brightness(0.12) contrast(1.3) sepia(0.5)",
                    }}
                  />
                  <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at center, rgba(0,100,0,0.15) 0%, transparent 70%)" }} />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <span style={{ fontSize: "48px", filter: "drop-shadow(0 0 20px rgba(0,230,118,0.3))" }}>🃏</span>
                      <div style={{ fontSize: "11px", color: "rgba(255,255,255,0.5)", marginTop: "8px", letterSpacing: "1px" }}>
                        ${table.smallBlind}/${table.bigBlind} BLINDS
                      </div>
                    </div>
                  </div>
                  <div className="player-count">
                    <div className="live-dot" />
                    {table.currentPlayers}/{table.maxPlayers} seated
                  </div>
                </div>
                <div className="card-info">
                  <h3>{table.name}</h3>
                  <div className="card-provider">Buy-in: ${table.buyin} • {table.maxPlayers}-max</div>
                </div>
              </button>
            ))}
          </div>

          {/* Poker Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { label: "Active Tables", value: MOCK_TABLES.length.toString(), icon: <Users size={16} /> },
              { label: "Total Players", value: MOCK_TABLES.reduce((a, t) => a + t.currentPlayers, 0).toString(), icon: <Coins size={16} /> },
              { label: "Biggest Pot Today", value: "$12,450", icon: <Trophy size={16} /> },
            ].map((stat) => (
              <div key={stat.label} className="glass-card p-4 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "rgba(212,168,67,0.1)", color: "var(--gold)" }}>
                  {stat.icon}
                </div>
                <div>
                  <div style={{ fontSize: "12px", color: "#64748b" }}>{stat.label}</div>
                  <div style={{ fontSize: "20px", fontWeight: 700, fontFamily: "'JetBrains Mono', monospace", color: "#e2e8f0" }}>{stat.value}</div>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        <>
          {/* Table View */}
          <button
            onClick={() => setSelectedTable(null)}
            className="flex items-center gap-2 mb-6 hover:opacity-80 transition-opacity"
            style={{ color: "#94a3b8", fontSize: "14px" }}
          >
            <ArrowLeft size={16} /> Back to Tables
          </button>

          <div className="glass-card overflow-hidden mb-6" style={{ border: "1px solid rgba(0,100,0,0.3)" }}>
            <div className="p-4 flex items-center justify-between" style={{ borderBottom: "1px solid var(--glass-border)" }}>
              <h2 className="flex items-center gap-2" style={{ fontSize: "18px", fontWeight: 600, color: "#e2e8f0" }}>
                🃏 {selectedTable.name}
              </h2>
              <div className="flex items-center gap-3">
                <span style={{ fontSize: "12px", color: "#64748b" }}>Blinds: ${selectedTable.smallBlind}/${selectedTable.bigBlind}</span>
                <span className="flex items-center gap-1" style={{ fontSize: "12px", color: "var(--neon-green)" }}>
                  <div className="live-dot" style={{ width: "6px", height: "6px" }} />
                  {selectedTable.currentPlayers}/{selectedTable.maxPlayers}
                </span>
              </div>
            </div>

            {/* Poker Table Visual */}
            <div className="relative" style={{ minHeight: "400px" }}>
              <div
                className="absolute inset-0"
                style={{
                  backgroundImage: `url(${WATERMARK_URL})`,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                  filter: "brightness(0.08) contrast(1.3) sepia(0.6)",
                }}
              />
              <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at 50% 50%, rgba(0,80,0,0.2) 0%, transparent 60%)" }} />
              <div className="absolute inset-0 pointer-events-none" style={{ boxShadow: "inset 0 0 100px rgba(0,0,0,0.6)" }} />

              <div className="relative flex items-center justify-center" style={{ minHeight: "400px" }}>
                {/* Table Oval */}
                <div
                  className="relative"
                  style={{
                    width: "500px",
                    height: "260px",
                    borderRadius: "50%",
                    background: "radial-gradient(ellipse, rgba(0,80,30,0.6) 0%, rgba(0,50,20,0.8) 100%)",
                    border: "4px solid rgba(212,168,67,0.4)",
                    boxShadow: "0 0 40px rgba(0,0,0,0.5), inset 0 0 40px rgba(0,0,0,0.3), 0 0 20px rgba(212,168,67,0.1)",
                  }}
                >
                  {/* Community Cards */}
                  <div className="absolute inset-0 flex items-center justify-center gap-2">
                    {["🂡", "🂮", "🂻", "🃁", "🃎"].map((card, i) => (
                      <div
                        key={i}
                        className="w-12 h-16 rounded-lg flex items-center justify-center"
                        style={{
                          background: "linear-gradient(135deg, #fff 0%, #e8e8e8 100%)",
                          boxShadow: "0 4px 12px rgba(0,0,0,0.4)",
                          fontSize: "24px",
                          border: "1px solid rgba(0,0,0,0.1)",
                        }}
                      >
                        {card}
                      </div>
                    ))}
                  </div>

                  {/* Pot Display */}
                  <div className="absolute" style={{ bottom: "20px", left: "50%", transform: "translateX(-50%)" }}>
                    <div
                      className="px-4 py-1 rounded-full"
                      style={{
                        background: "rgba(0,0,0,0.6)",
                        border: "1px solid rgba(212,168,67,0.3)",
                        fontSize: "13px",
                        fontFamily: "'JetBrains Mono', monospace",
                        color: "var(--gold)",
                        fontWeight: 600,
                      }}
                    >
                      POT: $450
                    </div>
                  </div>

                  {/* Players around table */}
                  {selectedTable.players.map((player, i) => {
                    const total = selectedTable.players.length;
                    const angle = (i / total) * Math.PI * 2 - Math.PI / 2;
                    const rx = 290;
                    const ry = 170;
                    const x = Math.cos(angle) * rx;
                    const y = Math.sin(angle) * ry;

                    return (
                      <div
                        key={player.id}
                        className="absolute"
                        style={{
                          left: `calc(50% + ${x}px - 40px)`,
                          top: `calc(50% + ${y}px - 25px)`,
                        }}
                      >
                        <div
                          className="rounded-xl px-3 py-2 text-center"
                          style={{
                            background: "rgba(0,0,0,0.7)",
                            border: player.isActive ? "1px solid rgba(0,230,118,0.4)" : "1px solid rgba(255,255,255,0.1)",
                            backdropFilter: "blur(8px)",
                            minWidth: "80px",
                          }}
                        >
                          <div style={{ fontSize: "11px", fontWeight: 600, color: "#e2e8f0", whiteSpace: "nowrap" }}>{player.name}</div>
                          <div style={{ fontSize: "11px", fontFamily: "'JetBrains Mono', monospace", color: "var(--gold)" }}>
                            ${player.chips.toLocaleString()}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="glass-card p-6">
            <div className="grid grid-cols-4 gap-3">
              {[
                { label: "Fold", color: "#ef4444", bg: "rgba(239,68,68,0.1)" },
                { label: "Check", color: "#94a3b8", bg: "rgba(148,163,184,0.1)" },
                { label: "Call $10", color: "var(--gold)", bg: "rgba(212,168,67,0.1)" },
                { label: "Raise", color: "var(--neon-green)", bg: "rgba(0,230,118,0.1)" },
              ].map((action) => (
                <button
                  key={action.label}
                  onClick={() => toast.info(`${action.label} — Feature coming soon`)}
                  className="rounded-xl py-4 transition-all hover:scale-105"
                  style={{
                    background: action.bg,
                    border: `1px solid ${action.color}30`,
                    color: action.color,
                    fontSize: "15px",
                    fontWeight: 700,
                    letterSpacing: "0.5px",
                  }}
                >
                  {action.label}
                </button>
              ))}
            </div>
          </div>
        </>
      )}
    </CasinoLayout>
  );
}
