import { useAuth } from "@/_core/hooks/useAuth";
import CasinoLayout from "@/components/CasinoLayout";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { Loader2, Gift, Heart, Zap, TrendingUp, Trophy, Users, Clock, Crown, ArrowUpRight, ArrowDownLeft, Search, CloudRain } from "lucide-react";

type TipTab = "send" | "received" | "given" | "leaderboard" | "rain";

const TABS: { id: TipTab; label: string; icon: React.ReactNode }[] = [
  { id: "send", label: "Send Tip", icon: <Gift size={14} /> },
  { id: "rain", label: "Rain", icon: <CloudRain size={14} /> },
  { id: "leaderboard", label: "Leaderboard", icon: <Trophy size={14} /> },
  { id: "received", label: "Received", icon: <ArrowDownLeft size={14} /> },
  { id: "given", label: "Given", icon: <ArrowUpRight size={14} /> },
];

const PRESET_AMOUNTS = [1, 5, 10, 25, 50, 100];

const MOCK_LEADERBOARD = [
  { rank: 1, username: "HighRoller99", totalTipped: 15420, vipLevel: 5 },
  { rank: 2, username: "CasinoKing", totalTipped: 12350, vipLevel: 4 },
  { rank: 3, username: "LuckyAce", totalTipped: 8900, vipLevel: 4 },
  { rank: 4, username: "PokerPro", totalTipped: 6200, vipLevel: 3 },
  { rank: 5, username: "SlotMaster", totalTipped: 4100, vipLevel: 3 },
];

const MOCK_RECENT_TIPS = [
  { id: 1, from: "HighRoller99", to: "LuckyAce", amount: 50, timestamp: new Date(Date.now() - 60000) },
  { id: 2, from: "CasinoKing", to: "PokerPro", amount: 25, timestamp: new Date(Date.now() - 120000) },
  { id: 3, from: "Xebb", to: "SlotMaster", amount: 100, timestamp: new Date(Date.now() - 300000) },
  { id: 4, from: "LuckyAce", to: "RiverRat", amount: 10, timestamp: new Date(Date.now() - 600000) },
];

const VIP_COLORS: Record<number, string> = {
  0: "#64748b", 1: "#94a3b8", 2: "#3b82f6", 3: "#8b5cf6", 4: "#f59e0b", 5: "#ef4444",
};

export default function Tipping() {
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState<TipTab>("send");
  const [recipient, setRecipient] = useState("");
  const [amount, setAmount] = useState("");
  const [message, setMessage] = useState("");
  const [rainAmount, setRainAmount] = useState("");
  const [rainCount, setRainCount] = useState("5");

  const handleSendTip = () => {
    if (!user) { window.location.href = getLoginUrl(); return; }
    if (!recipient.trim() || !amount || parseFloat(amount) <= 0) {
      toast.error("Please enter a valid recipient and amount");
      return;
    }
    toast.success(`Sent $${amount} tip to ${recipient}!`);
    setRecipient("");
    setAmount("");
    setMessage("");
  };

  const handleRain = () => {
    if (!user) { window.location.href = getLoginUrl(); return; }
    if (!rainAmount || parseFloat(rainAmount) <= 0 || !rainCount || parseInt(rainCount) <= 0) {
      toast.error("Please enter valid rain amount and recipient count");
      return;
    }
    toast.success(`Rained $${rainAmount} across ${rainCount} users!`);
    setRainAmount("");
    setRainCount("5");
  };

  if (loading) {
    return (
      <CasinoLayout>
        <div className="flex items-center justify-center py-32">
          <Loader2 className="w-8 h-8 animate-spin" style={{ color: "var(--gold)" }} />
        </div>
      </CasinoLayout>
    );
  }

  return (
    <CasinoLayout>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="flex items-center gap-2" style={{ fontSize: "24px", fontWeight: 700, color: "#e2e8f0" }}>
            <Gift size={24} style={{ color: "var(--gold)" }} />
            Tips & Rain
          </h1>
          <p style={{ fontSize: "14px", color: "#64748b", marginTop: "4px" }}>Send tips to players or rain on the community</p>
        </div>
        <div className="glass-card px-4 py-2 flex items-center gap-2">
          <Zap size={14} style={{ color: "var(--gold)" }} />
          <span style={{ fontSize: "13px", color: "#94a3b8" }}>Total Tipped Today:</span>
          <span style={{ fontSize: "14px", fontWeight: 700, fontFamily: "'JetBrains Mono', monospace", color: "var(--neon-green)" }}>$4,250.00</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 p-1 rounded-xl" style={{ background: "var(--surface-2)" }}>
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg transition-all flex-1 justify-center cursor-pointer"
            style={{
              background: activeTab === tab.id ? "var(--surface-1)" : "transparent",
              color: activeTab === tab.id ? "var(--gold)" : "#64748b",
              fontSize: "13px",
              fontWeight: activeTab === tab.id ? 600 : 400,
              border: activeTab === tab.id ? "1px solid var(--glass-border)" : "1px solid transparent",
            }}
          >
            {tab.icon}
            <span className="hidden sm:inline">{tab.label}</span>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2">
          {activeTab === "send" && (
            <div className="glass-card p-6" style={{ border: "1px solid rgba(212,168,67,0.1)" }}>
              <h2 className="flex items-center gap-2 mb-6" style={{ fontSize: "18px", fontWeight: 600, color: "#e2e8f0" }}>
                <Heart size={18} style={{ color: "#ef4444" }} />
                Send a Tip
              </h2>

              <div className="space-y-5">
                {/* Recipient */}
                <div>
                  <label style={{ fontSize: "12px", fontWeight: 500, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.05em" }}>Recipient</label>
                  <div className="relative mt-2">
                    <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "#475569" }} />
                    <input
                      type="text"
                      value={recipient}
                      onChange={(e) => setRecipient(e.target.value)}
                      placeholder="Enter username..."
                      className="w-full rounded-xl py-3 pl-10 pr-4"
                      style={{ background: "var(--surface-2)", border: "1px solid var(--glass-border)", color: "#e2e8f0", fontSize: "14px", outline: "none" }}
                    />
                  </div>
                </div>

                {/* Amount */}
                <div>
                  <label style={{ fontSize: "12px", fontWeight: 500, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.05em" }}>Amount</label>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full rounded-xl py-3 px-4 mt-2"
                    style={{ background: "var(--surface-2)", border: "1px solid var(--glass-border)", color: "#e2e8f0", fontSize: "18px", fontWeight: 600, fontFamily: "'JetBrains Mono', monospace", outline: "none" }}
                  />
                  <div className="flex flex-wrap gap-2 mt-3">
                    {PRESET_AMOUNTS.map((preset) => (
                      <button
                        key={preset}
                        onClick={() => setAmount(String(preset))}
                        className="rounded-lg px-3 py-1.5 transition-all hover:scale-105 cursor-pointer"
                        style={{
                          background: amount === String(preset) ? "rgba(212,168,67,0.15)" : "var(--surface-2)",
                          border: `1px solid ${amount === String(preset) ? "rgba(212,168,67,0.3)" : "var(--glass-border)"}`,
                          color: amount === String(preset) ? "var(--gold)" : "#94a3b8",
                          fontSize: "13px",
                          fontWeight: 600,
                          fontFamily: "'JetBrains Mono', monospace",
                        }}
                      >
                        ${preset}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Message */}
                <div>
                  <label style={{ fontSize: "12px", fontWeight: 500, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.05em" }}>Message (Optional)</label>
                  <input
                    type="text"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Add a message..."
                    className="w-full rounded-xl py-3 px-4 mt-2"
                    style={{ background: "var(--surface-2)", border: "1px solid var(--glass-border)", color: "#e2e8f0", fontSize: "14px", outline: "none" }}
                  />
                </div>

                <button onClick={handleSendTip} className="btn-primary w-full py-3 rounded-xl flex items-center justify-center gap-2" style={{ fontSize: "15px", fontWeight: 600 }}>
                  <Gift size={18} />
                  Send Tip {amount ? `— $${amount}` : ""}
                </button>
              </div>
            </div>
          )}

          {activeTab === "rain" && (
            <div className="glass-card p-6" style={{ border: "1px solid rgba(212,168,67,0.1)" }}>
              <h2 className="flex items-center gap-2 mb-2" style={{ fontSize: "18px", fontWeight: 600, color: "#e2e8f0" }}>
                <CloudRain size={18} style={{ color: "#3b82f6" }} />
                Make it Rain
              </h2>
              <p style={{ fontSize: "13px", color: "#64748b", marginBottom: "24px" }}>Distribute funds randomly to online players</p>

              <div className="space-y-5">
                <div>
                  <label style={{ fontSize: "12px", fontWeight: 500, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.05em" }}>Total Amount</label>
                  <input
                    type="number"
                    value={rainAmount}
                    onChange={(e) => setRainAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full rounded-xl py-3 px-4 mt-2"
                    style={{ background: "var(--surface-2)", border: "1px solid var(--glass-border)", color: "#e2e8f0", fontSize: "18px", fontWeight: 600, fontFamily: "'JetBrains Mono', monospace", outline: "none" }}
                  />
                </div>

                <div>
                  <label style={{ fontSize: "12px", fontWeight: 500, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.05em" }}>Number of Recipients</label>
                  <input
                    type="number"
                    value={rainCount}
                    onChange={(e) => setRainCount(e.target.value)}
                    placeholder="5"
                    className="w-full rounded-xl py-3 px-4 mt-2"
                    style={{ background: "var(--surface-2)", border: "1px solid var(--glass-border)", color: "#e2e8f0", fontSize: "14px", outline: "none" }}
                  />
                </div>

                {rainAmount && rainCount && parseInt(rainCount) > 0 && (
                  <div className="rounded-xl p-4" style={{ background: "rgba(59,130,246,0.05)", border: "1px solid rgba(59,130,246,0.15)" }}>
                    <p style={{ fontSize: "13px", color: "#94a3b8" }}>Each recipient gets:</p>
                    <p style={{ fontSize: "24px", fontWeight: 700, fontFamily: "'JetBrains Mono', monospace", color: "#3b82f6" }}>
                      ${(parseFloat(rainAmount) / parseInt(rainCount)).toFixed(2)}
                    </p>
                  </div>
                )}

                <button onClick={handleRain} className="btn-primary w-full py-3 rounded-xl flex items-center justify-center gap-2" style={{ fontSize: "15px", fontWeight: 600 }}>
                  <CloudRain size={18} />
                  Rain {rainAmount ? `$${rainAmount}` : ""} on {rainCount} Players
                </button>
              </div>
            </div>
          )}

          {activeTab === "leaderboard" && (
            <div className="glass-card p-6" style={{ border: "1px solid rgba(212,168,67,0.1)" }}>
              <h2 className="flex items-center gap-2 mb-6" style={{ fontSize: "18px", fontWeight: 600, color: "#e2e8f0" }}>
                <Trophy size={18} style={{ color: "var(--gold)" }} />
                Top Tippers
              </h2>
              <div className="space-y-2">
                {MOCK_LEADERBOARD.map((entry) => (
                  <div
                    key={entry.rank}
                    className="flex items-center gap-4 rounded-xl p-3 transition-colors hover:bg-[rgba(255,255,255,0.02)]"
                    style={{ border: entry.rank <= 3 ? `1px solid ${entry.rank === 1 ? "rgba(245,158,11,0.2)" : entry.rank === 2 ? "rgba(148,163,184,0.2)" : "rgba(180,83,9,0.2)"}` : "1px solid transparent" }}
                  >
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center"
                      style={{
                        background: entry.rank === 1 ? "rgba(245,158,11,0.15)" : entry.rank === 2 ? "rgba(148,163,184,0.15)" : entry.rank === 3 ? "rgba(180,83,9,0.15)" : "var(--surface-2)",
                        fontSize: "14px",
                        fontWeight: 700,
                        color: entry.rank === 1 ? "#f59e0b" : entry.rank === 2 ? "#94a3b8" : entry.rank === 3 ? "#b45309" : "#64748b",
                      }}
                    >
                      {entry.rank}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span style={{ fontSize: "14px", fontWeight: 600, color: "#e2e8f0" }}>{entry.username}</span>
                        {entry.vipLevel >= 4 && <Crown size={12} style={{ color: VIP_COLORS[entry.vipLevel] }} />}
                      </div>
                    </div>
                    <span style={{ fontSize: "14px", fontWeight: 700, fontFamily: "'JetBrains Mono', monospace", color: "var(--neon-green)" }}>
                      ${entry.totalTipped.toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {(activeTab === "received" || activeTab === "given") && (
            <div className="glass-card p-6" style={{ border: "1px solid rgba(212,168,67,0.1)" }}>
              <h2 className="flex items-center gap-2 mb-6" style={{ fontSize: "18px", fontWeight: 600, color: "#e2e8f0" }}>
                {activeTab === "received" ? <ArrowDownLeft size={18} style={{ color: "var(--neon-green)" }} /> : <ArrowUpRight size={18} style={{ color: "#3b82f6" }} />}
                Tips {activeTab === "received" ? "Received" : "Given"}
              </h2>
              {!user ? (
                <div className="text-center py-12">
                  <p style={{ fontSize: "14px", color: "#64748b", marginBottom: "16px" }}>Log in to view your tip history</p>
                  <a href={getLoginUrl()} className="btn-primary rounded-xl px-6 py-2.5 inline-block" style={{ fontSize: "14px", fontWeight: 600, textDecoration: "none" }}>Log In</a>
                </div>
              ) : (
                <div className="space-y-2">
                  {MOCK_RECENT_TIPS.map((tip) => (
                    <div key={tip.id} className="flex items-center justify-between rounded-xl p-3 hover:bg-[rgba(255,255,255,0.02)] transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "rgba(212,168,67,0.1)", border: "1px solid rgba(212,168,67,0.2)", fontSize: "11px", fontWeight: 700, color: "var(--gold)" }}>
                          {(activeTab === "received" ? tip.from : tip.to)[0]}
                        </div>
                        <div>
                          <span style={{ fontSize: "13px", fontWeight: 500, color: "#e2e8f0" }}>
                            {activeTab === "received" ? `From ${tip.from}` : `To ${tip.to}`}
                          </span>
                          <p style={{ fontSize: "11px", color: "#475569" }}>
                            {tip.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                          </p>
                        </div>
                      </div>
                      <span style={{
                        fontSize: "14px",
                        fontWeight: 700,
                        fontFamily: "'JetBrains Mono', monospace",
                        color: activeTab === "received" ? "var(--neon-green)" : "#3b82f6",
                      }}>
                        {activeTab === "received" ? "+" : "-"}${tip.amount.toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Recent Activity */}
          <div className="glass-card p-4">
            <h3 className="flex items-center gap-2 mb-3" style={{ fontSize: "14px", fontWeight: 600, color: "#e2e8f0" }}>
              <Clock size={14} style={{ color: "var(--gold)" }} />
              Recent Tips
            </h3>
            <div className="space-y-2">
              {MOCK_RECENT_TIPS.map((tip) => (
                <div key={tip.id} className="flex items-center justify-between py-1.5">
                  <div>
                    <span style={{ fontSize: "12px", color: "#94a3b8" }}>{tip.from}</span>
                    <span style={{ fontSize: "12px", color: "#475569" }}> → </span>
                    <span style={{ fontSize: "12px", color: "#94a3b8" }}>{tip.to}</span>
                  </div>
                  <span style={{ fontSize: "12px", fontWeight: 600, fontFamily: "'JetBrains Mono', monospace", color: "var(--neon-green)" }}>${tip.amount}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Stats */}
          <div className="glass-card p-4">
            <h3 className="flex items-center gap-2 mb-3" style={{ fontSize: "14px", fontWeight: 600, color: "#e2e8f0" }}>
              <TrendingUp size={14} style={{ color: "var(--gold)" }} />
              Your Stats
            </h3>
            <div className="space-y-3">
              {[
                { label: "Tips Sent", value: user ? "12" : "—" },
                { label: "Tips Received", value: user ? "8" : "—" },
                { label: "Total Given", value: user ? "$450.00" : "—" },
                { label: "Total Received", value: user ? "$320.00" : "—" },
              ].map((stat) => (
                <div key={stat.label} className="flex justify-between items-center">
                  <span style={{ fontSize: "12px", color: "#64748b" }}>{stat.label}</span>
                  <span style={{ fontSize: "13px", fontWeight: 600, fontFamily: "'JetBrains Mono', monospace", color: "var(--gold)" }}>{stat.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </CasinoLayout>
  );
}
