import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Loader2, ArrowLeft, BarChart3, Users, Coins, Settings, FileText, TrendingUp } from "lucide-react";
import { Link, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

type AdminTab = "overview" | "users" | "withdrawals" | "rtp" | "bonuses" | "vip" | "support" | "stats";

export default function Admin() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<AdminTab>("overview");
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [adjustAmount, setAdjustAmount] = useState("");
  const [adjustReason, setAdjustReason] = useState("");

  const statsQuery = trpc.admin.getStats.useQuery();
  const withdrawalsQuery = trpc.admin.getPendingWithdrawals.useQuery();
  const approveWithdrawalMutation = trpc.admin.approveWithdrawal.useMutation();
  const rejectWithdrawalMutation = trpc.admin.rejectWithdrawal.useMutation();
  const updateRtpMutation = trpc.admin.updateRtp.useMutation();
  const adjustBalanceMutation = trpc.admin.adjustUserBalance.useMutation();

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="card-theatrical p-8 text-center">
          <h2 className="text-2xl font-bold text-accent mb-4">Access Denied</h2>
          <p className="text-muted-foreground mb-6">You do not have admin privileges.</p>
          <Link href="/">
            <Button className="btn-gold">Return Home</Button>
          </Link>
        </Card>
      </div>
    );
  }

  const handleApproveWithdrawal = async (withdrawalId: number) => {
    try {
      const txHash = `0x${Math.random().toString(16).slice(2)}`;
      await approveWithdrawalMutation.mutateAsync({ withdrawalId, txHash });
      withdrawalsQuery.refetch();
      toast.success("Withdrawal approved");
    } catch (error: any) {
      toast.error(error.message || "Failed to approve withdrawal");
    }
  };

  const handleRejectWithdrawal = async (withdrawalId: number) => {
    try {
      await rejectWithdrawalMutation.mutateAsync({ withdrawalId, reason: "Rejected by admin" });
      withdrawalsQuery.refetch();
      toast.success("Withdrawal rejected");
    } catch (error: any) {
      toast.error(error.message || "Failed to reject withdrawal");
    }
  };

  const handleUpdateRtp = async (gameType: string) => {
    try {
      const rtp = Math.random() * 0.1 + 0.92; // 92-102%
      await updateRtpMutation.mutateAsync({ gameType, targetRtp: rtp });
      toast.success(`RTP updated for ${gameType}`);
    } catch (error: any) {
      toast.error(error.message || "Failed to update RTP");
    }
  };

  const handleAdjustBalance = async () => {
    if (!selectedUserId || !adjustAmount) {
      toast.error("Please select a user and enter an amount");
      return;
    }
    try {
      await adjustBalanceMutation.mutateAsync({
        userId: selectedUserId,
        amount: Number(adjustAmount),
        reason: adjustReason || "Admin adjustment",
      });
      setAdjustAmount("");
      setAdjustReason("");
      setSelectedUserId(null);
      toast.success("Balance adjusted");
    } catch (error: any) {
      toast.error(error.message || "Failed to adjust balance");
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b border-border bg-card/50 sticky top-0 z-40">
        <div className="container flex items-center justify-between h-16">
          <Link href="/">
            <Button variant="ghost" className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-accent">Admin Dashboard</h1>
          <div className="text-sm text-muted-foreground">
            {user?.name}
          </div>
        </div>
      </div>

      <div className="container py-8">
        {/* Navigation Tabs */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          {[
            { id: "overview", label: "Overview", icon: BarChart3 },
            { id: "users", label: "Users", icon: Users },
            { id: "withdrawals", label: "Withdrawals", icon: Coins },
            { id: "rtp", label: "RTP Settings", icon: Settings },
            { id: "bonuses", label: "Bonuses", icon: TrendingUp },
            { id: "vip", label: "VIP Tiers", icon: Users },
            { id: "support", label: "Support", icon: FileText },
            { id: "stats", label: "Statistics", icon: BarChart3 },
          ].map((tab) => (
            <Button
              key={tab.id}
              variant={activeTab === tab.id ? "default" : "outline"}
              className={`gap-2 whitespace-nowrap ${activeTab === tab.id ? "btn-gold" : ""}`}
              onClick={() => setActiveTab(tab.id as AdminTab)}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </Button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === "overview" && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="card-theatrical p-6">
              <h3 className="text-sm text-muted-foreground mb-2">Total Users</h3>
              <p className="text-4xl font-bold text-accent">{statsQuery.data?.totalUsers || 0}</p>
            </Card>
            <Card className="card-theatrical p-6">
              <h3 className="text-sm text-muted-foreground mb-2">Total Wagered</h3>
              <p className="text-4xl font-bold text-accent">{Number(statsQuery.data?.totalWagered || 0).toFixed(2)}</p>
            </Card>
            <Card className="card-theatrical p-6">
              <h3 className="text-sm text-muted-foreground mb-2">Total Payouts</h3>
              <p className="text-4xl font-bold text-accent">{Number(statsQuery.data?.totalPayouts || 0).toFixed(2)}</p>
            </Card>
          </div>
        )}

        {/* Users Tab */}
        {activeTab === "users" && (
          <Card className="card-theatrical p-6">
            <h2 className="text-2xl font-bold text-accent mb-6">User Management</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Select User ID</label>
                <Input
                  type="number"
                  placeholder="Enter user ID"
                  value={selectedUserId || ""}
                  onChange={(e) => setSelectedUserId(e.target.value ? Number(e.target.value) : null)}
                />
              </div>
              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Adjustment Amount</label>
                <Input
                  type="number"
                  placeholder="Enter amount (positive or negative)"
                  value={adjustAmount}
                  onChange={(e) => setAdjustAmount(e.target.value)}
                  step="0.01"
                />
              </div>
              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Reason</label>
                <Input
                  type="text"
                  placeholder="Reason for adjustment"
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                />
              </div>
              <Button
                className="btn-gold w-full"
                onClick={handleAdjustBalance}
                disabled={adjustBalanceMutation.isPending}
              >
                {adjustBalanceMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    Adjusting...
                  </>
                ) : (
                  "Adjust Balance"
                )}
              </Button>
            </div>
          </Card>
        )}

        {/* Withdrawals Tab */}
        {activeTab === "withdrawals" && (
          <Card className="card-theatrical p-6">
            <h2 className="text-2xl font-bold text-accent mb-6">Pending Withdrawals</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-2 text-accent">User ID</th>
                    <th className="text-right py-2 text-accent">Amount</th>
                    <th className="text-left py-2 text-accent">Address</th>
                    <th className="text-center py-2 text-accent">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {withdrawalsQuery.data?.map((withdrawal, i) => (
                    <tr key={i} className="border-b border-border/50 hover:bg-background/50">
                      <td className="py-3">{withdrawal.userId}</td>
                      <td className="text-right">{Number(withdrawal.amount).toFixed(4)}</td>
                      <td className="text-xs font-mono truncate">{withdrawal.toAddress}</td>
                      <td className="text-center">
                        <div className="flex gap-2 justify-center">
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-green-400 border-green-400"
                            onClick={() => handleApproveWithdrawal(withdrawal.id)}
                            disabled={approveWithdrawalMutation.isPending}
                          >
                            Approve
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-red-400 border-red-400"
                            onClick={() => handleRejectWithdrawal(withdrawal.id)}
                            disabled={rejectWithdrawalMutation.isPending}
                          >
                            Reject
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {!withdrawalsQuery.data?.length && (
                <p className="text-center text-muted-foreground py-8">No pending withdrawals</p>
              )}
            </div>
          </Card>
        )}

        {/* RTP Settings Tab */}
        {activeTab === "rtp" && (
          <Card className="card-theatrical p-6">
            <h2 className="text-2xl font-bold text-accent mb-6">RTP Configuration</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {["blackjack", "plinko", "slots"].map((game) => (
                <div key={game} className="p-4 bg-background/50 rounded border border-border">
                  <h3 className="font-bold text-accent mb-3 capitalize">{game}</h3>
                  <Button
                    className="btn-gold w-full"
                    onClick={() => handleUpdateRtp(game)}
                    disabled={updateRtpMutation.isPending}
                  >
                    {updateRtpMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                        Updating...
                      </>
                    ) : (
                      "Adjust RTP"
                    )}
                  </Button>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Bonuses Tab */}
        {activeTab === "bonuses" && (
          <Card className="card-theatrical p-6">
            <h2 className="text-2xl font-bold text-accent mb-6">Bonus Code Management</h2>
            <p className="text-muted-foreground mb-6">Create, edit, and manage bonus codes here.</p>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input placeholder="Bonus Code" />
                <Input type="number" placeholder="Value" step="0.01" />
                <Input placeholder="Description" />
                <Input type="number" placeholder="Max Uses" />
              </div>
              <Button className="btn-gold w-full">Create Bonus Code</Button>
            </div>
          </Card>
        )}

        {/* VIP Tiers Tab */}
        {activeTab === "vip" && (
          <Card className="card-theatrical p-6">
            <h2 className="text-2xl font-bold text-accent mb-6">VIP Tier Management</h2>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {["Bronze", "Silver", "Gold", "Platinum", "Diamond"].map((tier) => (
                <div key={tier} className="p-4 bg-background/50 rounded border border-border">
                  <h3 className="font-bold text-accent mb-3">{tier}</h3>
                  <div className="space-y-2 text-sm">
                    <div>
                      <label className="text-muted-foreground">Cashback %</label>
                      <Input type="number" placeholder="0" step="0.1" />
                    </div>
                    <Button size="sm" className="btn-gold w-full">Save</Button>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Support Tab */}
        {activeTab === "support" && (
          <Card className="card-theatrical p-6">
            <h2 className="text-2xl font-bold text-accent mb-6">Support Tickets</h2>
            <p className="text-muted-foreground mb-6">Manage and respond to user support tickets.</p>
            <div className="space-y-4">
              <div className="p-4 bg-background/50 rounded border border-border">
                <h3 className="font-bold text-accent mb-2">Ticket #1</h3>
                <p className="text-sm text-muted-foreground mb-3">User issue description here...</p>
                <Button size="sm" variant="outline">View Details</Button>
              </div>
            </div>
          </Card>
        )}

        {/* Statistics Tab */}
        {activeTab === "stats" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="card-theatrical p-6">
              <h3 className="text-lg font-bold text-accent mb-4">Game Statistics</h3>
              <div className="space-y-3">
                {["Blackjack", "Plinko", "Slots"].map((game) => (
                  <div key={game} className="flex justify-between items-center p-3 bg-background/50 rounded">
                    <span>{game}</span>
                    <span className="text-accent font-bold">0 plays</span>
                  </div>
                ))}
              </div>
            </Card>
            <Card className="card-theatrical p-6">
              <h3 className="text-lg font-bold text-accent mb-4">Financial Summary</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-background/50 rounded">
                  <span>Total Revenue</span>
                  <span className="text-green-400 font-bold">0.00</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-background/50 rounded">
                  <span>Total Payouts</span>
                  <span className="text-red-400 font-bold">0.00</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-background/50 rounded">
                  <span>House Edge</span>
                  <span className="text-accent font-bold">0.00%</span>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
