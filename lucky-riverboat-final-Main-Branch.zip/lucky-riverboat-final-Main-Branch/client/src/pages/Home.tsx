import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import CasinoLayout from "@/components/CasinoLayout";
import { useState, useEffect, useMemo } from "react";
import { Link } from "wouter";
import {
  Zap, Star, Crown, Shield, Gift, TrendingUp, Users, Gamepad2,
  ArrowRight, Play, ChevronRight, Sparkles, Trophy, Flame, Target
} from "lucide-react";

const CDN = {
  logo: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663341115981/HeloXDUGeVanZOfa.png",
  meetXebb: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663341115981/IlbAQcuRYBLhaRrf.jpg",
  riverParty: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663341115981/XcyxdgjVlpyTAoNS.jpg",
  adultVices: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663341115981/rUuZWqHwtvUsAvHf.jpg",
  watermark: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663341115981/TtZTjkmKyKWMaHFr.jpg",
  riverboat: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663341115981/wjBBYSglkzmfceOv.jpg",
  video0Edge: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663341115981/vDzQSIPxMEoSjtSN.mp4",
  videoCelebration: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663341115981/rynfMUyIlcdZCjbP.mp4",
};

// Game card data with gradient colors
const houseGames = [
  { name: "Blackjack", provider: "House Original", rtp: "100%", players: 47, gradient: "linear-gradient(135deg, #1a472a, #2d5a3f)", icon: "🃏", path: "/games" },
  { name: "Plinko", provider: "House Original", rtp: "100%", players: 83, gradient: "linear-gradient(135deg, #4a1942, #6b2c5f)", icon: "⚡", path: "/games" },
  { name: "Slots", provider: "House Original", rtp: "100%", players: 124, gradient: "linear-gradient(135deg, #1a3a5c, #2a5a8c)", icon: "🎰", path: "/games" },
  { name: "Poker", provider: "House Original", rtp: "100%", players: 36, gradient: "linear-gradient(135deg, #5c1a1a, #8c2a2a)", icon: "♠️", path: "/poker" },
  { name: "Roulette", provider: "House Original", rtp: "100%", players: 58, gradient: "linear-gradient(135deg, #3d1a5c, #5a2a8c)", icon: "🎯", path: "/games" },
  { name: "Crash", provider: "House Original", rtp: "100%", players: 92, gradient: "linear-gradient(135deg, #5c4a1a, #8c6a2a)", icon: "📈", path: "/games" },
  { name: "Keno", provider: "House Original", rtp: "100%", players: 29, gradient: "linear-gradient(135deg, #1a5c5c, #2a8c8c)", icon: "🎱", path: "/games" },
];

const premiumSlots = [
  { name: "Big Bass Bonanza", provider: "Pragmatic Play", rtp: "96.71%", players: 215, gradient: "linear-gradient(135deg, #0d4f3c, #1a7a5c)", icon: "🐟", path: "/games/premium" },
  { name: "Sweet Bonanza", provider: "Pragmatic Play", rtp: "96.48%", players: 189, gradient: "linear-gradient(135deg, #7a1a4e, #a62d6b)", icon: "🍬", path: "/games/premium" },
  { name: "Gates of Olympus", provider: "Pragmatic Play", rtp: "96.50%", players: 167, gradient: "linear-gradient(135deg, #1a3d7a, #2d5aa6)", icon: "⚡", path: "/games/premium" },
  { name: "Starlight Princess", provider: "Pragmatic Play", rtp: "96.50%", players: 143, gradient: "linear-gradient(135deg, #5c1a7a, #7a2da6)", icon: "✨", path: "/games/premium" },
  { name: "Lucky Lucky", provider: "House Original", rtp: "97.50%", players: 78, gradient: "linear-gradient(135deg, #7a5c1a, #a67a2d)", icon: "🍀", path: "/games/premium" },
];

// Simulated live wagers
const generateWager = () => {
  const names = ["CryptoKing", "LuckyAce", "DiamondHands", "MoonShot", "WhaleBet", "RiverRat", "GoldRush", "NeonNight", "HighRoller", "SteamPunk"];
  const games = ["Blackjack", "Plinko", "Slots", "Poker", "Crash", "Roulette", "Big Bass", "Sweet Bonanza"];
  const isWin = Math.random() > 0.45;
  return {
    id: Math.random().toString(36).substr(2, 9),
    user: names[Math.floor(Math.random() * names.length)],
    game: games[Math.floor(Math.random() * games.length)],
    amount: (Math.random() * 500 + 1).toFixed(2),
    multiplier: isWin ? (Math.random() * 10 + 1.1).toFixed(2) : "0.00",
    isWin,
    time: "just now",
  };
};

function GameCard({ game }: { game: typeof houseGames[0] }) {
  return (
    <Link href={game.path} className="game-card-premium" style={{ minWidth: "200px", width: "200px" }}>
      <div className="relative overflow-hidden" style={{ aspectRatio: "4/3", background: game.gradient }}>
        <div className="absolute inset-0 flex items-center justify-center">
          <span style={{ fontSize: "56px", filter: "drop-shadow(0 4px 12px rgba(0,0,0,0.4))" }}>{game.icon}</span>
        </div>
        <div className="rtp-badge rtp-100">100% RTP</div>
        <div className="player-count">
          <div className="live-dot" />
          {game.players} playing
        </div>
      </div>
      <div className="card-info">
        <h3>{game.name}</h3>
        <div className="card-provider">{game.provider}</div>
      </div>
    </Link>
  );
}

function SlotCard({ game }: { game: typeof premiumSlots[0] }) {
  return (
    <Link href={game.path} className="game-card-premium" style={{ minWidth: "200px", width: "200px" }}>
      <div className="relative overflow-hidden" style={{ aspectRatio: "4/3", background: game.gradient }}>
        <div className="absolute inset-0 flex items-center justify-center">
          <span style={{ fontSize: "56px", filter: "drop-shadow(0 4px 12px rgba(0,0,0,0.4))" }}>{game.icon}</span>
        </div>
        <div className="rtp-badge rtp-high">{game.rtp}</div>
        <div className="player-count">
          <div className="live-dot" />
          {game.players} playing
        </div>
      </div>
      <div className="card-info">
        <h3>{game.name}</h3>
        <div className="card-provider">{game.provider}</div>
      </div>
    </Link>
  );
}

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [wagers, setWagers] = useState(() => Array.from({ length: 8 }, generateWager));
  const [jackpot, setJackpot] = useState(127843.67);

  useEffect(() => {
    const interval = setInterval(() => {
      setWagers((prev) => [generateWager(), ...prev.slice(0, 7)]);
      setJackpot((prev) => prev + Math.random() * 5);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <CasinoLayout>
      {/* Promo Banner */}
      <div className="promo-banner mb-6">
        <Gift size={16} style={{ color: "var(--gold)", flexShrink: 0 }} />
        <span>
          <strong style={{ color: "var(--gold)" }}>Welcome Bonus:</strong> First deposit matched 100% up to $1,000 + 50 free spins.
          Use code <span style={{ fontFamily: "'JetBrains Mono', monospace", color: "var(--neon-green)", fontWeight: 600 }}>RIVERBOAT</span>
        </span>
        <Link href="/wallet" style={{ color: "var(--gold)", fontWeight: 600, fontSize: "13px", whiteSpace: "nowrap", marginLeft: "auto" }}>
          Claim Now →
        </Link>
      </div>

      {/* Hero Section */}
      <div className="hero-gradient rounded-2xl overflow-hidden mb-8 relative" style={{ border: "1px solid var(--glass-border)" }}>
        <div className="relative z-10 flex flex-col lg:flex-row items-center gap-8 p-8 lg:p-12">
          {/* Left: Text */}
          <div className="flex-1 text-center lg:text-left">
            <div className="badge-rtp mb-4 inline-flex">
              <Zap size={12} /> 100% RTP • 0% House Edge
            </div>
            <h1 style={{ fontSize: "clamp(28px, 4vw, 48px)", lineHeight: 1.1, marginBottom: "16px", letterSpacing: "-0.02em" }}>
              The First Casino That<br />
              <span style={{ background: "linear-gradient(135deg, var(--gold), var(--gold-light))", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                Gives It All Back
              </span>
            </h1>
            <p style={{ fontSize: "16px", color: "#94a3b8", lineHeight: 1.6, maxWidth: "480px", marginBottom: "28px" }}>
              The purest form of gambling. No hidden edges, no rigged odds. Every game runs at 100% RTP with provably fair results.
            </p>
            <div className="flex flex-wrap gap-3 justify-center lg:justify-start">
              <Link href="/games" className="btn-primary flex items-center gap-2" style={{ padding: "12px 28px" }}>
                <Play size={16} /> Play Now
              </Link>
              <Link href="/sportsbook" className="btn-secondary flex items-center gap-2" style={{ padding: "12px 28px" }}>
                <Trophy size={16} /> Sportsbook
              </Link>
            </div>
          </div>

          {/* Right: Logo + Jackpot */}
          <div className="flex-shrink-0 text-center">
            <div className="animate-float">
              <img
                src={CDN.logo}
                alt="The Lucky Riverboat"
                className="w-64 h-64 lg:w-80 lg:h-80 object-contain mx-auto"
                style={{ filter: "drop-shadow(0 0 40px rgba(212,168,67,0.3))" }}
              />
            </div>
            <div className="mt-4">
              <div style={{ fontSize: "11px", color: "#64748b", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: "4px" }}>
                Progressive Jackpot
              </div>
              <div className="jackpot-counter">
                ${jackpot.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
            </div>
          </div>
        </div>

        {/* Background image overlay */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{ backgroundImage: `url(${CDN.watermark})`, backgroundSize: "600px", backgroundRepeat: "repeat" }}
        />
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Total Wagered", value: "$2.4M+", icon: TrendingUp, color: "var(--gold)" },
          { label: "Active Players", value: "1,247", icon: Users, color: "var(--neon-green)" },
          { label: "Games Available", value: "12+", icon: Gamepad2, color: "var(--neon-blue)" },
          { label: "Avg. RTP", value: "99.2%", icon: Target, color: "var(--neon-purple)" },
        ].map((stat) => (
          <div key={stat.label} className="stat-card">
            <div className="flex items-center gap-2 mb-2">
              <stat.icon size={14} style={{ color: stat.color }} />
              <span className="stat-label">{stat.label}</span>
            </div>
            <div className="stat-value" style={{ color: stat.color }}>{stat.value}</div>
          </div>
        ))}
      </div>

      {/* House Originals Carousel */}
      <div className="mb-8">
        <div className="section-header">
          <h2>
            <Flame size={20} style={{ color: "var(--gold)" }} />
            House Originals
          </h2>
          <Link href="/games" className="view-all flex items-center gap-1">
            View All <ChevronRight size={14} />
          </Link>
        </div>
        <div className="game-carousel">
          {houseGames.map((game) => (
            <GameCard key={game.name} game={game} />
          ))}
        </div>
      </div>

      {/* Premium Slots Carousel */}
      <div className="mb-8">
        <div className="section-header">
          <h2>
            <Sparkles size={20} style={{ color: "var(--neon-purple)" }} />
            Premium Slots
          </h2>
          <Link href="/games/premium" className="view-all flex items-center gap-1">
            View All <ChevronRight size={14} />
          </Link>
        </div>
        <div className="game-carousel">
          {premiumSlots.map((game) => (
            <SlotCard key={game.name} game={game} />
          ))}
        </div>
      </div>

      {/* Two Column: Live Wagers + Kick Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Live Wagers Feed */}
        <div className="lg:col-span-2 wager-feed">
          <div className="feed-header">
            <Zap size={14} style={{ color: "var(--gold)" }} />
            Live Wagers
            <div className="ml-auto badge-live">
              <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#ef4444", animation: "live-pulse 1.5s ease-in-out infinite" }} />
              LIVE
            </div>
          </div>
          <div style={{ maxHeight: "360px", overflow: "hidden" }}>
            {wagers.map((w) => (
              <div key={w.id} className="feed-item">
                <div className="flex items-center gap-3">
                  <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: "var(--surface-3)", fontSize: "12px" }}>
                    {w.user[0]}
                  </div>
                  <div>
                    <div className="user-name">{w.user}</div>
                    <div className="game-name">{w.game}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className={`amount ${w.isWin ? "win" : "loss"}`}>
                    {w.isWin ? "+" : "-"}${w.amount}
                  </div>
                  <div style={{ fontSize: "11px", color: "#475569" }}>{w.multiplier}x</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Kick Stream Widget */}
        <div className="glass-card overflow-hidden">
          <div className="p-4" style={{ borderBottom: "1px solid var(--glass-border)" }}>
            <div className="flex items-center gap-2">
              <div className="badge-live">
                <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#ef4444", animation: "live-pulse 1.5s ease-in-out infinite" }} />
                LIVE
              </div>
              <span style={{ fontSize: "13px", fontWeight: 600, color: "#e2e8f0" }}>Kick.com/x3bb3r</span>
            </div>
          </div>
          <div style={{ aspectRatio: "16/9", background: "var(--surface-2)", position: "relative" }}>
            <img
              src={CDN.meetXebb}
              alt="Stream"
              className="w-full h-full object-cover"
              style={{ opacity: 0.8 }}
            />
            <div className="absolute inset-0 flex items-center justify-center" style={{ background: "rgba(0,0,0,0.4)" }}>
              <div className="w-14 h-14 rounded-full flex items-center justify-center" style={{ background: "rgba(212,168,67,0.9)", boxShadow: "0 0 30px rgba(212,168,67,0.4)" }}>
                <Play size={24} style={{ color: "var(--surface-0)", marginLeft: "2px" }} />
              </div>
            </div>
          </div>
          <div className="p-4">
            <div style={{ fontSize: "13px", fontWeight: 600, color: "#e2e8f0", marginBottom: "4px" }}>
              The Lucky Riverboat - Live Casino Stream
            </div>
            <div className="flex items-center gap-3" style={{ fontSize: "12px", color: "#64748b" }}>
              <span className="flex items-center gap-1">
                <Users size={12} /> 342 viewers
              </span>
              <span>Gambling</span>
            </div>
          </div>
        </div>
      </div>

      {/* Comparison Section */}
      <div className="mb-8">
        <div className="text-center mb-8">
          <h2 style={{ fontSize: "28px", marginBottom: "8px" }}>Why The Lucky Riverboat?</h2>
          <p style={{ fontSize: "15px", color: "#64748b" }}>See how we compare to traditional online casinos</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Traditional */}
          <div className="comparison-card">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "rgba(239,68,68,0.1)" }}>
                <Shield size={20} style={{ color: "#ef4444" }} />
              </div>
              <div>
                <h3 style={{ fontSize: "18px", color: "#e2e8f0", fontFamily: "'Inter', sans-serif", textShadow: "none" }}>Traditional Casinos</h3>
                <span style={{ fontSize: "12px", color: "#ef4444" }}>The Old Way</span>
              </div>
            </div>
            <div className="space-y-3">
              {["2-15% House Edge on every bet", "Opaque RNG with no verification", "Slow withdrawals (3-7 business days)", "Hidden terms in bonus offers", "No player-to-player interaction"].map((item) => (
                <div key={item} className="flex items-start gap-3" style={{ fontSize: "14px", color: "#94a3b8" }}>
                  <span style={{ color: "#ef4444", fontWeight: 600, flexShrink: 0 }}>✕</span>
                  {item}
                </div>
              ))}
            </div>
          </div>

          {/* Lucky Riverboat */}
          <div className="comparison-card highlight">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "rgba(0,230,118,0.1)" }}>
                <Crown size={20} style={{ color: "var(--neon-green)" }} />
              </div>
              <div>
                <h3 style={{ fontSize: "18px", color: "#e2e8f0", fontFamily: "'Inter', sans-serif", textShadow: "none" }}>The Lucky Riverboat</h3>
                <span style={{ fontSize: "12px", color: "var(--neon-green)" }}>The Future</span>
              </div>
            </div>
            <div className="space-y-3">
              {["0% House Edge — 100% RTP on all games", "Provably fair with on-chain verification", "Instant crypto withdrawals", "Transparent bonus system", "Live chat, tipping, and community"].map((item) => (
                <div key={item} className="flex items-start gap-3" style={{ fontSize: "14px", color: "#e2e8f0" }}>
                  <span style={{ color: "var(--neon-green)", fontWeight: 600, flexShrink: 0 }}>✓</span>
                  {item}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Meet Xebb Section */}
      <div className="glass-card p-8 mb-8">
        <div className="flex flex-col lg:flex-row items-center gap-8">
          <div className="flex-shrink-0">
            <img
              src={CDN.meetXebb}
              alt="Meet Xebb"
              className="w-48 h-48 lg:w-56 lg:h-56 rounded-2xl object-cover"
              style={{ border: "2px solid rgba(212,168,67,0.3)", boxShadow: "0 8px 30px rgba(0,0,0,0.3)" }}
            />
          </div>
          <div className="text-center lg:text-left">
            <div className="badge-vip mb-3">
              <Crown size={12} /> Founder
            </div>
            <h2 style={{ fontSize: "28px", marginBottom: "8px" }}>Meet Xebb</h2>
            <p style={{ fontSize: "15px", color: "#94a3b8", lineHeight: 1.7, maxWidth: "560px" }}>
              The visionary behind The Lucky Riverboat. A passionate gamer and crypto enthusiast who
              believed the casino industry needed a revolution. No more hidden edges, no more rigged odds.
              Just pure, fair gambling the way it was meant to be. Watch live on Kick.com/x3bb3r and join
              the community that's changing online gambling forever.
            </p>
            <div className="flex flex-wrap gap-3 mt-6 justify-center lg:justify-start">
              <a href="https://kick.com/x3bb3r" target="_blank" rel="noopener noreferrer" className="btn-outline-gold flex items-center gap-2" style={{ padding: "10px 20px" }}>
                <Play size={14} /> Watch Live
              </a>
              <Link href="/chat" className="btn-secondary flex items-center gap-2" style={{ padding: "10px 20px" }}>
                <Users size={14} /> Join Chat
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Feature Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {[
          { icon: "🎰", title: "House Originals", desc: "7 exclusive games built from scratch with 100% RTP and provably fair mechanics.", color: "rgba(212,168,67,0.1)", link: "/games" },
          { icon: "🏆", title: "Sportsbook", desc: "Bet on live sports with competitive odds across all major leagues and events.", color: "rgba(0,230,118,0.1)", link: "/sportsbook" },
          { icon: "💎", title: "VIP Program", desc: "Climb the ranks from Bronze to Diamond. Exclusive perks, higher limits, and priority support.", color: "rgba(179,136,255,0.1)", link: "/wallet" },
        ].map((feature) => (
          <Link key={feature.title} href={feature.link} className="feature-card group">
            <div className="feature-icon" style={{ background: feature.color }}>
              {feature.icon}
            </div>
            <h3 style={{ fontSize: "16px", fontFamily: "'Inter', sans-serif", color: "#e2e8f0", textShadow: "none", marginBottom: "8px" }}>
              {feature.title}
            </h3>
            <p style={{ fontSize: "14px", color: "#64748b", lineHeight: 1.6 }}>{feature.desc}</p>
            <div className="mt-4 flex items-center gap-1 justify-center" style={{ color: "var(--gold)", fontSize: "13px", fontWeight: 500 }}>
              Explore <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
            </div>
          </Link>
        ))}
      </div>

      {/* River Party Banner */}
      <div className="rounded-2xl overflow-hidden mb-8 relative" style={{ border: "1px solid var(--glass-border)" }}>
        <img
          src={CDN.riverParty}
          alt="The Lucky Riverboat"
          className="w-full h-48 lg:h-64 object-cover"
          style={{ opacity: 0.6 }}
        />
        <div className="absolute inset-0 flex items-center justify-center" style={{ background: "linear-gradient(to right, rgba(13,17,23,0.9), rgba(13,17,23,0.5))" }}>
          <div className="text-center px-6">
            <h2 style={{ fontSize: "clamp(24px, 3vw, 36px)", marginBottom: "12px" }}>Ready to Set Sail?</h2>
            <p style={{ fontSize: "15px", color: "#94a3b8", marginBottom: "20px" }}>
              Join thousands of players on the fairest casino in the world
            </p>
            <div className="flex flex-wrap gap-3 justify-center">
              {isAuthenticated ? (
                <Link href="/games" className="btn-primary flex items-center gap-2" style={{ padding: "12px 32px" }}>
                  <Gamepad2 size={16} /> Start Playing
                </Link>
              ) : (
                <a href={getLoginUrl()} className="btn-primary flex items-center gap-2" style={{ padding: "12px 32px" }}>
                  <Star size={16} /> Create Account
                </a>
              )}
            </div>
            <div className="flex items-center justify-center gap-6 mt-6" style={{ fontSize: "12px", color: "#64748b" }}>
              <span className="flex items-center gap-1">₿ Bitcoin</span>
              <span className="flex items-center gap-1">Ξ Ethereum</span>
              <span className="flex items-center gap-1">💳 Debit Card</span>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="pt-8 pb-12" style={{ borderTop: "1px solid var(--glass-border)" }}>
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img src={CDN.riverboat} alt="TLR" className="w-8 h-8 rounded-lg object-cover" />
            <span style={{ fontFamily: "'Playfair Display', serif", fontSize: "16px", fontWeight: 700, color: "var(--gold)" }}>
              The Lucky Riverboat
            </span>
          </div>
          <div className="flex items-center gap-6" style={{ fontSize: "13px", color: "#64748b" }}>
            <Link href="/support" className="hover:text-[#e2e8f0] transition-colors">Support</Link>
            <Link href="/chat" className="hover:text-[#e2e8f0] transition-colors">Community</Link>
            <span>Provably Fair</span>
            <span>Terms</span>
          </div>
          <div style={{ fontSize: "12px", color: "#475569" }}>
            © 2026 The Lucky Riverboat. All rights reserved.
          </div>
        </div>
      </footer>
    </CasinoLayout>
  );
}
