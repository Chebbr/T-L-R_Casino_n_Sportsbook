import { useAuth } from "@/_core/hooks/useAuth";
import CasinoLayout from "@/components/CasinoLayout";
import { useState } from "react";
import { toast } from "sonner";
import { Loader2, Gamepad2, Zap, Trophy, Coins, Star, TrendingUp, Play } from "lucide-react";

type GameType = "big-bass-bonanza" | "sweet-bonanza" | "gates-of-olympus" | "starlight-princess" | "lucky-lucky";

interface GameInfo {
  id: GameType;
  name: string;
  provider: string;
  rtp: number;
  volatility: "low" | "medium" | "high";
  maxWin: string;
  icon: string;
  description: string;
  gradient: string;
}

const AVAILABLE_GAMES: GameInfo[] = [
  { id: "big-bass-bonanza", name: "Big Bass Bonanza", provider: "Pragmatic Play", rtp: 96.71, volatility: "high", maxWin: "2,100x", icon: "🎣", description: "Cast your line in this fishing-themed slot with free spins and money collect features.", gradient: "linear-gradient(135deg, #1e3a5f, #0d253f)" },
  { id: "sweet-bonanza", name: "Sweet Bonanza", provider: "Pragmatic Play", rtp: 96.51, volatility: "high", maxWin: "21,175x", icon: "🍬", description: "A candy-filled slot with tumble mechanics and multiplier bombs.", gradient: "linear-gradient(135deg, #5f1e3a, #3f0d25)" },
  { id: "gates-of-olympus", name: "Gates of Olympus", provider: "Pragmatic Play", rtp: 96.50, volatility: "high", maxWin: "5,000x", icon: "⚡", description: "Zeus drops multipliers from the sky in this mythical slot adventure.", gradient: "linear-gradient(135deg, #3a1e5f, #250d3f)" },
  { id: "starlight-princess", name: "Starlight Princess", provider: "Pragmatic Play", rtp: 96.50, volatility: "high", maxWin: "5,000x", icon: "✨", description: "A magical princess-themed slot with cascading wins and random multipliers.", gradient: "linear-gradient(135deg, #1e5f3a, #0d3f25)" },
  { id: "lucky-lucky", name: "Lucky Lucky", provider: "House Original", rtp: 100.00, volatility: "medium", maxWin: "1,000x", icon: "🍀", description: "Our house original slot with 100% RTP — the fairest game on the river!", gradient: "linear-gradient(135deg, #5f4a1e, #3f300d)" },
];

const VOLATILITY_COLORS: Record<string, string> = {
  low: "#22c55e",
  medium: "#f59e0b",
  high: "#ef4444",
};

export default function AdditionalGames() {
  const { user, loading } = useAuth();
  const [activeGame, setActiveGame] = useState<GameType | null>(null);
  const [isSpinning, setIsSpinning] = useState(false);
  const [betAmount, setBetAmount] = useState("1.00");
  const [lastWin, setLastWin] = useState<number | null>(null);

  const handleSpin = () => {
    if (!user) { toast.error("Please log in to play"); return; }
    setIsSpinning(true);
    setLastWin(null);
    setTimeout(() => {
      const win = Math.random() < 0.35 ? parseFloat(betAmount) * (Math.random() * 10 + 0.5) : 0;
      setLastWin(win);
      setIsSpinning(false);
      if (win > 0) toast.success(`Won $${win.toFixed(2)}!`);
      else toast.info("No win this spin. Try again!");
    }, 2000);
  };

  const currentGame = AVAILABLE_GAMES.find((g) => g.id === activeGame);

  if (loading) {
    return (
      <CasinoLayout>
        <div className="flex items-center justify-center py-32">
          <Loader2 className="w-8 h-8 animate-spin" style={{ color: "var(--gold)" }} />
        </div>
      </CasinoLayout>
    );
  }

  return (
    <CasinoLayout>
      {!activeGame ? (
        <>
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="flex items-center gap-2" style={{ fontSize: "24px", fontWeight: 700, color: "#e2e8f0" }}>
                <Gamepad2 size={24} style={{ color: "var(--gold)" }} />
                Premium Slots
              </h1>
              <p style={{ fontSize: "14px", color: "#64748b", marginTop: "4px" }}>Top-tier slots from leading providers</p>
            </div>
          </div>

          {/* Games Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {AVAILABLE_GAMES.map((game) => (
              <div
                key={game.id}
                onClick={() => setActiveGame(game.id)}
                className="group glass-card overflow-hidden cursor-pointer transition-all hover:scale-[1.02]"
                style={{ border: "1px solid rgba(212,168,67,0.1)" }}
              >
                {/* Game Banner */}
                <div className="relative h-40 flex items-center justify-center" style={{ background: game.gradient }}>
                  <span style={{ fontSize: "64px", filter: "drop-shadow(0 4px 8px rgba(0,0,0,0.3))" }}>{game.icon}</span>
                  {/* Play overlay */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity" style={{ background: "rgba(0,0,0,0.5)" }}>
                    <div className="w-14 h-14 rounded-full flex items-center justify-center" style={{ background: "var(--gold)", boxShadow: "0 0 20px rgba(212,168,67,0.4)" }}>
                      <Play size={24} style={{ color: "#0a0e1a", marginLeft: "2px" }} />
                    </div>
                  </div>
                  {/* Provider badge */}
                  <div className="absolute top-3 left-3 rounded-md px-2 py-1" style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(8px)", fontSize: "10px", color: "#94a3b8", fontWeight: 500 }}>
                    {game.provider}
                  </div>
                  {/* RTP badge */}
                  <div className="absolute top-3 right-3 rounded-md px-2 py-1" style={{ background: game.rtp >= 100 ? "rgba(34,197,94,0.2)" : "rgba(0,0,0,0.6)", backdropFilter: "blur(8px)", fontSize: "10px", color: game.rtp >= 100 ? "#22c55e" : "var(--gold)", fontWeight: 600, fontFamily: "'JetBrains Mono', monospace" }}>
                    {game.rtp}% RTP
                  </div>
                </div>

                {/* Game Info */}
                <div className="p-4">
                  <h3 style={{ fontSize: "16px", fontWeight: 600, color: "#e2e8f0", marginBottom: "4px" }}>{game.name}</h3>
                  <p style={{ fontSize: "12px", color: "#64748b", lineHeight: 1.4, marginBottom: "12px" }}>{game.description}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-1">
                        <TrendingUp size={10} style={{ color: VOLATILITY_COLORS[game.volatility] }} />
                        <span style={{ fontSize: "11px", color: VOLATILITY_COLORS[game.volatility], fontWeight: 500, textTransform: "capitalize" }}>{game.volatility}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Trophy size={10} style={{ color: "var(--gold)" }} />
                        <span style={{ fontSize: "11px", color: "var(--gold)", fontWeight: 500 }}>{game.maxWin}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} size={10} style={{ color: i < 4 ? "var(--gold)" : "#334155", fill: i < 4 ? "var(--gold)" : "none" }} />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        <>
          {/* Active Game */}
          <div className="flex items-center gap-3 mb-6">
            <button onClick={() => { setActiveGame(null); setLastWin(null); }} className="glass-card px-3 py-2 rounded-lg transition-all hover:scale-105 cursor-pointer" style={{ fontSize: "13px", color: "#94a3b8" }}>
              ← Back
            </button>
            <div>
              <h1 className="flex items-center gap-2" style={{ fontSize: "24px", fontWeight: 700, color: "#e2e8f0" }}>
                <span style={{ fontSize: "28px" }}>{currentGame?.icon}</span>
                {currentGame?.name}
              </h1>
              <p style={{ fontSize: "13px", color: "#64748b" }}>{currentGame?.provider} • {currentGame?.rtp}% RTP • {currentGame?.volatility} volatility</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Game Area */}
            <div className="lg:col-span-3 glass-card overflow-hidden" style={{ border: "1px solid rgba(212,168,67,0.1)" }}>
              <div className="relative" style={{ height: "500px", background: currentGame?.gradient }}>
                {/* Slot Reels */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="flex gap-4">
                    {[0, 1, 2, 3, 4].map((i) => (
                      <div
                        key={i}
                        className="w-20 h-24 rounded-xl flex items-center justify-center"
                        style={{
                          background: "rgba(0,0,0,0.4)",
                          border: "2px solid rgba(212,168,67,0.2)",
                          fontSize: "40px",
                          animation: isSpinning ? `spin-reel 0.1s linear infinite` : "none",
                          boxShadow: "inset 0 2px 8px rgba(0,0,0,0.3)",
                        }}
                      >
                        {isSpinning ? ["🎰", "💎", "7️⃣", "🍒", "⭐"][Math.floor(Math.random() * 5)] : ["🎰", "💎", "7️⃣", "🍒", "⭐"][i]}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Win Display */}
                {lastWin !== null && lastWin > 0 && (
                  <div className="absolute inset-0 flex items-center justify-center" style={{ background: "rgba(0,0,0,0.6)" }}>
                    <div className="text-center animate-bounce">
                      <p style={{ fontSize: "16px", color: "var(--gold)", fontWeight: 600, marginBottom: "8px" }}>🎉 YOU WON!</p>
                      <p style={{ fontSize: "48px", fontWeight: 800, fontFamily: "'JetBrains Mono', monospace", color: "var(--neon-green)", textShadow: "0 0 20px rgba(0,255,136,0.4)" }}>
                        ${lastWin.toFixed(2)}
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Controls */}
              <div className="p-4 flex items-center justify-between" style={{ borderTop: "1px solid var(--glass-border)" }}>
                <div className="flex items-center gap-3">
                  <span style={{ fontSize: "12px", color: "#64748b", fontWeight: 500 }}>BET:</span>
                  {["0.50", "1.00", "5.00", "10.00", "25.00"].map((amt) => (
                    <button
                      key={amt}
                      onClick={() => setBetAmount(amt)}
                      className="rounded-lg px-3 py-1.5 transition-all cursor-pointer"
                      style={{
                        background: betAmount === amt ? "rgba(212,168,67,0.15)" : "var(--surface-2)",
                        border: `1px solid ${betAmount === amt ? "rgba(212,168,67,0.3)" : "var(--glass-border)"}`,
                        color: betAmount === amt ? "var(--gold)" : "#64748b",
                        fontSize: "12px",
                        fontWeight: 600,
                        fontFamily: "'JetBrains Mono', monospace",
                      }}
                    >
                      ${amt}
                    </button>
                  ))}
                </div>
                <button
                  onClick={handleSpin}
                  disabled={isSpinning}
                  className="btn-primary rounded-xl px-8 py-3 flex items-center gap-2 transition-all"
                  style={{ fontSize: "15px", fontWeight: 700, opacity: isSpinning ? 0.7 : 1 }}
                >
                  {isSpinning ? <Loader2 size={18} className="animate-spin" /> : <Zap size={18} />}
                  {isSpinning ? "Spinning..." : "SPIN"}
                </button>
              </div>
            </div>

            {/* Game Info Sidebar */}
            <div className="space-y-4">
              <div className="glass-card p-4">
                <h3 className="flex items-center gap-2 mb-3" style={{ fontSize: "14px", fontWeight: 600, color: "#e2e8f0" }}>
                  <Coins size={14} style={{ color: "var(--gold)" }} />
                  Game Stats
                </h3>
                <div className="space-y-3">
                  {[
                    { label: "RTP", value: `${currentGame?.rtp}%`, color: (currentGame?.rtp || 0) >= 100 ? "var(--neon-green)" : "var(--gold)" },
                    { label: "Volatility", value: currentGame?.volatility || "", color: VOLATILITY_COLORS[currentGame?.volatility || "medium"] },
                    { label: "Max Win", value: currentGame?.maxWin || "", color: "var(--gold)" },
                    { label: "Provider", value: currentGame?.provider || "", color: "#94a3b8" },
                  ].map((stat) => (
                    <div key={stat.label} className="flex justify-between items-center">
                      <span style={{ fontSize: "12px", color: "#64748b" }}>{stat.label}</span>
                      <span style={{ fontSize: "13px", fontWeight: 600, color: stat.color, textTransform: "capitalize" }}>{stat.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="glass-card p-4">
                <h3 className="flex items-center gap-2 mb-3" style={{ fontSize: "14px", fontWeight: 600, color: "#e2e8f0" }}>
                  <Trophy size={14} style={{ color: "var(--gold)" }} />
                  Recent Wins
                </h3>
                <div className="space-y-2">
                  {[
                    { user: "HighRoller99", amount: 1250, mult: "25x" },
                    { user: "LuckyAce", amount: 450, mult: "9x" },
                    { user: "SlotMaster", amount: 2100, mult: "42x" },
                  ].map((win, i) => (
                    <div key={i} className="flex items-center justify-between py-1.5">
                      <span style={{ fontSize: "12px", color: "#94a3b8" }}>{win.user}</span>
                      <div className="flex items-center gap-2">
                        <span style={{ fontSize: "10px", color: "#475569" }}>{win.mult}</span>
                        <span style={{ fontSize: "12px", fontWeight: 600, fontFamily: "'JetBrains Mono', monospace", color: "var(--neon-green)" }}>${win.amount}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </CasinoLayout>
  );
}
