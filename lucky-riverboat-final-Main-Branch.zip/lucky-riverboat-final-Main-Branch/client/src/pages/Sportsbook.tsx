import { useAuth } from "@/_core/hooks/useAuth";
import CasinoLayout from "@/components/CasinoLayout";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { Loader2, Trophy, TrendingUp, Zap, Target } from "lucide-react";

type BetType = "moneyline" | "spread" | "over_under";

export default function Sportsbook() {
  const { user, loading } = useAuth();
  const [selectedEvent, setSelectedEvent] = useState<number | null>(null);
  const [betType, setBetType] = useState<BetType>("moneyline");
  const [betAmount, setBetAmount] = useState("");
  const [selectedTeam, setSelectedTeam] = useState<string>("");

  const balanceQuery = trpc.wallet.getBalance.useQuery();
  const eventsQuery = trpc.sportsbook.getEvents.useQuery();
  const placeBetMutation = trpc.sportsbook.placeBet.useMutation();
  const userBetsQuery = trpc.sportsbook.getUserBets.useQuery({ limit: 10 });
  const balance = Number(balanceQuery.data?.balance || 0);

  const handlePlaceBet = async () => {
    if (!selectedEvent || !betAmount || !selectedTeam) {
      toast.error("Please select an event, team, and enter a bet amount");
      return;
    }
    try {
      await placeBetMutation.mutateAsync({
        eventId: selectedEvent,
        betType,
        amount: Number(betAmount),
        selectedTeam,
        odds: 1.5,
      });
      setBetAmount("");
      setSelectedTeam("");
      balanceQuery.refetch();
      userBetsQuery.refetch();
      toast.success("Bet placed successfully!");
    } catch (error: any) {
      toast.error(error.message || "Failed to place bet");
    }
  };

  if (loading) {
    return (
      <CasinoLayout>
        <div className="flex items-center justify-center py-32">
          <Loader2 className="w-8 h-8 animate-spin" style={{ color: "var(--gold)" }} />
        </div>
      </CasinoLayout>
    );
  }

  const selectedEventData = eventsQuery.data?.find((e: any) => e.id === selectedEvent);

  return (
    <CasinoLayout>
      {/* Page Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="flex items-center gap-2" style={{ fontSize: "24px", fontWeight: 700, color: "#e2e8f0" }}>
            <Trophy size={24} style={{ color: "var(--gold)" }} />
            Sportsbook
          </h1>
          <p style={{ fontSize: "14px", color: "#64748b", marginTop: "4px" }}>Live sports betting with competitive odds</p>
        </div>
        <div className="glass-card px-4 py-2">
          <span style={{ fontSize: "12px", color: "#64748b" }}>Balance</span>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "16px", fontWeight: 600, color: "var(--gold)" }}>
            ${balance.toFixed(2)}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Live Events */}
        <div className="lg:col-span-2 space-y-6">
          <div className="glass-card overflow-hidden">
            <div className="p-4 flex items-center justify-between" style={{ borderBottom: "1px solid var(--glass-border)" }}>
              <h2 className="flex items-center gap-2" style={{ fontSize: "16px", fontWeight: 600, color: "#e2e8f0" }}>
                <Zap size={16} style={{ color: "var(--neon-green)" }} />
                Live Events
              </h2>
              <div className="flex items-center gap-2">
                <div className="live-dot" />
                <span style={{ fontSize: "12px", color: "var(--neon-green)" }}>{eventsQuery.data?.length || 0} Live</span>
              </div>
            </div>

            <div className="p-4 space-y-3">
              {eventsQuery.data?.map((event: any) => (
                <button
                  key={event.id}
                  onClick={() => setSelectedEvent(event.id)}
                  className="w-full text-left rounded-xl p-4 transition-all duration-200"
                  style={{
                    background: selectedEvent === event.id ? "rgba(212,168,67,0.08)" : "var(--surface-2)",
                    border: selectedEvent === event.id ? "1px solid rgba(212,168,67,0.4)" : "1px solid var(--glass-border)",
                    boxShadow: selectedEvent === event.id ? "0 0 20px rgba(212,168,67,0.1)" : "none",
                  }}
                >
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 style={{ fontSize: "15px", fontWeight: 600, color: "#e2e8f0" }}>
                        {event.homeTeam} vs {event.awayTeam}
                      </h3>
                      <p style={{ fontSize: "12px", color: "#64748b", marginTop: "2px" }}>
                        {event.sport} • {event.league}
                      </p>
                    </div>
                    <span
                      className="flex items-center gap-1"
                      style={{
                        fontSize: "11px",
                        padding: "2px 8px",
                        borderRadius: "6px",
                        background: "rgba(0,230,118,0.1)",
                        color: "var(--neon-green)",
                        fontWeight: 600,
                      }}
                    >
                      <div className="live-dot" style={{ width: "6px", height: "6px" }} />
                      LIVE
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { label: event.homeTeam, odds: event.homeOdds, team: "home" },
                      { label: "Draw", odds: event.drawOdds || "-", team: "draw" },
                      { label: event.awayTeam, odds: event.awayOdds, team: "away" },
                    ].map((opt) => (
                      <div
                        key={opt.team}
                        className="text-center rounded-lg py-2 px-3 transition-colors"
                        style={{
                          background: selectedEvent === event.id && selectedTeam === opt.team
                            ? "rgba(212,168,67,0.15)"
                            : "rgba(0,0,0,0.2)",
                          border: selectedEvent === event.id && selectedTeam === opt.team
                            ? "1px solid rgba(212,168,67,0.4)"
                            : "1px solid transparent",
                        }}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedEvent(event.id);
                          setSelectedTeam(opt.team);
                        }}
                      >
                        <div style={{ fontSize: "11px", color: "#64748b", marginBottom: "2px" }}>{opt.label}</div>
                        <div style={{ fontSize: "16px", fontWeight: 700, fontFamily: "'JetBrains Mono', monospace", color: "var(--gold)" }}>
                          {opt.odds}
                        </div>
                      </div>
                    ))}
                  </div>
                </button>
              ))}

              {!eventsQuery.data?.length && (
                <div className="text-center py-12" style={{ color: "#475569" }}>
                  <Trophy size={40} style={{ margin: "0 auto 12px", opacity: 0.3 }} />
                  <p>No live events available right now</p>
                  <p style={{ fontSize: "13px", marginTop: "4px" }}>Check back soon for upcoming matches</p>
                </div>
              )}
            </div>
          </div>

          {/* Recent Bets */}
          <div className="glass-card overflow-hidden">
            <div className="p-4" style={{ borderBottom: "1px solid var(--glass-border)" }}>
              <h2 className="flex items-center gap-2" style={{ fontSize: "16px", fontWeight: 600, color: "#e2e8f0" }}>
                <TrendingUp size={16} style={{ color: "var(--gold)" }} />
                Your Recent Bets
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full" style={{ fontSize: "13px" }}>
                <thead>
                  <tr style={{ borderBottom: "1px solid var(--glass-border)" }}>
                    <th className="text-left py-3 px-4" style={{ color: "#64748b", fontWeight: 500 }}>Event</th>
                    <th className="text-left py-3 px-4" style={{ color: "#64748b", fontWeight: 500 }}>Type</th>
                    <th className="text-right py-3 px-4" style={{ color: "#64748b", fontWeight: 500 }}>Amount</th>
                    <th className="text-right py-3 px-4" style={{ color: "#64748b", fontWeight: 500 }}>Odds</th>
                    <th className="text-center py-3 px-4" style={{ color: "#64748b", fontWeight: 500 }}>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {userBetsQuery.data?.map((bet: any, i: number) => (
                    <tr key={i} style={{ borderBottom: "1px solid rgba(255,255,255,0.03)" }} className="hover:bg-[var(--surface-2)] transition-colors">
                      <td className="py-3 px-4" style={{ color: "#e2e8f0" }}>Event #{bet.eventId}</td>
                      <td className="py-3 px-4 capitalize" style={{ color: "#94a3b8" }}>{bet.betType}</td>
                      <td className="text-right py-3 px-4" style={{ fontFamily: "'JetBrains Mono', monospace", color: "#94a3b8" }}>${Number(bet.amount).toFixed(2)}</td>
                      <td className="text-right py-3 px-4" style={{ fontFamily: "'JetBrains Mono', monospace", color: "#94a3b8" }}>{Number(bet.odds).toFixed(2)}</td>
                      <td className="text-center py-3 px-4">
                        <span
                          style={{
                            fontSize: "11px",
                            padding: "2px 10px",
                            borderRadius: "6px",
                            fontWeight: 600,
                            background: bet.status === "won" ? "rgba(0,230,118,0.1)" : bet.status === "lost" ? "rgba(239,68,68,0.1)" : "rgba(212,168,67,0.1)",
                            color: bet.status === "won" ? "var(--neon-green)" : bet.status === "lost" ? "#ef4444" : "var(--gold)",
                          }}
                        >
                          {bet.status.toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {!userBetsQuery.data?.length && (
                <p className="text-center py-8" style={{ color: "#475569", fontSize: "13px" }}>No bets placed yet</p>
              )}
            </div>
          </div>
        </div>

        {/* Bet Slip */}
        <div>
          <div className="glass-card overflow-hidden sticky top-4" style={{ border: selectedEvent ? "1px solid rgba(212,168,67,0.2)" : undefined }}>
            <div className="p-4" style={{ borderBottom: "1px solid var(--glass-border)" }}>
              <h2 className="flex items-center gap-2" style={{ fontSize: "16px", fontWeight: 600, color: "#e2e8f0" }}>
                <Target size={16} style={{ color: "var(--gold)" }} />
                Bet Slip
              </h2>
            </div>

            <div className="p-4">
              {selectedEvent ? (
                <div className="space-y-4">
                  <div className="rounded-xl p-3" style={{ background: "var(--surface-2)", border: "1px solid var(--glass-border)" }}>
                    <div style={{ fontSize: "11px", color: "#64748b", marginBottom: "4px" }}>SELECTED EVENT</div>
                    <div style={{ fontSize: "14px", fontWeight: 600, color: "#e2e8f0" }}>
                      {selectedEventData ? `${selectedEventData.homeTeam} vs ${selectedEventData.awayTeam}` : `Event #${selectedEvent}`}
                    </div>
                  </div>

                  <div>
                    <label style={{ fontSize: "11px", color: "#64748b", fontWeight: 600, marginBottom: "8px", display: "block", letterSpacing: "1px" }}>BET TYPE</label>
                    <select
                      value={betType}
                      onChange={(e) => setBetType(e.target.value as BetType)}
                      className="w-full rounded-xl py-3 px-3"
                      style={{
                        background: "var(--surface-2)",
                        border: "1px solid var(--glass-border)",
                        color: "#e2e8f0",
                        fontSize: "14px",
                        outline: "none",
                      }}
                    >
                      <option value="moneyline">Moneyline</option>
                      <option value="spread">Spread</option>
                      <option value="over_under">Over/Under</option>
                    </select>
                  </div>

                  <div>
                    <label style={{ fontSize: "11px", color: "#64748b", fontWeight: 600, marginBottom: "8px", display: "block", letterSpacing: "1px" }}>SELECT TEAM</label>
                    <div className="grid grid-cols-2 gap-2">
                      {["home", "away"].map((team) => (
                        <button
                          key={team}
                          onClick={() => setSelectedTeam(team)}
                          className="rounded-xl py-3 px-3 transition-all capitalize"
                          style={{
                            background: selectedTeam === team ? "rgba(212,168,67,0.15)" : "var(--surface-2)",
                            border: selectedTeam === team ? "1px solid rgba(212,168,67,0.4)" : "1px solid var(--glass-border)",
                            color: selectedTeam === team ? "var(--gold)" : "#94a3b8",
                            fontSize: "14px",
                            fontWeight: 600,
                          }}
                        >
                          {team} Team
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label style={{ fontSize: "11px", color: "#64748b", fontWeight: 600, marginBottom: "8px", display: "block", letterSpacing: "1px" }}>BET AMOUNT</label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "#64748b", fontFamily: "'JetBrains Mono', monospace" }}>$</span>
                      <input
                        type="number"
                        value={betAmount}
                        onChange={(e) => setBetAmount(e.target.value)}
                        placeholder="0.00"
                        min="0.01"
                        step="0.01"
                        className="w-full rounded-xl py-3 pl-7 pr-3"
                        style={{
                          background: "var(--surface-2)",
                          border: "1px solid var(--glass-border)",
                          color: "#e2e8f0",
                          fontFamily: "'JetBrains Mono', monospace",
                          fontSize: "16px",
                          outline: "none",
                        }}
                      />
                    </div>
                  </div>

                  <div className="rounded-xl p-3" style={{ background: "rgba(0,230,118,0.05)", border: "1px solid rgba(0,230,118,0.15)" }}>
                    <div className="flex justify-between items-center">
                      <span style={{ fontSize: "13px", color: "#94a3b8" }}>Potential Payout</span>
                      <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "18px", fontWeight: 700, color: "var(--neon-green)" }}>
                        ${(Number(betAmount || 0) * 1.5).toFixed(2)}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={handlePlaceBet}
                    disabled={placeBetMutation.isPending || !selectedTeam || !betAmount}
                    className="btn-primary w-full flex items-center justify-center gap-2"
                    style={{ padding: "14px", fontSize: "15px", fontWeight: 700, borderRadius: "12px", opacity: placeBetMutation.isPending ? 0.7 : 1 }}
                  >
                    {placeBetMutation.isPending ? (
                      <><Loader2 className="w-5 h-5 animate-spin" /> Placing Bet...</>
                    ) : (
                      "Place Bet"
                    )}
                  </button>
                </div>
              ) : (
                <div className="text-center py-12">
                  <Target size={40} style={{ margin: "0 auto 12px", color: "#334155", opacity: 0.5 }} />
                  <p style={{ color: "#475569", fontSize: "14px" }}>Select an event to place a bet</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </CasinoLayout>
  );
}
