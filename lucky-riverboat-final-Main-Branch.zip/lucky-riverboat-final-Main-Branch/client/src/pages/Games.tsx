import { useAuth } from "@/_core/hooks/useAuth";
import CasinoLayout from "@/components/CasinoLayout";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import { Loader2, ArrowLeft, Flame, Zap, RotateCcw } from "lucide-react";

const WATERMARK_URL = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663341115981/TtZTjkmKyKWMaHFr.jpg";

export default function Games() {
  const { user, loading } = useAuth();
  const [activeGame, setActiveGame] = useState<"blackjack" | "plinko" | "slots" | null>(null);
  const [betAmount, setBetAmount] = useState("1.00");
  const [gameResult, setGameResult] = useState<any>(null);

  const balanceQuery = trpc.wallet.getBalance.useQuery();
  const blackjackMutation = trpc.games.playBlackjack.useMutation();
  const plinkoMutation = trpc.games.playPlinko.useMutation();
  const slotsMutation = trpc.games.playSlots.useMutation();
  const recentGamesQuery = trpc.games.getRecentGames.useQuery({ limit: 10 });

  const isPending = blackjackMutation.isPending || plinkoMutation.isPending || slotsMutation.isPending;
  const balance = Number(balanceQuery.data?.balance || 0);

  const handlePlay = async (game: string) => {
    try {
      let result: any;
      if (game === "blackjack") result = await blackjackMutation.mutateAsync({ betAmount: Number(betAmount) });
      else if (game === "plinko") result = await plinkoMutation.mutateAsync({ betAmount: Number(betAmount) });
      else result = await slotsMutation.mutateAsync({ betAmount: Number(betAmount) });
      setGameResult({ game, ...result });
      balanceQuery.refetch();
      recentGamesQuery.refetch();
      if (result.multiplier > 1) toast.success(`Won $${result.payout.toFixed(2)}!`);
      else toast.error(`Lost $${Number(betAmount).toFixed(2)}`);
    } catch (error: any) {
      toast.error(error.message || "Game error");
    }
  };

  const games = [
    { id: "blackjack", name: "Blackjack", desc: "Beat the dealer — get closest to 21", icon: "🃏", accentColor: "#00e676", players: 47 },
    { id: "plinko", name: "Plinko", desc: "Drop the ball — watch your fortune cascade", icon: "⚡", accentColor: "#d4a843", players: 83 },
    { id: "slots", name: "Slots", desc: "Spin the reels — match symbols to win big", icon: "🎰", accentColor: "#a855f7", players: 124 },
  ];

  if (loading) {
    return (
      <CasinoLayout>
        <div className="flex items-center justify-center py-32">
          <Loader2 className="w-8 h-8 animate-spin" style={{ color: "var(--gold)" }} />
        </div>
      </CasinoLayout>
    );
  }

  return (
    <CasinoLayout>
      {/* Page Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="flex items-center gap-2" style={{ fontSize: "24px", fontWeight: 700, color: "#e2e8f0" }}>
            <Flame size={24} style={{ color: "var(--gold)" }} />
            House Originals
          </h1>
          <p style={{ fontSize: "14px", color: "#64748b", marginTop: "4px" }}>100% RTP — 0% House Edge on every game</p>
        </div>
        <div className="glass-card px-4 py-2">
          <span style={{ fontSize: "12px", color: "#64748b" }}>Balance</span>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "16px", fontWeight: 600, color: "var(--gold)" }}>
            ${balance.toFixed(2)}
          </div>
        </div>
      </div>

      {!activeGame ? (
        <>
          {/* Game Grid — each card uses Watermark as background */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {games.map((game) => (
              <button
                key={game.id}
                onClick={() => { setActiveGame(game.id as any); setGameResult(null); }}
                className="game-card-premium text-left group"
              >
                <div className="relative overflow-hidden" style={{ aspectRatio: "4/3" }}>
                  {/* Watermark Background */}
                  <div
                    className="absolute inset-0"
                    style={{
                      backgroundImage: `url(${WATERMARK_URL})`,
                      backgroundSize: "cover",
                      backgroundPosition: "center",
                      filter: "brightness(0.15) contrast(1.2) sepia(0.3)",
                    }}
                  />
                  {/* Accent Overlay */}
                  <div
                    className="absolute inset-0"
                    style={{
                      background: `radial-gradient(ellipse at center, ${game.accentColor}15 0%, transparent 70%), linear-gradient(180deg, transparent 0%, rgba(0,0,0,0.6) 100%)`,
                    }}
                  />
                  {/* Animated Glow Border on Hover */}
                  <div
                    className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                    style={{
                      boxShadow: `inset 0 0 40px ${game.accentColor}20, 0 0 30px ${game.accentColor}10`,
                    }}
                  />
                  {/* Game Icon */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span
                      className="transition-transform duration-300 group-hover:scale-110"
                      style={{
                        fontSize: "80px",
                        filter: `drop-shadow(0 0 20px ${game.accentColor}60) drop-shadow(0 4px 16px rgba(0,0,0,0.5))`,
                      }}
                    >
                      {game.icon}
                    </span>
                  </div>
                  {/* RTP Badge */}
                  <div className="rtp-badge rtp-100">100% RTP</div>
                  {/* Player Count */}
                  <div className="player-count">
                    <div className="live-dot" />
                    {game.players} playing
                  </div>
                  {/* Watermark Overlay Pattern (subtle) */}
                  <div
                    className="absolute inset-0 pointer-events-none"
                    style={{
                      backgroundImage: `url(${WATERMARK_URL})`,
                      backgroundSize: "300px",
                      backgroundRepeat: "repeat",
                      opacity: 0.03,
                      mixBlendMode: "overlay",
                    }}
                  />
                </div>
                <div className="card-info">
                  <h3>{game.name}</h3>
                  <div className="card-provider">{game.desc}</div>
                </div>
              </button>
            ))}
          </div>

          {/* Recent Games Table */}
          <div className="glass-card overflow-hidden">
            <div className="p-4" style={{ borderBottom: "1px solid var(--glass-border)" }}>
              <h2 className="flex items-center gap-2" style={{ fontSize: "16px", fontWeight: 600, color: "#e2e8f0" }}>
                <Zap size={16} style={{ color: "var(--gold)" }} />
                Recent Games
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full" style={{ fontSize: "13px" }}>
                <thead>
                  <tr style={{ borderBottom: "1px solid var(--glass-border)" }}>
                    <th className="text-left py-3 px-4" style={{ color: "#64748b", fontWeight: 500 }}>Game</th>
                    <th className="text-right py-3 px-4" style={{ color: "#64748b", fontWeight: 500 }}>Bet</th>
                    <th className="text-right py-3 px-4" style={{ color: "#64748b", fontWeight: 500 }}>Multiplier</th>
                    <th className="text-right py-3 px-4" style={{ color: "#64748b", fontWeight: 500 }}>Payout</th>
                  </tr>
                </thead>
                <tbody>
                  {recentGamesQuery.data?.length ? recentGamesQuery.data.map((game, i) => (
                    <tr key={i} style={{ borderBottom: "1px solid rgba(255,255,255,0.03)" }} className="hover:bg-[var(--surface-2)] transition-colors">
                      <td className="py-3 px-4 capitalize" style={{ color: "#e2e8f0" }}>{game.gameType}</td>
                      <td className="text-right py-3 px-4" style={{ fontFamily: "'JetBrains Mono', monospace", color: "#94a3b8" }}>${Number(game.betAmount).toFixed(2)}</td>
                      <td className="text-right py-3 px-4" style={{ fontFamily: "'JetBrains Mono', monospace", color: "#94a3b8" }}>{Number(game.multiplier).toFixed(2)}x</td>
                      <td className="text-right py-3 px-4" style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 600, color: Number(game.payout) > 0 ? "var(--neon-green)" : "#ef4444" }}>
                        ${Number(game.payout).toFixed(2)}
                      </td>
                    </tr>
                  )) : (
                    <tr>
                      <td colSpan={4} className="text-center py-8" style={{ color: "#475569" }}>No games played yet. Select a game above to start!</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        <>
          {/* Active Game View */}
          <button
            onClick={() => { setActiveGame(null); setGameResult(null); }}
            className="flex items-center gap-2 mb-6 hover:opacity-80 transition-opacity"
            style={{ color: "#94a3b8", fontSize: "14px" }}
          >
            <ArrowLeft size={16} /> Back to Games
          </button>

          <div className="max-w-2xl mx-auto">
            {/* Game Display with Watermark Background */}
            <div className="glass-card overflow-hidden mb-6" style={{ border: `1px solid ${games.find(g => g.id === activeGame)?.accentColor}30` }}>
              <div className="p-4 flex items-center justify-between" style={{ borderBottom: "1px solid var(--glass-border)" }}>
                <h2 className="capitalize flex items-center gap-2" style={{ fontSize: "18px", fontWeight: 600, color: "#e2e8f0" }}>
                  {games.find(g => g.id === activeGame)?.icon} {activeGame}
                </h2>
                <div className="badge-rtp" style={{ fontSize: "11px" }}>
                  <Zap size={10} /> 100% RTP
                </div>
              </div>

              {/* Game Area with Watermark Background */}
              <div className="relative" style={{ minHeight: "320px" }}>
                {/* Watermark Background Layer */}
                <div
                  className="absolute inset-0"
                  style={{
                    backgroundImage: `url(${WATERMARK_URL})`,
                    backgroundSize: "cover",
                    backgroundPosition: "center",
                    filter: "brightness(0.12) contrast(1.3) sepia(0.4)",
                  }}
                />
                {/* Accent Color Overlay */}
                <div
                  className="absolute inset-0"
                  style={{
                    background: `radial-gradient(ellipse at 50% 30%, ${games.find(g => g.id === activeGame)?.accentColor}12 0%, transparent 60%), linear-gradient(180deg, transparent 40%, rgba(0,0,0,0.5) 100%)`,
                  }}
                />
                {/* Tiled Watermark Pattern Overlay */}
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    backgroundImage: `url(${WATERMARK_URL})`,
                    backgroundSize: "400px",
                    backgroundRepeat: "repeat",
                    opacity: 0.04,
                    mixBlendMode: "overlay",
                  }}
                />
                {/* Vignette Effect */}
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    boxShadow: "inset 0 0 80px rgba(0,0,0,0.6)",
                  }}
                />

                {/* Game Content */}
                <div className="relative flex items-center justify-center p-8" style={{ minHeight: "300px" }}>
                  {gameResult ? (
                    <div className="text-center space-y-4">
                      {activeGame === "blackjack" && (
                        <>
                          <div className="flex gap-12 justify-center">
                            <div>
                              <div style={{ fontSize: "11px", color: "rgba(255,255,255,0.4)", marginBottom: "8px", letterSpacing: "2px", fontWeight: 600 }}>YOUR HAND</div>
                              <div style={{ fontSize: "56px", fontWeight: 700, color: "#fff", textShadow: "0 0 20px rgba(0,230,118,0.3)" }}>{gameResult.playerHand}</div>
                            </div>
                            <div style={{ width: "1px", background: "rgba(255,255,255,0.1)", margin: "0 8px" }} />
                            <div>
                              <div style={{ fontSize: "11px", color: "rgba(255,255,255,0.4)", marginBottom: "8px", letterSpacing: "2px", fontWeight: 600 }}>DEALER</div>
                              <div style={{ fontSize: "56px", fontWeight: 700, color: "#fff", textShadow: "0 0 20px rgba(239,68,68,0.3)" }}>{gameResult.dealerHand}</div>
                            </div>
                          </div>
                          <div
                            className="mt-4"
                            style={{
                              fontSize: "28px",
                              fontWeight: 800,
                              letterSpacing: "2px",
                              color: gameResult.multiplier > 1 ? "var(--neon-green)" : gameResult.multiplier === 1 ? "var(--gold)" : "#ef4444",
                              textShadow: gameResult.multiplier > 1 ? "0 0 30px rgba(0,230,118,0.5)" : "none",
                            }}
                          >
                            {gameResult.multiplier > 1 ? "YOU WIN!" : gameResult.multiplier === 1 ? "PUSH" : "DEALER WINS"}
                          </div>
                        </>
                      )}
                      {activeGame === "plinko" && (
                        <>
                          <div style={{ fontSize: "72px", filter: "drop-shadow(0 0 20px rgba(212,168,67,0.5))" }}>⚡</div>
                          <div style={{
                            fontSize: "48px",
                            fontWeight: 800,
                            fontFamily: "'JetBrains Mono', monospace",
                            color: gameResult.multiplier > 1 ? "var(--neon-green)" : "#ef4444",
                            textShadow: gameResult.multiplier > 1 ? "0 0 40px rgba(0,230,118,0.5)" : "0 0 40px rgba(239,68,68,0.3)",
                          }}>
                            {Number(gameResult.multiplier).toFixed(2)}x
                          </div>
                        </>
                      )}
                      {activeGame === "slots" && (
                        <>
                          <div className="flex gap-4 justify-center mb-6">
                            {gameResult.reels?.map((r: string, i: number) => (
                              <div
                                key={i}
                                className="w-24 h-24 rounded-2xl flex items-center justify-center"
                                style={{
                                  background: "rgba(0,0,0,0.5)",
                                  fontSize: "48px",
                                  border: "2px solid rgba(212,168,67,0.3)",
                                  boxShadow: "0 0 20px rgba(0,0,0,0.3), inset 0 0 20px rgba(212,168,67,0.05)",
                                  backdropFilter: "blur(8px)",
                                }}
                              >
                                {r}
                              </div>
                            ))}
                          </div>
                          <div style={{
                            fontSize: "28px",
                            fontWeight: 800,
                            letterSpacing: "2px",
                            color: gameResult.multiplier > 1 ? "var(--neon-green)" : "#ef4444",
                            textShadow: gameResult.multiplier > 1 ? "0 0 30px rgba(0,230,118,0.5)" : "none",
                          }}>
                            {gameResult.multiplier > 1 ? "WINNER!" : "TRY AGAIN"}
                          </div>
                        </>
                      )}
                      <div style={{
                        fontFamily: "'JetBrains Mono', monospace",
                        fontSize: "24px",
                        fontWeight: 700,
                        color: "#fff",
                        textShadow: "0 2px 10px rgba(0,0,0,0.5)",
                        marginTop: "8px",
                      }}>
                        ${Number(gameResult.payout).toFixed(2)}
                      </div>
                    </div>
                  ) : (
                    <div className="text-center">
                      <div style={{
                        fontSize: "100px",
                        opacity: 0.3,
                        filter: `drop-shadow(0 0 30px ${games.find(g => g.id === activeGame)?.accentColor}40)`,
                      }}>
                        {games.find(g => g.id === activeGame)?.icon}
                      </div>
                      <p style={{ fontSize: "14px", color: "rgba(255,255,255,0.3)", marginTop: "16px", letterSpacing: "1px" }}>Place your bet to start</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Bet Controls */}
            <div className="glass-card p-6">
              <div className="mb-4">
                <label style={{ fontSize: "11px", color: "#64748b", fontWeight: 600, marginBottom: "8px", display: "block", letterSpacing: "1px" }}>
                  BET AMOUNT
                </label>
                <div className="flex gap-2">
                  <div className="flex-1 relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "#64748b", fontFamily: "'JetBrains Mono', monospace" }}>$</span>
                    <input
                      type="number"
                      value={betAmount}
                      onChange={(e) => setBetAmount(e.target.value)}
                      min="0.01"
                      step="0.01"
                      disabled={isPending}
                      className="w-full rounded-xl py-3 pl-7 pr-3"
                      style={{
                        background: "var(--surface-2)",
                        border: "1px solid var(--glass-border)",
                        color: "#e2e8f0",
                        fontFamily: "'JetBrains Mono', monospace",
                        fontSize: "16px",
                        outline: "none",
                      }}
                    />
                  </div>
                  {[0.5, 2, "½", "MAX"].map((btn) => (
                    <button
                      key={String(btn)}
                      onClick={() => {
                        if (btn === "½") setBetAmount((balance / 2).toFixed(2));
                        else if (btn === "MAX") setBetAmount(balance.toFixed(2));
                        else if (typeof btn === "number") setBetAmount((Number(betAmount) * btn).toFixed(2));
                      }}
                      className="px-4 rounded-xl transition-all hover:scale-105"
                      style={{
                        background: "var(--surface-2)",
                        border: "1px solid var(--glass-border)",
                        color: "#94a3b8",
                        fontSize: "13px",
                        fontWeight: 500,
                      }}
                    >
                      {typeof btn === "number" ? `${btn}x` : btn}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={() => activeGame && handlePlay(activeGame)}
                disabled={!betAmount || Number(betAmount) <= 0 || Number(betAmount) > balance || isPending}
                className="btn-primary w-full flex items-center justify-center gap-2"
                style={{
                  padding: "16px",
                  fontSize: "16px",
                  fontWeight: 700,
                  borderRadius: "12px",
                  opacity: isPending ? 0.7 : 1,
                  letterSpacing: "1px",
                }}
              >
                {isPending ? (
                  <><Loader2 className="w-5 h-5 animate-spin" /> Playing...</>
                ) : (
                  <><RotateCcw size={18} /> PLACE BET</>
                )}
              </button>
            </div>
          </div>
        </>
      )}
    </CasinoLayout>
  );
}
