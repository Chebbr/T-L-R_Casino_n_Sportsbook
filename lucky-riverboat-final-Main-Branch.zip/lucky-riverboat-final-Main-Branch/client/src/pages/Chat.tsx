import { useAuth } from "@/_core/hooks/useAuth";
import CasinoLayout from "@/components/CasinoLayout";
import { useState, useEffect, useRef } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Loader2, Send, Users, MessageSquare, Heart, Shield, Crown } from "lucide-react";

interface ChatMessage {
  id: number;
  userId: number;
  username: string;
  message: string;
  timestamp: Date;
  isAdmin: boolean;
  isModerator: boolean;
}

interface OnlineUser {
  id: number;
  username: string;
  status: "online" | "away" | "playing";
  vipLevel: number;
}

const MOCK_MESSAGES: ChatMessage[] = [
  { id: 1, userId: 1, username: "HighRoller99", message: "Just hit 5x on Plinko! 🎉", timestamp: new Date(Date.now() - 120000), isAdmin: false, isModerator: false },
  { id: 2, userId: 2, username: "Xebb", message: "Welcome aboard the Riverboat! 🚢", timestamp: new Date(Date.now() - 90000), isAdmin: true, isModerator: true },
  { id: 3, userId: 3, username: "LuckyAce", message: "Anyone up for poker?", timestamp: new Date(Date.now() - 60000), isAdmin: false, isModerator: false },
  { id: 4, userId: 4, username: "CasinoKing", message: "Blackjack is hot tonight 🔥", timestamp: new Date(Date.now() - 30000), isAdmin: false, isModerator: false },
  { id: 5, userId: 5, username: "PokerPro", message: "GG on that last hand!", timestamp: new Date(Date.now() - 15000), isAdmin: false, isModerator: true },
];

const MOCK_ONLINE: OnlineUser[] = [
  { id: 1, username: "HighRoller99", status: "playing", vipLevel: 4 },
  { id: 2, username: "Xebb", status: "online", vipLevel: 5 },
  { id: 3, username: "LuckyAce", status: "online", vipLevel: 2 },
  { id: 4, username: "CasinoKing", status: "playing", vipLevel: 3 },
  { id: 5, username: "PokerPro", status: "away", vipLevel: 3 },
  { id: 6, username: "SlotMaster", status: "online", vipLevel: 1 },
  { id: 7, username: "RiverRat", status: "playing", vipLevel: 2 },
];

const VIP_COLORS: Record<number, string> = {
  0: "#64748b", 1: "#94a3b8", 2: "#3b82f6", 3: "#8b5cf6", 4: "#f59e0b", 5: "#ef4444",
};

export default function Chat() {
  const { user, loading } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>(MOCK_MESSAGES);
  const [newMessage, setNewMessage] = useState("");
  const [showUsers, setShowUsers] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!newMessage.trim()) return;
    if (!user) { toast.error("Please log in to chat"); return; }
    const msg: ChatMessage = {
      id: Date.now(),
      userId: user.id,
      username: user.name || "Anonymous",
      message: newMessage,
      timestamp: new Date(),
      isAdmin: user.role === "admin",
      isModerator: false,
    };
    setMessages((prev) => [...prev, msg]);
    setNewMessage("");
  };

  if (loading) {
    return (
      <CasinoLayout>
        <div className="flex items-center justify-center py-32">
          <Loader2 className="w-8 h-8 animate-spin" style={{ color: "var(--gold)" }} />
        </div>
      </CasinoLayout>
    );
  }

  return (
    <CasinoLayout>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="flex items-center gap-2" style={{ fontSize: "24px", fontWeight: 700, color: "#e2e8f0" }}>
            <MessageSquare size={24} style={{ color: "var(--gold)" }} />
            Live Chat
          </h1>
          <p style={{ fontSize: "14px", color: "#64748b", marginTop: "4px" }}>
            {MOCK_ONLINE.length} players online
          </p>
        </div>
        <button
          onClick={() => setShowUsers(!showUsers)}
          className="glass-card px-4 py-2 flex items-center gap-2 transition-all hover:scale-105"
          style={{ fontSize: "13px", color: showUsers ? "var(--gold)" : "#94a3b8", fontWeight: 600, cursor: "pointer" }}
        >
          <Users size={14} />
          {showUsers ? "Hide Users" : "Show Users"}
        </button>
      </div>

      <div className="grid gap-6" style={{ gridTemplateColumns: showUsers ? "1fr 280px" : "1fr" }}>
        {/* Chat Panel */}
        <div className="glass-card overflow-hidden flex flex-col" style={{ height: "calc(100vh - 220px)", border: "1px solid rgba(212,168,67,0.1)" }}>
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3" style={{ scrollbarWidth: "thin", scrollbarColor: "rgba(255,255,255,0.1) transparent" }}>
            {messages.map((msg) => (
              <div key={msg.id} className="group flex gap-3 hover:bg-[rgba(255,255,255,0.02)] rounded-lg p-2 -mx-2 transition-colors">
                {/* Avatar */}
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{
                    background: msg.isAdmin ? "rgba(239,68,68,0.15)" : "rgba(212,168,67,0.1)",
                    border: `1px solid ${msg.isAdmin ? "rgba(239,68,68,0.3)" : "rgba(212,168,67,0.2)"}`,
                    fontSize: "12px",
                    fontWeight: 700,
                    color: msg.isAdmin ? "#ef4444" : "var(--gold)",
                  }}
                >
                  {msg.username[0].toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span style={{ fontSize: "13px", fontWeight: 600, color: msg.isAdmin ? "#ef4444" : "#e2e8f0" }}>
                      {msg.username}
                    </span>
                    {msg.isAdmin && (
                      <span className="flex items-center gap-1" style={{ fontSize: "10px", padding: "1px 6px", borderRadius: "4px", background: "rgba(239,68,68,0.1)", color: "#ef4444", fontWeight: 600 }}>
                        <Shield size={8} /> ADMIN
                      </span>
                    )}
                    {msg.isModerator && !msg.isAdmin && (
                      <span style={{ fontSize: "10px", padding: "1px 6px", borderRadius: "4px", background: "rgba(139,92,246,0.1)", color: "#8b5cf6", fontWeight: 600 }}>
                        MOD
                      </span>
                    )}
                    <span style={{ fontSize: "11px", color: "#475569" }}>
                      {msg.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </span>
                  </div>
                  <p style={{ fontSize: "14px", color: "#94a3b8", marginTop: "2px", lineHeight: 1.4 }}>{msg.message}</p>
                </div>
                {/* Actions */}
                <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-start gap-1">
                  <button
                    className="p-1 rounded hover:bg-[rgba(255,255,255,0.05)]"
                    style={{ color: "#475569" }}
                    onClick={() => toast.info("Liked!")}
                  >
                    <Heart size={12} />
                  </button>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4" style={{ borderTop: "1px solid var(--glass-border)" }}>
            <div className="flex gap-2">
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                placeholder={user ? "Type a message..." : "Log in to chat"}
                disabled={!user}
                className="flex-1 rounded-xl py-3 px-4"
                style={{
                  background: "var(--surface-2)",
                  border: "1px solid var(--glass-border)",
                  color: "#e2e8f0",
                  fontSize: "14px",
                  outline: "none",
                }}
              />
              <button
                onClick={handleSend}
                disabled={!user || !newMessage.trim()}
                className="btn-primary rounded-xl px-5 flex items-center gap-2"
                style={{ opacity: !user || !newMessage.trim() ? 0.5 : 1 }}
              >
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>

        {/* Online Users Panel */}
        {showUsers && (
          <div className="glass-card overflow-hidden" style={{ height: "calc(100vh - 220px)" }}>
            <div className="p-4" style={{ borderBottom: "1px solid var(--glass-border)" }}>
              <h3 className="flex items-center gap-2" style={{ fontSize: "14px", fontWeight: 600, color: "#e2e8f0" }}>
                <Users size={14} style={{ color: "var(--gold)" }} />
                Online — {MOCK_ONLINE.length}
              </h3>
            </div>
            <div className="overflow-y-auto p-3 space-y-1" style={{ maxHeight: "calc(100vh - 300px)", scrollbarWidth: "thin", scrollbarColor: "rgba(255,255,255,0.1) transparent" }}>
              {MOCK_ONLINE.map((u) => (
                <div
                  key={u.id}
                  className="flex items-center gap-3 rounded-lg p-2 hover:bg-[rgba(255,255,255,0.03)] transition-colors cursor-pointer"
                >
                  <div className="relative">
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center"
                      style={{
                        background: `${VIP_COLORS[u.vipLevel]}15`,
                        border: `1px solid ${VIP_COLORS[u.vipLevel]}40`,
                        fontSize: "11px",
                        fontWeight: 700,
                        color: VIP_COLORS[u.vipLevel],
                      }}
                    >
                      {u.username[0]}
                    </div>
                    <div
                      className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full"
                      style={{
                        background: u.status === "online" ? "var(--neon-green)" : u.status === "playing" ? "var(--gold)" : "#64748b",
                        border: "2px solid var(--surface-1)",
                      }}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span style={{ fontSize: "13px", fontWeight: 500, color: "#e2e8f0" }} className="truncate">{u.username}</span>
                      {u.vipLevel >= 4 && <Crown size={10} style={{ color: VIP_COLORS[u.vipLevel] }} />}
                    </div>
                    <span style={{ fontSize: "11px", color: "#475569", textTransform: "capitalize" }}>{u.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </CasinoLayout>
  );
}
