import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, json } from "drizzle-orm/mysql-core";

// ==================== CORE USERS ====================
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  vipTier: mysqlEnum("vipTier", ["bronze", "silver", "gold", "platinum", "diamond"]).default("bronze").notNull(),
  vipPoints: int("vipPoints").default(0).notNull(),
  balance: decimal("balance", { precision: 20, scale: 8 }).default("0").notNull(),
  vaultBalance: decimal("vaultBalance", { precision: 20, scale: 8 }).default("0").notNull(),
  totalWagered: decimal("totalWagered", { precision: 20, scale: 8 }).default("0").notNull(),
  totalWon: decimal("totalWon", { precision: 20, scale: 8 }).default("0").notNull(),
  gamesPlayed: int("gamesPlayed").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ==================== TRANSACTIONS ====================
export const transactions = mysqlTable("transactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["deposit", "withdrawal", "bet", "win", "refund", "bonus", "vip_reward", "affiliate_payout", "tip", "rain"]).notNull(),
  method: mysqlEnum("method", ["btc", "eth", "stripe", "game"]).default("game").notNull(),
  amount: decimal("amount", { precision: 20, scale: 8 }).notNull(),
  status: mysqlEnum("status", ["pending", "completed", "failed", "cancelled"]).default("pending").notNull(),
  txHash: varchar("txHash", { length: 128 }),
  stripePaymentId: varchar("stripePaymentId", { length: 128 }),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;

// ==================== GAME SESSIONS ====================
export const gameSessions = mysqlTable("gameSessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  gameType: varchar("gameType", { length: 32 }).notNull(),
  betAmount: decimal("betAmount", { precision: 20, scale: 8 }).notNull(),
  multiplier: decimal("multiplier", { precision: 10, scale: 4 }).default("0.0000"),
  payout: decimal("payout", { precision: 20, scale: 8 }).default("0.00").notNull(),
  result: json("result"),
  status: mysqlEnum("status", ["active", "completed", "cancelled"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GameSession = typeof gameSessions.$inferSelect;
export type InsertGameSession = typeof gameSessions.$inferInsert;

// ==================== SPORTS BETS ====================
export const sportsBets = mysqlTable("sportsBets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  eventId: varchar("eventId", { length: 128 }).notNull(),
  sport: varchar("sport", { length: 64 }).notNull(),
  eventName: text("eventName"),
  selection: text("selection").notNull(),
  odds: decimal("odds", { precision: 10, scale: 2 }).notNull(),
  betAmount: decimal("betAmount", { precision: 20, scale: 8 }).notNull(),
  potentialPayout: decimal("potentialPayout", { precision: 20, scale: 8 }).notNull(),
  status: mysqlEnum("status", ["pending", "won", "lost", "cancelled", "void"]).default("pending").notNull(),
  settledAt: timestamp("settledAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SportsBet = typeof sportsBets.$inferSelect;
export type InsertSportsBet = typeof sportsBets.$inferInsert;

// ==================== VIP SYSTEM ====================
export const vipTiers = mysqlTable("vipTiers", {
  id: int("id").autoincrement().primaryKey(),
  name: mysqlEnum("name", ["bronze", "silver", "gold", "platinum", "diamond"]).notNull().unique(),
  minWagered: decimal("minWagered", { precision: 20, scale: 8 }).default("0").notNull(),
  cashbackPercent: decimal("cashbackPercent", { precision: 5, scale: 2 }).default("0").notNull(),
  depositBonus: decimal("depositBonus", { precision: 5, scale: 2 }).default("0").notNull(),
  weeklyBonus: decimal("weeklyBonus", { precision: 20, scale: 8 }).default("0").notNull(),
  levelUpBonus: decimal("levelUpBonus", { precision: 20, scale: 8 }).default("0").notNull(),
  maxBetMultiplier: decimal("maxBetMultiplier", { precision: 5, scale: 2 }).default("1").notNull(),
  exclusiveGames: boolean("exclusiveGames").default(false).notNull(),
  prioritySupport: boolean("prioritySupport").default(false).notNull(),
  description: text("description"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type VipTier = typeof vipTiers.$inferSelect;
export type InsertVipTier = typeof vipTiers.$inferInsert;

// ==================== BONUS CODES ====================
export const bonusCodes = mysqlTable("bonusCodes", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 64 }).notNull().unique(),
  description: text("description"),
  type: mysqlEnum("type", ["deposit_match", "free_credits", "free_spins", "cashback"]).notNull(),
  value: decimal("value", { precision: 20, scale: 8 }).notNull(),
  maxUses: int("maxUses").default(0),
  currentUses: int("currentUses").default(0).notNull(),
  minDeposit: decimal("minDeposit", { precision: 20, scale: 8 }).default("0"),
  maxPayout: decimal("maxPayout", { precision: 20, scale: 8 }),
  expiresAt: timestamp("expiresAt"),
  isActive: boolean("isActive").default(true).notNull(),
  vipTierRequired: mysqlEnum("vipTierRequired", ["bronze", "silver", "gold", "platinum", "diamond"]),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BonusCode = typeof bonusCodes.$inferSelect;
export type InsertBonusCode = typeof bonusCodes.$inferInsert;

// ==================== BONUS REDEMPTIONS ====================
export const bonusRedemptions = mysqlTable("bonusRedemptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  bonusCodeId: int("bonusCodeId").notNull(),
  code: varchar("code", { length: 64 }).notNull(),
  amountCredited: decimal("amountCredited", { precision: 20, scale: 8 }).notNull(),
  redeemedAt: timestamp("redeemedAt").defaultNow().notNull(),
});

export type BonusRedemption = typeof bonusRedemptions.$inferSelect;
export type InsertBonusRedemption = typeof bonusRedemptions.$inferInsert;

// ==================== RTP CONFIGURATIONS ====================
export const rtpConfigs = mysqlTable("rtpConfigs", {
  id: int("id").autoincrement().primaryKey(),
  gameType: varchar("gameType", { length: 32 }).notNull().unique(),
  targetRtp: decimal("targetRtp", { precision: 6, scale: 4 }).default("0.9600").notNull(),
  minRtp: decimal("minRtp", { precision: 6, scale: 4 }).default("0.9000").notNull(),
  maxRtp: decimal("maxRtp", { precision: 6, scale: 4 }).default("1.0000").notNull(),
  houseEdge: decimal("houseEdge", { precision: 6, scale: 4 }).default("0.0400").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  adjustmentNotes: text("adjustmentNotes"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type RtpConfig = typeof rtpConfigs.$inferSelect;
export type InsertRtpConfig = typeof rtpConfigs.$inferInsert;

// ==================== CHAT MESSAGES ====================
export const chatMessages = mysqlTable("chatMessages", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  userName: varchar("userName", { length: 128 }),
  message: text("message").notNull(),
  type: mysqlEnum("type", ["chat", "system", "support"]).default("chat").notNull(),
  isDeleted: boolean("isDeleted").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = typeof chatMessages.$inferInsert;

// ==================== SUPPORT TICKETS ====================
export const supportTickets = mysqlTable("supportTickets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  userName: varchar("userName", { length: 128 }),
  subject: varchar("subject", { length: 256 }).notNull(),
  status: mysqlEnum("status", ["open", "in_progress", "resolved", "closed"]).default("open").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  resolvedAt: timestamp("resolvedAt"),
});

export type SupportTicket = typeof supportTickets.$inferSelect;
export type InsertSupportTicket = typeof supportTickets.$inferInsert;

export const supportMessages = mysqlTable("supportMessages", {
  id: int("id").autoincrement().primaryKey(),
  ticketId: int("ticketId").notNull(),
  userId: int("userId").notNull(),
  isAdmin: boolean("isAdmin").default(false).notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SupportMessage = typeof supportMessages.$inferSelect;
export type InsertSupportMessage = typeof supportMessages.$inferInsert;

// ==================== AFFILIATE SYSTEM ====================
export const referrals = mysqlTable("referrals", {
  id: int("id").autoincrement().primaryKey(),
  referrerId: int("referrerId").notNull(),
  referralCode: varchar("referralCode", { length: 32 }).notNull().unique(),
  commissionRate: decimal("commissionRate", { precision: 5, scale: 4 }).default("0.0500").notNull(),
  totalEarnings: decimal("totalEarnings", { precision: 20, scale: 8 }).default("0").notNull(),
  totalReferred: int("totalReferred").default(0).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Referral = typeof referrals.$inferSelect;
export type InsertReferral = typeof referrals.$inferInsert;

export const referralEarnings = mysqlTable("referralEarnings", {
  id: int("id").autoincrement().primaryKey(),
  referralId: int("referralId").notNull(),
  referrerId: int("referrerId").notNull(),
  referredUserId: int("referredUserId").notNull(),
  wagerAmount: decimal("wagerAmount", { precision: 20, scale: 8 }).notNull(),
  commissionAmount: decimal("commissionAmount", { precision: 20, scale: 8 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ReferralEarning = typeof referralEarnings.$inferSelect;
export type InsertReferralEarning = typeof referralEarnings.$inferInsert;

// ==================== WITHDRAWAL REQUESTS ====================
export const withdrawalRequests = mysqlTable("withdrawalRequests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  amount: decimal("amount", { precision: 20, scale: 8 }).notNull(),
  toAddress: varchar("toAddress", { length: 128 }).notNull(),
  txHash: varchar("txHash", { length: 128 }),
  status: mysqlEnum("status", ["pending", "processing", "completed", "failed", "cancelled"]).default("pending").notNull(),
  processedAt: timestamp("processedAt"),
  failureReason: text("failureReason"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WithdrawalRequest = typeof withdrawalRequests.$inferSelect;
export type InsertWithdrawalRequest = typeof withdrawalRequests.$inferInsert;

// ==================== DEPOSIT REQUESTS ====================
export const depositRequests = mysqlTable("depositRequests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  amount: decimal("amount", { precision: 20, scale: 8 }).notNull(),
  txHash: varchar("txHash", { length: 128 }),
  status: mysqlEnum("status", ["pending", "processing", "completed", "failed", "cancelled"]).default("pending").notNull(),
  processedAt: timestamp("processedAt"),
  failureReason: text("failureReason"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DepositRequest = typeof depositRequests.$inferSelect;
export type InsertDepositRequest = typeof depositRequests.$inferInsert;

// ==================== TIPPING SYSTEM ====================
export const tips = mysqlTable("tips", {
  id: int("id").autoincrement().primaryKey(),
  fromUserId: int("fromUserId").notNull(),
  toUserId: int("toUserId").notNull(),
  amount: decimal("amount", { precision: 20, scale: 8 }).notNull(),
  message: text("message"),
  tipType: mysqlEnum("tipType", ["player", "streamer", "rain"]).default("player").notNull(),
  vipMultiplier: decimal("vipMultiplier", { precision: 5, scale: 2 }).default("1.00").notNull(),
  actualAmount: decimal("actualAmount", { precision: 20, scale: 8 }).notNull(),
  status: mysqlEnum("status", ["pending", "completed", "failed", "cancelled"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Tip = typeof tips.$inferSelect;
export type InsertTip = typeof tips.$inferInsert;

export const tipPayouts = mysqlTable("tipPayouts", {
  id: int("id").autoincrement().primaryKey(),
  tipId: int("tipId").notNull(),
  userId: int("userId").notNull(),
  amount: decimal("amount", { precision: 20, scale: 8 }).notNull(),
  payoutStatus: mysqlEnum("payoutStatus", ["pending", "scheduled", "completed", "failed"]).default("pending").notNull(),
  payoutMethod: mysqlEnum("payoutMethod", ["wallet", "btc", "eth", "stripe"]).default("wallet").notNull(),
  txHash: varchar("txHash", { length: 128 }),
  scheduledAt: timestamp("scheduledAt"),
  completedAt: timestamp("completedAt"),
  failureReason: text("failureReason"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TipPayout = typeof tipPayouts.$inferSelect;
export type InsertTipPayout = typeof tipPayouts.$inferInsert;

export const tipLeaderboard = mysqlTable("tipLeaderboard", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  totalTipsReceived: decimal("totalTipsReceived", { precision: 20, scale: 8 }).default("0").notNull(),
  totalTipsGiven: decimal("totalTipsGiven", { precision: 20, scale: 8 }).default("0").notNull(),
  tipsReceivedCount: int("tipsReceivedCount").default(0).notNull(),
  tipsGivenCount: int("tipsGivenCount").default(0).notNull(),
  lastTipAt: timestamp("lastTipAt"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TipLeaderboard = typeof tipLeaderboard.$inferSelect;
export type InsertTipLeaderboard = typeof tipLeaderboard.$inferInsert;

// ==================== AUDIT LOGS ====================
export const auditLogs = mysqlTable("auditLogs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  action: varchar("action", { length: 128 }).notNull(),
  entity: varchar("entity", { length: 64 }),
  entityId: int("entityId"),
  details: text("details"),
  ipAddress: varchar("ipAddress", { length: 45 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;

// ==================== SITE SETTINGS ====================
export const siteSettings = mysqlTable("siteSettings", {
  id: int("id").autoincrement().primaryKey(),
  settingKey: varchar("settingKey", { length: 128 }).notNull().unique(),
  settingValue: text("settingValue").notNull(),
  description: text("description"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SiteSetting = typeof siteSettings.$inferSelect;
export type InsertSiteSetting = typeof siteSettings.$inferInsert;

// ==================== PLAYER STATISTICS ====================
export const playerStats = mysqlTable("playerStats", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  totalBets: int("totalBets").default(0),
  totalWins: int("totalWins").default(0),
  totalLosses: int("totalLosses").default(0),
  totalWagered: decimal("totalWagered", { precision: 20, scale: 8 }).default("0").notNull(),
  totalPayout: decimal("totalPayout", { precision: 20, scale: 8 }).default("0").notNull(),
  biggestWin: decimal("biggestWin", { precision: 20, scale: 8 }).default("0"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PlayerStat = typeof playerStats.$inferSelect;
export type InsertPlayerStat = typeof playerStats.$inferInsert;

// ==================== LIVE WAGERS FEED ====================
export const liveWagers = mysqlTable("liveWagers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  userName: varchar("userName", { length: 128 }),
  gameType: varchar("gameType", { length: 32 }).notNull(),
  betAmount: decimal("betAmount", { precision: 20, scale: 8 }).notNull(),
  multiplier: decimal("multiplier", { precision: 10, scale: 4 }),
  payout: decimal("payout", { precision: 20, scale: 8 }),
  isWin: boolean("isWin").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type LiveWager = typeof liveWagers.$inferSelect;
export type InsertLiveWager = typeof liveWagers.$inferInsert;
