CREATE TABLE `auditLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`action` varchar(128) NOT NULL,
	`entity` varchar(64),
	`entityId` int,
	`details` text,
	`ipAddress` varchar(45),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `auditLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `bonusCodes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(64) NOT NULL,
	`description` text,
	`type` enum('deposit_match','free_credits','free_spins','cashback') NOT NULL,
	`value` decimal(20,8) NOT NULL,
	`maxUses` int DEFAULT 0,
	`currentUses` int NOT NULL DEFAULT 0,
	`minDeposit` decimal(20,8) DEFAULT '0',
	`maxPayout` decimal(20,8),
	`expiresAt` timestamp,
	`isActive` boolean NOT NULL DEFAULT true,
	`vipTierRequired` enum('bronze','silver','gold','platinum','diamond'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `bonusCodes_id` PRIMARY KEY(`id`),
	CONSTRAINT `bonusCodes_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `bonusRedemptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`bonusCodeId` int NOT NULL,
	`code` varchar(64) NOT NULL,
	`amountCredited` decimal(20,8) NOT NULL,
	`redeemedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `bonusRedemptions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `chatMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`userName` varchar(128),
	`message` text NOT NULL,
	`type` enum('chat','system','support') NOT NULL DEFAULT 'chat',
	`isDeleted` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chatMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `depositRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`amount` decimal(20,8) NOT NULL,
	`txHash` varchar(128),
	`status` enum('pending','processing','completed','failed','cancelled') NOT NULL DEFAULT 'pending',
	`processedAt` timestamp,
	`failureReason` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `depositRequests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `gameSessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`gameType` varchar(32) NOT NULL,
	`betAmount` decimal(20,8) NOT NULL,
	`multiplier` decimal(10,4) DEFAULT '0.0000',
	`payout` decimal(20,8) NOT NULL DEFAULT '0.00',
	`result` json,
	`status` enum('active','completed','cancelled') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `gameSessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `liveWagers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`userName` varchar(128),
	`gameType` varchar(32) NOT NULL,
	`betAmount` decimal(20,8) NOT NULL,
	`multiplier` decimal(10,4),
	`payout` decimal(20,8),
	`isWin` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `liveWagers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `playerStats` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`totalBets` int DEFAULT 0,
	`totalWins` int DEFAULT 0,
	`totalLosses` int DEFAULT 0,
	`totalWagered` decimal(20,8) NOT NULL DEFAULT '0',
	`totalPayout` decimal(20,8) NOT NULL DEFAULT '0',
	`biggestWin` decimal(20,8) DEFAULT '0',
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `playerStats_id` PRIMARY KEY(`id`),
	CONSTRAINT `playerStats_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `referralEarnings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`referralId` int NOT NULL,
	`referrerId` int NOT NULL,
	`referredUserId` int NOT NULL,
	`wagerAmount` decimal(20,8) NOT NULL,
	`commissionAmount` decimal(20,8) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `referralEarnings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `referrals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`referrerId` int NOT NULL,
	`referralCode` varchar(32) NOT NULL,
	`commissionRate` decimal(5,4) NOT NULL DEFAULT '0.0500',
	`totalEarnings` decimal(20,8) NOT NULL DEFAULT '0',
	`totalReferred` int NOT NULL DEFAULT 0,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `referrals_id` PRIMARY KEY(`id`),
	CONSTRAINT `referrals_referralCode_unique` UNIQUE(`referralCode`)
);
--> statement-breakpoint
CREATE TABLE `rtpConfigs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`gameType` varchar(32) NOT NULL,
	`targetRtp` decimal(6,4) NOT NULL DEFAULT '0.9600',
	`minRtp` decimal(6,4) NOT NULL DEFAULT '0.9000',
	`maxRtp` decimal(6,4) NOT NULL DEFAULT '1.0000',
	`houseEdge` decimal(6,4) NOT NULL DEFAULT '0.0400',
	`isActive` boolean NOT NULL DEFAULT true,
	`adjustmentNotes` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `rtpConfigs_id` PRIMARY KEY(`id`),
	CONSTRAINT `rtpConfigs_gameType_unique` UNIQUE(`gameType`)
);
--> statement-breakpoint
CREATE TABLE `siteSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`settingKey` varchar(128) NOT NULL,
	`settingValue` text NOT NULL,
	`description` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `siteSettings_id` PRIMARY KEY(`id`),
	CONSTRAINT `siteSettings_settingKey_unique` UNIQUE(`settingKey`)
);
--> statement-breakpoint
CREATE TABLE `sportsBets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`eventId` varchar(128) NOT NULL,
	`sport` varchar(64) NOT NULL,
	`eventName` text,
	`selection` text NOT NULL,
	`odds` decimal(10,2) NOT NULL,
	`betAmount` decimal(20,8) NOT NULL,
	`potentialPayout` decimal(20,8) NOT NULL,
	`status` enum('pending','won','lost','cancelled','void') NOT NULL DEFAULT 'pending',
	`settledAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sportsBets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `supportMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ticketId` int NOT NULL,
	`userId` int NOT NULL,
	`isAdmin` boolean NOT NULL DEFAULT false,
	`message` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `supportMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `supportTickets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`userName` varchar(128),
	`subject` varchar(256) NOT NULL,
	`status` enum('open','in_progress','resolved','closed') NOT NULL DEFAULT 'open',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`resolvedAt` timestamp,
	CONSTRAINT `supportTickets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('deposit','withdrawal','bet','win','refund','bonus','vip_reward','affiliate_payout','tip','rain') NOT NULL,
	`method` enum('btc','eth','stripe','game') NOT NULL DEFAULT 'game',
	`amount` decimal(20,8) NOT NULL,
	`status` enum('pending','completed','failed','cancelled') NOT NULL DEFAULT 'pending',
	`txHash` varchar(128),
	`stripePaymentId` varchar(128),
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `vipTiers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` enum('bronze','silver','gold','platinum','diamond') NOT NULL,
	`minWagered` decimal(20,8) NOT NULL DEFAULT '0',
	`cashbackPercent` decimal(5,2) NOT NULL DEFAULT '0',
	`depositBonus` decimal(5,2) NOT NULL DEFAULT '0',
	`weeklyBonus` decimal(20,8) NOT NULL DEFAULT '0',
	`levelUpBonus` decimal(20,8) NOT NULL DEFAULT '0',
	`maxBetMultiplier` decimal(5,2) NOT NULL DEFAULT '1',
	`exclusiveGames` boolean NOT NULL DEFAULT false,
	`prioritySupport` boolean NOT NULL DEFAULT false,
	`description` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `vipTiers_id` PRIMARY KEY(`id`),
	CONSTRAINT `vipTiers_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `withdrawalRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`amount` decimal(20,8) NOT NULL,
	`toAddress` varchar(128) NOT NULL,
	`txHash` varchar(128),
	`status` enum('pending','processing','completed','failed','cancelled') NOT NULL DEFAULT 'pending',
	`processedAt` timestamp,
	`failureReason` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `withdrawalRequests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `vipTier` enum('bronze','silver','gold','platinum','diamond') DEFAULT 'bronze' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `vipPoints` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `balance` decimal(20,8) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `vaultBalance` decimal(20,8) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `totalWagered` decimal(20,8) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `totalWon` decimal(20,8) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `gamesPlayed` int DEFAULT 0 NOT NULL;