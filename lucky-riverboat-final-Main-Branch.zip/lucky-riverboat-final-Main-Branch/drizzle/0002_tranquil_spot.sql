CREATE TABLE `tipLeaderboard` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`totalTipsReceived` decimal(20,8) NOT NULL DEFAULT '0',
	`totalTipsGiven` decimal(20,8) NOT NULL DEFAULT '0',
	`tipsReceivedCount` int NOT NULL DEFAULT 0,
	`tipsGivenCount` int NOT NULL DEFAULT 0,
	`lastTipAt` timestamp,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tipLeaderboard_id` PRIMARY KEY(`id`),
	CONSTRAINT `tipLeaderboard_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `tipPayouts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tipId` int NOT NULL,
	`userId` int NOT NULL,
	`amount` decimal(20,8) NOT NULL,
	`payoutStatus` enum('pending','scheduled','completed','failed') NOT NULL DEFAULT 'pending',
	`payoutMethod` enum('wallet','btc','eth','stripe') NOT NULL DEFAULT 'wallet',
	`txHash` varchar(128),
	`scheduledAt` timestamp,
	`completedAt` timestamp,
	`failureReason` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `tipPayouts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tips` (
	`id` int AUTO_INCREMENT NOT NULL,
	`fromUserId` int NOT NULL,
	`toUserId` int NOT NULL,
	`amount` decimal(20,8) NOT NULL,
	`message` text,
	`tipType` enum('player','streamer','rain') NOT NULL DEFAULT 'player',
	`vipMultiplier` decimal(5,2) NOT NULL DEFAULT '1.00',
	`actualAmount` decimal(20,8) NOT NULL,
	`status` enum('pending','completed','failed','cancelled') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `tips_id` PRIMARY KEY(`id`)
);
